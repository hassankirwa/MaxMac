<?php
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://wptravelengine.com/
 * @since             1.0.1
 * @package           WP_Travel_Engine
 *
 * @wordpress-plugin
 * Plugin Name:       WP Travel Engine - PayPal Express Gateway
 * Plugin URI:        https://wptravelengine.com/
 * Description:       An extension of WP Travel Engine plugin to accept credit cards directly on your website through your paypal account.
 * Version:           2.2.0
 * Author:            WP Travel Engine
 * Author URI:        https://wptravelengine.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wte-paypalexpress
 * Domain Path:       /languages
 * WTE requires at least: 4.3.0
 * WTE tested up to: 5.6.0
 * WTE: 7093:wte_paypal_express_license_key
 * Requires PHP: 7.2
 * Tested up to: 6.1
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WTE_Paypal_Express_Checkout' ) ) :
	/**
	 * Class WTE_Paypal_Express_Checkout.
	 *
	 * @package WTE Trips Embedder.
	 */
	class WTE_Paypal_Express_Checkout {

		/**
		 * Plugin Name.
		 *
		 * @var string
		 */
		public $plugin_name = 'wte-paypalexpress';

		/**
		 * Version.
		 *
		 * @var string
		 */
		public $version = '2.2.0';

		/**
		 * The single instance of the class.
		 *
		 * @var string $_instance
		 */
		protected static $instance = null;

		/**
		 * Main WTE_Paypal_Express_Checkout Instance.
		 * Ensures only one instance of WTE_Paypal_Express_Checkout is loaded or can be loaded.
		 *
		 * @return WTE_Paypal_Express_Checkout - Main instance.
		 */
		public static function instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}
			return self::$instance;
		}

		/**
		 * Class Constructor.
		 */
		public function __construct() {
			$this->define_constants();
			add_action( 'admin_notices', array( $this, 'check_dependency' ) );
			if ( class_exists( 'WP_Travel_Engine' ) ) {
				$this->init_hooks();
			}
		}

		/**
		 * Plugin constants.
		 */
		private function define_constants() {

			$paypal_url = defined( 'WP_TRAVEL_ENGINE_PAYMENT_DEBUG' ) && WP_TRAVEL_ENGINE_PAYMENT_DEBUG ? 'https://api.sandbox.paypal.com/v1/' : 'https://api.paypal.com/v1/';
			$this->define( 'PayPal_BASE_URL', $paypal_url );
			$this->define( 'WP_TRAVEL_ENGINE_PAYPAL_EXPRESS_VERSION', $this->version );
			$this->define( 'WP_TRAVEL_ENGINE_PAYPAL_EXPRESS_FILE_PATH', __FILE__ );
			$this->define( 'WP_TRAVEL_ENGINE_PAYPAL_EXPRESS_BASE_PATH', dirname( __FILE__ ) );

		}

		/**
		 * Define constants.
		 *
		 * @param string $name Constant name.
		 * @param string $value Constant value.
		 */
		public function define( $name, $value ) {
			if ( ! defined( $name ) ) {
				define( $name, $value );
			}
		}

		/**
		 * Include  required function/ class files.
		 */
		private function includes() {

			require WP_TRAVEL_ENGINE_PAYPAL_EXPRESS_BASE_PATH . '/includes/class-wp-travel-engine-paypal-express-gateway.php';

			require WP_TRAVEL_ENGINE_PAYPAL_EXPRESS_BASE_PATH . '/includes/class-wte-paypal-express-request.php';

			/**
			 * The class responsible for updating the add-on from EDD.
			 */
			if ( is_admin() ) {

				require WP_TRAVEL_ENGINE_PAYPAL_EXPRESS_BASE_PATH . '/updater/wte-paypalexpress-updater.php';
			}
		}

		/**
		 * Hooks to init in start.
		 */
		public function init_hooks() {

			$this->includes();

		}

		/**
		 * This will uninstall this plugin if parent WP Travel plugin not found.
		 */
		public function check_dependency() {

			if ( ! class_exists( 'Wp_Travel_Engine' ) || ! $this->meets_requirements() ) {
				echo '<div class="error">';
				echo wp_kses_post( '<p><strong>WP Travel Engine Paypal Express Checkout</strong> requires the <a href="https://wptravelengine.com" target="__blank">WP Travel Engine</a> to work. Please install and activate the latest WP Travel Engine plugin first. <b>WP Travel Engine Paypal Express Checkout will now be deactivated now.</b></p>' );
				echo '</div>';

				// Deactivate Plugins.
				deactivate_plugins( plugin_basename( __FILE__ ) );
			}
		}

		/**
		 * Check if all plugin requirements are met.
		 *
		 * @since 1.0.0
		 *
		 * @return bool True if requirements are met, otherwise false.
		 */
		private function meets_requirements() {
			return ( class_exists( 'WP_Travel_Engine' ) && defined( 'WP_TRAVEL_ENGINE_VERSION' ) && version_compare( WP_TRAVEL_ENGINE_VERSION, '4.3.0', '>=' ) );
		}

	}

	/**
	 * Initiate WP Travel Engine trips Embedder addon.
	 */
	function wte_paypal_express_checkout_init() {
		return WTE_Paypal_Express_Checkout::instance();
	}

	add_action( 'plugins_loaded', 'wte_paypal_express_checkout_init' );
endif;
