<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://wptravelengine.com/
 * @since      1.0.0
 *
 * @package    Wte_Trip_Weather_Forecast
 * @subpackage Wte_Trip_Weather_Forecast/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Wte_Trip_Weather_Forecast
 * @subpackage Wte_Trip_Weather_Forecast/includes
 * @author     WP Travel Engine <test@test.com>
 */
class Wte_Trip_Weather_Forecast_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
