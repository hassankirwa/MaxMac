<?php

/**
 * Fired during plugin activation
 *
 * @link       https://wptravelengine.com/
 * @since      1.0.0
 *
 * @package    Wte_Trip_Weather_Forecast
 * @subpackage Wte_Trip_Weather_Forecast/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wte_Trip_Weather_Forecast
 * @subpackage Wte_Trip_Weather_Forecast/includes
 * @author     WP Travel Engine <test@test.com>
 */
class Wte_Trip_Weather_Forecast_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
