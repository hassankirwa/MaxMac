<?php
// Register and load the widget
function wte_weather_forecast_load_widget()
{
    register_widget('Wte_Weather_Forecast_Widget');
}

add_action('widgets_init', 'wte_weather_forecast_load_widget');

/**
 * Class Wte_Weather_Forecast_Widget
 */
class Wte_Weather_Forecast_Widget extends WP_Widget
{

    function __construct()
    {
        parent::__construct(

            // Base ID of your widget
            'wte_weather_forecast_widget',

            // Widget name will appear in UI
            __( 'Trip Weather Forecast', 'wte-trip-weather-forecast' ),

            // Widget description
            array( 'description' => __( 'Weather Forecast Widget for Trips.', 'wte-trip-weather-forecast' ), )
        );
    }

    /*-------------------------------------------------------
    *				Front-end display of widget
    *-------------------------------------------------------*/

    function widget( $args, $instance )
    {
        $title             = apply_filters( 'widget_title', $instance[ 'title' ] );
        $language          = 'en';
        $unit              = isset( $instance[ 'unit' ] ) ? $instance[ 'unit' ] : 'c';
        $header            = isset( $instance[ 'header' ] ) ? $instance[ 'header' ] : FALSE;
        $sunrise_sunset    = isset( $instance[ 'sunrise_sunset' ] ) ? $instance[ 'sunrise_sunset' ] : 1;
        $current           = isset( $instance[ 'current' ] ) ? $instance[ 'current' ] : 1;
        $hourly            = isset( $instance[ 'hourly' ] ) ? $instance[ 'hourly' ] : 0;
        $daily             = isset( $instance[ 'daily' ] ) ? $instance[ 'daily' ] : 3;
        
        if ( ! is_singular( 'trip' ) ) {
            return;
        } 
        wp_reset_postdata();
        $wte_weather_settings = get_post_meta( get_the_ID(), 'wte_weather_settings', true );
        if ( isset( $wte_weather_settings[ 'hide' ] ) && $wte_weather_settings[ 'hide' ] == '1' ) {
            return;
        }

        if ( ! empty( $wte_weather_settings[ 'city_name' ] ) && ! empty( $wte_weather_settings[ 'city_selector' ] ) ) {
            $city_name = $wte_weather_settings[ 'city_name' ];
        } else {
            return;
        }

        if ( 'c' == $unit ) {
            $def_units_temperature   = '°C';
            $unit_kph_mph            = 'kph';
            $def_units_windspeed     = 'km/h';
            $unit_mm_in              = 'mm';
            $def_units_precipitation = 'mm';
            $unit_mb_in              = 'mb';
            $def_units_pressure      = 'mbar';
            $unit_km_mi              = 'km';
            $def_units_distance      = 'km';
        } else {
            $def_units_temperature   = '°F';
            $unit_kph_mph            = 'mph';
            $def_units_windspeed     = 'mph';
            $unit_mm_in              = 'in';
            $def_units_precipitation = '"';
            $unit_mb_in              = 'in';
            $def_units_pressure      = '"Hg';
            $unit_km_mi              = 'mi';
            $def_units_distance      = 'mi';
        }
        $def_units_degree  = '°';
        $def_units_percent = '%';

        echo $args['before_widget'];

        $return = '';
        $weather_data = $this->weather_data( $city_name, $daily );
        // json2array
        $weather_data_array = json_decode( $weather_data, TRUE );

        if ( $title ) {
            echo $args['before_title'] . $title . $args['after_title'];
        }

        if ( ! empty( $weather_data_array ) && is_array( $weather_data_array ) && ! isset( $weather_data_array['error']['code'] ) ) {
            if ( array_key_exists( "location", $weather_data_array ) ) {
                $city_name                             = isset( $weather_data_array[ 'location' ][ 'name' ] ) ? $weather_data_array[ 'location' ][ 'name' ] : FALSE;
                ${'country_name_' . $language}         = isset( $weather_data_array[ 'location' ][ 'country' ] ) ? $weather_data_array[ 'location' ][ 'country' ] : FALSE;
                ${'country_name_rewrite_' . $language} = isset( $weather_data_array[ 'location' ][ 'country' ] ) ? $weather_data_array[ 'location' ][ 'country' ] : FALSE;
                ${'city_name_' . $language}            = isset( $weather_data_array[ 'location' ][ 'name' ] ) ? $weather_data_array[ 'location' ][ 'name' ] : FALSE;
                ${'city_name_rewrite_' . $language}    = isset( $weather_data_array[ 'location' ][ 'name' ] ) ? $weather_data_array[ 'location' ][ 'name' ] : FALSE;

                $timezone_abbr = isset( $weather_data_array[ 'location' ]['tz_id' ] ) ? $weather_data_array[ 'location' ][ 'tz_id' ] : FALSE;
                $time_of_sunrise = isset( $weather_data_array[ 'forecast' ][ 'forecastday' ][ '0' ][ 'astro' ] ) && isset( $weather_data_array[ 'forecast' ][ 'forecastday' ][ '0' ][ 'astro' ][ 'sunrise' ] ) ? $weather_data_array[ 'forecast' ][ 'forecastday' ][ '0' ][ 'astro' ][ 'sunrise' ] : FALSE;
                $time_of_sunset = isset( $weather_data_array[ 'forecast' ][ 'forecastday' ][ '0' ][ 'astro' ] ) && isset( $weather_data_array[ 'forecast' ][ 'forecastday' ][ '0' ][ 'astro' ][ 'sunset' ] ) ? $weather_data_array[ 'forecast' ][ 'forecastday' ][ '0' ][ 'astro' ][ 'sunset' ] : FALSE;
            }

            if ( array_key_exists( "current", $weather_data_array ) ) {
                ${'current_temp_' . $unit}           = ( 'c' == $unit ) ? $weather_data_array[ 'current' ][ 'temp_c' ] : $weather_data_array[ 'current' ][ 'temp_f' ];
                ${'current_temp_feelslike_' . $unit} = ( 'c' == $unit ) ? $weather_data_array[ 'current' ][ 'feelslike_c' ] : $weather_data_array[ 'current' ][ 'feelslike_f' ];
                $current_icon                            = isset( $weather_data_array[ 'current' ][ 'condition' ] ) && isset( $weather_data_array[ 'current' ][ 'condition' ][ 'icon' ] ) ? $weather_data_array[ 'current' ][ 'condition' ][ 'icon' ] : FALSE;
                ${'current_text_' . $language}           = isset( $weather_data_array[ 'current' ][ 'condition' ][ 'text' ] ) ? $weather_data_array[ 'current' ][ 'condition' ][ 'text' ] : FALSE;
                ${'current_wind_' . $unit_kph_mph}       = ( 'c' == $unit ) ? $weather_data_array[ 'current' ][ 'wind_kph' ] : $weather_data_array[ 'current' ][ 'wind_mph' ];
                $current_wind_dir                        = isset( $weather_data_array[ 'current' ][ 'wind_dir' ] ) ? $weather_data_array[ 'current' ][ 'wind_dir' ] : FALSE;
                $current_wind_deg                        = isset( $weather_data_array[ 'current' ][ 'wind_degree' ] ) ? $weather_data_array[ 'current' ][ 'wind_degree' ] : FALSE;
                $current_humidity_relative               = isset( $weather_data_array[ 'current' ][ 'humidity' ] ) ? $weather_data_array[ 'current' ][ 'humidity' ] : FALSE;
                ${'current_pressure_' . $unit_mb_in} = ( 'c' == $unit ) ? $weather_data_array[ 'current' ][ 'pressure_mb' ] : $weather_data_array[ 'current' ][ 'pressure_in' ];
                $current_uv_index = isset( $weather_data_array[ 'current' ][ 'uv' ] ) ? $weather_data_array[ 'current' ][ 'uv' ] : FALSE;


                ${'def_feelslike_' . $language}         = ( 'c' == $unit ) ? $weather_data_array[ 'current' ][ 'feelslike_c' ] : $weather_data_array[ 'current' ][ 'feelslike_f' ];
                ${'def_wind_' . $language}              = isset( $weather_data_array[ 'current' ][ 'wind_degree' ] ) ? $weather_data_array[ 'current' ][ 'wind_degree' ] : FALSE;
                ${'def_humidity_relative_' . $language} = isset( $weather_data_array[ 'current' ][ 'humidity' ] ) ? $weather_data_array[ 'current' ][ 'humidity' ] : FALSE;
                ${'def_pressure_' . $language}          = ( 'c' == $unit ) ? $weather_data_array[ 'current' ][ 'pressure_mb' ] : $weather_data_array[ 'current' ][ 'pressure_in' ];
                ${'def_uv_index_' . $language}          = isset( $weather_data_array[ 'current' ][ 'uv' ] ) ? $weather_data_array[ 'current' ][ 'uv' ] : FALSE;
            }

            $return .= "<div class='wte-weather-forecast-wrapper'>";
            $return .= "<div class='wte-weather-forecast-header'>";

            if ( ! empty( $current_icon ) ) {
                $return .= "<div class='wte_current_icon'><img src=". $current_icon ." alt=". esc_attr( 'Weather Icon' ) ."></div>";
            }
            $return .= "<div class='wte_current_temp'>";

            if ( ! empty( ${'city_name_' . $language} ) ) {
                $header_title = $header ? $header : ${'city_name_' . $language};
            } else {
                $header_title = $header;
            }
            $return .= "<span class='wte_header_title'>" . $header_title . "</span>";

            if ( ( isset( ${'current_temp_' . $unit} ) ) and ( is_numeric( ${'current_temp_' . $unit} ) ) ) {
                $return .= "<span class='wte_temp'>" . ${'current_temp_' . $unit} . "<small>" . $def_units_temperature . "</small></span>";
            }
            if ( !empty( ${'current_text_' . $language} ) ) {
                $return .= "<span class='wte_current_text'>" . ${'current_text_' . $language} . "</span>";
            }
            $return .= "</div>";
            $return .= "</div>";

            if ( ( ! empty( $sunrise_sunset ) ) and ( ! empty( $time_of_sunrise ) ) and ( ! empty( $time_of_sunset ) ) and ( ! empty( $timezone_abbr ) ) ) {
                $return .= "<div class='wte_sunrise_sunset'>";
                $return .= "<div class='wte_sunrise'>";
                $return .= "<span class='wte_sunrise_title'>" . __( 'SUNRISE', 'wte-trip-weather-forecast' ) . "</span>";
                $return .= "<i class='wi wi-sunrise'></i>";
                $return .= "<span class='wte_sunrise_time'>" . $time_of_sunrise . "</span></div>";

                $return .= "<div class='wte_sunset'>";
                $return .= "<span class='wte_sunset_title'>" . __( 'SUNSET', 'wte-trip-weather-forecast' ) . "</span>";
                $return .= "<i class='wi wi-sunset'></i>";
                $return .= "<span class='wte_sunset_time'>" . $time_of_sunset . " " . $timezone_abbr . "</span></div>";
                $return .= "</div>";
            }

            if ( ( ! empty( $current ) ) and ( array_key_exists( "current", $weather_data_array ) ) ) {
                $return .= "<div class='wte_current_conditions'>";
                if ( ( ! empty( ${'def_feelslike_' . $language} ) ) and ( is_numeric( ${'current_temp_feelslike_' . $unit} ) ) ) {
                    $return .= "<span class='wte_feels_like'>" . __( 'Feels Like', 'wte-trip-weather-forecast' ) . ": ";
                    $return .= ${'current_temp_feelslike_' . $unit} . "<small>" . $def_units_temperature . "</small></span>";
                }
                if ( ( ! empty( ${'def_wind_' . $language} ) ) and  (is_numeric( ${'current_wind_' . $unit_kph_mph} ) ) ) {
                    $return .= "<span class='wte_wind'>" . __( 'Wind', 'wte-trip-weather-forecast' ) . ": ";
                    $return .= ${'current_wind_' . $unit_kph_mph} . "<small>" . $def_units_windspeed . "</small>";

                    if ( $language == 'en' ) {
                        $return .= " " . $current_wind_dir;
                    } else {
                        $return .= " " . $current_wind_deg . "<small>" . $def_units_degree . "</small>";
                    }
                    $return .= "</span>";
                }
                if ( ( ! empty( ${'def_humidity_relative_' . $language} ) ) and ( is_numeric( $current_humidity_relative ) ) ) {
                    $return .= "<span class='wte_humidity'>" . __( 'Humidity', 'wte-trip-weather-forecast' ) . ": ";
                    $return .= $current_humidity_relative . "<small>" . $def_units_percent . "</small></span>";
                }
                if ( ( ! empty( ${'def_pressure_' . $language} ) ) and ( is_numeric( ${'current_pressure_' . $unit_mb_in} ) ) ) {
                    $return .= "<span class='wte_pressure'>" . __( 'Pressure', 'wte-trip-weather-forecast' ) . ": ";
                    $return .= ${'current_pressure_' . $unit_mb_in} . "<small>" . $def_units_pressure . "</small></span>";
                }
                if ( ( ! empty(${'def_uv_index_' . $language} ) ) and ( is_numeric( $current_uv_index ) ) ) {
                    $return .= "<span class='wte_uv_index'>" . __( 'UV Index', 'wte-trip-weather-forecast' ) . ": ";
                    $return .= $current_uv_index . "</span>";
                }
                $return .= "</div>";
            }
			

            $timezone_abbr = isset( $weather_data_array[ 'location' ][ 'tz_id' ] ) ? $weather_data_array[ 'location' ][ 'tz_id' ] : FALSE;
            date_default_timezone_set( $timezone_abbr );

            $daily_forecast = isset( $weather_data_array[ 'forecast' ] ) && isset( $weather_data_array[ 'forecast' ][ 'forecastday' ] ) ? $weather_data_array[ 'forecast' ][ 'forecastday' ] : '';     
            // Calculate 1 hour after the current time
            $nextHour = date( 'H', strtotime( '+1 hour' ) );
            
            if ( ( !empty( $hourly ) ) and ( array_key_exists( "forecast", $weather_data_array ) ) ) {

                $return .= "<div class='wte_hourly_forecast'>";
                $return .= "<span class='wte_hourly_forecast_title'>" . __( 'Hourly Forecast', 'wte-trip-weather-forecast' ) . "</span>";
            
                $hourlyData = [];
            
                foreach ( $daily_forecast as $today ) {
                    if ( $today['date'] === date( 'Y-m-d' ) ) {
                        $hourlyData = $today[ 'hour' ];
                        break;
                    }
                }
            
                $hourCounter = 0;
            
                foreach ( $hourlyData as $data ) {
                    $hour = isset( $data[ 'time' ] ) ? date( 'H', strtotime( $data[ 'time' ] ) ) : FALSE;
            
                    // Check if the hour is within the next 5 hours, starting from 1 hour after the current time
                    if ( $hour && $hour >= $nextHour && $hourCounter < $hourly ) {
            
                        $hourCounter++;
            
                        ${'hour_temp_' . $unit} = ( $unit == 'c' ) ? $data[ 'temp_c' ] : $data[ 'temp_f' ];
             
                        $hour_icon = isset( $data[ 'condition' ] ) ? $data[ 'condition' ][ 'icon' ] : FALSE;
            
                        ${'hour_text_' . $language} = isset( $data[ 'condition' ] ) ? $data[ 'condition' ][ 'text' ] : FALSE;
            
                        $return .= "<span class='wte_forecast_hour_$hour'";
            
                        if ( ! empty( ${'hour_text_' . $language} ) ) {
                            $return .= " title='" . ${'hour_text_' . $language} . "'";
                        }
                        $return .= ">";    
                        
                        if ( is_numeric( ${'hour'} ) ) {
                            $return .= "<span class='wte_hour_text'>" . $hour . __(':00 H','wte-trip-weather-forecast') . "</span>";
                        }
                        
                        if ( ! empty( $hour_icon ) ) {
                            $return .= "<img src=" . $hour_icon . " alt=" . esc_attr( 'Weather Icon' ) . ">";
                        }
                        if ( is_numeric( ${'hour_temp_' . $unit} ) ) {
                            $return .= "<span class='wte_temp'>" . ${'hour_temp_' . $unit} . "<small>" . $def_units_temperature . "</small></span>";
                        }
            
                        $return .= "</span>";
                    }
                }
            
                $return .= "</div>";
            }

            if ( ( ! empty( $daily ) ) and ( array_key_exists( "forecast", $weather_data_array ) ) ) {
                $return .= "<div class='wte_daily_forecast'>";
                $return .= "<span class='wte_daily_forecast_title'>" . __( 'Daily Forecast', 'wte-trip-weather-forecast' ) . "</span>";

                foreach ( $daily_forecast as $day ) {

                    ${'day_name_' . $language . '_short'} = isset( $day[ 'date' ] ) ? date( 'D', strtotime( $day[ 'date' ] ) ) : FALSE;

                    ${'day_temp_high_' . $unit} = isset( $day[ 'day' ] ) && ( $unit == 'c' ) ? $day[ 'day' ][ 'maxtemp_c' ] : $day[ 'day' ][ 'maxtemp_f' ];

                    ${'day_temp_low_' . $unit}  = isset( $day[ 'day' ] ) && ( $unit == 'c' ) ? $day[ 'day' ][ 'mintemp_c' ] : $day[ 'day' ][ 'mintemp_f' ];

                    $day_icon                       = isset( $day[ 'day' ] ) && isset( $day['day'][ 'condition' ] ) ? $day[ 'day' ][ 'condition' ][ 'icon' ] : FALSE;

                    ${'day_text_' . $language}      = isset( $day[ 'day' ] ) && isset( $day['day'][ 'condition' ] ) ? $day['day'][ 'condition' ][ 'text' ] : FALSE;

                    $return .= "<div class='wte_forcast_day wte_forcast_day'";

                    if ( ! empty( ${'day_text_' . $language} ) ) {
                        $return .= " title='" . ${'day_text_' . $language} . "'";
                    }
                    $return .= ">";
                    if ( ! empty( $day_icon ) ) {
                        $return .= "<img src=". $day_icon ." alt=". esc_attr( 'Weather Icon' ) .">";
                    }
                    if ( ! empty( ${'day_name_' . $language . '_short'} ) ) {
                        $return .= "<div class='wte-day-wrap'><span class='wte_day_text'>" . ${'day_name_' . $language . '_short'} . "</span>";
                    }
                    if ( is_numeric( ${'day_temp_high_' . $unit} ) ) {
                        if ( ${'day_temp_high_' . $unit} != '-99' ) {
                            $return .= "<span class='wte_temp'>" . ${'day_temp_high_' . $unit} . "/";
                        } else {
                            $return .= "<span class='wte_temp'>" . __( 'min ', 'wte-trip-weather-forecast' );
                        }
                    }
                    if ( is_numeric( ${'day_temp_low_' . $unit} ) ) {
                        $return .= ${'day_temp_low_' . $unit} . "<small>" . $def_units_temperature . "</small></span>";
                        $return .= "<span>" . ${'day_text_' . $language} . "</span></div>";

                    }
                    $return .= "</div>";
                }
                $return .= "</div>";
            }
            $return .= "<span>" . __( 'Powered by <a href="https://www.weatherapi.com/" title="Weather API">WeatherAPI.com</a>', 'wte-trip-weather-forecast' ). "</span>";

            $return .= "</div>";
        } else {
            $return .= "<span>" . __( 'API key is invalid or not provided.', 'wte-trip-weather-forecast' ) . "</span>";
        }

        echo $return;
        echo $args['after_widget'];
    }

    function get_key()
    {
        $str = 'abcdefghijklmnopqrstuvwxyz0123456789';
        $key = '';
        for ($i = 0; $i < 15; $i++) {
            $random = rand(0, 35);
            $key .= $str[$random];
        }
        return $key;
    }

    function weather_data( $city_name, $daily )
    {

        $transient_data = get_transient( 'weather_forecast_cached_data_' . $city_name );

        if ( false === $transient_data ) {
            $transient_data = '';
            if ( isset( $city_name ) ) {
                $wte_settings = get_option( 'wp_travel_engine_settings' );
                $key = isset( $wte_settings[ 'weather_forecast' ][ 'api_key' ] ) ? esc_attr( $wte_settings[ 'weather_forecast' ][ 'api_key' ] ) : '';
    
                // API URL for current weather
                $api_url = 'http://api.weatherapi.com/v1/forecast.json';
                $api_params = array(
                    'q'     => $city_name,
                    'key'   => $key,
                    'days'  => $daily,
                );
    
                $wp_remote_get_response = wp_remote_get( add_query_arg( $api_params, $api_url ) );
                $transient_data = wp_remote_retrieve_body( $wp_remote_get_response );
    
                if ( ! empty( $transient_data ) ) {
                    set_transient( 'weather_forecast_cached_data_' . $city_name, $transient_data, 60 );
                    return $transient_data;
                }
            }
        } else {
            return $transient_data;
        }

    }

    function update($new_instance, $old_instance)
    {
        $instance                               = $old_instance;
        $instance['title']                    = strip_tags($new_instance['title']);
        $instance['unit']                     = strip_tags($new_instance['unit']);
        $instance['header']                   = strip_tags($new_instance['header']);
        $instance['sunrise_sunset']           = strip_tags($new_instance['sunrise_sunset']);
        $instance['current']                  = strip_tags($new_instance['current']);
        $instance['hourly']                   = strip_tags($new_instance['hourly']);
        $instance['daily']                    = strip_tags($new_instance['daily']);

        return $instance;
    }

    function form($instance)
    {

        $title             = isset($instance['title']) ? $instance['title'] : FALSE;
        $unit              = isset($instance['unit']) ? $instance['unit'] : 'c';
        $header            = isset($instance['header']) ? $instance['header'] : FALSE;
        $sunrise_sunset    = isset($instance['sunrise_sunset']) ? $instance['sunrise_sunset'] : 1;
        $current           = isset($instance['current']) ? $instance['current'] : 1;
        $hourly            = isset($instance['hourly']) ? $instance['hourly'] : 0;
        $daily             = isset($instance['daily']) ? $instance['daily'] : 3;

        // print_r($instance);
        ?>
        <h3><?php _e('Display', 'wte-trip-weather-forecast'); ?></h3>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php _e('Title', 'wte-trip-weather-forecast'); ?></label>
            <input id="<?php echo esc_attr($this->get_field_id('title')); ?>" class="widefat" type="text" name="<?php echo esc_attr($this->get_field_name('title')); ?>" value="<?php echo esc_attr($title); ?>" />
            <small><?php _e('If blank - no heading will appear above widget.', 'wte-trip-weather-forecast'); ?></small>
        </p>
        <p>
            <label for="<?php echo esc_attr($this->get_field_id('header')); ?>"><?php _e('Header ', 'wte-trip-weather-forecast');
                                                                                _e('(optional)', 'wte-trip-weather-forecast'); ?></label>
            <input id="<?php echo esc_attr($this->get_field_id('header')); ?>" class="widefat" type="text" name="<?php echo esc_attr($this->get_field_name('header')); ?>" value="<?php echo $header; ?>" />
            <small><?php _e('If blank - City name will appear in widget\'s header.', 'wte-trip-weather-forecast'); ?></small>
        </p>

        <h3><?php _e('Location', 'wte-trip-weather-forecast'); ?></h3>
        <p>
            <span class="wte-weather-option-note" class="example-text"><?php _e('Please set the Location on individual trip post.', 'wte-trip-weather-forecast'); ?></span>
        </p>

        <h3><?php _e('Settings', 'wte-trip-weather-forecast'); ?></h3>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('unit')); ?>"><?php _e('Unit:', 'wte-trip-weather-forecast'); ?> </label>
            <select id="<?php echo esc_attr($this->get_field_id('unit')); ?>" name="<?php echo esc_attr($this->get_field_name('unit')); ?>">
                <option value="f" <?php echo $unit == 'f' ? 'selected' : ''; ?>><?php _e('Fahrenheit', 'wte-trip-weather-forecast'); ?></option>
                <option value="c" <?php echo $unit == 'c' ? 'selected' : ''; ?>><?php _e('Celsius', 'wte-trip-weather-forecast'); ?></option>
            </select>
        </p>

        <p>
            <input id="<?php echo esc_attr($this->get_field_id('sunrise_sunset')); ?>" type="checkbox" name="<?php echo esc_attr($this->get_field_name('sunrise_sunset')); ?>" value='1' <?php if ($sunrise_sunset == 1) echo "checked='checked'"; ?> />
            <label for="<?php echo esc_attr($this->get_field_id('sunrise_sunset')); ?>"><?php _e('Show: sunrise / sunset time', 'wte-trip-weather-forecast'); ?></label>
        </p>

        <p>
            <input id="<?php echo esc_attr($this->get_field_id('current')); ?>" type="checkbox" name="<?php echo esc_attr($this->get_field_name('current')); ?>" value='1' <?php if ($current == 1) echo "checked='checked'"; ?> />
            <label for="<?php echo esc_attr($this->get_field_id('current')); ?>"><?php _e('Show: feels like / wind / humidity / pressure / uv index', 'wte-trip-weather-forecast'); ?></label>
        </p>

        <?php $hourly_options = array(
            '0' => __('hide hourly forecast', 'wte-trip-weather-forecast'),
            '1' => '1 ' . __('hour', 'wte-trip-weather-forecast'),
            '2' => '2 ' . __('hours', 'wte-trip-weather-forecast'),
            '3' => '3 ' . __('hours', 'wte-trip-weather-forecast'),
            '4' => '4 ' . __('hours', 'wte-trip-weather-forecast'),
            '5' => '5 ' . __('hours', 'wte-trip-weather-forecast'),
        );
        ?>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('hourly')); ?>">
                <h4><?php _e('Hourly forecast', 'wte-trip-weather-forecast'); ?></h4>
            </label>
            <select id="<?php echo esc_attr($this->get_field_id('hourly')); ?>" name="<?php echo esc_attr($this->get_field_name('hourly')); ?>">
                <?php foreach ($hourly_options as $key => $value) {
                    echo '<option value="' . $key . '"' . selected($hourly, $key, FALSE) . '>' . esc_html($value) . '</option>';
                }
                ?>
            </select>
        </p>

        <?php $daily_options = array(
            '0' => __('hide daily forecast', 'wte-trip-weather-forecast'),
            '1' => '1 ' . __('day', 'wte-trip-weather-forecast'),
            '2' => '2 ' . __('days', 'wte-trip-weather-forecast'),
            '3' => '3 ' . __('days', 'wte-trip-weather-forecast'),
        );
        ?>

        <p>
            <label for="<?php echo esc_attr($this->get_field_id('daily')); ?>">
                <h4><?php _e('Daily forecast', 'wte-trip-weather-forecast'); ?></h4>
            </label>
            <select id="<?php echo esc_attr($this->get_field_id('daily')); ?>" name="<?php echo esc_attr($this->get_field_name('daily')); ?>">
                <?php foreach ($daily_options as $key => $value) {
                    echo '<option value="' . $key . '"' . selected($daily, $key, FALSE) . '>' . esc_html($value) . '</option>';
                }
                ?>
            </select>
        </p>
<?php
    }
}
