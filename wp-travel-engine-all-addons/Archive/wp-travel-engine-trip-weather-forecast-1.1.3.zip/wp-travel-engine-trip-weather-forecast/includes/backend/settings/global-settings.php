<?php
/**
 * Global Settings For Weather API.
 * 
 * @since 1.1.2
 */

$wte_settings = get_option( 'wp_travel_engine_settings' );
?>
<div class="wpte-info-block" style="margin-bottom: 40px;">
    <p>
        <?php
            echo sprintf( __( 'We have integrated a new weather API offered by the weather API service. Kindly generate a fresh API Key from %sthis source%s, where both free and premium API Keys are available for use.', 'wte-trip-weather-forecast' ),
            '<a href="https://www.weatherapi.com/" target="_blank" rel="nofollow">',
            '</a>'
            );
		?>
    </p>
</div>
<div class="group-status-options" id="wte-weather-forecast">
    <div class="wpte-form-block">
        <div class="wpte-field wpte-text wpte-floated departure-dates-options">
            <label class="wpte-field-label" for="wp_travel_engine_settings[weather_forecast][api_key]">
                <?php _e( 'API Key: ', 'wte-trip-weather-forecast' ); ?>
            </label>
            <input type="text" class="disable_notif"
                name="wp_travel_engine_settings[weather_forecast][api_key]"
                id="wp_travel_engine_settings[weather_forecast][api_key]"
                value="<?php echo esc_attr( $wte_settings['weather_forecast']['api_key'] ); ?>" />
            <span class="wpte-tooltip"><?php printf(
                __( 'Get an Free API Key %sfrom here%s.' , 'wte-trip-weather-forecast' ),
                '<a href="https://www.weatherapi.com/pricing.aspx" target="_blank" rel="nofollow">',
                '</a>'
            ); ?>
            </span>
        </div>
    </div>
</div>