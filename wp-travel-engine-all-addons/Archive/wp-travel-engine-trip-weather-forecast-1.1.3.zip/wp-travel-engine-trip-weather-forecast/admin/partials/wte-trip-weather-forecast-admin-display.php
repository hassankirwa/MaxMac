<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://wptravelengine.com/
 * @since      1.0.0
 *
 * @package    Wte_Trip_Weather_Forecast
 * @subpackage Wte_Trip_Weather_Forecast/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
