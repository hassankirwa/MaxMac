<?php
class Wte_Trip_Weather_Forecast_MetaBox
{

	function __construct()
	{

		add_action( 'add_meta_boxes', array( $this, 'wte_weather_forecast_add_meta_boxes' ) );
		add_action( 'save_post', array( $this, 'wte_weather_forecast_save_meta_box_data' ) );

		/**
		 * Action to get AJAX Request.
		 *
		 * @since 1.1.2
		 */
		add_action( 'wp_ajax_wte_get_autocomplete_data', array( $this, 'wte_get_autocomplete_data') );
		add_action( 'wp_ajax_nopriv_wte_get_autocomplete_data', array( $this, 'wte_get_autocomplete_data') );
	}


	/**
	 * The function responsible for creating the actual meta box.
	 *
	 * @since    1.0.0
	 */
	public function wte_weather_forecast_add_meta_boxes()
	{

		$post_type = array( 'trip' );

		add_meta_box(
			'wte_weather_forecast_meta_id',  // Unique ID
			__( 'Trip Weather Configuration', 'wte-trip-weather-forecast' ),	// Box title
			array( $this, 'display_wte_weather_options_meta_box' ),   // Content callback, must be of type callable
			$post_type, 	// Post type
			'side',
			'high'
		);
	}

	/**
	 * Renders the content of the meta box.
	 *
	 * @since    1.0.0
	 */
	public function display_wte_weather_options_meta_box()
	{
		$wte_weather_settings = get_post_meta( get_the_ID(), 'wte_weather_settings', true );
		
		wp_nonce_field( 'wte_weather_forecast_nonce', 'wte_weather_forecast_nonce_field' );
		?>
			<div class="wte-weather-settings">
				<label for="wte_weather_settings[hide]" class="weather-checkbox-label">
					<h4><?php _e( 'Hide Weather Widget : ', 'wte-trip-weather-forecast' ); ?></h4>

					<input type="checkbox" id="wte_weather_settings[hide]" name="wte_weather_settings[hide]" value="1" <?php if ( isset( $wte_weather_settings['hide']) && $wte_weather_settings['hide'] != '' ) echo 'checked'; ?>>
					<span class="checkbox-label"></span>
				</label>
			</div>

			<div class="wte-weather-settings">
				<h4><?php _e( 'Location', 'wte-trip-weather-forecast' ); ?></h4>
				<p class="location_autocomplete">
					<label for="wte_weather_settings[city_name]">
						<?php _e( 'City:', 'wte-trip-weather-forecast' ); ?></label>
					<input id="wte_weather_settings[city_name]" class="wte_city_name" type="text" name="wte_weather_settings[city_name]" value="<?php echo isset( $wte_weather_settings['city_name'] ) ? esc_attr( $wte_weather_settings['city_name'] ) : ''; ?>" />
				<p><span class="wte-forecast-note">
						<?php _e( 'Note: Please type and select the location from drop-down. Widget doesn\'t support the locations that do not appear in drop-down.', 'wte-trip-weather-forecast' ); ?>
					</span></p>
				</p>

				<input id="wte_weather_settings[city_selector]" class="wte_city_selector" type="hidden" name="wte_weather_settings[city_selector]" value="<?php echo isset( $wte_weather_settings['city_selector'] ) ? esc_attr( $wte_weather_settings['city_selector'] ) : ''; ?>" />
			</div>
		<?php
	}

	/**
	 * Sanitizes and serializes the information associated with this post.
	 *
	 * @since    1.0.0
	 *
	 * @param    int    $post_id    The ID of the post that's currently being edited.
	 */
	public function wte_weather_forecast_save_meta_box_data( $post_id )
	{
		if ( ! current_user_can( 'edit_post', $post_id ) || ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE) )  {
			return;
		}
		
		if ( ! empty( $_POST['wte_weather_settings'] ) ) {
			// We'll remove all white space, HTML tags, and encode the information to be saved
			$weather_details =  array(
				'hide' => sanitize_text_field( wp_unslash( $_POST['wte_weather_settings']['hide'] ) ),
				'city_name' => sanitize_text_field( wp_unslash( $_POST['wte_weather_settings']['city_name'] ) ),
				'city_selector' => sanitize_text_field( wp_unslash( $_POST['wte_weather_settings']['city_selector'] ) ),
			);

			update_post_meta( $post_id, 'wte_weather_settings', $weather_details );
		}
	}

	/**
	 * Fetch Weather API data.
	 * 
	 * @since 1.1.2
	 */
	public function wte_get_autocomplete_data() {

		// Ensure this is a POST request
		if ( 'POST' !== $_SERVER[ 'REQUEST_METHOD' ]  ) {
			wp_send_json_error( 'Invalid request method' );
		}
	
		$wte_settings = get_option( 'wp_travel_engine_settings' );
		$key = isset( $wte_settings[ 'weather_forecast' ][ 'api_key' ] ) ? esc_attr( $wte_settings[ 'weather_forecast' ][ 'api_key' ] ) : '';
		$q = sanitize_text_field( $_POST[ 'q' ] );

		//Make the API request
		$api_url = 'https://api.weatherapi.com/v1/search.json';
		$api_params = array(
			'key' => $key,
			'q' => $q,
		);
	
		$response = wp_remote_get( add_query_arg( $api_params, $api_url ) );

		if ( is_wp_error( $response ) ) {
			wp_send_json( [] );
		}

		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );
 
		if ( null !== $data  ) {
			wp_send_json( $data );
		} else {
			wp_send_json( [] );
		}
		
	}
	
}
new Wte_Trip_Weather_Forecast_MetaBox();
