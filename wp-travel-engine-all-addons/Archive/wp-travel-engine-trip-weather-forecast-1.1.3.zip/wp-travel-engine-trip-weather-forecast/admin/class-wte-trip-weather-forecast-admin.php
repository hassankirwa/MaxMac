<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://wptravelengine.com/
 * @since      1.0.0
 *
 * @package    Wte_Trip_Weather_Forecast
 * @subpackage Wte_Trip_Weather_Forecast/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wte_Trip_Weather_Forecast
 * @subpackage Wte_Trip_Weather_Forecast/admin
 * @author     WP Travel Engine <test@test.com>
 */
class Wte_Trip_Weather_Forecast_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = WTE_WEATHER_FORECAST_VERSION;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wte_Trip_Weather_Forecast_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wte_Trip_Weather_Forecast_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wte-trip-weather-forecast-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wte_Trip_Weather_Forecast_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wte_Trip_Weather_Forecast_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		wp_enqueue_script( 'jquery-ui-autocomplete' );
		wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wte-trip-weather-forecast-admin.js', array( 'jquery' ), $this->version, false );

		// Localize the script with necessary data
		$localization_data = array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'plugin_name' => $this->plugin_name,
		);
	
		wp_localize_script( $this->plugin_name, 'wte_script_data', $localization_data );

	}

	/**
	 * Global settings array register.
	 *
	 * @since 1.1.2
	 * @return array
	 */
	public function wte_weather_forecast_extension( $extension_settings ) {
		$extension_settings['wte_weather_forecast'] = array(
			'label'        => __( 'Trip Weather Forecast', 'wte-trip-weather-forecast' ),
			'content_path' => WTE_WEATHER_FORECAST_BASE_PATH . '/includes/backend/settings/global-settings.php',
			'current'      => true,
		);
		
		return $extension_settings;
	}

}
