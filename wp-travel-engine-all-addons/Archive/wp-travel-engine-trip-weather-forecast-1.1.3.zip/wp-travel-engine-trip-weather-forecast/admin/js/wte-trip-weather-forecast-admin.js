jQuery(document).ready(function ($) {
	$('.wte_city_name').autocomplete({
		source: function (request, response) {
			$.ajax({
				url: wte_script_data.ajax_url,
				type: 'POST',
				dataType: 'json',
				data: {
					action: 'wte_get_autocomplete_data',
					q: request.term
				},
				success: function (data) {
					// Check if data is an array and not empty
					if (Array.isArray(data) && data.length > 0) {
						// Map the data to get an array of names
						const names = data.map(function (item) {
							return item.name;
						});

						// Respond with the array of names
						response(names.map(function (name) {
							return {
								label: name,
								value: name
							};
						}));

						$('.wte_city_selector').val( data[0].country );
					} else {
						// Handle no results
						response([]);
					}
				},
				error: function (xhr, status, error) {
					// Handle the error
					console.error( 'Error fetching autocomplete data:', error );
					response([]);
				}
			});
		},
	});
});
