<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://wptravelengine.com/
 * @since             1.0.0
 * @package           Wte_Trip_Weather_Forecast
 *
 * @wordpress-plugin
 * Plugin Name:       WP Travel Engine - Trip Weather Forecast
 * Plugin URI:        https://wptravelengine.com/
 * Description:       An extension for WP Travel Engine plugin to add a weather forecast widget to desired trips.
 * Version:           1.1.3
 * Author:            WP Travel Engine
 * Author URI:        https://wptravelengine.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wte-trip-weather-forecast
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'WTE_WEATHER_FORECAST_VERSION', '1.1.3' );
define( 'WTE_WEATHER_FORECAST_BASE_PATH', dirname( __FILE__ ) );
define( 'WP_TRAVEL_ENGINE_WEATHER_FORECAST_ITEM_ID', 6724 ); // IMPORTANT: change the name of this constant to something unique to prevent conflicts with other plugins using this system

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wte-trip-weather-forecast-activator.php
 */
function activate_wte_trip_weather_forecast() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wte-trip-weather-forecast-activator.php';
	Wte_Trip_Weather_Forecast_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-wte-trip-weather-forecast-deactivator.php
 */
function deactivate_wte_trip_weather_forecast() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wte-trip-weather-forecast-deactivator.php';
	Wte_Trip_Weather_Forecast_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_wte_trip_weather_forecast' );
register_deactivation_hook( __FILE__, 'deactivate_wte_trip_weather_forecast' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-wte-trip-weather-forecast.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_wte_trip_weather_forecast() {

	$plugin = new Wte_Trip_Weather_Forecast();
	$plugin->run();

}
run_wte_trip_weather_forecast();

// license info
function wte_trip_weather_forecast_license( $array ) {
	$wp_travel_engine                      = get_option( 'wp_travel_engine_license' );
	$wte_trip_weather_forecast_license_key = isset( $wp_travel_engine['wte_trip_weather_forecast_license_key'] ) ? esc_attr( $wp_travel_engine['wte_trip_weather_forecast_license_key'] ) : '';// setup the updater

	$array[] = array(
		'version' => '1.1.0',     // current version number
		'license' => $wte_trip_weather_forecast_license_key,   // license key (used get_option above to retrieve from DB)
		'item_id' => WP_TRAVEL_ENGINE_WEATHER_FORECAST_ITEM_ID,   // id of this product in EDD
		'author'  => 'WP Travel Engine',  // author of this plugin
		'url'     => home_url(),
	);
	return $array;
}

$wp_travel_engine                         = get_option( 'wp_travel_engine_license' );
$wte_trip_weather_forecast_license_status = isset( $wp_travel_engine['wte_trip_weather_forecast_license_status'] ) ? esc_attr( $wp_travel_engine['wte_trip_weather_forecast_license_status'] ) : '';

if ( isset( $wte_trip_weather_forecast_license_status ) && $wte_trip_weather_forecast_license_status == 'valid' ) {
	add_filter( 'wp_travel_engine_licenses', 'wte_trip_weather_forecast_license' );
}

// addons name
add_filter( 'wp_travel_engine_addons', 'wte_trip_weather_forecast_name' );
function wte_trip_weather_forecast_name( $array ) {
	 $array['WP Travel Engine - Trip Weather Forecast'] = 'wte_trip_weather_forecast';
	return $array;
}

add_filter( 'wp_travel_engine_addons_id', 'wte_trip_weather_forecast_id' );
function wte_trip_weather_forecast_id( $array ) {
	$array['wte_trip_weather_forecast'] = WP_TRAVEL_ENGINE_WEATHER_FORECAST_ITEM_ID;
	return $array;
}
