<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://wptravelengine.com/
 * @since             1.0.0
 * @package           Wte_Fixed_Starting_Dates_Countdown
 *
 * @wordpress-plugin
 * Plugin Name:       WP Travel Engine - Trip Fixed Starting Dates Countdown
 * Plugin URI:        https://wptravelengine.com/
 * Description:       An extension for WP Travel Engine plugin to add a fixed starting dates countdown to desired trips.
 * Version:           2.1.0
 * Author:            WP Travel Engine
 * Author URI:        https://wptravelengine.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wte-fixed-starting-dates-countdown
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */

define( 'WTE_FSDATES_COUNTDOWN_VERSION', '2.1.0' );
define( 'WTE_FSDATES_COUNTDOWN_BASE_PATH', dirname( __FILE__ ) );
define( 'WP_TRAVEL_ENGINE_TRIP_COUNTDOWN_FILE_PATH', __FILE__ );
define( 'WP_TRAVEL_ENGINE_TRIP_COUNTDOWN_REQUIRES_AT_LEAST', '4.3.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wte-fixed-starting-dates-countdown-activator.php
 */
function activate_wte_fixed_starting_dates_countdown() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wte-fixed-starting-dates-countdown-activator.php';
	Wte_Fixed_Starting_Dates_Countdown_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-wte-fixed-starting-dates-countdown-deactivator.php
 */
function deactivate_wte_fixed_starting_dates_countdown() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wte-fixed-starting-dates-countdown-deactivator.php';
	Wte_Fixed_Starting_Dates_Countdown_Deactivator::deactivate();
}

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_wte_fixed_starting_dates_countdown() {
	$plugin = new Wte_Fixed_Starting_Dates_Countdown();
	$plugin->run();
}

/**
 *
 * @since 2.1.0
 */
function wte_starting_dates_countdown_fail_requirements() {
	if ( ! defined( 'WP_TRAVEL_ENGINE_VERSION' ) || version_compare( WP_TRAVEL_ENGINE_VERSION, WP_TRAVEL_ENGINE_TRIP_COUNTDOWN_REQUIRES_AT_LEAST, '<' ) ) {
		add_action(
			'admin_notices',
			function() {
				echo wp_kses_post(
					sprintf(
						'<div class="error"><p>'
						// translators: 1. WTE Extension Name 2. Link to WTE Plugin.
						. sprintf( __( '%1$s requires the %2$s plugin to work. Please install and activate the latest <strong>%2$s</strong> plugin first.', 'wte-fixed-starting-dates-countdown' ), '<strong>WP Travel Engine - Trip Fixed Starting Dates Countdown</strong>', '<a href="https://wordpress.org/plugins/wp-travel-engine/" target="__blank">WP Travel Engine</a>' )
						. '</p></div>'
					)
				);
			}
		);
	} else {
		register_activation_hook( __FILE__, 'activate_wte_fixed_starting_dates_countdown' );
		register_deactivation_hook( __FILE__, 'deactivate_wte_fixed_starting_dates_countdown' );

		/**
		 * The core plugin class that is used to define internationalization,
		 * admin-specific hooks, and public-facing site hooks.
		 */
		require plugin_dir_path( __FILE__ ) . 'includes/class-wte-fixed-starting-dates-countdown.php';
		run_wte_fixed_starting_dates_countdown();
	}
}

add_action( 'plugins_loaded', 'wte_starting_dates_countdown_fail_requirements' );
