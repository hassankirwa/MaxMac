/**
 * BLOCK
 */
import './editor.scss';
import './style.scss';

import apiFetch from '@wordpress/api-fetch';
import { TripEmbed } from '../common-components/template/TripEmbed';

const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks
const { Component, Fragment } = wp.element; // Import Componen and Fragment
const { InspectorControls } = wp.editor; // Import
const { PanelBody, TextControl, SelectControl } = wp.components; // Import Setting Controls


class WP_Travel_Engine_Trips_By_Trip_Type extends Component {
  constructor() {
    super(...arguments);

    this.state = {
      trips: {},
      types: {},
      isLoading: false
    }

    this.preventClick = this.preventClick.bind(this);
    this.doApiTypeRequest = this.doApiTypeRequest.bind(this);
    this.doApiRequest = this.doApiRequest.bind(this);
  }

  preventClick(e) {
    e.preventDefault();
    return false;
  }

  doApiTypeRequest( tax ) {
    const { trips, types, isLoading } = this.state;
    const { setAttributes } = this.props;

    apiFetch({ url: wptrvlengine.ajaxURL + '?action=wp_travel_engine_trip_type_taxomomy&tax=' + tax }).then(_terms => {
      const { types } = _terms;

      this.setState({ types });

    });
  }

  doApiRequest(postNumbers, tripType, tax) {
    const { attributes, setAttributes } = this.props;
    const { trips, isLoading } = this.state;

    this.setState({ isLoading: !isLoading });

    apiFetch({ url: wptrvlengine.ajaxURL + '?action=wp_travel_engine_trip_type_block&post_number=' + postNumbers + '&taxonomy=' + tax + '&term=' + tripType }).then(_trips => {
      const { found, trips } = _trips;

      if (true === found) {
        this.setState({ trips, isLoading: false });
      }
      else {
        this.setState({ trips: {}, isLoading: false });
      }

    });
  }

  componentDidMount() {
    const { attributes } = this.props;
    const { postNumbers, tripType, tax } = attributes;

    this.doApiTypeRequest( tax );
    this.doApiRequest(postNumbers, tripType, tax);
  }

  shouldComponentUpdate(nextProps, nextState) {
    const { postNumbers, tripType, tax } = this.props.attributes;

    if (postNumbers !== nextProps.attributes.postNumbers) {
      this.doApiRequest(nextProps.attributes.postNumbers);
    }
    else if (tripType !== nextProps.attributes.tripType) {
      this.doApiRequest(nextProps.attributes.postNumbers, nextProps.attributes.tripType, nextProps.attributes.tax);
    }
    else if ( tax !== nextProps.attributes.tax ) {
      this.doApiTypeRequest(nextProps.attributes.tax);
      this.doApiRequest(nextProps.attributes.postNumbers, nextProps.attributes.tripType, nextProps.attributes.tax);
    }

    return true;
  }

  render() {
    const { attributes, setAttributes } = this.props;
    const { title, heading, layout, postNumbers, tripType, tax } = attributes;
    const { trips, types, isLoading } = this.state;

    return (
      <Fragment>
        <InspectorControls>
          <PanelBody title={__('WTE Trips by Taxonomy Settings')}>
            <TextControl
              label={__('Title')}
              value={title}
              onChange={(value) => setAttributes({ title: value })}
            />
            <SelectControl
              label={__('Heading')}
              value={heading}
              options={[
                { label: 'H1', value: 'h1' },
                { label: 'H2', value: 'h2' },
                { label: 'H3', value: 'h3' },
                { label: 'H4', value: 'h4' },
                { label: 'H5', value: 'h5' },
                { label: 'H6', value: 'h6' },
                { label: 'Paragraph', value: 'p' },
              ]}
              onChange={(value) => setAttributes({ heading: value })}
            />
            <SelectControl
              label={__('Taxonomy')}
              value={tax}
              options={[
                { label: __('Destinations'), value: 'destination' },
                { label: __('Trip Types'), value: 'trip_types' },
                { label: __('Activities'), value: 'activities' },

              ]}
              onChange={(value) => setAttributes({ tax: value } , () => setAttributes({ tripType: 'All' }) )
            }
            />
            <SelectControl
              label={__('Term')}
              value={tripType}
              options={types}
              onChange={(value) => setAttributes({ tripType: value })}
            />
            <SelectControl
              label={__('Layout')}
              value={layout}
              options={[
                { label: __('Grid View'), value: 'grid-view' },
                { label: __('List View'), value: 'list-view' }
              ]}
              onChange={(value) => setAttributes({ layout: value })}
            />
            <TextControl
              label={__('No. of trip to show')}
              type='number'
              min={1}
              value={postNumbers}
              onChange={(value) => setAttributes({ postNumbers: value })}
            />
          </PanelBody>
        </InspectorControls>

          {('h1' === heading) && <h1 className="widget-title">{title}</h1>}
          {('h2' === heading) && <h2 className="widget-title">{title}</h2>}
          {('h3' === heading) && <h3 className="widget-title">{title}</h3>}
          {('h4' === heading) && <h4 className="widget-title">{title}</h4>}
          {('h5' === heading) && <h5 className="widget-title">{title}</h5>}
          {('h6' === heading) && <h6 className="widget-title">{title}</h6>}
          {('p' === heading) && <p className="widget-title">{title}</p>}
            {isLoading && (<span className="loading">{__('Loading...')}</span>)}
            <div className="te-post-wrap-outer">
              {(trips.length > 0) &&
                trips.map((trip, index) => (
                  ('list-view') == layout
                  ?
                    <div className="te-post-wrap te-list-layout">
                        <TripEmbed trip={trip} index={index} preventClick={this.preventClick} />
                    </div>
                    :
                    <div className="te-post-wrap te-grid-layout">
                        <div className="owl-carousel">
                            <TripEmbed trip={trip} index={index} preventClick={this.preventClick} />
                        </div>
                    </div>
                ))
              }
              </div>
            {( Object.entries(trips).length < 1 ) ? 'Trips not found.': '' }
      </Fragment>
    )
  }


}

/**
 * Register: aa Gutenberg Block.
 *
 * Registers a new block provided a unique name and an object defining its
 * behavior. Once registered, the block is made editor as an option to any
 * editor interface where blocks are implemented.
 *
 * @link https://wordpress.org/gutenberg/handbook/block-api/
 * @param  {string}   name     Block name.
 * @param  {Object}   settings Block settings.
 * @return {?WPBlock}          The block, if it has been successfully
 *                             registered; otherwise `undefined`.
 */
registerBlockType('wp-travel-engine/trip-type', {
  title: __('WTE Trips by Taxonomy'),
  description: __('A block to list the trips by taxonomy.'),
  icon: 'list-view',
  category: 'wp-travel-engine',
  keywords: [__('type'), __('trip'), __('travel')],
  attributes: { // default values
    title: {
      type: 'string',
      default: __('Trips by Type')
    },
    heading: {
      type: 'string',
      default: 'h2'
    },
    tax:{
      type: 'string',
      default: 'destination'
    },
    tripType: {
      type: 'string',
      default: ''
    },
    layout: {
      type: 'string',
      default: 'grid-view'
    },
    postNumbers: {
      type: 'number',
      default: '2'
    }
  },
  edit: WP_Travel_Engine_Trips_By_Trip_Type,
  save: function ({ attributes }) {
    return null;
  },
}); // END Register GBSS Boxes Block
