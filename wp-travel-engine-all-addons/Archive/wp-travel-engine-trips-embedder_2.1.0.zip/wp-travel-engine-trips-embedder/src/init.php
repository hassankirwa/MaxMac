<?php
/**
 * Blocks Initializer
 *
 * Enqueue CSS/JS of all the blocks.
 *
 * @since   1.0.0
 * @package CGB
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue Gutenberg block assets for both frontend + backend.
 *
 * Assets enqueued:
 * 1. blocks.style.build.css - Frontend + Backend.
 * 2. blocks.build.js - Backend.
 * 3. blocks.editor.build.css - Backend.
 *
 * @uses {wp-blocks} for block type registration & related functions.
 * @uses {wp-element} for WP Element abstraction — structure of blocks.
 * @uses {wp-i18n} to internationalize the block's text.
 * @uses {wp-editor} for WP editor styles.
 * @since 1.0.0
 */
add_action( 'enqueue_block_assets', 'wte_trips_enbedder_cgb_block_assets' );
/**
 * Enqueue Gutenberg block assets for both frontend + backend.
 *
 * @uses {wp-editor} for WP editor styles.
 * @since 1.0.0
 */
function wte_trips_enbedder_cgb_block_assets() { // phpcs:ignore
	// Styles.
	wp_enqueue_style(
		'wte_trips_enbedder-cgb-style-css', // Handle.
		plugins_url( 'dist/blocks.style.build.css', dirname( __FILE__ ) ), // Block style CSS.
		array( 'wp-editor' ) // Dependency to include the CSS after it.
		// filemtime( plugin_dir_path( __DIR__ ) . 'dist/blocks.style.build.css' ) // Version: File modification time.
	);
}


add_action( 'enqueue_block_editor_assets', 'wte_trips_enbedder_cgb_editor_assets' );
/**
 * Enqueue Gutenberg block assets for backend editor.
 *
 * @uses {wp-blocks} for block type registration & related functions.
 * @uses {wp-element} for WP Element abstraction — structure of blocks.
 * @uses {wp-i18n} to internationalize the block's text.
 * @uses {wp-editor} for WP editor styles.
 * @since 1.0.0
 */
function wte_trips_enbedder_cgb_editor_assets() { // phpcs:ignore
	// Scripts.
	wp_enqueue_script(
		'wte_trips_enbedder-cgb-block-js', // Handle.
		plugins_url( '/dist/blocks.build.js', dirname( __FILE__ ) ), // Block.build.js: We register the block here. Built with Webpack.
		array( 'jquery', 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-editor' ), // Dependencies, defined above.
		// filemtime( plugin_dir_path( __DIR__ ) . 'dist/blocks.build.js' ), // Version: File modification time.
		true // Enqueue the script in the footer.
	);
	wp_localize_script( 'wte_trips_enbedder-cgb-block-js', 'wptrvlengine', array( 'ajaxURL' => admin_url( 'admin-ajax.php' ) ) );

	// Styles.
	wp_enqueue_style(
		'wte_trips_enbedder-cgb-block-editor-css', // Handle.
		plugins_url( 'dist/blocks.editor.build.css', dirname( __FILE__ ) ), // Block editor CSS.
		array( 'wp-edit-blocks' ) // Dependency to include the CSS after it.
		// filemtime( plugin_dir_path( __DIR__ ) . 'dist/blocks.editor.build.css' ) // Version: File modification time.
	);
}


add_filter( 'block_categories', 'wte_trips_embedder_block_categories', 10, 2 );
/**
 * Register new Block Category
 */
function wte_trips_embedder_block_categories( $categories, $post ) {
	return array_merge(
		$categories,
		array(
			array(
				'slug'  => 'wp-travel-engine',
				'title' => __( 'WP Travel Engine', 'wp-travel-engine-trips-embedder' ),
				// 'icon'  => '',
			),
		)
	);
}

// List by Trip Types Block.
require_once dirname( __FILE__ ) . '/trip-type/block.php';
require_once dirname( __FILE__ ) . '/handpicked-trips/block.php';
