<?php
// PHP rendering for the block (for frontend)
function wp_travel_engine_handpicked_trips_block() {
	if ( ! function_exists( 'register_block_type' ) ) {
			return;
	}

		register_block_type(
			'wp-travel-engine/handpicked-trips',
			array(
				'attributes'      => array(
					'title'       => array(
						'type'    => 'string',
						'default' => __( 'WTE Handpicked Trips', 'wp-travel-engine-trips-embedder' ),
					),
					'heading'     => array(
						'type'    => 'string',
						'default' => 'h2',
					),
					'TripsSelect'    => array(
						'type'    => 'string',
						'default' => '',
					),
					'layout'      => array(
						'type'    => 'string',
						'default' => 'grid-view',
					),
				),
				'render_callback' => 'wp_travel_engine_handpicked_trips_block_render',
			)
		);
}
add_action( 'init', 'wp_travel_engine_handpicked_trips_block' );

/**
 * Call back function for frontend rendering
 */
if ( ! function_exists( 'wp_travel_engine_handpicked_trips_block_render' ) ) {
	function wp_travel_engine_handpicked_trips_block_render( $attributes ) {
		
		extract( $attributes );

		if ( isset( $attributes['Trip'] ) && ! empty( $attributes['Trip'] ) ) :
			
			$post_in = array_column( $attributes['Trip'], 'value' );

		endif;
		
		$layout = 'grid-view' === $attributes['layout'] ? 'grid' : 'list';

		$args = array(
			'offset'           => 0,
			'orderby'          => 'date',
			'order'            => 'DESC',
			'post_type'        => 'trip',
			'post_status'      => 'publish',
			'suppress_filters' => true,
		);

		if ( ! empty( $post_in ) && is_array( $post_in ) ) :

			$args['post__in'] = $post_in;
			$args['orderby']  = 'post__in';

		endif;

		$itineraries = new WP_Query( $args );

		ob_start();

		if ( $title ) {
			printf( '<%1$s class="wte-tr-title">%2$s</%1$s>', $heading, $title );
		}

		$j = 1;

		if ( $itineraries->have_posts() ) :

			?>
			<div class="te-post-wrap te-<?php echo esc_attr( $layout ); ?>-layout">
				<?php if ( 'grid' === $layout ) : ?>
					<div class="owl-carousel">
				<?php endif; ?>

					<?php

						while( $itineraries->have_posts() ) : $itineraries->the_post();

							echo wte_trips_embedder_get_template_html( 'wte-embed.php', array( 'layout' => $layout ) );

						endwhile; wp_reset_postdata();

					
					if ( 'grid' === $layout ) : ?>
					</div>
				<?php endif; ?>
			</div>

		<?php
		
		else : ?>
				<p class="itinerary-none"><?php esc_html_e( 'Trips not found.', 'wp-travel-engine-trips-embedder' ); ?></p>
			<?php
			endif;

		return ob_get_clean();
	}
}

/**
 * Ajax from Backend Trip Type Terms for the block.
 */
function wp_travel_engine_handpicked_trips_ajax() {
	$TripsSelect = new Wp_Query(
		array(
			'post_type'      => 'trip',
			'posts_per_page' => -1,
		)
	);

	if ( $TripsSelect->have_posts() ) {
		while ( $TripsSelect->have_posts() ) {

			$TripsSelect->the_post();

			$TripOptions[] = array(
				'value' => get_the_ID(),
				'label' => get_the_title(),
			);
		}
		wp_reset_postdata();
	}

	wp_send_json( array( 'TripOptions' => $TripOptions ) );
	exit;
}
add_action( 'wp_ajax_wp_travel_engine_handpicked_trips_ajax', 'wp_travel_engine_handpicked_trips_ajax' );

/**
 * Ajax from Backend for the block.
 */
function wp_travel_engine_handpicked_trips_block_ajax() {

	$post__in = filter_input( INPUT_GET, 'posts_in' );
	
	$args = array(
		'offset'           => 0,
		'post_type'        => 'trip',
		'post_status'      => 'publish',
		'suppress_filters' => true,
	);

	if ( ! empty( $post__in ) ) {
		$args['post__in'] = explode( ',', $post__in );
		$args['orderby']  = 'post__in';
	}

	$itineraries = new WP_Query( $args );

	$trips = array();

	if ( $itineraries->have_posts() ) {

		while ( $itineraries->have_posts() ) {
			$itineraries->the_post();
			$post_id = get_the_ID();

			$trip_settings = get_post_meta( $post_id, 'wp_travel_engine_setting', true );

			$trip_duration = isset( $trip_settings['trip_duration'] ) && ! empty( $trip_settings['trip_duration'] ) ? $trip_settings['trip_duration'] : false;

			$destinations     = get_the_terms( $trip_id, 'destination' );
			$destination      = array();

			if ( ! empty( $destinations ) && ! is_wp_error( $destinations ) ) :
				
				foreach( $destinations as $key => $desti ) :

					$destination[$key] = array(
						'name' => $desti->name,
					);

				endforeach;

			endif;

			$fixed_departures = wp_travel_engine_get_fixed_departure_dates( $post_id );

			$comments = get_comments( array(
                'post_id' => $post_id,
                'status'  => 'approve',
			) );

			$aggregate = 0;
			
			if ( ! empty( $comments ) )
            {
                $sum = 0;
                $i = 0;
                foreach($comments as $comment) {
                    $rating = get_comment_meta( $comment->comment_ID, 'stars', true );
                    $sum = $sum+$rating;
                    $i++;
                }
                $aggregate = $sum/$i;
                $aggregate = round($aggregate,2);
            }

			$trips[] = array(
				'id'               => $post_id,
				'title'            => get_the_title(),
				'post_excerpt'     => get_the_excerpt( $post_id ),
				'enable_sale'      => wp_travel_engine_is_trip_on_sale( $post_id ),
				'trip_price'       => wp_travel_engine_get_prev_price( $post_id ),
				'sale_price'       => wp_travel_engine_get_sale_price( $post_id ),
				'featured_image'   => get_the_post_thumbnail_url( $post_id ),
				'currency_code'    => wp_travel_engine_get_currency_code(),
				'currency_symbol'  => wp_travel_engine_get_currency_symbol( wp_travel_engine_get_currency_code() ),
				'trip_duration'    => sprintf( _nx( '%1$d Day', '%1$d Days', $trip_duration, 'trip duration', 'wp-travel-engine-trips-embedder' ), $trip_duration ),
				'show_reviews'     => class_exists( 'Wte_Trip_Review_Init' ) && ! empty( $comments ) ? true : false,
				'average_rating'   => $aggregate,
				'review_count'     => $i,
				'reviews_text'     => esc_html( _nx( 'Review', 'Reviews', $i, 'reviews count', 'wp-travel-engine-trips-embedder' ) ),
				'discount'         => wte_trips_embedder_get_discount_percent( $post_id ),
				'destination'      => $destination,
				'fixed_departures' => $fixed_departures,
			);
		}

		wp_reset_postdata();
		wp_send_json(
			array(
				'found' => true,
				'trips' => $trips,
			)
		);

	}

	wp_send_json(
		array(
			'found' => false,
			'trips' => array(),
		)
	);

	die();

}
add_action( 'wp_ajax_wp_travel_engine_handpicked_trips_block', 'wp_travel_engine_handpicked_trips_block_ajax' );
