/**
 * BLOCK:
 */
import './editor.scss';
import './style.scss';

import apiFetch from '@wordpress/api-fetch';
import { TripEmbed } from '../common-components/template/TripEmbed';
import Select from 'react-select';

const { __ } = wp.i18n; // Import __() from wp.i18n
const { registerBlockType } = wp.blocks; // Import registerBlockType() from wp.blocks
const { Component, Fragment } = wp.element; // Import Componen and Fragment
const { InspectorControls } = wp.editor; // Import
const { PanelBody, TextControl, SelectControl } = wp.components; // Import Setting Controls


class WP_Travel_Engine_Handpicked_Trips extends Component {
    constructor() {
        super(...arguments);

        this.state = {
            trips: {},
            TripOptions: [],
            isLoading: false
        }

        this.preventClick      = this.preventClick.bind(this);
        this.doApiTripsRequest = this.doApiTripsRequest.bind(this);
        this.doApiRequest      = this.doApiRequest.bind(this);
    }

    preventClick(e) {
        e.preventDefault();
        return false;
    }

    doApiTripsRequest() {
        const { trips, TripOptions, isLoading } = this.state;
        const { setAttributes } = this.props;

            apiFetch({ url: wptrvlengine.ajaxURL + '?action=wp_travel_engine_handpicked_trips_ajax' }).then( _terms => {
            
            const { TripOptions } = _terms;

            this.setState({ TripOptions });

        });
    }

    doApiRequest( Trip ) {
        const { attributes, setAttributes } = this.props;
        const { trips, isLoading } = this.state;

        if ( Trip == null ) {
            Trip = [];
        }
            Trip = Trip.map(function(Trip){return Trip.value;}).join(',');

            this.setState({ isLoading: !isLoading });

            apiFetch({ url: wptrvlengine.ajaxURL + '?action=wp_travel_engine_handpicked_trips_block&posts_in=' + Trip }).then(_trips => {
                const { found, trips } = _trips;

                if (true === found) {
                    this.setState({ trips, isLoading: false });
                }
                else {
                    this.setState({ trips: {}, isLoading: false });
                }

            });
    }

    componentDidMount() {
        const { attributes } = this.props;
        const { Trip } = attributes;

        this.doApiTripsRequest();
        this.doApiRequest(Trip);
    }

    shouldComponentUpdate(nextProps, nextState) {
        const { Trip } = this.props.attributes;

        if (Trip !== nextProps.attributes.Trip) {
            this.doApiRequest(nextProps.attributes.Trip);
        }

        return true;
    }

    render() {
        const { attributes, setAttributes } = this.props;
        const { title, heading, layout, Trip } = attributes;
        const { trips, TripOptions, isLoading } = this.state;

        return (
        <Fragment>
            <InspectorControls>
            <PanelBody title={__('WTE Handpicked Trips Settings')}>
                <TextControl
                label={__('Title')}
                value={title}
                onChange={(value) => setAttributes({ title: value })}
                />
                <SelectControl
                label={__('Heading')}
                value={heading}
                options={[
                    { label: 'H1', value: 'h1' },
                    { label: 'H2', value: 'h2' },
                    { label: 'H3', value: 'h3' },
                    { label: 'H4', value: 'h4' },
                    { label: 'H5', value: 'h5' },
                    { label: 'H6', value: 'h6' },
                    { label: 'Paragraph', value: 'p' },
                ]}
                onChange={(value) => setAttributes({ heading: value })}
                />
                <div class="components-base-control">
                    <div class="components-base-control__field">
                        <label class="components-base-control__label">{__('Trips')}</label>
                        <Select
                        label={__('Trips')}
                        value={Trip}
                        options={TripOptions}
                        isMulti='true'
                        onChange={(value) => setAttributes({ Trip: value })}
                        />
                    </div>
                </div>
                <SelectControl
                label={__('Layout')}
                value={layout}
                options={[
                    { label: __('Grid View'), value: 'grid-view' },
                    { label: __('List View'), value: 'list-view' },
                ]}
                onChange={(value) => setAttributes({ layout: value })}
                />
            </PanelBody>
            </InspectorControls>
            {('h1' === heading) && <h1 className="widget-title">{title}</h1>}
            {('h2' === heading) && <h2 className="widget-title">{title}</h2>}
            {('h3' === heading) && <h3 className="widget-title">{title}</h3>}
            {('h4' === heading) && <h4 className="widget-title">{title}</h4>}
            {('h5' === heading) && <h5 className="widget-title">{title}</h5>}
            {('h6' === heading) && <h6 className="widget-title">{title}</h6>}
            {('p' === heading) && <p className="widget-title">{title}</p>}
                {isLoading && (<span className="loading">{__('Loading...')}</span>)}
                <div className="te-post-wrap-outer">
                {(trips.length > 0) &&
                    trips.map((trip, index) => (
                    ('list-view') == layout
                        ?
                        <div className="te-post-wrap te-list-layout">
                            <TripEmbed trip={trip} index={index} preventClick={this.preventClick} />
                        </div>
                        :
                        
                        <div className="te-post-wrap te-grid-layout">
                            <div className="owl-carousel">
                                <TripEmbed trip={trip} index={index} preventClick={this.preventClick} />
                            </div>
                        </div>
                        
                    ))
                }
                </div>
                {( Object.entries(trips).length < 1 ) ? 'Trips not found.': '' }

        </Fragment>
        )
    }


}

/**
 * Register: aa Gutenberg Block.
 *
 * Registers a new block provided a unique name and an object defining its
 * behavior. Once registered, the block is made editor as an option to any
 * editor interface where blocks are implemented.
 *
 * @link https://wordpress.org/gutenberg/handbook/block-api/
 * @param  {string}   name     Block name.
 * @param  {Object}   settings Block settings.
 * @return {?WPBlock}          The block, if it has been successfully
 *                             registered; otherwise `undefined`.
 */
registerBlockType('wp-travel-engine/handpicked-trips', {
    title: __('WTE Handpicked Trips'),
    description: __('A block to list the handpicked trips.'),
    icon: 'list-view',
    category: 'wp-travel-engine',
    keywords: [__('type'), __('trip'), __('travel')],
    attributes: { // default values
        title: {
        type: 'string',
        default: __('Handpicked Trips')
        },
        heading: {
        type: 'string',
        default: 'h2'
        },
        Trip: {
        type: 'array',
        default: []
        },
        layout: {
        type: 'string',
        default: 'grid-view'
        },
    },
    example: {
        attributes: { 
            content: __( 'Content of the block' )
        },
        innerBlocks: []
    },
    edit: WP_Travel_Engine_Handpicked_Trips,
    save: function ({ attributes }) {
        return null;
    },
}); // END Register GBSS Boxes Block
