import "../../../node_modules/rateyo/src/jquery.rateyo";
const { decodeEntities } = wp.htmlEntities;
const { __ } = wp.i18n;

const { Component, Fragment } = wp.element;

export class TripEmbed extends Component {
	constructor() {
		super(...arguments);
	}

	// componentDidMount() {
	//   const { trip, index, preventClick } = this.props;
	//   var el = $('.agg-rating');
	//   $(el).rateYo({
	//     rating: trip.average_rating,
	//     readOnly: true,
	//   });
	// }

	// shouldComponentUpdate(nextProps, nextState) {
	//   const { trip, index, preventClick } = this.props;
	//   var el = $('.agg-rating');
	//   $(el).rateYo({
	//     rating: trip.average_rating,
	//     readOnly: true,
	//   });
	// }

	render() {
		const { trip, index, preventClick } = this.props;
		return (
			<Fragment key={index}>
				<article className="te-post">
					<figure className="te-post-img">
						<a href="#" title={trip.title} onClick={preventClick}>
							<img src={trip.featured_image} alt={trip.title} />
						</a>
						{trip.discount && (
							<span className="te-post-discount">
								{trip.discount}
								{__("% Off")}
							</span>
						)}
					</figure>
					<div className="te-post-content-wrap">
						<h3 className="te-post-title">
							<a href="#" title={trip.title} onClick={preventClick}>
								{trip.title}
							</a>
						</h3>
						<div className="te-post-meta">
							<span className="te-post-price">
								{trip.enable_sale && (
									<del>
										{decodeEntities(trip.currency_symbol)}
										{trip.trip_price}
									</del>
								)}
								<ins>
									{" "}
									{trip.enable_sale
										? `${decodeEntities(trip.currency_symbol)} ${
												trip.sale_price
										  }`
										: `${decodeEntities(trip.currency_symbol)} ${
												trip.trip_price
										  }`}
								</ins>
							</span>
							<span className="te-post-days">
								<svg
									className="svg-inline--fa fa-history fa-w-16"
									aria-hidden="true"
									data-prefix="fas"
									data-icon="history"
									role="img"
									xmlns="http://www.w3.org/2000/svg"
									viewBox="0 0 512 512"
									data-fa-i2svg=""
								>
									<path
										fill="currentColor"
										d="M504 255.531c.253 136.64-111.18 248.372-247.82 248.468-59.015.042-113.223-20.53-155.822-54.911-11.077-8.94-11.905-25.541-1.839-35.607l11.267-11.267c8.609-8.609 22.353-9.551 31.891-1.984C173.062 425.135 212.781 440 256 440c101.705 0 184-82.311 184-184 0-101.705-82.311-184-184-184-48.814 0-93.149 18.969-126.068 49.932l50.754 50.754c10.08 10.08 2.941 27.314-11.313 27.314H24c-8.837 0-16-7.163-16-16V38.627c0-14.254 17.234-21.393 27.314-11.314l49.372 49.372C129.209 34.136 189.552 8 256 8c136.81 0 247.747 110.78 248 247.531zm-180.912 78.784l9.823-12.63c8.138-10.463 6.253-25.542-4.21-33.679L288 256.349V152c0-13.255-10.745-24-24-24h-16c-13.255 0-24 10.745-24 24v135.651l65.409 50.874c10.463 8.137 25.541 6.253 33.679-4.21z"
									></path>
								</svg>
								<span className="te-post-day">{trip.trip_duration}</span>
							</span>
							<span className="te-post-location">
								<svg
									className="svg-inline--fa fa-map-marker-alt fa-w-12"
									aria-hidden="true"
									data-prefix="fas"
									data-icon="map-marker-alt"
									role="img"
									xmlns="http://www.w3.org/2000/svg"
									viewBox="0 0 384 512"
									data-fa-i2svg=""
								>
									<path
										fill="currentColor"
										d="M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0zM192 272c44.183 0 80-35.817 80-80s-35.817-80-80-80-80 35.817-80 80 35.817 80 80 80z"
									></path>
								</svg>
								{trip.destination.map((value, index) => {
									return (
										<a href="#" onClick={preventClick} rel="tag">
											{value.name},{" "}
										</a>
									);
								})}
							</span>
						</div>
						<div className="te-footer">
							{trip.show_reviews && (
								<span className="te-post-rating">
									<div className="te-star-holder">
										<div class="review-wrap">
											<div class="average-rating">
												<div class="agg-rating"></div>
												<div class="aggregate-rating">
													<span class="rating-star">{trip.average_rating}</span>
													<span>{trip.review_count}</span> {trip.reviews_text}
												</div>
											</div>
										</div>
									</div>
								</span>
							)}
							{"" != trip.fixed_departures && (
								<span className="te-post-departure">
									<b>{__("Next Departure:")}</b>
									<ul className="wte-next-departure-list">
										{trip.fixed_departures.map((value, index) => {
											return (
												<li key={index}>
													<span className="te-departure-date">
														{value.start_date}
													</span>
												</li>
											);
										})}
									</ul>
								</span>
							)}
						</div>
					</div>
				</article>
			</Fragment>
		);
	}
}
