(function ($) {
    tinymce.PluginManager.add('wte_trips_embedder_mce_btn', function (editor, url) {
        editor.addButton('wte_trips_embedder_mce_btn', {
            icon: 'embed-trip is-dashicon dashicons dashicons-location-alt',
            text: false,
            title: 'WP Travel Engine - Trips Embedder',
            onPostRender: function () {
                jQuery('.is-dashicon').css('font-family', 'dashicons');
            },
            onclick: function (e) {
                $('#wte-trips-embedder-metabox').show();
                $('#wteEmbedderDialog').modal('show');
            }
        });
    });

    $('#wteEmbedderDialog').on('hidden.bs.modal', function (e) {
        $('body:not(.post-type-wte-embed) #wte-trips-embedder-metabox').hide();
    });

    $('.trip-embeder-tab-wrap .trip-embeder-tab').on('click', function (e) {

        e.preventDefault();

        var tabId = $(this).attr('id');
        $('.trip-embeder-tab').removeClass('active');
        $('.trip-embeder-content').removeClass('active');
        $(this).addClass('active');
        $('#' + tabId + '-content').addClass('active');
    });

    // Bootstrap Listbox JS
    jQuery(function () {

        $(".wte-em-sortable").sortable({ handle: '.te-item-move' });

        jQuery('body').on('click', '.list-group .list-group-item label', function () {
            jQuery(this).parent('.list-group-item').toggleClass('active');
        });
        jQuery('.list-arrows button').click(function (e) {

            e.preventDefault();

            var $button = jQuery(this), actives = '';
            if ($button.hasClass('move-left')) {
                actives = jQuery('.list-right ul li.active');
                actives.clone().appendTo('.list-left ul');
                actives.remove();
            } else if ($button.hasClass('move-right')) {
                actives = jQuery('.trip-embeder-content.active .list-left ul li.active');

                actives.each(function (index, item) {
                    var trip_id = $(this).data('trip-id');
                    var trip_title = $(this).data('trip-title');
                    var id = $(this).data('id');

                    var template = wp.template('wte-trip-embeder-right-list');
                    $('.trip-embeder-content.active .list-right ul').append(template({ trip_id: trip_id, trip_title: trip_title, id: id }));

                    $(this).removeClass('active').hide();

                    $(this).children('input[type="checkbox"]').prop('checked', false);

                    $(".wte-em-sortable").sortable('refresh');

                });

                // actives.clone().appendTo('.list-right ul');
                // actives.remove();
            }
            UpdateSelectedTrips();
        });

        function UpdateSelectedTrips() {

            var total_selections = $('.trip-embeder-content.active .list-right ul li').length;

            $('.trip-embeder-content.active .trip-embeder-count').html(total_selections);

        }

        jQuery(document).on('click', '.te-item-remove', function (e) {

            e.preventDefault();

            var datael = $(this).parent('.te-selected-item').parent('.te-selected-item-lst');

            var trip_id = datael.data('trip-id');
            var trip_title = datael.data('trip-title');
            var id = datael.data('id');

            // var template = wp.template('wte-trip-embeder-left-list');
            // $('.trip-embeder-content.active .list-left ul').not('ul.children').append(template({ trip_id: trip_id, trip_title: trip_title, id: id }));

            $('.trip-embeder-content.active .list-left ul li[data-trip-id="' + trip_id + '"]').show();

            datael.remove();

            $(".wte-em-sortable").sortable('refresh');
            UpdateSelectedTrips();

        });

        jQuery('.dual-list .selector').click(function () {
            var $checkBox = jQuery(this);
            if (!$checkBox.hasClass('selected')) {
                $checkBox.addClass('selected').closest('.well').find('ul li:not(.active)').addClass('active');
                $checkBox.children('i').removeClass('glyphicon-unchecked').addClass('glyphicon-check');
            } else {
                $checkBox.removeClass('selected').closest('.well').find('ul li.active').removeClass('active');
                $checkBox.children('i').removeClass('glyphicon-check').addClass('glyphicon-unchecked');
            }
        });
        jQuery('[name="SearchDualList"]').on('keyup search', function (e) {
            $('.trip-embeder-content.active .dual-list .no-results').hide();
            $('.trip-embeder-alphabet').hide();
            var code = e.keyCode || e.which;
            if (code == '9') return;
            if (code == '27') jQuery(this).val(null);
            var $rows = jQuery('.trip-embeder-content.active .dual-list').find('li.list-group-item');
            var val = $.trim(jQuery(this).val()).replace(/ +/g, ' ').toLowerCase();
            $rows.show().filter(function () {
                var text = jQuery(this).children('label').text().replace(/\s+/g, ' ').toLowerCase();
                return !~text.indexOf(val);
            }).hide();
            if ('' === val) {
                $('.trip-embeder-alphabet').show();
                $('.trip-embeder-content.active .dual-list .no-results').hide();
            }

            if ($('.trip-embeder-content.active .dual-list .te-trip-list').children(':visible').length == 0) {
                $('.trip-embeder-content.active .dual-list .no-results').show();
            }

        });

    });

    $(document).on('click', '#wte_embed_insert_embed_sh', function (e) {

        e.preventDefault();

        var active_tab = $('.trip-embeder-tab.active');

        var shortcode_base = '';
        var trips_param = '';
        var custom_type = '';
        var selected_ids = [];
        var $ids_string = '';
        var number_param = false;

        switch (active_tab.html()) {
            case 'Trips':

                shortcode_base = 'wte_trips_embedder_trips';
                trips_param = 'ids';

                $selected_items = $('.trip-embeder-content.active .wte-sel-trips > li.te-selected-item-lst');

                $selected_items.each(function (id, item) {
                    selected_ids[id] = $(this).data('trip-id');
                });

                $ids_string = selected_ids.join(',');

                break;

            case 'Destinations':

                shortcode_base = 'wte_trips_embedder_tax';
                trips_param = 'destination';
                number_param = 'number';

                $selected_items = $('.trip-embeder-content.active .wte-sel-trips > li.te-selected-item-lst');

                $selected_items.each(function (id, item) {
                    selected_ids[id] = $(this).data('trip-id');
                });

                $ids_string = selected_ids.join(',');


                break;

            case 'Activities':

                shortcode_base = 'wte_trips_embedder_tax';
                trips_param = 'activities';
                number_param = 'number';

                $selected_items = $('.trip-embeder-content.active .wte-sel-trips > li.te-selected-item-lst');

                $selected_items.each(function (id, item) {
                    selected_ids[id] = $(this).data('trip-id');
                });

                $ids_string = selected_ids.join(',');


                break;

            case 'Trip Type':

                shortcode_base = 'wte_trips_embedder_tax';
                trips_param = 'trip_types';
                number_param = 'number';

                $selected_items = $('.trip-embeder-content.active .wte-sel-trips > li.te-selected-item-lst');

                $selected_items.each(function (id, item) {
                    selected_ids[id] = $(this).data('trip-id');
                });

                $ids_string = selected_ids.join(',');


                break;

            default:
                // code block
                var cst_filter_ = active_tab.data('filter-slug');
                custom_type = 'custom_type= ' + cst_filter_;
                shortcode_base = 'wte_trips_embedder_tax';
                trips_param = 'custom_terms';
                number_param = 'number';

                $selected_items = $('.trip-embeder-content.active .wte-sel-trips > li.te-selected-item-lst');

                $selected_items.each(function (id, item) {
                    selected_ids[id] = $(this).data('trip-id');
                });

                $ids_string = selected_ids.join(',');
        }

        if ('' === $ids_string) {

            alert('Please select some items first.');

        } else {

            // Get layout.
            $layout = $('input[name=wte_trip_embedder_sh_layout]:checked').val();

            $posts_num = $('.trip-embeder-content.active .wte-numberOfposts-val').val();

            if (number_param && '' != $posts_num) {

                if ($('body').hasClass('post-type-wte-embed')) {

                    WteGenerateEmbedCode($ids_string, shortcode_base, $layout, trips_param, $posts_num, custom_type);

                } else {

                    // Insert to Editor.
                    tinymce.activeEditor.insertContent('[' + shortcode_base + ' ' + 'layout="' + $layout + '" ' + 'postsnumber="' + $posts_num + '" ' + trips_param + '="' + $ids_string + '" ' + custom_type + ']');
                }

            }

            else {

                if ($('body').hasClass('post-type-wte-embed')) {

                    WteGenerateEmbedCode($ids_string, shortcode_base, $layout, trips_param, $posts_num = false, custom_type);

                } else {

                    // Insert to Editor.
                    tinymce.activeEditor.insertContent('[' + shortcode_base + ' ' + 'layout="' + $layout + '" ' + trips_param + '="' + $ids_string + '" ' + custom_type + ']');
                }

            }

            $('#wteEmbedderDialog').modal('hide');

        }

    });

    $('#wte-media-btn-trop-embed').click(function (e) {

        e.preventDefault();

        $('#wte-trips-embedder-metabox').show();

        if ($('body').hasClass('post-type-wte-embed')) {

            $('#wte_embed_insert_embed_sh').attr('value', 'Generate Embed Code');
        }

        $('#wteEmbedderDialog').modal('show');

    });

    /**
     * handle third party embed script generation.
     */
    function WteGenerateEmbedCode($ids_string, shortcode_base, $layout, wte_embed_trips_param, $posts_num = false, custom_type = false) {

        var embed_width = $('#wte_embed_iframe_width').val();
        var embed_height = $('#wte_embed_iframe_height').val();

        // $( '#wte-thirdparty-embedcode' ).val( '<div id="wte-embedder-prim-wrap-'+ wpte_embedder.postID +'" class="wte-embedder-prim-wrap" data-embed-id="'+ wpte_embedder.postID +'"></div><script type="text/javascript">var wte_embed_trips_width = "'+ embed_width +'"; var wte_embed_trips_height = "'+ embed_height +'"; var wte_embed_trips_param = "'+ wte_embed_trips_param +'"; var wte_trp_embed_id = "' + wpte_embedder.postID + '"; var wte_embed_source_site = "' + wpte_embedder.source_url + '"; var wte_embed_type = "' + shortcode_base + '"; var wte_embed_ids_string = "' + $ids_string + '"; var wte_embed_layout = "' + $layout + '"; var wte_embed_posts_num = "' + $posts_num + '";</script><script src="'+ wpte_embedder.plugin_url +'assets/js/public/wpte-embed-handler.js" type="text/javascript"></script><div style="--aspect-ratio: 16/9;" id="wte-trips-embedder-'+ wpte_embedder.postID +'"></div></div>' );

        $('#wte-thirdparty-embedcode').val('<div id="wte-embedder-prim-wrap-' + wpte_embedder.postID + '" class="wte-embedder-prim-wrap" data-trp_embed_id="' + wpte_embedder.postID + '" data-embed_trips_width="' + embed_width + '" data-embed_trips_height = "' + embed_height + '" data-embed_source_site = "' + wpte_embedder.source_url + '" data-embed_type = "' + shortcode_base + '" data-embed_trips_param = "' + wte_embed_trips_param + '" data-embed_id="' + wpte_embedder.postID + '" data-embed_ids_string = "' + $ids_string + '" data-embed_layout = "' + $layout + '" data-embed_posts_num = "' + $posts_num + '" data-' + custom_type + '"><script src="' + wpte_embedder.plugin_url + 'assets/js/public/wpte-embed-handler.js" type="text/javascript"></script><div class="wte-trips-embedder-ext-iframe-container" id="wte-trips-embedder-' + wpte_embedder.postID + '"></div></div>');

        return false;

    }

    jQuery(document).ready(function () {

        if ($('#wte_trp_embed_allowed_sites').length > 0) {

            var $input = $('#wte_trp_embed_allowed_sites').tagify({
                pattern: /^(?:(?:https?|ftp):\/\/)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:\/\S*)?$/,
            })
                .on('add', function (e, tagName) {
                    // console.log('JQEURY EVENT: ', 'added', tagName)

                    if ('' == $input.val()) {
                        $('#wte_trp_embed_allowed_sites_val').val('');
                        return;
                    }

                    var value = JSON.parse($input.val());

                    var result = value.map(function (val) {
                        return val.value;
                    }).join(',');

                    $('#wte_trp_embed_allowed_sites_val').val(result);
                })
                .on('remove', function (e, tagName) {
                    // console.log('JQEURY EVENT: ', 'added', tagName)

                    if ('' == $input.val()) {
                        $('#wte_trp_embed_allowed_sites_val').val('');
                        return;
                    }

                    var value = JSON.parse($input.val());

                    var result = value.map(function (val) {
                        return val.value;
                    }).join(',');

                    $('#wte_trp_embed_allowed_sites_val').val(result);
                })

            // get the Tagify instance assigned for this jQuery input object so its methods could be accessed
            var jqTagify = $input.data('tagify');

            // bind the "click" event on the "remove all tags" button
            $('.tags-jquery--removeAllBtn').on('click', jqTagify.removeAllTags.bind(jqTagify))

            $('#wte_trp_embed_allowed_sites').on('change focus', function () {

            });
        }

        $('#wte_embed_iframe_width').on('change', function (e) {

            $textarea_val = $('#wte-thirdparty-embedcode').val();

            if ('' == $textarea_val) {
                return false;
            }

            var regexp = new RegExp('data-embed_trips_width="\\d+(%{1}|(px){1})"', 'gmiu');

            // console.log( regexp.test( $textarea_val ) );

            var updated_width = $(this).val();
            var updated_string = $textarea_val.replace(regexp, 'data-embed_trips_width="' + updated_width + '"');

            $('#wte-thirdparty-embedcode').val(updated_string);

        });

        $('#wte_embed_iframe_height').on('change', function (e) {

            $textarea_val = $('#wte-thirdparty-embedcode').val();

            if ('' == $textarea_val) {
                return false;
            }

            var regexp = new RegExp('data-embed_trips_height = "\\d+%*(px)*"', 'gimu');

            var updated_height = $(this).val();
            var updated_string = $textarea_val.replace(regexp, 'data-embed_trips_height = "' + updated_height + '"');

            $('#wte-thirdparty-embedcode').val(updated_string);

        });

    })

    function WTECopyEmbedCode() {
        var copyText = document.getElementById("wte-thirdparty-embedcode");
        copyText.select();
        copyText.setSelectionRange(0, 99999);
        document.execCommand("copy");

        var tooltip = document.getElementById("wteCodeCopyToolTip");
        tooltip.innerHTML = "Copied: " + copyText.value;
    }

    function wteCopyEmbedOut() {
        var tooltip = document.getElementById("wteCodeCopyToolTip");
        tooltip.innerHTML = "Copy to clipboard";
    }

    $('#wteCodeCopyBtn').on('click', function (e) {

        e.preventDefault();

        WTECopyEmbedCode();

    });

    $('#wteCodeCopyBtn').on('mouseout', function (e) {

        e.preventDefault();

        wteCopyEmbedOut();

    });

})(jQuery);
