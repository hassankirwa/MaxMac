(function ($) {

    jQuery(document).ready(function($) {
        //tab js
        $(".trip-embeder-tab-wrap .trip-embeder-tab").on("click", function() {
            var tabId = $(this).attr("id");
            $(".trip-embeder-tab").removeClass("active");
            $(".trip-embeder-content").removeClass("active");
            $(this).addClass("active");
            $("#" + tabId + "-content").addClass("active");
        });
        
        $(".te-post-wrap.te-grid-layout .owl-carousel").owlCarousel({
            items: 3,
            // autoplay:true,
            // autoplayTimeout:5000,
            // autoplayHoverPause:true,
            margin: 30,
            loop: false,
            stagePadding: 25,
            nav: true,
            navText: [
                '<i class="fas fa-chevron-left"></i>',
                '<i class="fas fa-chevron-right"></i>'
            ],
            dots: false,
            responsive: {
                0: {
                    items: 1,
                    stagePadding: 20
                },
                768: {
                    items: 2,
                    stagePadding: 25
                },
                1025: {
                    items: 3
                }
            }
        });
    }); //document close

})(jQuery);
