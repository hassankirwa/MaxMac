/**
  * wpte-embed-handler.js
  *
  * Inserts an iframe into the DOM and calls the remote embed plugin
  * via a get parameter:
  * This is intercepted by the remote 'WP Travel Engine Trips Embedder' plugin
  *
  */
(function () {

    // Localize jQuery variable
    var jQuery;

    /* Load jQuery if not present */
    if (window.jQuery === undefined || window.jQuery.fn.jquery !== '1.7.2') {
        var script_tag = document.createElement('script');
        script_tag.setAttribute("type", "text/javascript");
        script_tag.setAttribute("src",
            "https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js");
        if (script_tag.readyState) {
            script_tag.onreadystatechange = function () { // For old versions of IE
                if (this.readyState == 'complete' || this.readyState == 'loaded') {
                    scriptLoadHandler();
                }
            };
        }
        else {
            script_tag.onload = scriptLoadHandler;
        }

        (document.getElementsByTagName("head")[0] || document.documentElement).appendChild(script_tag);
    }
    else {
        // The jQuery version on the window is the one we want to use
        jQuery = window.jQuery;
        main();
    }

    /* Called once jQuery has loaded */
    function scriptLoadHandler() {
        jQuery = window.jQuery.noConflict(true);
        main();
    }

    /* Our Start function */
    function main() {
        jQuery(document).ready(function ($) {

            $('.wte-embedder-prim-wrap').each(function ($) {

                /* Get 'embed' parameter from the query */
                var wte_trp_embed_id = jQuery(this).data('trp_embed_id');
                var wte_embed_source_site = jQuery(this).data('embed_source_site');
                var wte_embed_type = jQuery(this).data('embed_type');
                var wte_embed_ids_string = jQuery(this).data('embed_ids_string');
                var wte_embed_layout = jQuery(this).data('embed_layout');
                var wte_embed_posts_num = jQuery(this).data('embed_posts_num');
                var wte_embed_trips_param = jQuery(this).data('embed_trips_param');
                var wte_embed_frame_width = jQuery(this).data('embed_trips_width');
                var wte_embed_frame_height = jQuery(this).data('embed_trips_height');
                var wte_custom_type = jQuery(this).data('custom_type') || false;
                var wte_req_domain = encodeURIComponent(window.document.location);
                var wte_frame_no_scroll = 'grid' == wte_embed_layout ? 'scrolling="no"' : '';

                /* Set 'height' and 'width' according to the content type */
                var iframeContent = '<iframe width="' + wte_embed_frame_width + '" height="' + wte_embed_frame_height + '" frameborder="0" ' + wte_frame_no_scroll + ' src="' + wte_embed_source_site + '/?wte_trp_embed_id=' + wte_trp_embed_id + '&wte_embed_type=' + wte_embed_type + '&wte_embed_ids_string=' + wte_embed_ids_string + '&wte_embed_layout=' + wte_embed_layout + '&wte_embed_posts_num=' + wte_embed_posts_num + '&wte_req_domain=' + wte_req_domain + '&wte_embed_trips_param=' + wte_embed_trips_param + '&wte_custom_type=' + wte_custom_type + '"></iframe>';

                // console.log( iframeContent );

                jQuery(this).children('.wte-trips-embedder-ext-iframe-container').html(iframeContent);

                // jQuery("#wte-trips-embedder-" + wte_trp_embed_id ).html(iframeContent);


            });
        });
    }

})();
