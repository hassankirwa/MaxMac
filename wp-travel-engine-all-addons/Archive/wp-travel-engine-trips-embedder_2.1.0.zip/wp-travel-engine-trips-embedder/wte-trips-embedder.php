<?php
/**
 * Plugin Name: WP Travel Engine - Trips Embedder
 * Plugin URI: https://wptravelengine.com
 * Description: WP Travel Engine Trips Embedder is a custom addon for WP Travel Engine plugin that lets you embed trips data in various places inside post content editor and Gutenberg blocks.
 * Author: WP Travel Engine
 * Author URI: https://wptravelengine.com
 * Version: 2.1.0
 * License: GPL2+
 * License URI: https://www.gnu.org/licenses/gpl-2.0.txt
 * Domain Path: /i18n/languages/
 * WTE requires at least: 4.3.0
 * WTE tested up to: 5.3
 * WTE: 22896:wte_trips_embedder_license_key
 *
 * @package WTE Trips Embedder.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

defined( 'WTE_TRIPS_EMBEDDER_REQUIRES_AT_LEAST' ) || define( 'WTE_TRIPS_EMBEDDER_REQUIRES_AT_LEAST', '4.3.0' );

if ( ! class_exists( 'WTE_Trips_Embedder' ) ) :
	/**
	 * Class WTE_Trips_Embedder.
	 *
	 * @package WTE Trips Embedder.
	 */
	class WTE_Trips_Embedder {

		/**
		 * Plugin Name.
		 *
		 * @var string
		 */
		public $plugin_name = 'wte-trips-embedder';

		/**
		 * Version.
		 *
		 * @var string
		 */
		public $version = '2.1.0';

		/**
		 * The single instance of the class.
		 *
		 * @var string $_instance
		 */
		protected static $_instance = null;

		/**
		 * Main WTE_Trips_Embedder Instance.
		 * Ensures only one instance of WTE_Trips_Embedder is loaded or can be loaded.
		 *
		 * @return WTE_Trips_Embedder - Main instance.
		 */
		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}
			return self::$_instance;
		}

		/**
		 * Class Constructor.
		 */
		public function __construct() {
			$this->define_constants();
			add_action( 'admin_notices', array( $this, 'check_dependency' ) );
			if ( class_exists( 'WP_Travel_Engine' ) ) {
				$this->init_hooks();
			}
		}

		/**
		 * Plugin constants.
		 */
		private function define_constants() {
			$this->define( 'WTE_TRIPS_EMBEDDER_PLUGIN_FILE', __FILE__ );
			$this->define( 'WTE_TRIPS_EMBEDDER_ABSPATH', dirname( __FILE__ ) . '/' );
			$this->define( 'WTE_TRIPS_EMBEDDER_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
			$this->define( 'WTE_TRIPS_EMBEDDER_PLUGIN_PATH', untrailingslashit( plugin_dir_path( __FILE__ ) ) );
			$this->define( 'WTE_TRIPS_EMBEDDER_VERSION', $this->version );
		}

		/**
		 * Define constants.
		 *
		 * @param string $name Constant name.
		 * @param string $value Constant value.
		 */
		public function define( $name, $value ) {
			if ( ! defined( $name ) ) {
				define( $name, $value );
			}
		}

		/**
		 * Include  required function/ class files.
		 */
		private function includes() {

			include WTE_TRIPS_EMBEDDER_ABSPATH . '/includes/class-wte-trips-embedder-init.php';

			require_once WTE_TRIPS_EMBEDDER_ABSPATH . '/includes/class-wte-trips-embedder-external.php';

			require_once plugin_dir_path( __FILE__ ) . 'src/init.php';

			include WTE_TRIPS_EMBEDDER_ABSPATH . '/includes/wte-trips-embedder-helpers.php';

			if ( is_admin() ) {
				require_once WTE_TRIPS_EMBEDDER_ABSPATH . '/updater/wte-trips-embedder-updater.php';
			}
		}

		/**
		 * Hooks to init in start.
		 */
		public function init_hooks() {

			$this->includes();

			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

			add_action( 'after_setup_theme', array( $this, 'add_image_sizes' ) );

			add_action( 'init', array( $this, 'load_plugin_textdomain_embedder' ) );

		}

		/**
		 * Load plugin textdomain.
		 *
		 * @return void
		 */
		public function load_plugin_textdomain_embedder() {
			load_plugin_textdomain( 'wte-trips-embedder', false, dirname( plugin_basename( __FILE__ ) ) . '/i18n/languages' );
		}

		/**
		 * Add required image sizes for plugin list and grid.
		 *
		 * @return void
		 */
		public function add_image_sizes() {
			add_image_size( 'wte-embed-list-image', 252, 200, true );
			add_image_size( 'wte-embed-grid-image', 400, 300, true );
		}

		/**
		 * Enqueue frontend scripts and styles.
		 */
		public function enqueue_scripts() {

			$asset_script_path = '/min/';
			$version_prefix    = '-' . WTE_TRIPS_EMBEDDER_VERSION;

			if ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) {
				$asset_script_path = '/';
				$version_prefix    = '';
			}

			wp_enqueue_style( 'wte-trips-embedder-frontend', plugin_dir_url( WTE_TRIPS_EMBEDDER_PLUGIN_FILE ) . '/assets/css/public' . $asset_script_path . 'wte-trips-embedder-public' . $version_prefix . '.css', array(), WTE_TRIPS_EMBEDDER_VERSION, 'all' );

			wp_enqueue_style( 'owl-carousel', plugin_dir_url( WTE_TRIPS_EMBEDDER_PLUGIN_FILE ) . '/assets/vendors/owl-carousal/css/owl.carousel.min.css', array(), '2.3.4', 'all' );

			wp_enqueue_script( 'wte-trips-embedder-frontend', plugin_dir_url( WTE_TRIPS_EMBEDDER_PLUGIN_FILE ) . '/assets/js/public' . $asset_script_path . 'wte-trips-embedder-frontend' . $version_prefix . '.js', array( 'jquery' ), WTE_TRIPS_EMBEDDER_VERSION, true );

			wp_enqueue_script( 'owl-carousel', plugin_dir_url( WTE_TRIPS_EMBEDDER_PLUGIN_FILE ) . '/assets/vendors/owl-carousal/js/owl.carousel.min.js', array( 'jquery' ), '2.3.4', true );

		}

		/**
		 * This will uninstall this plugin if parent WP Travel plugin not found.
		 */
		public function check_dependency() {

			if ( ! class_exists( 'Wp_Travel_Engine' ) || ! $this->meets_requirements() ) {
				echo '<div class="error">';
				echo wp_kses_post( '<p><strong>WP Travel Engine - Trips Embedder</strong> requires the <a href="https://wptravelengine.com" target="__blank">WP Travel Engine</a> <b>version - 4.0.0 or later</b> to work. Please install and activate the latest WP Travel Engine plugin first. <b>WP Travel Engine - Trips Embedder will be deactivated now.</b></p>' );
				echo '</div>';

				// Deactivate Plugins.
				deactivate_plugins( plugin_basename( __FILE__ ) );
			}
		}

		/**
		 * Check if all plugin requirements are met.
		 *
		 * @since 1.0.0
		 *
		 * @return bool True if requirements are met, otherwise false.
		 */
		private function meets_requirements() {
			return ( class_exists( 'WP_Travel_Engine' ) && defined( 'WP_TRAVEL_ENGINE_VERSION' ) && version_compare( WP_TRAVEL_ENGINE_VERSION, '4.0.0', '>=' ) );
		}


	}

	/**
	 * Initiate WP Travel Engine trips Embedder addon.
	 */
	function wte_trips_embedder_init() {

		if ( ! defined( 'WP_TRAVEL_ENGINE_VERSION' ) || version_compare( WP_TRAVEL_ENGINE_VERSION, WTE_TRIPS_EMBEDDER_REQUIRES_AT_LEAST, '<' ) ) {
			add_action(
				'admin_notices',
				function() {
					echo wp_kses_post(
						sprintf(
							'<div class="error"><p>'
							// translators: 1. WTE Extension Name 2. Link to WTE Plugin.
							. sprintf( __( '%1$s requires the %2$s plugin to work. Please install and activate the latest <strong>WP Travel Engine</strong> plugin first.', 'wp-travel-engine-trips-embedder' ), '<strong>WP Travel Engine - Trips Embedder</strong>', '<a href="https://wptravelengine.com" target="__blank">WP Travel Engine</a>' )
							. '</p></div>'
						)
					);
				}
			);
		} else {
			return WTE_Trips_Embedder::instance();
		}

	}

	add_action( 'plugins_loaded', 'wte_trips_embedder_init' );
endif;
