=== WP Travel Engine - Trips Embedder ===
Contributors: wptravelengine
Plugin link: https://wptravelengine.com/
Tags: tour-booking, tour-operator, travel, travel-booking, travel-agency, travel-engine
Requires at least: 4.4.0
Tested up to: 5.9
Requires PHP: 5.6
Stable tag: 2.1.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

WP Travel Engine Trips Embedder is a custom addon for WP Travel Engine plugin that lets you embed trips data in various places inside post content editor and Gutenberg blocks.

== Description ==

WP Travel Engine Trips Embedder is a custom addon for WP Travel Engine plugin that lets you embed trips data in various places inside post content editor and Gutenberg blocks.

WP Travel Engine Trips Embedder addon requires WP Travel Engine plugin v. 4.0.0 or later installed and activated in the site.

== Changelog ==

= 2.1.0 =
Released on: 4th April, 2022
* Compatibility updates for WTE 5.0+
* Minor bug fixes

= 2.0.4 =
Released on: 6th May, 2021

Fixes:
* Fixed textdomain issue for translation support.
* Minor bug fixes.

= 2.0.3 =
Released on: 22nd December, 2020

Fixes:
* Added conditional checks for get_current_screen() function to resolve issues with Divi builder.
* Minor bug fixes.

= 2.0.2 =

Released on: 12th November, 2020

Fixes:

* Minor bug fixes.

= 2.0.1 =

Released on: 20th July, 2020

Enhancements:

* Domain path added for translations.

Fixes:

* Minor bug fixes.

= 2.0.0 =

Released on: 12th June, 2020

Enhancements:

* Revamped backend UI.
* Assets minification, optimization, and conditional loading.

Fixes:

* Minor bug fixes.

== 1.0.3 ==

Released on: 21st January, 2020

Fixes:

* Load admin assets only in allowed screens.
* Minor Bug Fixes

== 1.0.2 ==

Released on: 20th January, 2020

Fixes:

* Trip currency symbol and destination icons displayed for empty values issue fixed.
* Minor Bug Fixes

== 1.0.1 ==

Released on: 3rd December, 2019

Features:

* External Trip Embeds feature added

Fixes:

* Minor Bug Fixes

= 1.0.0 =

Released on: 8th November, 2019

* Initial Release
