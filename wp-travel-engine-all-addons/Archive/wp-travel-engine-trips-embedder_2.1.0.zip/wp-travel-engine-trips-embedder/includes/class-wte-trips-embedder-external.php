<?php
/**
 * External widget embed class
 * 
 * @package WTE_Trips_Embedder
 * 
 */
class WTE_Trips_Embedder_External  {
    
    /**
     * Class constructor.
     */
    public function __construct()
    {
        add_action( 'template_redirect', array( $this, 'catch_widget_query' ) );

        add_action( 'init', array( $this, 'register_trip_embeds' ) );
        
        add_action( 'init', array( $this, 'widget_add_vars' ) );

    }

    /**
     * Register trip embeds post type
     *
     * @return void
     */
    public function register_trip_embeds() {

        $labels = array(
			'name'               => _x( 'Embeds', 'post type general name', 'wp-travel-engine-trips-embedder' ),
			'singular_name'      => _x( 'Embed', 'post type singular name', 'wp-travel-engine-trips-embedder' ),
			'menu_name'          => _x( 'Embeds', 'admin menu', 'wp-travel-engine-trips-embedder' ),
			'name_admin_bar'     => _x( 'Embed', 'add new on admin bar', 'wp-travel-engine-trips-embedder' ),
			'add_new'            => _x( 'Add New', 'Embed', 'wp-travel-engine-trips-embedder' ),
			'add_new_item'       => __( 'Add New Embed', 'wp-travel-engine-trips-embedder' ),
			'new_item'           => __( 'New Embed', 'wp-travel-engine-trips-embedder' ),
			'edit_item'          => __( 'Edit Embed', 'wp-travel-engine-trips-embedder' ),
			'view_item'          => __( '', 'wp-travel-engine-trips-embedder' ),
			'all_items'          => __( 'External Embeds', 'wp-travel-engine-trips-embedder' ),
			'search_items'       => __( 'Search Embeds', 'wp-travel-engine-trips-embedder' ),
			'parent_item_colon'  => __( 'Parent Embeds:', 'wp-travel-engine-trips-embedder' ),
			'not_found'          => __( 'No Embeds found.', 'wp-travel-engine-trips-embedder' ),
			'not_found_in_trash' => __( 'No Embeds found in Trash.', 'wp-travel-engine-trips-embedder' )
		);

		$args = array(
			'labels'             => $labels,
            'description'        => __( 'Description.', 'wp-travel-engine-trips-embedder' ),
			'public'             => false,
			'publicly_queryable' => false,
			'show_ui'            => true,
			'show_in_menu'       => 'edit.php?post_type=booking',
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'wte-embed' ),
			'capability_type'    => 'post',
            'map_meta_cap'       => true,
			'has_archive'        => false,
			'hierarchical'       => false,
			'menu_position'      => null,
			'supports'           => array( 'title' )
		);

		register_post_type( 'wte-embed', $args );
		flush_rewrite_rules();

    }
    
    /**
     * Add widget vars to global $wp
     *
     * @return void
     */
    public function widget_add_vars() { 

        global $wp; 

        $wp->add_query_var( 'wte_trp_embed_id' );
        $wp->add_query_var( 'wte_embed_trips_param' );
        $wp->add_query_var( 'wte_embed_type' );
        $wp->add_query_var( 'wte_embed_ids_string' );
        $wp->add_query_var( 'wte_custom_type' );
        $wp->add_query_var( 'wte_embed_posts_num' );
        $wp->add_query_var( 'wte_embed_layout' );
        $wp->add_query_var( 'wte_req_domain' );

    }

    /**
     * Export embed trips data.
     *
     * @return void
     */
    private function export_trips( $args = array() ) {

        if ( empty( $args ) ) return;

        ob_start();
        
        ?>
            <html>

                <head>

                    <meta name="robots" content="noindex,nofollow">

                    <link rel="stylesheet" id="wte-trips-embedder-frontend-css-css"  href="<?php echo esc_url( plugin_dir_url( WTE_TRIPS_EMBEDDER_PLUGIN_FILE ) ) ?>assets/css/public/wte-trips-embedder-public.css?ver=<?php echo esc_attr(WTE_TRIPS_EMBEDDER_VERSION ) ?>" type="text/css" media="all" />

                    <link rel="stylesheet" id="owl-carousal-css-css"  href="<?php echo esc_url( plugin_dir_url( WTE_TRIPS_EMBEDDER_PLUGIN_FILE ) ) ?>assets/vendors/owl-carousal/css/owl.carousel.min.css?ver=<?php echo esc_attr( WTE_TRIPS_EMBEDDER_VERSION ) ?>" type="text/css" media="all" />

                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.4/jquery.rateyo.min.css" integrity="sha256-ID13vwlZpwd7LC7cqFBO4jHdT38C6nBb58Ae8b9P2oM=" crossorigin="anonymous" />
                
                </head>

                <body>

                    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>

                    <script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.4/jquery.rateyo.min.js" integrity="sha256-p6ZD8Ci86YyOjS7LHXKInKWMKnF1NeVWJKXqe2NQ+Wo=" crossorigin="anonymous"></script>
                    
                        <?php

                            $num_posts_param = 'false' != $args['posts_num'] ? ' postsnumber="'. $args['posts_num'] .'"' : '';

                            if ( $args['custom_type'] ) {
                                echo do_shortcode( '[' . esc_attr( $args['shortcode_base'] ) .' layout="'. $args['layout'] .'" '. esc_attr( $args['trips_param'] ) .'="' . esc_attr( $args['ids_string'] ) . '" custom_type="' . $args['custom_type'] . '" '. $num_posts_param .' nofollow="true"]' );
                            } else {
                                echo do_shortcode( '[' . esc_attr( $args['shortcode_base'] ) .' layout="'. $args['layout'] .'" '. esc_attr( $args['trips_param'] ) .'="' . esc_attr( $args['ids_string'] ) . '"'. $num_posts_param .' nofollow="true"]' );
                            }

                            
                        ?>

                    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js" integrity="sha256-qM7QTJSlvtPSxVRjVWNM2OfTAz/3k5ovHOKmKXuYMO4=" crossorigin="anonymous"></script>
                    
                    <script type='text/javascript' src='<?php echo esc_url( plugin_dir_url( WTE_TRIPS_EMBEDDER_PLUGIN_FILE ) ) ?>assets/js/public/wte-trips-embedder-frontend.js?ver=<?php echo esc_attr(WTE_TRIPS_EMBEDDER_VERSION ) ?>'></script>

                    <script type='text/javascript' src='<?php echo esc_url( plugin_dir_url( WTE_TRIPS_EMBEDDER_PLUGIN_FILE ) ) ?>assets/vendors/owl-carousal/js/owl.carousel.min.js?ver=<?php echo esc_attr(WTE_TRIPS_EMBEDDER_VERSION ) ?>'></script>

                </body>

            </html>

        <?php 

        $outstring = ob_get_clean();

        return $outstring;

    }

    /**
     * Catches our query variable. If it’s there, we’ll stop the
     * rest of WordPress from loading and do our thing, whatever 
     * that may be.
     */
    public function catch_widget_query() {

        /* If no 'embed' parameter found, return */
        if( ! get_query_var( 'wte_trp_embed_id' ) || ! get_query_var( 'wte_embed_type' ) || ! get_query_var( 'wte_embed_ids_string' ) || ! get_query_var( 'wte_embed_layout' ) || ! get_query_var( 'wte_embed_posts_num' ) ) :
            return;
        endif;

        $wte_trp_embed_id      = get_query_var( 'wte_trp_embed_id' );
        $wte_embed_type        = get_query_var( 'wte_embed_type' );
        $wte_embed_ids_string  = get_query_var( 'wte_embed_ids_string' );
        $wte_embed_layout      = get_query_var( 'wte_embed_layout' );
        $wte_embed_posts_num   = get_query_var( 'wte_embed_posts_num' );
        $wte_req_domain        = get_query_var( 'wte_req_domain' );
        $wte_embed_trips_param = get_query_var( 'wte_embed_trips_param' );
        $wte_custom_type       = get_query_var( 'wte_custom_type' ) ? get_query_var( 'wte_custom_type' ) : false;


        if( ! empty( $wte_trp_embed_id ) && get_post_type( $wte_trp_embed_id ) == 'wte-embed' ) {


            $wte_trp_embds = get_post_meta( $wte_trp_embed_id, 'wte_trp_embds', true );
            $allowed_sites = isset( $wte_trp_embds['allowed_sites'] ) && ! empty( $wte_trp_embds['allowed_sites'] ) ? $wte_trp_embds['allowed_sites'] : array();

            if ( ! empty( $allowed_sites ) && ! empty( $wte_req_domain ) ) :

                
                $allowed_sites       = array_map( 'parse_url', $allowed_sites );
                $wte_req_domain_host = parse_url( $wte_req_domain );
                $allowed_sites       = array_column( $allowed_sites, 'host' );

                // Bail if not allowed.
                if ( ! in_array( $wte_req_domain_host['host'], $allowed_sites ) ) {

                    echo esc_html__( 'This domain is not registered to display trips embedder content.', 'wp-travel-engine-trips-embedder' );

                    exit();
                }

            endif;

            $args = array(
                'shortcode_base' => $wte_embed_type,
                'trips_param'    => $wte_embed_trips_param,
                'layout'         => $wte_embed_layout,
                'ids_string'     => $wte_embed_ids_string,
                'posts_num'      => $wte_embed_posts_num,
                'custom_type'    => $wte_custom_type
            );

            $data_to_embed = $this->export_trips( $args );
            
            echo $data_to_embed;
        
        }

        exit();
    }
}

$widget = new WTE_Trips_Embedder_External();
