<?php
/**
 * WTE Trips Embedder helpers.
 * 
 * @package WTE_Trips_Embedder
 */
/**
 * Return template.
 *
 * @param  String $template_name Path of template.
 * @param  array  $args arguments.
 * @return Mixed
 */
function wte_trips_embedder_get_template( $template_name, $args = array() ) {
	$template_path = apply_filters( 'wte_trips_embedder_template_path', 'wte-trips-embedder/' );
	$default_path  = sprintf( '%s/templates/', plugin_dir_path( dirname( __FILE__ ) ) );

	// Look templates in theme first.
	$template = locate_template(
		array(
			trailingslashit( $template_path ) . $template_name,
			$template_name,
		)
	);
	if ( ! $template ) {
		$template = $default_path . $template_name;
	}
	if ( file_exists( $template ) ) {
		return $template;
	}
	return false;
}

/**
 * Like wte_trips_embedder_get_template, but returns the HTML instead of outputting.
 *
 * @see wte_trips_embedder_get_template
 * @since 1.0.0
 * @param string $template_name Template name.
 * @param array  $args          Arguments. (default: array).
 *
 * @return string
 */
function wte_trips_embedder_get_template_html( $template_name, $args = array() ) {
	ob_start();
	if ( ! empty( $args ) && is_array( $args ) ) {
		extract( $args ); // @codingStandardsIgnoreLine
	}
	include wte_trips_embedder_get_template( $template_name );
	return ob_get_clean();
}

/**
 * Get Template Part.
 *
 * @param  String $slug Name of slug.
 * @param  string $name Name of file / template.
 */
function wte_trips_embedder_get_template_part( $slug, $name = '' ) {
	$template  = '';
	$file_name = ( $name ) ? "{$slug}-{$name}.php" : "{$slug}.php";
	if ( $name ) {
		$template = wte_trips_embedder_get_template( $file_name );
	}
	if ( $template ) {
		load_template( $template, false );
	}
}

/**
 * Load Template
 *
 * @param  String $path Path of template.
 * @param  array  $args Template arguments.
 */
function wte_trips_embedder_load_template( $path, $args = array() ) {
	$template = wte_trips_embedder_get_template( $path, $args );
	if ( $template ) {
		include $template;
	}
}

/**
 * Get discount percent
 * 
 * @param $trip_id
 */
function wte_trips_embedder_get_discount_percent( $trip_id ) {
	
	// Bail if no trip found.
	if ( ! isset( $trip_id ) || empty ( $trip_id ) )
		return false;

	// Bail if not a trip.
	if( 'trip' !== get_post_type( $trip_id ) ) 
		return false;

	$wte           = new Wp_Travel_Engine_Functions();
	$trip_settings = get_post_meta( $trip_id, 'wp_travel_engine_setting', true );

	$trip_price = isset( $trip_settings['trip_prev_price'] ) ? $trip_settings['trip_prev_price']: 0;

	if( $trip_price != '' && isset( $trip_settings['sale'] ) ) {

		$sale_price       = isset( $trip_settings['trip_price'] ) ? $trip_settings['trip_price']: 0;
		$discount_percent = ( ( $trip_price - $sale_price )*100 ) /$trip_price;

		return round( $discount_percent );
		
	}

	return false;

}

/**
 * get term lists.
 *
 * @param [type] $id
 * @param [type] $taxonomy
 * @param string $before
 * @param string $sep
 * @param string $after
 * @return void
 */
function wte_get_the_term_list( $id, $taxonomy, $before = '', $sep = '', $after = '', $nofollow = false ) {
	
	$terms = get_the_terms( $id, $taxonomy );

	if ( is_wp_error( $terms ) ) {
		return $terms;
	}

	if ( empty( $terms ) ) {
		return false;
	}

	$nof_attr = $nofollow ? 'rel=nofollow' : 'rel=tag';
	$target   = $nofollow ? '_blank' : '_self';

	$links = array();

	foreach ( $terms as $term ) {
		$link = get_term_link( $term, $taxonomy );
		if ( is_wp_error( $link ) ) {
			return $link;
		}
		$links[] = '<a ' . esc_attr( $nof_attr ) . ' target="' . esc_attr( $target ) . '" href="' . esc_url( $link ) . '" >' . $term->name . '</a>';
	}

	/**
	 * Filters the term links for a given taxonomy.
	 *
	 * The dynamic portion of the filter name, `$taxonomy`, refers
	 * to the taxonomy slug.
	 *
	 * @since 2.5.0
	 *
	 * @param string[] $links An array of term links.
	 */
	$term_links = apply_filters( "term_links-{$taxonomy}", $links );  // phpcs:ignore WordPress.NamingConventions.ValidHookName.UseUnderscores

	return $before . join( $sep, $term_links ) . $after;
}
