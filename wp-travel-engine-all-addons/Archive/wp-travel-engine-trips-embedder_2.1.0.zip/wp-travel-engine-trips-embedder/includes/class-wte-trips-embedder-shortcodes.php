<?php
/**
 * WP Travel Engine Shortcode class
 * 
 * @package WTE_Trips_Embedder
 */
class WTE_Trips_Embedder_Shortcodes {

    /**
     * Class Constructor
     */
    public function __construct() {

        $this->init_hooks();

    }

    /**
     * init hooks for the shortcode class.
     *
     * @return void
     */
    public function init_hooks() {

        add_shortcode( 'wte_trips_embedder_trips', array( $this, 'wte_trips_embedder_trips_render' ) );
        add_shortcode( 'wte_trips_embedder_tax', array( $this, 'wte_trips_embedder_tax_render' ) );

    }

    /**
     * Render the trips embedder shortcode output.
     *
     * @param [type] $atts
     * @return void
     */
    public function wte_trips_embedder_trips_render( $atts ) {
        
        $atts = shortcode_atts( array(
            'ids'      => '',
            'layout'   => 'grid',
            'nofollow' => false,
        ), $atts, 'wte_trips_embedder_trips' );
        
        if ( ! empty( $atts['ids'] ) ) {
            
            $ids         = array();
            $ids         = explode(",", $atts['ids']);
            $atts['ids'] = $ids;
        
        }
        
        ob_start();

        $args = array(
            'offset'           => 0,
			'orderby'          => 'date',
			'order'            => 'DESC',
			'post_type'        => 'trip',
			'post_status'      => 'publish',
			'suppress_filters' => true,
        );

        if ( ! empty( $atts['ids'] ) ) {
            $args['post__in'] = $atts['ids'];
            $args['orderby']  = 'post__in';
        }
        
        $query = new WP_Query( $args );
        
        if ( $query->have_posts() ) :

            ?>

            <div class="te-post-wrap te-<?php echo esc_attr( $atts['layout'] ); ?>-layout">
				<?php if ( 'grid' === $atts['layout'] ) : ?>
					<div class="owl-carousel">
				<?php endif;

                    while( $query->have_posts() ) : $query->the_post();

                        echo wte_trips_embedder_get_template_html( 'wte-embed.php', $atts );

                    endwhile; wp_reset_postdata();

                if ( 'grid' === $atts['layout'] ) : ?>
					</div>
				<?php endif; ?>

            </div>

            <?php

        else :

            esc_html_e( 'Np Trips Found', 'wp-travel-engine-trips-embedder' );

        endif;

        $data = ob_get_clean();

        return $data;

    }

    /**
     * Render the trips embedder shortcode output.
     *
     * @param [type] $atts
     * @return void
     */
    public function wte_trips_embedder_tax_render( $atts ) {

        $atts = shortcode_atts( array(
            'activities'  => '',
            'destination' => '',
            'trip_types'  => '',
            'layout'      => 'grid',
            'postsnumber' => get_option( 'posts_per_page' ),
            'nofollow'    => false,
            'custom_type' => false,
            'custom_terms' => '',
        ), $atts, 'wte_trips_embedder_tax' );

        if ( ! empty( $atts['activities'] ) ) {
            $activities         = array();
            $activities         = explode(",", $atts['activities']);
            $atts['activities'] = $activities;
        }

        if ( ! empty( $atts['destination'] ) ) {
            $destination         = array();
            $destination         = explode(",", $atts['destination']);
            $atts['destination'] = $destination;
        }

        if ( ! empty( $atts['trip_types'] ) ) {
            $trip_types         = array();
            $trip_types         = explode(",", $atts['trip_types']);
            $atts['trip_types'] = $trip_types;
        }

        ob_start();

        if(! empty( $atts['activities'] ) || ! empty( $atts['destination'] ) || ! empty( $atts['trip_types'] ) || $atts['custom_type'] )
        {
            $paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
            $default_posts_per_page = get_option( 'posts_per_page' );
            // Query arguments.
            $args = array(
                'post_type'                     => 'trip',
                'posts_per_page'                => $atts['postsnumber'],
                'wpse_search_or_tax_query'      => true,
                'paged'                         => $paged
            );

            $taxquery = array('relation' => 'OR');
            if ( ! empty( $atts['activities'] ) ) {
                array_push($taxquery,array(
                        'taxonomy'         => 'activities',
                        'field'            => 'term_id',
                        'terms'            => $atts['activities'],
                        'include_children' => true,
                    ));
            }
            if ( ! empty( $atts['destination'] ) ) {
                array_push($taxquery,array(
                        'taxonomy'         => 'destination',
                        'field'            => 'term_id',
                        'terms'            => $atts['destination'],
                        'include_children' => true,
                    ));
            }
            if ( ! empty( $atts['trip_types'] ) ) {
                array_push($taxquery,array(
                        'taxonomy'         => 'trip_types',
                        'field'            => 'term_id',
                        'terms'            => $atts['trip_types'],
                        'include_children' => true,
                    ));
            }

            if( $atts['custom_type'] ){
                array_push($taxquery,array(
                        'taxonomy'         => $atts['custom_type'],
                        'field'            => 'term_id',
                        'terms'            => $atts['custom_terms'],
                        'include_children' => true,
                    ));
            }

            if(!empty($taxquery))
            {
                $args['tax_query'] = $taxquery;
            }
            $query = new WP_Query( $args );
        }


        if ( $query->have_posts() ) :

            ?>

            <div class="te-post-wrap te-<?php echo esc_attr( $atts['layout'] ); ?>-layout">
				<?php if ( 'grid' === $atts['layout'] ) : ?>
					<div class="owl-carousel">
				<?php endif;

                    while( $query->have_posts() ) : $query->the_post();

                        echo wte_trips_embedder_get_template_html( 'wte-embed.php', $atts );

                    endwhile; wp_reset_postdata();

                if ( 'grid' === $atts['layout'] ) : ?>
					</div>
				<?php endif; ?>

            </div>

            <?php

        else :

            esc_html_e( 'Np Trips Found', 'wp-travel-engine-trips-embedder' );

        endif;


        $data = ob_get_clean();

        return $data;

    }


}
new WTE_Trips_Embedder_Shortcodes();
