<?php
/**
 * WP Travel Engine Trips Embedder init class
 */
class WTE_Trips_Embedder_Init {

    // Var Allowed screens.
    private $allowed_screens = array( 'post', 'page', 'trip', 'wte-embed' );

    /**
     * Class Constructor.
     */
    public function __construct() {
        $this->init_hooks();
        $this->includes();
    }

    /**
     * Includes for the section.
     *
     * @return void
     */
    public function includes() {

        include WTE_TRIPS_EMBEDDER_ABSPATH . '/includes/class-wte-trips-embedder-shortcodes.php';

    }

    /**
     * Init hooks for the tinymce buttons.
     *
     * @return void
     */
    public function init_hooks() {
        
        add_action( 'admin_head', array( $this, 'wte_register_custom_mce_buttons' ) );

        add_action( 'admin_enqueue_scripts', array( $this, 'wte_add_admin_scripts' ) );

        add_action( 'add_meta_boxes', array( $this, 'wte_register_custom_mce_metabox_buttons' ) );

        add_action( 'media_buttons', array( $this, 'add_editor_beside_media_btn' ) );

        add_action( 'save_post', array( $this, 'save_trip_embed_data' ) );

    }

    /**
     * Add  additional button beside the Addmedia button on editor.
     */
    public function add_editor_beside_media_btn( $editor_id ){

        if ( ! function_exists( 'get_current_screen' ) ) {
            return;
        }

        $screen = get_current_screen();

        if ( isset( $screen->post_type ) && in_array( $screen->post_type, $this->allowed_screens ) ) :

            echo '<a title="'. esc_html__( 'WP Travel Engine - Trips Embedder', 'wp-travel-engine-trips-embedder' ) .'" id="wte-media-btn-trop-embed" href="#" class="button"><i class="dashicons dashicons-location-alt"></i>'. esc_html__( 'Trips Embedder', 'wp-travel-engine-trips-embedder' ) .'</a>';

        endif;
    }

    /**
     * Add metabox to hold the custom screen.
     *
     * @return void
     */
    public function wte_register_custom_mce_metabox_buttons() {
        add_meta_box( 'wte-trips-embedder-metabox', __( 'WTE Trips Embedder Metabox', 'wp-travel-engine-trips-embedder' ), array( $this, 'wte_trips_embedder_mb_callback' ), $this->allowed_screens );
    }

    /**
     * Add admin side scripts.
     *
     * @return void
     */
    public function wte_add_admin_scripts() {

        $screen = get_current_screen();

        if ( isset( $screen->post_type ) && in_array( $screen->post_type, $this->allowed_screens ) ) :
        
            wp_enqueue_style( 'jquery-rateyo', plugin_dir_url( WTE_TRIPS_EMBEDDER_PLUGIN_FILE )  .'/assets/css/admin/rateyo.css' );
            
            wp_enqueue_style( 'bootstrap', plugin_dir_url( WTE_TRIPS_EMBEDDER_PLUGIN_FILE )  .'/assets/vendors/bootstrap/css/bootstrap.css' );
            
            wp_enqueue_style( 'wte-trips-embedder-admin', plugin_dir_url( WTE_TRIPS_EMBEDDER_PLUGIN_FILE )  .'/assets/css/admin/wte-trips-embedder-admin.css' );

            wp_enqueue_style( 'tagify-core', plugin_dir_url( WTE_TRIPS_EMBEDDER_PLUGIN_FILE )  .'/assets/css/admin/tagify-core.css' );

            wp_enqueue_script( 'tagify-core', plugin_dir_url( WTE_TRIPS_EMBEDDER_PLUGIN_FILE )  .'/assets/js/admin/tagify-core.js', array( 'jquery' ), '2.31.6', true );
            
            wp_enqueue_script( 'bootstrap', plugin_dir_url( WTE_TRIPS_EMBEDDER_PLUGIN_FILE )  .'/assets/vendors/bootstrap/js/bootstrap.min.js', array( 'jquery' ), '3.4.1', true );
            
            wp_register_script( 'wpte-embedder-custom', plugin_dir_url( WTE_TRIPS_EMBEDDER_PLUGIN_FILE )  .'/assets/js/admin/wte-trips-embedder-backend.js', array( 'jquery', 'bootstrap', 'wp-tinymce', 'tagify-core', 'wp-util' ), WTE_TRIPS_EMBEDDER_VERSION, true );

            global $post;

            $post_id = isset( $post->ID ) ? $post->ID : 0;

            wp_localize_script( 'wpte-embedder-custom', 'wpte_embedder', array( 'postID' => $post_id, 'source_url' => esc_url( home_url( '/' ) ), 'plugin_url' => esc_url( plugin_dir_url( WTE_TRIPS_EMBEDDER_PLUGIN_FILE ) ) ) );

            wp_enqueue_script( 'wpte-embedder-custom' );

            wp_enqueue_script( 'all', plugin_dir_url( WTE_TRIPS_EMBEDDER_PLUGIN_FILE )  .'/assets/vendors/fontawesome/all.js', array( 'jquery' ), '5.11.2', true );

        endif;

    }

    /**
     * Metabox callback.
     *
     * @return void
     */
    public function wte_trips_embedder_mb_callback( $post ) {        
        
        $screen = get_current_screen();

            // Allow only in wte embed edit.
            if ( 'wte-embed' === $screen->id ) :

            global $post;
            $wte_post_id = $post->ID;

            $wte_trp_embds               = get_post_meta( $wte_post_id, 'wte_trp_embds', true );
            $wte_trp_embds_code          = isset( $wte_trp_embds['embed_script'] ) && ! empty( $wte_trp_embds['embed_script'] ) ? $wte_trp_embds['embed_script'] : '';
            $wte_trp_embds_width         = isset( $wte_trp_embds['iframe_width'] ) && ! empty( $wte_trp_embds['iframe_width'] ) ? $wte_trp_embds['iframe_width'] : '100%';
            $wte_trp_embds_height        = isset( $wte_trp_embds['iframe_height'] ) && ! empty( $wte_trp_embds['iframe_height'] ) ? $wte_trp_embds['iframe_height'] : '500px';
            $wte_trp_embds_allowed_sites = isset( $wte_trp_embds['allowed_sites'] ) && ! empty( $wte_trp_embds['allowed_sites'] ) ? $wte_trp_embds['allowed_sites'] : array();

        ?>
                <table id="wte-trp-embdr-settings-tbl">

                    <tr>
                        <td>
                            <label><?php esc_html_e( 'Embed Size', 'wp-travel-engine-trips-embedder' ) ?></label><br>
                            <i><?php esc_html_e( 'Enter height and width values ( in px or % ) for the embed iframe size.', 'wp-travel-engine-trips-embedder' ); ?></i><br>
                            <i><strong><?php esc_html_e( ' Please make sure to copy the code again if height and width values are changed.', 'wp-travel-engine-trips-embedder' ); ?></strong></i>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <span><label for="wte_embed_iframe_width"><?php esc_html_e( 'Width: ', 'wp-travel-engine-trips-embedder' ); ?></label><input required value="<?php echo esc_attr( $wte_trp_embds_width ); ?>" name="wte_trp_embds[iframe_width]" id="wte_embed_iframe_width" type="text"></span>
                            <span><label for="wte_embed_iframe_height"><?php esc_html_e( 'Height: ', 'wp-travel-engine-trips-embedder' ); ?></label><input required value="<?php echo esc_attr( $wte_trp_embds_height ); ?>" name="wte_trp_embds[iframe_height]" id="wte_embed_iframe_height" type="text"></span>
                        </td>
                    </tr>

                    <tr>
                        <td><?php echo '<a title="'. esc_html__( 'WP Travel Engine - Trips Embedder', 'wp-travel-engine-trips-embedder' ) .'" id="wte-media-btn-trop-embed" href="#" class="button"><i class="dashicons dashicons-location-alt"></i>'. esc_html__( ' Create Embed Code', 'wp-travel-engine-trips-embedder' ) .'</a>'; ?>

                        <div class="tooltip">
                            <button class="button" id="wteCodeCopyBtn">
                                <span class="tooltiptext" id="wteCodeCopyToolTip"><?php esc_html_e( 'Copy to clipboard', 'wp-travel-engine-trips-embedder' ); ?></span>
                                <i class="dashicons dashicons-admin-page"></i><?php esc_html_e( 'Copy code', 'wp-travel-engine-trips-embedder' ); ?>
                            </button>
                        </div>
                    </td>
                    </tr>

                    <tr>
                        <td>
                            <textarea name="wte_trp_embds[embed_script]" readonly="readonly" rows="10" cols="60" id="wte-thirdparty-embedcode"><?php echo $wte_trp_embds_code; ?></textarea>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <label for="wte_trp_embed_allowed_sites"><?php esc_html_e( 'Allowed URLs:', 'wp-travel-engine-trips-embedder' ); ?></label><br>
                            <i><?php esc_html_e( 'Enter comma separated URLs to restrict embed on selected domains only. Leave blank to remove restriction!!', 'wp-travel-engine-trips-embedder' ); ?></i>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <input id="wte_trp_embed_allowed_sites" name="wte_trp_embds[allowed_sites]" value='<?php echo esc_attr( implode( ',', $wte_trp_embds_allowed_sites ) ); ?>'>
                            <input id="wte_trp_embed_allowed_sites_val" value="<?php echo esc_attr( implode( ',', $wte_trp_embds_allowed_sites ) ); ?>" name="wte_trp_embds[allowed_sites]" type="hidden">
                            <!-- <button class='tags-jquery--removeAllBtn' type='button'><?php esc_html_e( 'Clear URLs', 'wp-travel-engine-trips-embedder' ); ?></button> -->
                        </td>
                        <?php wp_nonce_field( 'wpte_trip_embed_save_data_action', 'wpte_trip_embed_save_data' ); ?>
                    </tr>

                </table>

        <?php
            endif;

            $filters = get_option( 'wte_custom_filters', array() );
        ?>

        <!-- Modal -->
        <div class="modal fade" id="wteEmbedderDialog" tabindex="-1" role="dialog" aria-labelledby="wteEmbedderDialogTitle" aria-hidden="true">
        <div class="modal-dialog modal-xl" style="" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="wteEmbedderDialogTitle"><?php esc_html_e( 'WP Travel Engine - Trips Embedder', 'wp-travel-engine-trips-embedder' ); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="trip-embeder-popup-outer">
                        <div class="trip-embeder-popup-inner">
                            <div class="trip-embeder-tab-block">
                                <div class="trip-embeder-tab-wrap">
                                    <div class="te-tab-inner">
                                        <button id="te-tab1" class="trip-embeder-tab active"><?php esc_html_e( 'Trips', 'wp-travel-engine-trips-embedder' ); ?></button>
                                        <button id="te-tab2" class="trip-embeder-tab"><?php esc_html_e( 'Destinations', 'wp-travel-engine-trips-embedder' ); ?></button>
                                        <button id="te-tab3" class="trip-embeder-tab"><?php esc_html_e( 'Activities', 'wp-travel-engine-trips-embedder' ); ?></button>
                                        <button id="te-tab4" class="trip-embeder-tab"><?php esc_html_e( 'Trip Type', 'wp-travel-engine-trips-embedder' ); ?></button>
                                        <?php
                                            if ( count( $filters ) > 0 ) :
                                                foreach ( $filters as $filter ) :
                                                    echo '<button id="te-tab'. $filter['slug'] .'" data-filter-slug="'. $filter['slug'] .'" class="trip-embeder-tab">'. $filter['label'] .'</button>';
                                                endforeach;
                                            endif;
                                        ?>
                                    </div>
                                </div>
                                <div class="trip-embeder-content-wrap">
                                    <div id="te-tab1-content" class="trip-embeder-content active">
                                        <h4><?php esc_html_e( 'Trips', 'wp-travel-engine-trips-embedder' ); ?></h4>
                                        <div class="trip-embeder-cols">
                                        <?php

                                            $trips_query_args = array(
                                                'post_type'      => 'trip',
                                                'posts_per_page' => -1,
                                                'orderby'        => 'title',
                                                'order'          => 'ASC',
                                            );
                                            $trips_query = new WP_Query( $trips_query_args );

                                        if ( $trips_query->have_posts() ) :

                                        ?>
                                            <div class="trip-embeder-col">
                                                <div class="trip-embeder-search">
                                                    <div class="trip-embeder-form">
                                                        <label>
                                                            <span class="screen-reader-text"><?php esc_html_e( 'Search for:', 'wp-travel-engine-trips-embedder' ); ?></span>
                                                            <input class="search-field" placeholder="<?php esc_attr_e( 'Search...', 'wp-travel-engine-trips-embedder' ); ?>" value="" name="SearchDualList" type="search">
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="trip-embeder-select-fields list-left">
                                                    <h5><?php esc_html_e( 'Select Trips...', 'wp-travel-engine-trips-embedder' ); ?></h5>
                                                    <div class="trip-embeder-select dual-list">
                                                        <ul class="te-trip-list list-group">
                                                            <?php while( $trips_query->have_posts() ) : $trips_query->the_post(); 
                                                            
                                                            $trip_base_title = get_the_title();
                                                            
                                                            ?>
                                                                <li data-id="<?php echo esc_attr( sanitize_title( get_the_title() ) ); ?>_<?php echo esc_attr( get_the_ID() ); ?>" data-trip-id="<?php echo esc_attr( get_the_ID() ); ?>" data-trip-title="<?php the_title(); ?>" class="list-group-item">
                                                                    <input id="<?php echo esc_attr( sanitize_title( get_the_title() ) ); ?>_<?php echo esc_attr( get_the_ID() ); ?>" type="checkbox" name="<?php echo esc_attr( sanitize_title( get_the_title() ) ); ?>_<?php echo esc_attr( get_the_ID() ); ?>">
                                                                    <label for="<?php echo esc_attr( sanitize_title( get_the_title() ) ); ?>_<?php echo esc_attr( get_the_ID() ); ?>"><?php the_title(); ?></label>
                                                                </li>
                                                            <?php endwhile; wp_reset_postdata(); ?>
                                                            <li style="display:none;" class="no-results"><?php esc_html_e( 'No trips found', 'wp-travel-engine-trips-embedder' ); ?></li>
                                                        </ul>
                                                    </div>					
                                                </div>
                                                <div class="list-arrows col-md-1 text-center">
                                                    <button class="btn btn-default btn-sm move-right">
                                                        <?php esc_html_e('Add to selected trips', 'wp-travel-engine-trips-embedder'); ?>
                                                    </button>
                                                </div>
                                            </div>
                                        <?php 

                                        else :

                                            esc_html_e( 'No trips found.', 'wp-travel-engine-trips-embedder' );
                                    
                                        endif; ?>

                                            <div class="trip-embeder-col trip-embeder-selected list-right">
                                                <h5><?php esc_html_e( 'Total Selected Trips', 'wp-travel-engine-trips-embedder' ) ?> <span class="trip-embeder-count"><?php echo esc_html__( '0', 'wp-travel-engine-trips-embedder' ); ?></span></h5>
                                                <ul class="te-selected-list wte-sel-trips wte-em-sortable">
                                                    
                                                </ul>
                                            </div>  
                                        </div>
                                    </div>

                                    <div id="te-tab2-content" class="trip-embeder-content">
                                        <h4><?php esc_html_e( 'Destinations', 'wp-travel-engine-trips-embedder' ); ?></h4>
                                        <div class="trip-embeder-cols">
                                        <?php 

                                            $destinations         = get_terms('destination', array('hide_empty' => false));
                                            $destinationHierarchy = array();
                                            $this->sort_terms_hierarchicaly( $destinations, $destinationHierarchy );

                                        if( ! empty( $destinationHierarchy ) ) :

                                        ?>
                                            <div class="trip-embeder-col">
                                                <div class="trip-embeder-search">
                                                    <div class="trip-embeder-form">
                                                        <label>
                                                            <span class="screen-reader-text"><?php esc_html_e( 'Search for:', 'wp-travel-engine-trips-embedder' ); ?></span>
                                                            <input class="search-field" placeholder="<?php esc_attr_e( 'Search...', 'wp-travel-engine-trips-embedder' ); ?>" value="" name="SearchDualList" type="search">
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="trip-embeder-select-fields list-left">
                                                    <h5><?php esc_html_e( 'Select Destinations...', 'wp-travel-engine-trips-embedder' ); ?></h5>
                                                    <div class="trip-embeder-select dual-list">
                                                        
                                                        <?php 
                                                            /**
                                                             * Display template.
                                                             */
                                                            $this->display_taxonomy_template( $destinationHierarchy, false );
                                                        ?>

                                                    </div>					
                                                </div>
                                                <div class="list-arrows col-md-1 text-center">
                                                    <div class="wte-posts-num-wrap move-left">
                                                        <label for="wte-destination-posts"><?php echo esc_html__( 'No. of posts', 'wp-travel-engine-trips-embedder' ); ?></label>
                                                        <input class="wte-numberOfposts-val" type="number" name="wte-destination-posts" min="1" id="wte-destination-posts">
                                                    </div>
                                                    <button class="btn btn-default btn-sm move-right">
                                                        <?php esc_html_e('Add to selected destinations', 'wp-travel-engine-trips-embedder'); ?>
                                                    </button>
                                                </div>
                                            </div>
                                        <?php 

                                        else :

                                            esc_html_e( 'No destinations found', 'wp-travel-engine-trips-embedder' );
                                    
                                        endif; ?>

                                            <div class="trip-embeder-col trip-embeder-selected list-right">
                                                <h5><?php esc_html_e( 'Total Selected Destinations', 'wp-travel-engine-trips-embedder' ) ?> <span class="trip-embeder-count"><?php echo esc_html__( '0', 'wp-travel-engine-trips-embedder' ); ?></span></h5>
                                                <ul class="te-selected-list wte-sel-trips wte-em-sortable">
                                                    
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div id="te-tab3-content" class="trip-embeder-content">
                                        <h4><?php esc_html_e( 'Activities', 'wp-travel-engine-trips-embedder' ); ?></h4>
                                        <div class="trip-embeder-cols">
                                        <?php 

                                            $destinations         = get_terms('activities', array('hide_empty' => false));
                                            $destinationHierarchy = array();
                                            $this->sort_terms_hierarchicaly( $destinations, $destinationHierarchy );

                                        if( ! empty( $destinationHierarchy ) ) :

                                        ?>
                                            <div class="trip-embeder-col">
                                                <div class="trip-embeder-search">
                                                    <div class="trip-embeder-form">
                                                        <label>
                                                            <span class="screen-reader-text"><?php esc_html_e( 'Search for:', 'wp-travel-engine-trips-embedder' ); ?></span>
                                                            <input class="search-field" placeholder="<?php esc_attr_e( 'Search...', 'wp-travel-engine-trips-embedder' ); ?>" value="" name="SearchDualList" type="search">
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="trip-embeder-select-fields list-left">
                                                    <h5><?php esc_html_e( 'Select Activities...', 'wp-travel-engine-trips-embedder' ); ?></h5>
                                                    <div class="trip-embeder-select dual-list">
                                                        
                                                        <?php 
                                                            /**
                                                             * Display template.
                                                             */
                                                            $this->display_taxonomy_template( $destinationHierarchy, false );
                                                        ?>

                                                    </div>					
                                                </div>
                                                <div class="list-arrows col-md-1 text-center">
                                                    <div class="wte-posts-num-wrap move-left">
                                                        <label for="wte-activities-posts"><?php echo esc_html__( 'No. of posts', 'wp-travel-engine-trips-embedder' ); ?></label>
                                                        <input class="wte-numberOfposts-val" type="number" name="wte-activities-posts" min="1" id="wte-activities-posts">
                                                    </div>
                                                    <button class="btn btn-default btn-sm move-right">
                                                        <?php esc_html_e('Add to selected activities', 'wp-travel-engine-trips-embedder'); ?>
                                                    </button>
                                                </div>
                                            </div>
                                        <?php 

                                        else :

                                            esc_html_e( 'No Activities found', 'wp-travel-engine-trips-embedder' );
                                    
                                        endif; ?>

                                            <div class="trip-embeder-col trip-embeder-selected list-right">
                                                <h5><?php esc_html_e( 'Total Selected Activities', 'wp-travel-engine-trips-embedder' ) ?> <span class="trip-embeder-count"><?php echo esc_html__( '0', 'wp-travel-engine-trips-embedder' ); ?></span></h5>
                                                <ul class="te-selected-list wte-sel-trips wte-em-sortable">
                                                    
                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                    <div id="te-tab4-content" class="trip-embeder-content">
                                        <h4><?php esc_html_e( 'Trip Type', 'wp-travel-engine-trips-embedder' ); ?></h4>

                                        <div class="trip-embeder-cols">
                                        <?php 

                                            $destinations         = get_terms('trip_types', array('hide_empty' => false));
                                            $destinationHierarchy = array();
                                            $this->sort_terms_hierarchicaly( $destinations, $destinationHierarchy );

                                        if( ! empty( $destinationHierarchy ) ) :

                                        ?>
                                            <div class="trip-embeder-col">
                                                <div class="trip-embeder-search">
                                                    <div class="trip-embeder-form">
                                                        <label>
                                                            <span class="screen-reader-text"><?php esc_html_e( 'Search for:', 'wp-travel-engine-trips-embedder' ); ?></span>
                                                            <input class="search-field" placeholder="<?php esc_attr_e( 'Search...', 'wp-travel-engine-trips-embedder' ); ?>" value="" name="SearchDualList" type="search">
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="trip-embeder-select-fields list-left">
                                                    <h5><?php esc_html_e( 'Select Trip Types...', 'wp-travel-engine-trips-embedder' ); ?></h5>
                                                    <div class="trip-embeder-select dual-list">
                                                        
                                                        <?php 
                                                            /**
                                                             * Display template.
                                                             */
                                                            $this->display_taxonomy_template( $destinationHierarchy, false );
                                                        ?>

                                                    </div>					
                                                </div>
                                                <div class="list-arrows col-md-1 text-center">
                                                    <div class="wte-posts-num-wrap move-left">
                                                        <label for="wte-trip-types-posts"><?php echo esc_html__( 'No. of posts', 'wp-travel-engine-trips-embedder' ); ?></label>
                                                        <input class="wte-numberOfposts-val" type="number" name="wte-trip-types-posts" min="1" id="wte-trip-types-posts">
                                                    </div>
                                                    <button class="btn btn-default btn-sm move-right">
                                                        <?php esc_html_e('Add to selected trip types', 'wp-travel-engine-trips-embedder'); ?>
                                                    </button>
                                                </div>
                                            </div>
                                        <?php 

                                        else :

                                            esc_html_e( 'No Trip Types found', 'wp-travel-engine-trips-embedder' );
                                    
                                        endif; ?>

                                            <div class="trip-embeder-col trip-embeder-selected list-right">
                                                <h5><?php esc_html_e( 'Total Selected Trip Types', 'wp-travel-engine-trips-embedder' ) ?> <span class="trip-embeder-count"><?php echo esc_html__( '0', 'wp-travel-engine-trips-embedder' ); ?></span></h5>
                                                <ul class="te-selected-list wte-sel-trips wte-em-sortable">
                                                    
                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                    <?php
                                            if ( count( $filters ) > 0 ) :
                                                foreach ( $filters as $filter ) :
                                                    ?>
                                                        <div id="te-tab<?php echo esc_attr( $filter['slug'] ) ?>-content" class="trip-embeder-content">
                                                            <h4><?php echo esc_html( $filter['label'] ); ?></h4>

                                                            <div class="trip-embeder-cols">
                                                            <?php 

                                                                $destinations         = get_terms($filter['slug'], array('hide_empty' => false));
                                                                $destinationHierarchy = array();
                                                                $this->sort_terms_hierarchicaly( $destinations, $destinationHierarchy );

                                                            if( ! empty( $destinationHierarchy ) ) :

                                                            ?>
                                                                <div class="trip-embeder-col">
                                                                    <div class="trip-embeder-search">
                                                                        <div class="trip-embeder-form">
                                                                            <label>
                                                                                <span class="screen-reader-text"><?php esc_html_e( 'Search for:', 'wp-travel-engine-trips-embedder' ); ?></span>
                                                                                <input class="search-field" placeholder="<?php esc_attr_e( 'Search...', 'wp-travel-engine-trips-embedder' ); ?>" value="" name="SearchDualList" type="search">
                                                                            </label>
                                                                        </div>
                                                                    </div>
                                                                    <div class="trip-embeder-select-fields list-left">
                                                                        <h5><?php echo sprintf(__( 'Select %s...', 'wp-travel-engine-trips-embedder' ), $filter['label']) ?></h5>
                                                                        <div class="trip-embeder-select dual-list">
                                                                            
                                                                            <?php 
                                                                                /**
                                                                                 * Display template.
                                                                                 */
                                                                                $this->display_taxonomy_template( $destinationHierarchy, false );
                                                                            ?>

                                                                        </div>					
                                                                    </div>
                                                                    <div class="list-arrows col-md-1 text-center">
                                                                        <div class="wte-posts-num-wrap move-left">
                                                                            <label for="wte-trip-types-posts"><?php echo esc_html__( 'No. of posts', 'wp-travel-engine-trips-embedder' ); ?></label>
                                                                            <input class="wte-numberOfposts-val" type="number" name="wte-trip-types-posts" min="1" id="wte-trip-types-posts">
                                                                        </div>
                                                                        <button class="btn btn-default btn-sm move-right">
                                                                        <?php echo sprintf(__( 'Add to selected %s', 'wp-travel-engine-trips-embedder' ), $filter['label']) ?>
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                            <?php 

                                                            else :

                                                                echo sprintf(__( 'No %s found', 'wp-travel-engine-trips-embedder' ), $filter['label']);
                                                        
                                                            endif; ?>

                                                                <div class="trip-embeder-col trip-embeder-selected list-right">
                                                                    <h5><?php esc_html_e( 'Total Selected Trip Types', 'wp-travel-engine-trips-embedder' ) ?> <span class="trip-embeder-count"><?php echo esc_html__( '0', 'wp-travel-engine-trips-embedder' ); ?></span></h5>
                                                                    <ul class="te-selected-list wte-sel-trips wte-em-sortable">
                                                                        
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php
                                                endforeach;
                                            endif;
                                        ?>
                                </div>
                            </div>

                            <div class="trip-embeder-layout-block">
                                <h4><?php esc_html_e( 'Select A Layout', 'wp-travel-engine-trips-embedder' ); ?></h4>
                                <div class="te-layout-holder">
                                    <div class="te-layout">
                                        <h5><?php esc_html_e( '1. Grid Layout', 'wp-travel-engine-trips-embedder' ); ?></h5>
                                        <label for="wte_trip_embedder_sh_layout_grid">
                                            <figure>
                                                <input value="grid" checked id="wte_trip_embedder_sh_layout_grid" name="wte_trip_embedder_sh_layout" type="radio" hidden="hidden">
                                                <img src="<?php echo plugin_dir_url( WTE_TRIPS_EMBEDDER_PLUGIN_FILE ); ?>/assets/images/grid-layout.jpg" alt="grid layout">
                                            </figure>
                                        </label>
                                    </div>

                                    <div class="te-layout">
                                        <h5><?php esc_html_e( '2. List Layout', 'wp-travel-engine-trips-embedder' ); ?></h5>
                                        <label for="wte_trip_embedder_sh_layout_list">
                                            <figure>
                                                <input id="wte_trip_embedder_sh_layout_list" value="list" name="wte_trip_embedder_sh_layout" type="radio" hidden="hidden">
                                                <img src="<?php echo plugin_dir_url( WTE_TRIPS_EMBEDDER_PLUGIN_FILE ); ?>/assets/images/list-layout.jpg" alt="list layout">
                                            </figure>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="te-button-wrap">
                                <input id="wte_embed_insert_embed_sh" name="wte_embed_insert_embed_sh" type="submit" class="button button-primary button-large" value="<?php _e( 'Insert', 'wp-travel-engine-trips-embedder' ); ?>">
                                <input name="cancel" data-dismiss="modal" type="submit" class="button button-primary button-large" id="cancel" value="Cancel">
                            </div>
                        </div>
                    </div><!-- .trip-embeder-popup-outer -->
                </div>
                <script type="text/html" id="tmpl-wte-trip-embeder-left-list">

                    <li data-trip-id="{{data.trip_id}}" data-trip-title="{{data.trip_title}}" class="list-group-item">
                        <input id="{{data.id}}" type="checkbox" name="{{data.id}}">
                        <label for="{{data.id}}">{{data.trip_title}}</label>
                    </li>
                    
                </script>
                <script type="text/html" id="tmpl-wte-trip-embeder-right-list">
                    
                    <li class="te-selected-item-lst" data-id="{{data.id}}" data-trip-id="{{data.trip_id}}" data-trip-title="{{data.trip_title}}">
                        <div class="te-selected-item">
                            <span class="te-item-text">{{data.trip_title}}</span>
                            <span class="te-item-remove"><?php esc_html_e( 'Close', 'wp-travel-engine-trips-embedder' ); ?></span>
                        </div>
                        <span class="te-item-move"><?php esc_html_e( 'Move', 'wp-travel-engine-trips-embedder' ); ?></span>
                    </li>
                        
                </script>
            </div>
        </div>
    </div>

<?php

    }

    /**
     * Save Trip embed metabox data.
     *
     * @return void
     */
    public function save_trip_embed_data( $post ) {

        if ( 'wte-embed' !== get_post_type( $post ) ) {
            return;
        }

        if ( ! isset( $_POST['wpte_trip_embed_save_data'] ) || ! wp_verify_nonce( $_POST['wpte_trip_embed_save_data'], 'wpte_trip_embed_save_data_action' ) ) {
            return;
        }

        if ( ! current_user_can( 'edit_post', $post ) ) {
            return $post;
        }
            
        if ( ! isset( $_POST['wte_trp_embds'] ) || empty( $_POST['wte_trp_embds'] ) ) {
            return $post;
        }

        $sanitized_data = $this->sanitize_embed_fields( $_POST['wte_trp_embds'] );

        update_post_meta( $post, 'wte_trp_embds', $sanitized_data );

        return false;
    }

    /**
     * Render taxonomy array list
     *
     * @param [type] $tax_array
     * @return void
     */
    public function display_taxonomy_template( $taxonomy_array, $has_children = false ){

        ?>
        <ul class="te-trip-list list-group <?php echo $has_children ? esc_attr( 'children' ) : ''; ?>">
            <?php foreach( $taxonomy_array as $ky => $tax ) :

            $term_id      = $tax->term_id;
            $term_name    = $tax->name;
            $has_children = isset( $tax->children ) && ! empty( $tax->children ) ? true : false;

            ?>
                <li data-id="<?php echo esc_attr( sanitize_title( $term_name ) ); ?>_<?php echo esc_attr( $term_id ); ?>" data-trip-id="<?php echo esc_attr( $term_id ); ?>" data-trip-title="<?php echo esc_html( $term_name ); ?>" class="list-group-item <?php echo $has_children ? esc_attr( 'has-children' ) : ''; ?>">
                    <input id="<?php echo esc_attr( sanitize_title( $term_name ) ); ?>_<?php echo esc_attr( $term_id ); ?>" type="checkbox" name="<?php echo esc_attr( sanitize_title( $term_name ) ); ?>_<?php echo esc_attr( $term_id ); ?>">
                    <label for="<?php echo esc_attr( sanitize_title( $term_name ) ); ?>_<?php echo esc_attr( $term_id ); ?>"><?php echo esc_html( $term_name ); ?></label>

                    <?php 
                        if ( $has_children ) : 
                            $this->display_taxonomy_template( $tax->children, $has_children );
                        endif;
                    ?>

                </li>
            <?php endforeach; ?>
            <li style="display:none;" class="no-results"><?php esc_html_e( 'No results found.', 'wp-travel-engine-trips-embedder' ); ?></li>
        </ul>

        <?php

    }
    /**
     * Recursively sort an array of taxonomy terms hierarchically. Child categories will be
     * placed under a 'children' member of their parent term.
     * @param Array   $cats     taxonomy term objects to sort
     * @param Array   $into     result array to put them in
     * @param integer $parentId the current parent ID to put them in
     */
    public function sort_terms_hierarchicaly(Array &$cats, Array &$into, $parentId = 0)
    {
        foreach ( $cats as $i => $cat ) {
            if ( $cat->parent == $parentId ) {
                $into[$cat->term_id] = $cat;
                unset( $cats[$i] );
            }
        }

        foreach ( $into as $topCat ) {
            
            $topCat->children = array();
            
            $this->sort_terms_hierarchicaly( $cats, $topCat->children, $topCat->term_id );
        }
    }

    /**
     * Add a custom button to tinymce editor
     * 
     * @return void
     */
    public function wte_register_custom_mce_buttons() {

        if ( ! function_exists( 'get_current_screen' ) ) {
            return;
        }

        $screen = get_current_screen();
        
        // Check if WYSIWYG is enabled
        if ( get_user_option( 'rich_editing' ) == 'true' && isset( $screen->post_type ) && in_array( $screen->post_type, $this->allowed_screens ) ) {

            add_filter( 'mce_external_plugins', array( $this, 'wte_external_tinymce_plugin' ) );
            add_filter( 'mce_buttons', array( $this, 'wte_embed_register_mce_buttons' ) );
        
        }
    }

    /**
     * Register external tinymce plugin | Add the path to the js file with the custom button function
     *
     * @param [type] $plugin_array
     * @return void
     */
    public function wte_external_tinymce_plugin( $plugin_array ) {

        $plugin_array['wte_trips_embedder_mce_btn'] =  plugin_dir_url( WTE_TRIPS_EMBEDDER_PLUGIN_FILE )  .'/assets/js/admin/wte-trips-embedder-backend.js';
        return $plugin_array;
    
    }

    /**
     * Embed tinymce button update.
     *
     * @param [type] $buttons
     * @return void
     */
    public function wte_embed_register_mce_buttons( $buttons ) {
        
        array_push( $buttons, 'wte_trips_embedder_mce_btn' );
        
        return $buttons;
    }

    /**
     * Sanitize embed data
     */
    public function sanitize_embed_fields( $data = array() ) {

        if ( isset( $data['embed_script'] ) && ! empty( $data['embed_script'] ) ) :

            $data['embed_script'] = htmlspecialchars( $data['embed_script'], ENT_QUOTES );

        endif;

        if ( isset( $data['allowed_sites'] ) && ! empty( $data['allowed_sites'] ) ) :

            $data['allowed_sites'] = explode( ',', $data['allowed_sites'] );
            $data['allowed_sites'] = array_map( 'esc_url', $data['allowed_sites'] );
        
        endif;

        if ( isset( $data['iframe_width'] ) && ! empty( $data['iframe_width'] ) ) :

            $data['iframe_width'] = sanitize_text_field( $data['iframe_width']  );

        endif;

        if ( isset( $data['iframe_height'] ) && ! empty( $data['iframe_height'] ) ) :

            $data['iframe_height'] = sanitize_text_field( $data['iframe_height']  );

        endif;


        return $data;

    }

}

// Initialize Class
new WTE_Trips_Embedder_Init();
