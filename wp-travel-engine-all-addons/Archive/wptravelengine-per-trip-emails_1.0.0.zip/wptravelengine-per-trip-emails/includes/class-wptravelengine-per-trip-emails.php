<?php
/**
 *
 * Registers post type for Per Trip Emails.
 *
 * @since 1.0.0
 */

/**
 * Class WPTravelEngine_Per_Trip_Emails.
 */
class WPTravelEngine_Per_Trip_Emails {

	/**
	 * Hold current instance.
	 *
	 * @var null|WPTravelEngine_Per_Trip_Emails $instance
	 */
	protected static $instance = null;

	/**
	 * @var string $posttype Post Type for Per-Trip-Emails.
	 */
	private $posttype = 'per-trip-emails';

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->load_dependencies();

		/**
		 * New hooks and filters added from here.
		 *
		 * @since 1.0.0
		 */
		$this->init_hooks();
	}

	/**
	 * Hooks and Filters.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function init_hooks() {
		add_action( 'init', array( $this, 'register' ) );
		add_action( 'save_post', array( $this, 'save_metabox' ) );
		add_filter( 'wptravelengine_order_email_template_content_customer', array( $this, 'email_template_content' ), 10, 2 );
		add_filter( 'wptravelengine_order_email_template_subject_customer', array( $this, 'email_templates_subject' ), 10, 2 );
		add_filter( 'manage_per-trip-emails_posts_columns', array( $this, 'trip_column' ) );
		add_action( 'manage_per-trip-emails_posts_custom_column', array( $this, 'trip_column_values' ), 10, 2 );
		add_action( 'post_submitbox_misc_actions', array( $this, 'email_status_metabox' ) );
		add_action( 'wp_trash_post', array( $this, 'delete_trip_postmeta' ), 10, 1 );
		add_action( 'edit_form_after_editor', array( $this, 'content_after_editor' ) );
		add_action( 'edit_form_after_title', array( $this, 'content_after_title' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'register_styles' ) );

		add_action( 'init', array( $this, 'handle_preview_request' ) );
	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function load_dependencies() {
		/**
		 * The class responsible for updating the add-on from EDD.
		 */
		require plugin_dir_path( WP_TRAVEL_ENGINE_PER_TRIP_EMAILS_FILE_PATH ) . 'updater/wptravelengine-per-trip-emails-updater.php';
	}

	/**
	 * Preview the current Template.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function handle_preview_request() {
		if ( isset( $_REQUEST['_action'] ) && 'email_custom_template_preview' === $_REQUEST['_action'] ) {
			require_once plugin_dir_path( \WP_TRAVEL_ENGINE_FILE_PATH ) . 'includes/class-wp-travel-engine-emails.php';

			// Get Email Header.
			wte_get_template( 'emails/email-header.php' );

			// Email Content.
			$template_id = isset( $_REQUEST['_template_id'] ) ? (int) $_REQUEST['_template_id'] : 0;
			echo $this->format_template( get_the_content( null, false, $template_id ) );

			// Get email footer.
			wte_get_template( 'emails/email-footer.php' );
			header( $_SERVER['SERVER_PROTOCOL'] . ' 200 OK' ); // phpcs:ignore
			exit;
		}
	}

	/**
	 * Returns single instance.
	 *
	 * @return WPTravelEngine_Per_Trip_Emails
	 */
	public static function instance() {
		if ( ! self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Registers Post Type per-trip-emails.
	 *
	 * @return void
	 */
	public function register( $args ) {
		$args = apply_filters(
			'wte_per_trip_emails_posttype_args',
			array(
				'label'        => __( 'Per Trip Emails', 'wptravelengine-per-trip-emails' ),
				'public'       => false,
				'show_ui'      => true,
				'show_in_menu' => 'edit.php?post_type=booking',
				'supports'     => array( 'title', 'editor' ),
				'labels'       => array(
					'add_new'      => __( 'Add New', 'wptravelengine-per-trip-emails' ),
					'add_new_item' => __( 'Add New Template', 'wptravelengine-per-trip-emails' ),
					'edit_item'    => __( 'Edit Template', 'wptravelengine-per-trip-emails' ),
					'not_found'    => __( 'No Templates Found.', 'wptravelengine-per-trip-emails' ),
					'menu_name'    => __( 'Per Trip Emails' . '<span class="update-plugins">NEW</span>', 'wptravelengine-per-trip-emails' ),
				)
			),
		);
		register_post_type(
			$this->posttype,
			$args
		);
	}

    /**
     * Enqueue styles and scripts.
     *
     * @since 1.0.0
     */
    public function register_styles() {
		$suffix = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '' : '.min';

		wp_register_style(
			'wte-per-trip-emails',
			plugin_dir_url( WP_TRAVEL_ENGINE_PER_TRIP_EMAILS_FILE_PATH ) . 'assets/css/wte-per-trip-emails-custom' . $suffix . '.css',
			array(),
			filemtime( plugin_dir_path( WP_TRAVEL_ENGINE_PER_TRIP_EMAILS_FILE_PATH ) . 'assets/css/wte-per-trip-emails-custom' . $suffix . '.css' ),
		);
    }

	/**
	 * Callback function for metabox.
	 *
	 * @param WP_Post $post Post Object
	 */
	public function content_after_title( $post ) {
		wp_enqueue_script( 'jquery-fancy-box' );
		wp_enqueue_style( 'jquery-fancy-box' );
		wp_enqueue_style( 'wte-per-trip-emails' );

		if ( "per-trip-emails" !== $post->post_type ) {
			return;
		}

		$args       = array(
			'post_type'      => 'trip',
			'post_status'    => 'publish',
			'posts_per_page' => -1,
		);
		$trip_query = get_posts( $args );

		$selected_trip = get_post_meta( $post->ID, 'email_template_trips', true );
		$email_subject = get_post_meta( $post->ID, 'email_template_subject', true );
		?>
		<div id="wte_per_trip_email_trip_selection">
			<div class="inside">
				<div class="form-field">
					<label>
						<?php _e( 'Trip Name', 'wptravelengine-per-trip-emails' ) ?>
					</label>
					<select name="email_template_trips" id="email_template_trips" class="wte_selector">
						<option>
							<?php _e( 'Select a Trip', 'wptravelengine-per-trip-emails' ) ?>
						</option>
						<?php
						foreach ( $trip_query as $trips ) {
							?>
							<option
								value="<?php echo esc_attr( $trips->ID ) ?>"
								<?php selected( $selected_trip, $trips->ID ); ?>>
								<?php echo esc_attr( $trips->post_title ) ?>
							</option>
							<?php
						}
						?>
					</select>
					<span>
						<?php _e( 'Select the trip for this template.', 'wptravelengine-per-trip-emails' ) ?>
					</span>
				</div>

                <div class="form-field">
                    <label>
                        <?php _e( 'Purchase Email Subject', 'wptravelengine-per-trip-emails' ) ?>
                    </label>
                    <input type="text" placeholder="<?php echo __( 'Your booking order has been placed ({booking_id})', 'wptravelengine-per-trip-emails' ); ?>" name="email_template_subject" id="email_template_subject" class="wte_selector" value="<?php echo esc_attr( $email_subject ); ?>">
                    <span><?php _e( 'Available tags: ', 'wptravelengine-per-trip-emails' ); ?><code>{booking_id}</code> <code>{payment_id}</code></span>
                </div>
			</div>
		</div>
		<hr />
		<p>
			<a class="wte-email-template-preview-link"
				data-fancybox
				data-type="iframe"
				data-src="<?php echo esc_url( home_url( '/' ) ); ?>?_action=email_custom_template_preview&_template_id=<?php echo (int) $post->ID; ?>"
				href="<?php echo esc_url( home_url( '/' ) ); ?>?_action=email_custom_template_preview&_template_id=<?php echo (int) $post->ID; ?>"><?php esc_html_e( 'Preview Template', 'wptravelengine-per-trip-emails' ); ?>
			</a>
		</p>
		<script>
			; (function () {
				window.addEventListener('load', function () {
					jQuery('.wte-email-template-preview-link').fancybox({
						type: 'iframe',
						baseClass: 'wte-fb-popup'
					})
				})
			})();
		</script>
		<?php
	}

	/**
	 * Email Template Tags metabox.
	 *
	 * @param WP_Post $post Post Object
	 * @return void
	 */
	public function content_after_editor( $post ) {

		if ( "per-trip-emails" !== $post->post_type ) {
			return;
		}

		?>
		<div class="inside">
			<div class="wpte-field wpte-tags wpte-custom-template-tags">
                <h3><?php _e( 'Available tags for email content.', 'wptravelengine-per-trip-emails' ); ?></h3>
				<ul class="wpte-list">
					<li>
						<b>{trip_url}</b>
						<span>
							<?php esc_html_e( 'The trip URL for each booked trip', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
					<li>
						<b>{name}</b>
						<span>
							<?php esc_html_e( 'The buyer\'s first name', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
					<li>
						<b>{fullname}</b>
						<span>
							<?php esc_html_e( 'The buyer\'s full name, first and last', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
					<li>
						<b>{user_email}</b>
						<span>
							<?php esc_html_e( 'The buyer\'s email address', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
					<li>
						<b>{billing_address}</b>
						<span>
							<?php esc_html_e( 'The buyer\'s billing address', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
					<li>
						<b>{city}</b>
						<span>
							<?php esc_html_e( 'The buyer\'s city', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
					<li>
						<b>{country}</b>
						<span>
							<?php esc_html_e( 'The buyer\'s country', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
					<li>
						<b>{tdate}</b>
						<span>
							<?php esc_html_e( 'The starting date of the trip', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
					<li>
						<b>{date}</b>
						<span>
							<?php esc_html_e( 'The trip booking date', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
					<li>
						<b>{traveler}</b>
						<span>
							<?php esc_html_e( 'The total number of traveller(s)', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
					<li>
						<b>{child-traveler}</b>
						<span>
							<?php esc_html_e( 'The total number of child traveller(s)', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
					<li>
						<b>{tprice}</b>
						<span>
							<?php esc_html_e( 'The trip price', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
					<li>
						<b>{price}</b>
						<span>
							<?php esc_html_e( 'The total payment made of the booking', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
					<li>
						<b>{total_cost}</b>
						<span>
							<?php esc_html_e( 'The total price of the booking', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
					<li>
						<b>{due}</b>
						<span>
							<?php esc_html_e( 'The due balance', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
					<li>
						<b>{sitename}</b>
						<span>
							<?php esc_html_e( 'Your site name', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
					<li>
						<b>{booking_url}</b>
						<span>
							<?php esc_html_e( 'The trip booking link', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
					<li>
						<b>{ip_address}</b>
						<span>
							<?php esc_html_e( 'The buyer\'s IP Address', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
					<li>
						<b>{booking_id}</b>
						<span>
							<?php esc_html_e( 'The booking order ID', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
					<li>
						<b>{bank_details}</b>
						<span>
							<?php esc_html_e( 'Banks Accounts Details. This tag will be replaced with the bank details and sent to the customer receipt email when Bank Transfer method has chosen by the customer.', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
					<li>
						<b>{check_payment_instruction}</b>
						<span>
							<?php esc_html_e( 'Instructions to make check payment.', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
					<li>
						<b>{booking_details}</b>
						<span>
							<?php esc_html_e( 'The booking details: Booked trips, Extra Services, Traveller details etc', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
					<li>
						<b>{traveler_data}</b>
						<span>
							<?php esc_html_e( 'The traveller details: Traveller details and Emergency Contact Details', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
					<li>
						<b>{payment_method}</b>
						<span>
							<?php esc_html_e( 'Payment Method used to checkout.', 'wptravelengine-per-trip-emails' ); ?>
						</span>
					</li>
				</ul>
				<?php
					/**
					 * Hook to add additional e-mail tags by addons.
					 */
					do_action( 'wte_additional_payment_email_tags' );
				?>
			</div>

		</div>
		<?php
	}

	/**
	 * Save Metas for Email Templates.
	 *
	 * @param int $template_id Email Template ID.
	 * @return void
	 */
	public function save_metabox( $template_id ) {
		if ( ! empty( $_POST['email_template_subject'] ) ) {
			update_post_meta( $template_id, 'email_template_subject', sanitize_text_field( wp_unslash( $_POST['email_template_subject'] ) ) );
		}
		if ( ! empty( $_POST['email_template_trips'] ) ) {
			$trip_id = sanitize_text_field( wp_unslash( $_POST['email_template_trips'] ) );
			update_post_meta( $template_id, 'email_template_trips', $trip_id );
			update_post_meta( $trip_id, '_booking_email_template', $template_id );
		}
		if ( ! empty( $_POST['email_template_status'] ) ) {
			update_post_meta( $template_id, 'email_template_status', sanitize_text_field( wp_unslash( $_POST['email_template_status'] ) ) );
		}
	}

	/**
	 * Conditional function.
	 *
	 * @param integer $booking_id
	 * @return boolean|integer
	 */
	public function maybe_use_custom_email_template( $booking_id ) {

		// Trip ID.
		$booking_trips = get_post_meta( $booking_id, 'order_trips', true );

		if ( is_array( $booking_trips ) ) {
			$booking_trip = array_values( $booking_trips )[0];
			$trip_id      = $booking_trip['ID'];

			// Check if trip has custom email template.
			$email_template_id = get_post_meta( $trip_id, '_booking_email_template', true );
		}

		return is_numeric( $email_template_id ) ? $email_template_id : false;
	}

	/**
	 * Format Templates. All table, tr,td happens here.
	 *
	 * @TODO: Implement advance formatting options.
	 * @param $content Original content string.
	 * @return string Formatted template.
	 */
	public function format_template( $content = '' ) {
		// $content           = str_replace( '-|-', '</td><td>', $content );
		// $content_fragments = preg_split( "/\r\n|\n/", $content );

		// $template_content = '<table><tr><td>';
		// $template_content .= implode( '</td></tr><tr><td>', $content_fragments );
		// $template_content .= '</td></tr></table>';
		// return $content;

		return wpautop( $content ); //TO Dev: only change line break to paragraph for now.
	}

	/**
	 * Email Template Content.
	 *
	 * @param string $content
	 * @param object $email_object
	 * @return string $content
	 */
	public function email_template_content( $content, $email_object ) {

		// Booking ID.
		$booking_id = $email_object->booking->ID;

		$email_template_id = $this->maybe_use_custom_email_template( $booking_id );

		// Get template status
		$get_template_status = get_post_meta( $email_template_id, 'email_template_status', true );

		if ( ! $email_template_id ) {
			return $content;
		}

		if ( $email_template_id && ( 'Active' === $get_template_status ) ) {
			$content = get_the_content( null, false, $email_template_id );
		}

		return $this->format_template( $content );

	}

	/**
	 * Email Template Subject.
	 *
	 * @param string $subject
	 * @param string $email_object
	 * @return string $subject
	 */
	public function email_templates_subject( $subject, $email_object ) {

		// Booking ID.
		$booking_id = $email_object->booking->ID;

		$email_template_id = $this->maybe_use_custom_email_template( $booking_id );

		if ( ! $email_template_id ) {
			return $subject;
		}

		// Get template status
		$get_template_status = get_post_meta( $email_template_id, 'email_template_status', true );

		if ( $email_template_id && ( 'Active' === $get_template_status ) ) {
			$subject = get_post_meta( $email_template_id, 'email_template_subject', true );
		}

		return $subject;

	}

	/**
	 * Adds custom column in admin panel.
	 *
	 * @param array $column
	 * @return array $_column
	 */
	public function trip_column( $column ) {

		$_column = array();
		foreach ( $column as $key => $value ) {
			$_column[ $key ] = $value;
			if ( $key == 'title' ) {
				$_column['trip_column']   = __( 'Trip', 'wptravelengine-per-trip-emails' ); // Put the trip column before date.
				$_column['status_column'] = __( 'Template Status', 'wptravelengine-per-trip-emails' ); // Put the status column before date.
			}
		}

		return $_column;
	}

	/**
	 * Adds meta values to column.
	 *
	 * @param array $column_name
	 * @param integer $template_id
	 * @return void
	 */
	public function trip_column_values( $column_name, $template_id ) {

		//Trip ID.
		$selected_trip_id = get_post_meta( $template_id, 'email_template_trips', true );

		if ( ! empty( $selected_trip_id ) ) {
			//Trip title.
			$get_trip_title = get_the_title( $selected_trip_id );
			$trip_title     = isset( $get_trip_title ) ? $get_trip_title : '';

			//Email template status.
			$get_email_status = get_post_meta( $template_id, 'email_template_status', true );
			$email_status     = isset( $get_email_status ) ? $get_email_status : '';

			switch ( $column_name ) {
				case "trip_column":
					echo '<a href="' . esc_url( get_edit_post_link( $selected_trip_id, 'display' ) ) . '">' . esc_html( $trip_title ) . '</a>';
					break;
				case "status_column":
					echo esc_attr( $email_status );
					break;
				default:
					break;
			}
		}
	}

	/**
	 * Email Status metabox.
	 *
	 * @return void
	 */
	public function email_status_metabox( $post ) {

		if ( get_post_type( $post ) === 'per-trip-emails' ) {
			$email_template_status = get_post_meta( $post->ID, 'email_template_status', true );
			?>
			<div class="misc-pub-section my-options">
				<label for="email_template_status">
					<?php _e( 'Template Status', 'wptravelengine-per-trip-emails' ) ?>
				</label>
				<select id="email_template_status" name="email_template_status">
					<option value="Active"
						<?php selected( $email_template_status, 'Active' ); ?>>
						<?php _e( 'Active', 'wptravelengine-per-trip-emails' ) ?>
					</option>
					<option value="Inactive"
						<?php selected( $email_template_status, 'Inactive' ); ?>>
						<?php _e( 'Inactive', 'wptravelengine-per-trip-emails' ) ?>
					</option>
				</select>
			</div>
			<?php
		}
	}

	/**
	 * Delete postmeta from post_type Trip,
	 * If the template is moved to trash.
	 *
	 * @param integer $template_id
	 * @return void
	 */
	public function delete_trip_postmeta( $template_id ) {
		// Trip ID.
		$trip_id = get_post_meta( $template_id, 'email_template_trips', true );

		if ( ! empty( $trip_id ) ) {
			delete_post_meta( $trip_id, '_booking_email_template' );
		}
	}
}

WPTravelEngine_Per_Trip_Emails::instance();
