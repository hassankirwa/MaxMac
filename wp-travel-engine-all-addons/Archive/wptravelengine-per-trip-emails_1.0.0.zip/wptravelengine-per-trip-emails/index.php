<?php
//  Silence is golden.