<?php
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link            https://wptravelengine.com/
 * @since           1.0.0
 * @package         WPTravelEngine_Per_Trip_Emails
 *
 * @wordpress-plugin
 * Plugin Name:     WP Travel Engine - Per Trip Emails
 * Plugin URI:      https://wptravelengine.com/
 * Description:     An extension for WP Travel Engine plugin to add a custom email template to desired trips.
 * Version:         1.0.0
 * Author:          WP Travel Engine
 * Author URI:      https://wptravelengine.com/
 * License:
 * Text Domain:     wptravelengine-per-trip-emails
 * Domain Path:     /languages
 * WTE requires at least: 4.3.0
 * WTE tested up to: 6.2
 * WTE: 127839:wptravelengine_per_trip_emails_license_key
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'WP_TRAVEL_ENGINE_PER_TRIP_EMAILS_FILE_PATH', __FILE__ );
define( 'WP_TRAVEL_ENGINE_PER_TRIP_EMAILS_BASE_PATH', dirname(__FILE__) );
define( 'WP_TRAVEL_ENGINE_PER_TRIP_EMAILS_VERSION', '1.0.0' );

add_action( 'admin_notices', 'wptravelengine_per_trip_emails_maybe_disable_plugin' );

/**
 * Output error message and disable plugin if requirements are not met.
 *
 * This fires on admin_notices.
 *
 * @since 1.0.0
 * @return void
 */
function wptravelengine_per_trip_emails_maybe_disable_plugin() {
    if( ! wptravelengine_per_trip_emails_meets_requirements() ) {
        // Displays error.
        echo '<div id="message" class="error">';
		echo '<p>' . sprintf( __( '<strong>WP Travel Engine - Per Trip Emails</strong> addon requires the WP Travel Engine plugin to work. Please install and activate the latest WP Travel Engine plugin first. <strong>WP Travel Engine - Per Trip Emails will be deactivated now.</strong>', 'wptravelengine-per-trip-emails' ), admin_url( 'plugins.php' ) ) . '</p>';
		echo '</div>';

		// Deactivate plugin.
		deactivate_plugins( __FILE__ );
    }
}

/**
 * Check if all plugin requirements are met.
 *
 * @since 1.0.0
 *
 * @return bool True if the requirements are met, otherwise false.
 */
function wptravelengine_per_trip_emails_meets_requirements() {
    return ( class_exists( 'WP_Travel_Engine' ) && defined( 'WP_TRAVEL_ENGINE_VERSION' ) && version_compare( WP_TRAVEL_ENGINE_VERSION, '4.0.0', '>=' ) );
}

/**
 * Per Trip Emails core load.
 *
 * @return void
 */
function wptravelengine_per_trip_emails_core() {
    if( ! wptravelengine_per_trip_emails_meets_requirements() ) {
        return false;
    }

    require WP_TRAVEL_ENGINE_PER_TRIP_EMAILS_BASE_PATH . '/includes/class-wptravelengine-per-trip-emails.php';
}
add_action( 'plugins_loaded', 'wptravelengine_per_trip_emails_core' );
