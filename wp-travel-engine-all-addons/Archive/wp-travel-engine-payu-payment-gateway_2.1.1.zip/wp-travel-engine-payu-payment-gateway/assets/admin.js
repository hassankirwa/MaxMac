jQuery(document).ready(function($){
    if ($('.payu').is( ':checked' )) {
        $('.wte-payu-form.settings').fadeIn('slow');
    }
    else{
        $('.wte-payu-form.settings').fadeOut('slow');
    }
    $('body').on('click', '.payu', function (e){ 
        if ($('.payu').is( ':checked' )) {
            $('.wte-payu-form.settings').fadeIn('slow');
        }
        else{
            $('.wte-payu-form.settings').fadeOut('slow');
        }
    });
});