jQuery(document).ready(function($){
  $("#wte_payment_options").on('change', function(e){
    e.preventDefault();
    var val = $('#wte_payment_options :selected').val();
    if( val != 'PayU' ){
      return;
    }
    jQuery.ajax({
      type: 'post',
      url: WTEAjaxData.ajaxurl,
      data : {action: 'payu_form'},
      success: function (response) {
        $('#wp-travel-engine-order-form').attr('action','');
        $( '.wp-travel-engine-billing-details-wrapper' ).html( response.data );
      }
    });
  });
});

jQuery( function($) {
  $(".wp-travel-engine-submit").on('click', function(e){
    var val = $('#wte_payment_options :selected').val();
    if( val != 'PayU' ){
      return;
    }
    
    e.preventDefault();

    var email = $('input[name=email]').val();
    var phone = $('input[name=phone]').val();
    var firstname = $('input[name=firstname]').val();
    var lastname = $('input[name=lastname]').val();
    var amount = $('input[name=amount]').val();
    var country = $('select[name=country]').val();
    var city = $('input[name=city]').val();
    var address1 = $('input[name=address1]').val();

    jQuery.ajax({
      type: 'post',
      url: WTEAjaxData.ajaxurl,
      data : {action: 'payu_payment_process',email:email,phone:phone,firstname:firstname,lastname:lastname,city:city,amount:amount,country:country,address1:address1},
      beforeSend: function(){
        $("#submit-loader").fadeIn(500);
      },
      success: function (response) {
        $('#wp-travel-engine-order-form').attr('action', payu.payU_URL );
        $( '.stripe-button:visible' ).remove();  
        $( '.stripe-button-el' ).remove();
        $( '.wp-travel-engine-submit' ).show();
        $( '.wp-travel-engine-billing-details-wrapper' ).html( response.data );
      },
      complete: function(){
        $("#submit-loader").fadeOut(500);
        $("#wp-travel-engine-order-form .successful").text(payu.success);
        $("#wp-travel-engine-order-form .successful").fadeIn();
        $("#wp-travel-engine-order-form").submit();             
      }
    });
  });
});
