<?php
//admin settings
class Wte_Payu_Admin
{
function __construct()
{
	add_action( 'wte_payu_settings',array( $this, 'wte_payu_settings' ) );
	add_action( 'wte_payu_enable',array( $this, 'wte_payu_enable' ) );
	add_action( 'admin_enqueue_scripts', array( $this, 'Wte_enqueue_backend_assets' ) );
	add_action( 'wp_enqueue_scripts', array( $this, 'Wte_enqueue_frontend_assets' ) );
	$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', true );

	add_action( 'admin_notices',array( $this, 'show_notifications' ) );

	if(isset($wp_travel_engine_settings['payu_enable']))
	{
	add_filter( 'wte_payment_gateways_dropdown_options', array( $this, 'wte_enable_payu_dropdown' ) );
	}
	add_action( 'wp_ajax_payu_form', array( $this, 'payu_form' ) );
	add_action( 'wp_ajax_nopriv_payu_form', array( $this, 'payu_form' ) );

	add_action( 'wp_ajax_payu_payment_process', array( $this, 'payu_payment_process' ) );
	add_action( 'wp_ajax_nopriv_payu_payment_process', array( $this, 'payu_payment_process' ) );
	add_action( 'wp_ajax_payu_generate_hash', array( $this, 'generate_hash' ) );
	add_action( 'wp_ajax_nopriv_payu_generate_hash', array( $this, 'generate_hash' ) ); 

	add_action( 'add_meta_boxes', array( $this, 'wpte_payu_add_meta_boxes' ) );
	add_action( 'save_post', array( $this, 'wp_travel_engine_payu_meta_box_data' ) );
	add_action( 'plugins_loaded', array( $this, 'load_plugin_textdomain' ) );

	// Add filter for the sortable gateway list.
	add_filter( 'wp_travel_engine_available_payment_gateways', array( $this, 'payu_gateway_list' ) );

	add_filter( 'wpte_settings_get_global_tabs', array( $this, 'add_global_settings' ) );

	//
	// add_action( 'wp_travel_engine_after_booking_process_completed', array( 'WTE_PayU_Biz_India', 'generate_payu_in_form' ) );
}

public function generate_hash() {
	$wte_settings = get_option( 'wp_travel_engine_settings' );
	$data = new stdClass;
	$data->key       = isset( $wte_settings['payu_merchant_id'] ) ? $wte_settings['payu_merchant_id'] : '';
	$data->txnid     = isset( $_POST["txnid"] ) ? $_POST["txnid"] : '';
	$data->amount    = isset( $_POST["amount"] ) ? $_POST["amount"] : '';
	$data->pinfo     = isset( $_POST["productinfo"] ) ? $_POST["productinfo"] : '';
	$data->firstname = isset( $_POST["firstname"] ) ? $_POST["firstname"] : '';
	$data->email     = isset( $_POST["email"] ) ? $_POST["email"] : '';
	$data->udf5      = isset( $_POST["udf5"] ) ? $_POST["udf5"] : '';
	$data->salt      = isset( $wte_settings['payu_salt'] ) ? $wte_settings['payu_salt'] : '';

	$hash = hash('sha512', $data->key.'|'.$data->txnid.'|'.$data->amount.'|'.$data->pinfo.'|'.$data->firstname.'|'.$data->email.'|||||'.$data->udf5.'||||||'.$data->salt);

	return wp_send_json_success( array('hash' => $hash) );
}

function load_plugin_textdomain() {

	load_plugin_textdomain(
	'wte-payu',
	false,
	dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
	);

}                                                                           
/**
 * Payment Details.
* @since 1.0
*/
function wpte_payu_add_meta_boxes(){
	$screens = array( 'booking' );
	foreach ( $screens as $screen ) {
		add_meta_box(
			'payu_id',
			__( 'PayU Payment Details', 'wte-payu' ),
			array($this,'wte_payu_metabox_callback'),
			$screen,
			'side',
			'high'
		);
	}
}

/**
 * Show notifications.
 */
public function show_notifications( ) { 

	if ( ! class_exists( 'WP_Travel_Engine' ) ) {
		deactivate_plugins( plugin_basename( __FILE__ ) );
		return;
	}

	if ( $this->is_currency_inr() ) {
		return;
	}
	?>

	<div class="notice notice-error"> 
		<p>
			<strong><?php _e( 'PayU Biz Error : ', 'wte-payu' ); ?></strong>
			<?php _e( 'Currency not supported. Change the currency to INR to enable PayU Biz.', 'wte-payu' ); ?>
		</p>
	</div>
<?php }


// Tab for notice listing and settings
public function wte_payu_metabox_callback(){
	include WP_TRAVEL_ENGINE_PAYU_BASE_PATH.'/admin/includes/backend/payu.php';
}

/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
function wp_travel_engine_payu_meta_box_data( $post_id ) {
	
	/*
	* We need to verify this came from our screen and with proper authorization,
	* because the save_post action can be triggered at other times.
	*/
	// Sanitize user input.
	if(isset($_POST['wp_travel_engine_booking_setting']))
	{
		$settings = $_POST['wp_travel_engine_booking_setting'];
		update_post_meta( $post_id, 'wp_travel_engine_booking_setting', $settings );
	}  
}

//enable payu on dropdown
function wte_enable_payu_dropdown($options)
{
	$options[] = 'PayU';
	return $options;
}
//Enqueue required assets for admin
function Wte_enqueue_backend_assets()
{
	wp_enqueue_script( 'Wte-PayU', plugin_dir_url( __FILE__ ) . 'assets/admin.js', array( 'jquery' ), '', false );
	wp_enqueue_style( 'Wte-PayU', plugin_dir_url( __FILE__ ) . 'assets/admin.css', array(), '', 'all' );
}

//Enqueue required assets for admin
function Wte_enqueue_frontend_assets()
{
	$wte_settings = get_option( 'wp_travel_engine_settings' );
	$merchant_key = isset( $wte_settings['payu_merchant_id'] ) ? $wte_settings['payu_merchant_id'] : '';
	$merchant_key = trim( $merchant_key );
	$enable = isset( $wte_settings['payu_enable'] ) ? true : false;

	wp_enqueue_style( 'Wte-PayU', plugin_dir_url( __FILE__ ) . 'assets/public.css', array(), '', 'all' );
	wp_register_script( 'Wte-PayU', plugin_dir_url( __FILE__ ) . 'assets/public.js', array( 'jquery' ), '', true );

	$payu_base_url             = isset( $wte_settings["payment_debug"] ) ? 'https://test.payu.in/_payment' : 'https://secure.payu.in/_payment';

	$translation_array = array(
	'settings' => array(
		'merchantKey' => $merchant_key,
		'enable' => $enable,
	),
	'success' => __( 'Redirecting to PayU...', 'wte-payu' ),
	'payU_URL' => $payu_base_url,
	);
	wp_localize_script( 'Wte-PayU', 'payu', $translation_array );
	wp_enqueue_script( 'Wte-PayU' );
}

function wte_payu_settings()
{ 
	$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', true );
	?>
	<div class="wte-payu-form settings wp-travel-engine-settings">
	<h4><?php _e( 'PayU Gateway Settings', 'wte-payu'); ?></h4>
	<label for="wp_travel_engine_settings[payu_merchant_id]"><?php _e('Merchant Key : ','wte-payu');?> <span class="tooltip" title="Enter a valid Merchant key from PayU account. All payments will go to this account."><i class="fas fa-question-circle"></i></span></label> 
	<input type="text" id="wp_travel_engine_settings[payu_merchant_id]" name="wp_travel_engine_settings[payu_merchant_id]" value="<?php echo isset($wp_travel_engine_settings['payu_merchant_id']) ? esc_attr( $wp_travel_engine_settings['payu_merchant_id'] ): '';?>">                               
	<label for="wp_travel_engine_settings[payu_salt]"><?php _e('Merchant Salt : ','wte-payu');?> <span class="tooltip" title="Enter a valid Merchant Salt from PayU account."><i class="fas fa-question-circle"></i></span></label> 
	<input type="text" id="wp_travel_engine_settings[payu_salt]" name="wp_travel_engine_settings[payu_salt]" value="<?php echo isset($wp_travel_engine_settings['payu_salt']) ? esc_attr( $wp_travel_engine_settings['payu_salt'] ): '';?>">
	</div>
<?php
}

//admin enable settings
function wte_payu_enable()
{   
	$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', true );
	?>
	<div class="wte-payu-form wp-travel-engine-settings">
	<label for="wp_travel_engine_settings[payu_enable]"><?php _e('PayU : ','wte-payu');?> <span class="tooltip" title="Please check this to enable PayU booking system for trip booking and fill the account info below."><i class="fas fa-question-circle"></i></span></label> 
	<input type="checkbox" id="wp_travel_engine_settings[payu_enable]" class="payu" name="wp_travel_engine_settings[payu_enable]" value="1" <?php if(isset($wp_travel_engine_settings['payu_enable']) && $wp_travel_engine_settings['payu_enable']!='' ) echo 'checked'; ?>>
	<label for="wp_travel_engine_settings[payu_enable]" class="checkbox-label"></label>
	</div>
<?php
}


function payu_form()
{ 
	ob_start();

	$obj = new Wp_Travel_Engine_Functions();
	$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', true );

	$billing_options           = $obj->order_form_billing_options();
	$personal_options          = $obj->order_form_personal_options();
	$relation_options          = $obj->order_form_relation_options();

	$merchant_key              = isset($wp_travel_engine_settings['payu_merchant_id']) ? esc_attr( $wp_travel_engine_settings['payu_merchant_id'] ): '';
	$merchant_salt             = isset($wp_travel_engine_settings['payu_salt']) ? esc_attr( $wp_travel_engine_settings['payu_salt'] ): '';

	$payu_base_url             = isset( $wp_travel_engine_settings["payment_debug"] ) ? 'https://secure.payu.com/api/v2_1/orders' : 'https://secure.payu.com/api/v2_1/orders'; // For Test environment
	$action                    = '';
	$currentDir                = 'http://localhost/creative/payment/payumoney/';

	$txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);
	
	$email     = $_POST['email'];
	$phone     = $_POST['phone'];
	$firstName = $_POST['firstName'];
	$lastName  = $_POST['lastName'];
	$amount    = $_POST['amount'].'.00';
	$hash      = '';

	if(isset($_POST['email']))
	{
	$hash_string = $merchant_key."|".$txnid."|".$amount."|"."productinfo|".$firstName."|".$email."|||||||||||".$merchant_salt;
	$hash = strtolower(hash('sha512', $hash_string));
	$action = $payu_base_url . '/_payment'; 
	}
	?>
		<input type="hidden" name="key" value="<?php echo $merchant_key;?>">
		<input type="hidden" name="hash" value="<?php echo $hash;?>">
		<input type="hidden" name="txnid" value="<?php echo $txnid;?>">
		<div class='payu-title'>
		<?php $title = __('Mandatory Parameters','wte-payu'); echo apply_filters('mandatory_payu_title',$title); ?>
		</div>
		<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('First Name', 'wte-payu' );?><span class="mand">*</span>:</label> 
		<input type="text" name="firstname" id="firstname" value="<?php echo esc_attr( $firstName );?>">
		</div>
		
		<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('Last Name','wte-payu');?><span class="mand">*</span>:</label> 
		<input type="text" name="lastname" id="lastname" value="<?php echo esc_attr($lastName);?>">
		</div>
		
		<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('Email','wte-payu');?><span class="mand">*</span>:</label> 
		<input type="email" name="email" id="email" value="<?php echo esc_attr($email);?>">
		</div>
		
		<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('Phone','wte-payu');?> <span class="mand">*</span>:</label> 
		<input type="text" name="phone" value="<?php echo esc_attr($phone);?>">
		<input name="productinfo" type="hidden" value="<?php echo get_the_title( $_SESSION['trip-id'] ); ?>" />
		<input type="hidden" name="surl" value="http://localhost/creative/payment/payumoney/success.php" size="64">
		<input type="hidden" name="furl" value="http://localhost/creative/payment/payumoney/failure.php" size="64">
		</div>
		
		<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('Country','wte-payu');?><span class="mand">*</span>:</label> 
		<select required id="<?php echo esc_attr( $key );?>" name="country" data-placeholder="<?php esc_attr_e( 'Choose a field type&hellip;', 'wte-payu' ); ?>" class="wc-enhanced-select" >
				<option value=" "><?php _e( 'Choose country&hellip;', 'wte-payu' ); ?></option>
				<?php
				$options = $obj->wp_travel_engine_country_list();
				foreach ( $options as $key => $val ) {
					echo '<option value="' .( !empty($val)?esc_attr( $val ):"Please select")  . '">' . esc_html( $val ) . '</option>';
				}
				?>
		</select>
		</div>
		
		<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('Address1: ','wte-payu');?><span class="mand">*</span>:</label> 
		<input type="text" name="address1" value="">
		</div>

		<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('City: ','wte-payu');?><span class="mand">*</span>:</label> 
		<input type="text" name="city" value="">
		<!-- <input type="hidden" name="service_provider" value="payu_paisa" size="64"> -->
		</div>
		<div class='payu-title'>
		<?php $title = __('Optional Parameters','wte-payu'); echo apply_filters('optional_payu_title',$title);?>
		</div>
		<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('State: ','wte-payu');?></label> 
		<input type="text" name="state" value="">
		</div>

		<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('Address2: ','wte-payu');?></label> 
		<input type="text" name="address2" value="">
		</div>
		
		<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('Zipcode: ','wte-payu');?></label>
		<input type="text" name="zipcode" value="">
		</div>

		<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('UDF2:','wte-payu');?></label>
		<input type="text" name="udf2" value="">
		<input type="hidden" name="udf1" value="">
		</div>

		<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('UDF3: ','wte-payu');?></label> 
		<input type="text" name="udf3" value="">
		</div>

		<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('UDF4:','wte-payu');?></label> 
		<input type="text" name="udf4" value="">
		</div>
		
		<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('UDF5: ','wte-payu');?></label> 
		<input type="text" name="udf5" value="">
		</div>
		
		<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('PG: ','wte-payu');?></label> 
		<input type="text" name="pg" value="">
		</div>
<?php
	wp_reset_postdata();
	$data = ob_get_clean();
	wp_send_json_success( $data );
}

function payu_payment_process()
{
	ob_start();
	$obj = new Wp_Travel_Engine_Functions();
	$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', true );

	$billing_options           = $obj->order_form_billing_options();
	$personal_options          = $obj->order_form_personal_options();
	$relation_options          = $obj->order_form_relation_options();

	$merchant_key              = isset( $wp_travel_engine_settings['payu_merchant_id'] ) ? esc_attr( $wp_travel_engine_settings['payu_merchant_id'] ): '';
	$merchant_salt             = isset( $wp_travel_engine_settings['payu_salt'] ) ? esc_attr( $wp_travel_engine_settings['payu_salt'] ): '';

	$payu_base_url             = "https://secure.payu.com/api/v2_1/orders"; // For Test environment
	$action                    = '';
	$currentDir                = 'http://localhost/creative/payment/payumoney/';

	$payu_base_url             = isset( $wp_travel_engine_settings["payment_debug"] ) ? 'https://secure.payu.com/api/v2_1/orders' : 'https://secure.payu.com/api/v2_1/orders';

	$txnid = substr(hash('sha256', mt_rand() . microtime()), 0, 20);

	$email     = $_POST['email'];
	$phone     = $_POST['phone'];
	$firstName = $_POST['firstname'];
	$lastName  = $_POST['lastname'];
	$country   = $_POST['country'];    
	$city      = $_POST['city'];
	$address1  = $_POST['address1'];
	$amount    = $_SESSION['trip-cost'];
	$amount    = str_replace( ',', '', $amount );
	
	$hash         = '';
	
	if(isset($_POST['email']))
	{
	$hash_string = $merchant_key.'|'.$txnid.'|'.$amount.'|'.get_the_title( $_SESSION['trip-id'] ).'|'.$firstName.'|'.$email.'|'.$_SESSION['travelers'].'||||||||||'.$merchant_salt;
	$hash = strtolower(hash('sha512', $hash_string));
	$action = $payu_base_url . '/_payment';
	}
	?>
	<input type="hidden" name="key" value="<?php echo $merchant_key;?>">
	<input type="hidden" name="hash" value="<?php echo $hash;?>">
	<input type="hidden" name="txnid" value="<?php echo $txnid;?>">
	<!-- <input type="hidden" name="service_provider" value="payu_paisa"> -->
	<div class='payu-title'>
		<?php _e('Mandatory Parameters','wte-payu');?>
	</div>
	<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('First Name','wte-payu');?><span class="mand">*</span>:</label> 
		<input type="text" name="firstname" id="firstname" value="<?php echo esc_attr( $firstName );?>">
	</div>

	<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('Last Name','wte-payu');?><span class="mand">*</span>:</label> 
		<input type="text" name="lastname" id="lastname" value="<?php echo esc_attr($lastName);?>">
		<input type="hidden" name="curl" value="<?php echo esc_url( get_permalink( $_SESSION['trip-id'] )) ?>">
	</div>

	<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('Email','wte-payu');?><span class="mand">*</span>:</label> 
		<input type="email" name="email" id="email" value="<?php echo esc_attr($email);?>">
	</div>

	<div class='wp-travel-engine-billing-details-field-wrap'>
		<?php _e('Phone','wte-payu');?><span class="mand">*</span>: 
		<input type="text" name="phone" value="<?php echo esc_attr($phone);?>">
		<input name="amount" type="hidden" value="<?php echo $amount; ?>">
		<input name="productinfo" type="hidden" value="<?php echo get_the_title( $_SESSION['trip-id'] ); ?>" />
		<?php
		$wp_travel_engine_confirm = isset($wp_travel_engine_settings['pages']['wp_travel_engine_confirmation_page']) ? esc_attr($wp_travel_engine_settings['pages']['wp_travel_engine_confirmation_page']) : '';
		$wp_travel_engine_confirm = get_permalink( $wp_travel_engine_confirm );
		?>
		<input type="hidden" name="surl" value="<?php echo esc_url($wp_travel_engine_confirm); ?>" size="64">
		<input type="hidden" name="furl" value="<?php echo esc_url( get_permalink( $_SESSION['trip-id'] )) ?>" size="64">
	</div>
	
	<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('Country','wte-payu');?><span class="mand">*</span>:</label> 
		<select required id="<?php echo esc_attr( $key );?>" name="country" data-placeholder="<?php esc_attr_e( 'Choose a field type&hellip;', 'wte-payu' ); ?>" class="wc-enhanced-select" >
				<option value=" "><?php _e( 'Choose country&hellip;', 'wte-payu' ); ?></option>
				<?php
				$options = $obj->wp_travel_engine_country_list();
				foreach ( $options as $key => $val ) {
				echo '<option value="' .( !empty($val)?esc_attr( $val ):"Please select")  . '"' . selected( $country, $val, false ) . '>' . esc_html( $val ) . '</option>';
				}
				?>
		</select>
	</div>

	<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('Address1','wte-payu');?><span class="mand">*</span>:</label> 
		<input type="text" name="address1" value="<?php echo esc_attr($address1);?>" required>
	</div>

	<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('City','wte-payu');?><span class="mand">*</span>:</label> 
		<input type="text" name="city" value="<?php echo esc_attr($city); ?>" required>
		<!-- <input type="hidden" name="service_provider" value="payu_paisa" size="64"> -->
	</div>
	<div class='payu-title'>
	<?php _e('Optional Parameters','wte-payu');?>
	</div>
	<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('State: ','wte-payu');?></label>
		<input type="text" name="state" value="">
	</div>
	
	<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('Address2: ','wte-payu');?></label> 
		<input type="text" name="address2" value="">
	</div>
	
	<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('Zipcode: ','wte-payu');?></label> 
		<input type="text" name="zipcode" value="">
	</div>

	<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('UDF2: ','wte-payu');?></label> 
		<input type="text" name="udf2" value="">
		<input type="hidden" name="udf1" value="<?php echo esc_attr($_SESSION['travelers']); ?>">
	</div>
	
	
	<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('UDF3: ','wte-payu');?></label> 
		<input type="text" name="udf3" value="">
	</div>

	<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('UDF4:','wte-payu');?></label> 
		<input type="text" name="udf4" value="">
	</div>

	<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('UDF5: ','wte-payu');?></label> 
		<input type="text" name="udf5" value="">
	</div>

	<div class='wp-travel-engine-billing-details-field-wrap'>
		<label><?php _e('PG: ','wte-payu');?></label> 
		<input type="text" name="pg" value="">
	</div>
<?php
	wp_reset_postdata();
	$data = ob_get_clean();
	wp_send_json_success( $data );
}

/**
	 * Add PayU to payment gateways list.
	 *
	 * @param [type] $gateway_list
	 * @return void
	 */
	public function payu_gateway_list( $gateway_list ) {
		if ( ! $this->is_currency_inr() ) {
			return $gateway_list;
		}

		$gateway_list['payu_enable'] = array(
			'label'       => __( 'PayU', 'wte-payu' ),
			'input_class' => 'payu',
			'info_text'   => __( 'Please check this to enable PayU booking system for trip booking and fill the account info below.', 'wte-payu' ),
		);

	return $gateway_list;

	}

	/**
	 * Is currency INR.
	 *
	 * @return boolean
	 */
	public function is_currency_inr() {
		$currency_code = wp_travel_engine_get_currency_code();

		return 'INR' === $currency_code;
	}

	public function add_global_settings( $global_tabs ) {
		

		if ( isset( $global_tabs['wpte-payment'] ) ) {
			$global_tabs['wpte-payment']['sub_tabs']['wte-payu'] = array(
				'label' => __( 'PayU Biz Payment', 'wte-payu' ),
				'content_path' => plugin_dir_path( __FILE__ ) . 'admin/includes/backend/global.php',
				'current' => false,
			);
		}

		return $global_tabs;
	}

}
new Wte_Payu_Admin;
