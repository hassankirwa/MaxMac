<?php
/**
 * Easy Digital Downloads Plugin Updater
 *
 * @package Wte_PayU_Gateway
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Includes the files needed for the plugin updater.
 *
 * @since 1.0.0
 */
if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {

	include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

/**
 * Download ID for the product in Easy Digital Downloads.
 *
 * @since 1.0.0
 */
define( 'WP_TRAVEL_ENGINE_PAYU_ITEM_ID', 1055 ); 

/**
 * Setup the updater for the Wte_PayU_Gateway Add-on.
 *
 * @since 1.0.0
 */
function wte_payu_payment_updater() {

	// retrieve our license key from the DB
	$settings    = get_option( 'wp_travel_engine_license' );
	$license_key = isset( $settings['wte_payu_license_key'] ) ? esc_attr( $settings['wte_payu_license_key'] ) : '';

	// setup the updater
	$edd_updater = new EDD_SL_Plugin_Updater( WP_TRAVEL_ENGINE_STORE_URL, WP_TRAVEL_ENGINE_PAYU_FILE_PATH,
		array(
			'version' => WP_TRAVEL_ENGINE_PAYU_VERSION,                    // current version number
			'license' => $license_key,             // license key (used get_option above to retrieve from DB)
			'item_id' => WP_TRAVEL_ENGINE_PAYU_ITEM_ID,       // ID of the product
			'author'  => 'WP Travel Engine', // author of this plugin
			'beta'    => false,
		)
	);

}
add_action( 'admin_init', 'wte_payu_payment_updater', 0 );

/**
 * Add-ons name for plugin license page.
 *
 * @since 1.0.0
 */
function wte_payu_name($array)
{
	$array['WP Travel Engine - PayU Biz Payment Gateway'] =  'wte_payu';
	return $array;
}
add_filter( 'wp_travel_engine_addons', 'wte_payu_name' );

/**
 * Add-ons Item ID for plugin license page.
 *
 * @since 1.0.0
 */
function wte_payu_id($array)
{
	$array['wte_payu'] = WP_TRAVEL_ENGINE_PAYU_ITEM_ID;
	return $array;
}
add_filter( 'wp_travel_engine_addons_id', 'wte_payu_id' );

/**
 * Add-ons License details for showing updates in plugin license page.
 *
 * @since 1.0.0
 */
function wte_payu_gateway_license($array)
{
	$settings = get_option( 'wp_travel_engine_license' );
	$license_key = isset( $settings['wte_payu_license_key'] ) ? esc_attr( $settings['wte_payu_license_key'] ) : '';// setup the updater

	$array[] = 
		array( 
	    'version' => WP_TRAVEL_ENGINE_PAYU_VERSION,     // current version number
	    'license' => $license_key,   // license key (used get_option above to retrieve from DB)
	    'item_id' => WP_TRAVEL_ENGINE_PAYU_ITEM_ID,   // id of this product in EDD
	    'author'  => 'WP Travel Engine',  // author of this plugin
	    'url'     => home_url()
	  );
	return $array;
}

$wp_travel_engine = get_option( 'wp_travel_engine_license' );
$wte_payu_license_status  = isset( $wp_travel_engine['wte_payu_license_status'] ) ? esc_attr( $wp_travel_engine['wte_payu_license_status'] ) : '';

if( isset( $wte_payu_license_status ) && $wte_payu_license_status == 'valid' ){
	add_filter( 'wp_travel_engine_licenses', 'wte_payu_gateway_license' );
}
