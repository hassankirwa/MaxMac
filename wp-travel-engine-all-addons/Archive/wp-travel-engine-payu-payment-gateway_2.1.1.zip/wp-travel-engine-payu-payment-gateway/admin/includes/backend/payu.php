<?php
global $post;
$wp_travel_engine_postmeta_settings = get_post_meta( $post->ID, 'wp_travel_engine_booking_setting', true );
?>
<div class="trip-info-meta">
	<div>
	<label for="wp_travel_engine_booking_setting[place_order][payment][mihpayid]"><?php _e('MIHPayID: ','wte-payu');?></label>	
	<input type="text" id="wp_travel_engine_booking_setting[place_order][payment][mihpayid]" name="wp_travel_engine_booking_setting[place_order][payment][mihpayid]" value="<?php echo isset($wp_travel_engine_postmeta_settings['place_order']['payment']['mihpayid']) ? esc_attr($wp_travel_engine_postmeta_settings['place_order']['payment']['mihpayid']):''?>">
	</div>
	<div>
	<label for="wp_travel_engine_booking_setting[place_order][payment][txnid]"><?php _e('Transaction ID: ','wte-payu');?></label>	
	<input type="text" id="wp_travel_engine_booking_setting[place_order][payment][txnid]" name="wp_travel_engine_booking_setting[place_order][payment][txnid]" value="<?php echo isset($wp_travel_engine_postmeta_settings['place_order']['payment']['txnid']) ? esc_attr($wp_travel_engine_postmeta_settings['place_order']['payment']['txnid']):'';?>">
	</div>
	<div>
	<label for="wp_travel_engine_booking_setting[place_order][payment][status]"><?php _e('Status: ','wte-payu');?></label>	
	<input type="text" id="wp_travel_engine_booking_setting[place_order][payment][status]" name="wp_travel_engine_booking_setting[place_order][payment][status]" value="<?php echo isset($wp_travel_engine_postmeta_settings['place_order']['payment']['status']) ? esc_attr($wp_travel_engine_postmeta_settings['place_order']['payment']['status']):'';?>">
	</div>
</div>