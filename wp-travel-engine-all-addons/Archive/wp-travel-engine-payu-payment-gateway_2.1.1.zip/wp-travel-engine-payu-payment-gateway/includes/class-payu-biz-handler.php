<?php
/**
 * PayU India Payment Gateway
 *
 * Provides a PayU India Payment Gateway.
 *
 * @class WTE_PayU_Biz_India
 * @package WP Travel Engine
 * @category Payment Gateways
 * @author WP Travel Engine
 */

class WTE_PayU_Biz_India {

	/**
	 * __construct function.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return void
	 */
	public function __construct() {

		$wte_settings = get_option( 'wp_travel_engine_settings', array() );

		$this->liveurl  = 'https://secure.payu.in/_payment';
		$this->testurl  = 'https://test.payu.in/_payment';
		$this->testmode = isset( $wte_settings['payment_debug'] ) && 'yes' === $wte_settings['payment_debug'];

		$merchantid   = isset( $wte_settings['payu_merchant_id'] ) ? $wte_settings['payu_merchant_id'] : '';
		$merchant_key = trim( $merchantid );

		$this->merchantid = $merchant_key;
		$this->salt       = isset( $wte_settings['payu_salt'] ) ? $wte_settings['payu_salt'] : '';

		// IPN
		if ( ! isset( $_REQUEST['_action'] ) && isset( $_GET['payu_in_callback'] ) && esc_attr( $_GET['payu_in_callback'] ) == '1' ) {
			$this->check_transaction_status();
		}

		$this->init_hooks();

	} // End Constructor

	public function init_hooks() {

		add_action( 'wp_travel_engine_after_booking_process_completed', array( $this, 'generate_payu_in_form' ) );

		add_action( 'wp_travel_engine_after_remaining_payment_process_completed', array( $this, 'generate_payu_in_form_partial' ) );

		add_filter( 'wp_travel_engine_checkout_default_fields', array( $this, 'payu_additional_fields' ) );

		add_action( 'wte_payment_gateway_payu_enable', array( $this, 'map_payment_data' ), 10, 3 );

		add_action( 'init', array( $this, 'remove_callback_hook_from_core' ), 8 );

		add_action( 'wte_callback_for_payu_enable_thankyou', array( $this, 'handle_notification_callback' ) );
	}

	/**
	 *
	 * @since 2.1.0
	 */
	public function handle_notification_callback( array $payload ) {
		list( $booking_id, $payment_id ) = array_values( $payload );

		if ( isset( $_REQUEST['txnid'] ) ) {
			$response = $_REQUEST;
		} else {
			return;
		}

		$txnid = $response['txnid'];
		if ( $this->payu_in_transaction_verification( $txnid ) == 'success' ) {
			$booking = get_post( $booking_id );
			\WTE_Booking::update_booking(
				$payment_id,
				array(
					'meta_input' => array(
						'payment_status'   => 'success',
						'payment_amount'   => array(
							'value'    => $response['amount'],
							'currency' => 'INR',
						),
						'gateway_response' => $response,
					),
				)
			);
			$meta_input = array(
				'wp_travel_engine_booking_status' => 'booked',
				'paid_amount'                     => +$booking->paid_amount + +wte_array_get( $response, 'amount', 0 ),
				'due_amount'                      => 0,
			);
			if ( (float) $booking->due_amount > (float) $response['amount'] ) {
				$meta_input['due_amount'] = (float) $booking->due_amount - (float) $response['amount'];
			}

			\WTE_Booking::update_booking(
				$booking_id,
				array(
					'meta_input' => $meta_input,
				)
			);
			\WTE_Booking::send_emails( $payment_id, 'order_confirmation', 'all' );
			return;
		}

	}

	/**
	 *
	 * @since 2.1.0
	 */
	public function remove_callback_hook_from_core() {
		if ( ( isset( $_REQUEST['wte_gateway'] ) && 'payubiz' === $_REQUEST['wte_gateway'] ) || ( isset( $_REQUEST['payu_in_callback'] ) && '1' === $_REQUEST['payu_in_callback'] ) ) {
			remove_action( 'init', array( 'WPTravelEngine\Core\Booking', 'payment_gateway_callback_backward_compatibility' ), 9 );
			remove_action( 'init', array( 'WTE_Booking', 'payment_gateway_callback_backward_compatibility' ), 9 );
		}
	}

	/**
	 *
	 * @since 2.1.0
	 */
	public function map_payment_data( $payment_id, $type = 'full_payment', $gateway = '' ) {
		remove_action( 'wp_travel_engine_after_booking_process_completed', array( $this, 'generate_payu_in_form' ) );
		remove_action( 'wp_travel_engine_after_remaining_payment_process_completed', array( $this, 'generate_payu_in_form_partial' ) );

		$payment_data = array(
			'payment_status'       => 'pending',
			'not_confirmed_amount' => get_post( $payment_id )->payable['amount'],
			'payment_remarks'      => 'Payment request has been set and need confirmation.',
		);

		\WTE_Booking::update_booking(
			$payment_id,
			array(
				'meta_input' => $payment_data,
			)
		);

		$booking_id = get_post_meta( $payment_id, 'booking_id', true );
		if ( empty( $booking_id ) ) {
			return;
		}

		do_action( 'wp_travel_engine_after_booking_process_completed', $booking_id );

		$this->generate_payu_in_form( $booking_id, $type == 'partial', $payment_id );
		// $this->generate_payu_in_form( $booking_id, $payment_id );
	}

	function generate_payu_in_form_partial( $booking_id ) {
		if ( ! $booking_id ) {
			return;
		}

		if ( ! isset( $_POST['wpte_checkout_paymnet_method'] ) || 'payu_enable' !== $_POST['wpte_checkout_paymnet_method'] ) {
			return;
		}

		$booking_metas  = get_post_meta( $booking_id, 'wp_travel_engine_booking_setting', true );
		$payment_amount = isset( $booking_metas['place_order']['due'] ) ? $booking_metas['place_order']['due'] : 0;
		$productinfo    = sprintf( __( 'Booking #%s from ', 'wte-payu' ), $booking_id ) . get_bloginfo( 'name' );
		// Hash data
		$hash_data['key'] = $this->merchantid;
		// Unique alphanumeric Transaction ID
		$hash_data['txnid']       = substr( hash( 'sha256', mt_rand() . microtime() ), 0, 20 );
		$hash_data['amount']      = $payment_amount;
		$hash_data['productinfo'] = $productinfo;
		$hash_data['firstname']   = isset( $booking_metas['place_order']['booking']['fname'] ) && ! empty( $booking_metas['place_order']['booking']['fname'] ) ? $booking_metas['place_order']['booking']['fname'] : '';
		$hash_data['email']       = isset( $booking_metas['place_order']['booking']['email'] ) && ! empty( $booking_metas['place_order']['booking']['email'] ) ? $booking_metas['place_order']['booking']['email'] : '';

		$hash_data['hash'] = $this->calculate_hash_before_transaction( $hash_data );

		update_post_meta( $booking_id, '_wte_payu_payment_txnid', $hash_data['txnid'] );

		$return_url = wp_travel_engine_get_booking_confirm_url();

		$return_url = add_query_arg(
			array(
				'booking_id'    => intval( $booking_id ),
				'status'        => 'success',
				'wte_gateway'   => 'payubiz',
				'redirect_type' => 'partial-payment',
			),
			urldecode( $return_url )
		);

		$fail_cancel_url = isset( $booking_metas['place_order']['tid'] ) && ! empty( $booking_metas['place_order']['tid'] ) ? get_the_permalink( $booking_metas['place_order']['tid'] ) : home_url( '/' );

		// PayU Args
		$payu_in_args = array(

			// Merchant details
			'key'         => $this->merchantid,
			'surl'        => add_query_arg( 'payu_in_callback', 1, $return_url ),
			'furl'        => add_query_arg(
				array(
					'payu_in_callback' => 1,
					'payu_in_status'   => 'failed',
				),
				esc_url( $fail_cancel_url )
			),
			'curl'        => add_query_arg(
				array(
					'payu_in_callback' => 1,
					'payu_in_status'   => 'cancelled',
				),
				esc_url( $fail_cancel_url )
			),

			// Customer details
			'firstname'   => esc_attr( $booking_metas['place_order']['booking']['fname'] ),
			'lastname'    => esc_attr( $booking_metas['place_order']['booking']['lname'] ),
			'email'       => esc_attr( $booking_metas['place_order']['booking']['email'] ),
			'address1'    => esc_attr( $booking_metas['place_order']['booking']['address'] ),
			'address2'    => '',
			'city'        => esc_attr( $booking_metas['place_order']['booking']['city'] ),
			'state'       => '',
			'zipcode'     => '',
			'country'     => esc_attr( $booking_metas['place_order']['booking']['country'] ),
			'phone'       => esc_attr( $booking_metas['place_order']['booking']['phone'] ),

			// Item details
			'productinfo' => $productinfo,
			'amount'      => $payment_amount,

			// Pre-selection of the payment method tab
			'pg'          => $this->get_get_var( 'pg' ),

		);

		$payuform = '';
		foreach ( $payu_in_args as $key => $value ) {
			if ( $value ) {
				$payuform .= '<input type="hidden" name="' . $key . '" value="' . $value . '" />' . "\n";
			}
		}

		$payuform .= '<input type="hidden" name="txnid" value="' . $hash_data['txnid'] . '" />' . "\n";
		$payuform .= '<input type="hidden" name="hash" value="' . $hash_data['hash'] . '" />' . "\n";

		// Get the right URL in case the test mode is enabled
		$posturl = $this->liveurl;
		if ( $this->testmode ) {
			$posturl = $this->testurl; }
		// The form
		echo '<p>' . esc_html_e( 'Redirecting to PayU Biz website...', 'wte-payu' ) . '</p>
			<form action="' . $posturl . '" method="POST" name="payform" id="payform">
				' . $payuform . '
				<input type="submit" class="button" id="submit_payu_in_payment_form" value="' . __( 'Pay via PayU', 'wte-payu' ) . '" />
				<script type="text/javascript">
                    document.getElementById("submit_payu_in_payment_form").click();
				</script>
            </form>';
		exit;
	}

	/**
	 *
	 * @since 2.1.0
	 */
	public function get_billing_info( $booking_id, $payment_mode = 'full_payment' ) {
		$billing_info  = array();
		$billing_infos = get_post_meta( $booking_id, 'billing_info', true );
		if ( ! empty( $billing_infos ) && is_array( $billing_infos ) ) {
			foreach (
				array(
					'fname' => 'firstname',
					'lname' => 'lastname',
					'email' => 'email',
					'phone' => '123456',
				) as $key => $args_key ) {
				if ( isset( $billing_infos[ $key ] ) ) {
					$billing_info[ $args_key ] = $billing_infos[ $key ];
				}
			}
		}

		return $billing_info;

	}

	/**
	 *
	 * @since 2.1.0
	 */
	public static function get_thankyou_page_url() {

		$wte_settings = get_option( 'wp_travel_engine_settings', array() );

		if ( isset( $wte_settings['pages']['wp_travel_engine_thank_you'] ) ) {
			$page_id = $wte_settings['pages']['wp_travel_engine_thank_you'];
		}

		if ( ! empty( $page_id ) ) {
			$page = get_permalink( $page_id );
		} else {
			$page = esc_url( home_url( '/' ) );
		}

		return $page;

	}

	/**
	 *
	 * @since 2.1.0
	 */
	public function prepare_payment_form( $payment_id, $payment_mode = 'full_payment' ) {
		$payment    = get_post( $payment_id );
		$booking_id = get_post_meta( $payment_id, 'booking_id', true );

		$booking = get_post( $booking_id );

		$cart_info = $booking->cart_info;
		$amounts   = array(
			'full_payment'      => round( $cart_info['total'], 2 ),
			'partial'           => round( $cart_info['cart_partial'], 2 ),
			'remaining_payment' => round( $cart_info['subtotal'], 2 ) - round( $cart_info['cart_partial'], 2 ),
		);

		if ( ! isset( $amounts[ $payment_mode ] ) ) {
			$payment_mode = 'full_payment';
		}

		if ( in_array( $payment_mode, array( 'due', 'remaining_payment' ) ) ) {
			$return_url = \WTE_Booking::get_tokened_url(
				'thankyou',
				array(
					'bid'      => $booking_id,
					'pid'      => $payment_id,
					'_gateway' => 'payu_enable',
				),
				self::get_thankyou_page_url()
			);
		} else {
			$return_url = \WTE_Booking::get_thankyou_url( $booking_id, $payment_id, 'payu_enable' );
		}

		$order_items = $booking->order_trips;

		$item_name = '';
		if ( is_array( $order_items ) ) {
			foreach ( $order_items as $item ) {
				$item_name = ! empty( $item['title'] ) ? $item['title'] : 'Trip';
				break;
			}
		}

		$productinfo = sprintf( __( 'Booking #%s from ', 'wte-payu' ), $booking_id ) . get_bloginfo( 'name' );

		$billing_info = $this->get_billing_info( $booking_id, $payment_mode );
		// Hash data.
		$hash_data = array();
		// Hash data
		$hash_data['key'] = $this->merchantid;
		// Unique alphanumeric Transaction ID
		$hash_data['txnid']       = substr( hash( 'sha256', mt_rand() . microtime() ), 0, 20 );
		$hash_data['amount']      = $amounts[ $payment_mode ];
		$hash_data['productinfo'] = $productinfo;
		$hash_data['firstname']   = $billing_info['firstname'];
		$hash_data['email']       = $billing_info['email'];
		$hash_data['hash']        = $this->calculate_hash_before_transaction( $hash_data );

		update_post_meta( $booking_id, '_wte_payu_payment_txnid', $hash_data['txnid'] );

		$form_data_array = array(
			// Merchant details
			'key'         => $this->merchantid,
			'surl'        => add_query_arg( 'payu_in_callback', 1, $return_url ),
			'furl'        => add_query_arg(
				array(
					'payu_in_callback' => 1,
					'payu_in_status'   => 'failed',
					'payment_id'       => $payment_id,
				),
				esc_url( home_url( '/' ) )
			),
			'curl'        => \WTE_Booking::get_cancel_url( $booking_id, $payment_id, 'payu_enable' ),
			'productinfo' => $productinfo,
			'amount'      => $amounts[ $payment_mode ],

			// Pre-selection of the payment method tab
			'pg'          => $this->get_get_var( 'pg' ),
		);

		$form_data_array = wp_parse_args( $billing_info, $form_data_array );

		$inputs = '';
		foreach ( $form_data_array as $name => $value ) {
			$inputs .= '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" />' . "\n";
		}
		$inputs  .= '<input type="hidden" name="txnid" value="' . $hash_data['txnid'] . '" />' . "\n";
		$inputs  .= '<input type="hidden" name="hash" value="' . $hash_data['hash'] . '" />' . "\n";
		$post_url = $this->testmode ? $this->testurl : $this->liveurl;
		echo '<p>' . esc_html_e( 'Redirecting to PayFast website...', 'wte-payu' ) . '</p>
			<form action="' . $post_url . '" method="POST" name="payfast_payment_form" id="submit_payu_in_payment_form">
				' . $inputs . '
				<input type="submit" class="button" id="submit_payu_in_payment_submit_button" value="' . __( 'Pay via PayU', 'wte-payu' ) . '" />
				<script type="text/javascript">
                    document.getElementById("submit_payu_in_payment_submit_button").click();
				</script>
            </form>';
		exit;
	}

	/**
	 * Generate the PayU India button link.
	 *
	 * @since 1.0.0
	 */
	function generate_payu_in_form( $booking_id, $partial_payment = false, $payment_id = false ) {

		if ( ! ! $payment_id ) {
			$payment_mode = isset( $_POST['wp_travel_engine_payment_mode'] ) ? $_POST['wp_travel_engine_payment_mode'] : 'full_payment';
			$this->prepare_payment_form( $payment_id, $payment_mode );
			return;
		}
		if ( ! $booking_id ) {
			return;
		}

		// Is partial payment check.
		if ( ! $partial_payment ) {
			do_action( 'wte_payment_process', $booking_id );
		}

		// Check if paypal is selected.
		if ( ! isset( $_POST['wpte_checkout_paymnet_method'] ) || 'payu_enable' !== $_POST['wpte_checkout_paymnet_method'] ) {
			return;
		}

		global $wte_cart;

		$cart_totals = $wte_cart->get_total();

		$payment_mode = isset( $_POST['wp_travel_engine_payment_mode'] ) ? $_POST['wp_travel_engine_payment_mode'] : '';

		$payment_amount = number_format( $cart_totals['total'], 2, '.', '' );

		if ( 'partial' === $payment_mode && wp_travel_engine_is_cart_partially_payable() ) :

			$payment_amount = number_format( $cart_totals['total_partial'], 2, '.', '' );

		endif;

		$productinfo = sprintf( __( 'Booking #%s from ', 'wte-payu' ), $booking_id ) . get_bloginfo( 'name' );

		// Hash data
		$hash_data['key'] = $this->merchantid;
		// Unique alphanumeric Transaction ID
		$hash_data['txnid']       = substr( hash( 'sha256', mt_rand() . microtime() ), 0, 20 );
		$hash_data['amount']      = $payment_amount;
		$hash_data['productinfo'] = $productinfo;
		$hash_data['firstname']   = esc_attr( $_POST['wp_travel_engine_booking_setting']['place_order']['booking']['fname'] );
		$hash_data['email']       = esc_attr( $_POST['wp_travel_engine_booking_setting']['place_order']['booking']['email'] );
		$hash_data['hash']        = $this->calculate_hash_before_transaction( $hash_data );

		update_post_meta( $booking_id, '_wte_payu_payment_txnid', $hash_data['txnid'] );

		$return_url = wp_travel_engine_get_booking_confirm_url();

		$return_url = add_query_arg(
			array(
				'booking_id'  => $booking_id,
				'payment_id'  => $payment_id,
				'booked'      => true,
				'wte_gateway' => 'payubiz',
			),
			urldecode( $return_url )
		);

		$booking_metas = get_post_meta( $booking_id, 'wp_travel_engine_booking_setting', true );

		$fail_cancel_url = isset( $booking_metas['place_order']['tid'] ) && ! empty( $booking_metas['place_order']['tid'] ) ? get_the_permalink( $booking_metas['place_order']['tid'] ) : home_url( '/' );

		// PayU Args
		$payu_in_args = array(

			// Merchant details
			'key'         => $this->merchantid,
			'surl'        => add_query_arg( 'payu_in_callback', 1, $return_url ),
			'furl'        => add_query_arg(
				array(
					'payu_in_callback' => 1,
					'payu_in_status'   => 'failed',
				),
				esc_url( $fail_cancel_url )
			),
			'curl'        => add_query_arg(
				array(
					'payu_in_callback' => 1,
					'payu_in_status'   => 'cancelled',
				),
				esc_url( $fail_cancel_url )
			),

			// Customer details
			'firstname'   => esc_attr( $_POST['wp_travel_engine_booking_setting']['place_order']['booking']['fname'] ),
			'lastname'    => esc_attr( $_POST['wp_travel_engine_booking_setting']['place_order']['booking']['lname'] ),
			'email'       => esc_attr( $_POST['wp_travel_engine_booking_setting']['place_order']['booking']['email'] ),
			'address1'    => esc_attr( $_POST['wp_travel_engine_booking_setting']['place_order']['booking']['address'] ),
			'address2'    => '',
			'city'        => esc_attr( $_POST['wp_travel_engine_booking_setting']['place_order']['booking']['city'] ),
			'state'       => '',
			'zipcode'     => '',
			'country'     => esc_attr( $_POST['wp_travel_engine_booking_setting']['place_order']['booking']['country'] ),
			'phone'       => esc_attr( $_POST['wp_travel_engine_booking_setting']['place_order']['booking']['phone'] ),

			// Item details
			'productinfo' => $productinfo,
			'amount'      => $payment_amount,

			// Pre-selection of the payment method tab
			'pg'          => $this->get_get_var( 'pg' ),

		);

		$payuform = '';

		foreach ( $payu_in_args as $key => $value ) {
			if ( $value ) {
				$payuform .= '<input type="hidden" name="' . $key . '" value="' . $value . '" />' . "\n";
			}
		}

		$payuform .= '<input type="hidden" name="txnid" value="' . $hash_data['txnid'] . '" />' . "\n";
		$payuform .= '<input type="hidden" name="hash" value="' . $hash_data['hash'] . '" />' . "\n";

		// Get the right URL in case the test mode is enabled
		$posturl = $this->liveurl;

		if ( $this->testmode ) {
			$posturl = $this->testurl; }

		// The form
		echo '<p>' . esc_html_e( 'Redirecting to PayU Biz website...', 'wte-payu' ) . '</p>
			<form action="' . $posturl . '" method="POST" name="payform" id="payform">
				' . $payuform . '
				<input type="submit" class="button" id="submit_payu_in_payment_form" value="' . __( 'Pay via PayU', 'wte-payu' ) . '" />
				<script type="text/javascript">
                    document.getElementById("submit_payu_in_payment_form").click();
				</script>
            </form>';
		exit;

	} // End generate_payu_in_form()

	/**
	 * Process the payment and return the result.
	 *
	 * @since 1.0.0
	 */
	function process_payment( $order_id ) {
		$order = new WC_Order( $order_id );

		return array(
			'result'   => 'success',
			'redirect' => add_query_arg( 'order', $order->id, add_query_arg( 'key', $order->order_key, add_query_arg( 'pg', $this->get_post_var( 'pg' ), $order->get_checkout_payment_url( true ) ) ) ),
		);
	} // End process_payment()


	/**
	 * Check the validity of data recived in $_POST and the status of transaction
	 *
	 * @since 1.0.0
	 */
	function check_transaction_status() {

		global $woocommerce;

		$salt = $this->salt;

		if ( ! empty( $_POST ) ) {

			foreach ( $_POST as $key => $value ) {

				$txnRs[ $key ] = htmlentities( $value, ENT_QUOTES );
			}
		} else {

			die( 'No transaction data was passed!' );

		}

		$txnid = $txnRs['txnid'];

		/* Checking hash / true or false */
		if ( $this->check_hash_after_transaction( $salt, $txnRs ) ) {

			if ( $txnRs['status'] == 'success' ) {
				$this->payment_success( $txnid );
			}

			if ( $txnRs['status'] == 'pending' ) {
				$this->payment_pending( $txnid );
			}

			if ( $txnRs['status'] == 'failure' ) {
				$this->payment_failure( $txnid );
			}
		} else {
			die( 'Hash incorrect!' );
		}

	} // End check_transaction_status()


	/**
	 * @since 1.0.0
	 */
	function payment_success( $txnid ) {

		if ( $this->payu_in_transaction_verification( $txnid ) == 'success' ) {

			$args = array(
				'meta_key'    => '_wte_payu_payment_txnid',
				'meta_value'  => $txnid,
				'post_type'   => 'booking',
				'post_status' => 'publish',
			);

			$results = get_posts( $args );

			if ( $results ) {

				foreach ( $results as $result ) {

					$booking_id = $result->ID;

					$booking_metas = get_post_meta( $booking_id, 'wp_travel_engine_booking_setting', true );

					$booking_metas['place_order']['payment']['mihpayid'] = $_POST['mihpayid'];
					$booking_metas['place_order']['payment']['txnid']    = $txnid;
					$booking_metas['place_order']['payment']['status']   = $_POST['status'];

					update_post_meta( $booking_id, 'wp_travel_engine_booking_setting', $booking_metas );

					break;

				}
			} else {
				return false;
			}
			return true;
		} else {
			die( 'PayU verification failed!' );
		}

	} // End payment_success()


	/**
	 * @since 1.0.0
	 */
	function payment_pending( $txnid ) {

		if ( $this->payu_in_transaction_verification( $txnid ) == 'pending' ) {

			global $woocommerce;

			$args = array(
				'meta_key'    => '_wte_payu_payment_txnid',
				'meta_value'  => $txnid,
				'post_type'   => 'booking',
				'post_status' => 'publish',
			);

			$results = get_posts( $args );

			if ( $results ) {

				foreach ( $results as $result ) {

					$booking_id = $result->ID;

					$booking_metas = get_post_meta( $booking_id, 'wp_travel_engine_booking_setting', true );

					$booking_metas['place_order']['payment']['mihpayid'] = $_POST['mihpayid'];
					$booking_metas['place_order']['payment']['txnid']    = $txnid;
					$booking_metas['place_order']['payment']['status']   = $_POST['status'];

					update_post_meta( $booking_id, 'wp_travel_engine_booking_setting', $booking_metas );

					break;

				}
			} else {

				return false;

			}

			return false;

		} else {

			die( 'PayU verification failed!' );
		}

	} // End payment_pending()


	/**
	 * @since 1.0.0
	 */
	function payment_failure( $txnid ) {
		global $woocommerce;

			$args = array(
				'meta_key'    => '_wte_payu_payment_txnid',
				'meta_value'  => $txnid,
				'post_type'   => 'booking',
				'post_status' => 'publish',
			);

			$results = get_posts( $args );

			if ( $results ) {
				foreach ( $results as $result ) {

					$booking_id = $result->ID;

					$booking_metas = get_post_meta( $booking_id, 'wp_travel_engine_booking_setting', true );

					$booking_metas['place_order']['payment']['mihpayid'] = $_POST['mihpayid'];
					$booking_metas['place_order']['payment']['txnid']    = $txnid;
					$booking_metas['place_order']['payment']['status']   = $_POST['status'];

					update_post_meta( $booking_id, 'wp_travel_engine_booking_setting', $booking_metas );

					break;
				}
			} else {
				return false;
			}

			return false;

	} // End payment_failure()


	/**
	 * @since 1.0.0
	 */
	function payu_in_transaction_verification( $txnid ) {

		$this->verification_liveurl = 'https://info.payu.in/merchant/postservice';
		$this->verification_testurl = 'https://test.payu.in/merchant/postservice';

		$host = $this->verification_liveurl;
		if ( $this->testmode ) {
			$host = $this->verification_testurl; }

		$hash_data['key']     = $this->merchantid;
		$hash_data['command'] = 'verify_payment';
		$hash_data['var1']    = $txnid;
		$hash_data['hash']    = $this->calculate_hash_before_verification( $hash_data );

		// Call the PayU, and verify the status
		$response = $this->send_request( $host, $hash_data );

		$response = unserialize( $response );

		return $response['transaction_details'][ $txnid ]['status'];

	} // End payu_in_transaction_verification()


	/**
	 * @since 1.0.0
	 */
	function send_request( $host, $data ) {

		$response = wp_remote_post(
			$host,
			array(
				'method'    => 'POST',
				'body'      => $data,
				'timeout'   => 70,
				'sslverify' => false,
			)
		);

		if ( is_wp_error( $response ) ) {
			throw new Exception( __( 'There was a problem connecting to the payment gateway.', 'wte-payu' ) );
		}

		if ( empty( $response['body'] ) ) {
			throw new Exception( __( 'Empty PayU response.', 'wte-payu' ) );
		}

		$parsed_response = $response['body'];

		return $parsed_response;

	} // End send_request()



	/**
	 * @since 1.0.0
	 */
	function calculate_hash_before_transaction( $hash_data ) {

		$hash_sequence = 'key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10';
		$hash_vars_seq = explode( '|', $hash_sequence );
		$hash_string   = '';

		foreach ( $hash_vars_seq as $hash_var ) {

			$hash_string .= isset( $hash_data[ $hash_var ] ) ? $hash_data[ $hash_var ] : '';
			$hash_string .= '|';

		}

		$hash_string .= $this->salt;

		$hash_data['hash'] = strtolower( hash( 'sha512', $hash_string ) );

		return $hash_data['hash'];

	} // End calculate_hash_before_transaction()


	/**
	 * @since 1.0.0
	 */
	function check_hash_after_transaction( $salt, $txnRs ) {

		$hash_sequence = 'key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10';
		$hash_vars_seq = explode( '|', $hash_sequence );

		// generation of hash after transaction is = salt + status + reverse order of variables
		$hash_vars_seq = array_reverse( $hash_vars_seq );

		$merc_hash_string = $salt . '|' . $txnRs['status'];

		foreach ( $hash_vars_seq as $merc_hash_var ) {

			$merc_hash_string .= '|';
			$merc_hash_string .= isset( $txnRs[ $merc_hash_var ] ) ? $txnRs[ $merc_hash_var ] : '';

		}

		$merc_hash = strtolower( hash( 'sha512', $merc_hash_string ) );

		/* The hash is valid */
		if ( $merc_hash == $txnRs['hash'] ) {
			return true;
		} else {
			return false;
		}

	} // End check_hash_after_transaction()


	/**
	 * @since 1.0.0
	 */
	function calculate_hash_before_verification( $hash_data ) {

		$hash_sequence = 'key|command|var1';
		$hash_vars_seq = explode( '|', $hash_sequence );
		$hash_string   = '';

		foreach ( $hash_vars_seq as $hash_var ) {

			$hash_string .= isset( $hash_data[ $hash_var ] ) ? $hash_data[ $hash_var ] : '';
			$hash_string .= '|';
		}

		$hash_string      .= $this->salt;
		$hash_data['hash'] = strtolower( hash( 'sha512', $hash_string ) );

		return $hash_data['hash'];

	} // End calculate_hash_before_verification()


	 /**
	  *  Get post data if set
	  *
	  * @since 1.4
	  */
	function get_post_var( $name ) {

		if ( isset( $_POST[ $name ] ) ) {

			return $_POST[ $name ];

		}

		return null;
	}

	/**
	 *  Get get data if set
	 *
	 * @since 1.4
	 */
	function get_get_var( $name ) {

		if ( isset( $_GET[ $name ] ) ) {

			return $_GET[ $name ];

		}

		return null;
	}

	/**
	 * Payu additional fields.
	 *
	 * @param [type] $form_fields
	 * @return void
	 */
	function payu_additional_fields( $form_fields ) {

		$wte_settings = get_option( 'wp_travel_engine_settings' );

		if ( isset( $wte_settings['payu_enable'] ) ) :

			$form_fields['phone_number'] = array(
				'type'          => 'number',
				'wrapper_class' => 'wp-travel-engine-billing-details-field-wrap',
				'field_label'   => __( 'Phone Number', 'wte-payu' ),
				'label_class'   => 'wpte-bf-label',
				'name'          => 'wp_travel_engine_booking_setting[place_order][booking][phone]',
				'id'            => 'wp_travel_engine_booking_setting[place_order][booking][phone]',
				'validations'   => array(
					'required' => true,
				),
				'attributes'    => array(
					'data-msg'                      => __( 'Please enter a valid indian phone number ( numbers only )', 'wte-payu' ),
					'data-parsley-required-message' => __( 'Please enter a valid indian phone number ( numbers only )', 'wte-payu' ),
				),
				'default'       => '',
				'priority'      => 31,
			);

		endif;

		return $form_fields;

	}

} //  End Class

new WTE_PayU_Biz_India();
