<?php
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://wptravelengine.com/
 * @since             1.0.0
 * @package           WP_Travel_Engine
 *
 * @wordpress-plugin
 * Plugin Name:       WP Travel Engine - PayU Biz Payment Gateway
 * Plugin URI:        https://wptravelengine.com/
 * Description:       An extension of WP Travel Engine plugin to accept credit cards directly on your website through your PayU account.
 * Version:           2.1.1
 * Author:            WP Travel Engine
 * Author URI:        https://wptravelengine.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wte-payu
 * Domain Path:       /languages
 * WTE tested up to: 5.4
 * WTE required at least: 4.3
 * WTE: 1055:wte_payu_license_key
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

define( 'WP_TRAVEL_ENGINE_PAYU_FILE_PATH', __FILE__ );
define( 'WP_TRAVEL_ENGINE_PAYU_BASE_PATH', dirname( __FILE__ ) );
define( 'WP_TRAVEL_ENGINE_PAYU_VERSION', '2.1.1' );

add_action( 'admin_notices', 'wte_payu_payment_maybe_disable_plugin' );

/**
 * Output error message and disable plugin if requirements are not met.
 *
 * This fires on admin_notices.
 *
 * @since 1.0.0
 */
function wte_payu_payment_maybe_disable_plugin() {

	if ( ! wte_payu_payment_meets_requirements() ) {

		// Display our error
		echo '<div id="message" class="error">';
		echo '<p>' . __( '<strong>WP Travel Engine - PayU Biz Payment Gateway</strong> requires the WP Travel Engine plugin to work. Please install and activate the latest WP Travel Engine plugin first. <strong>WP Travel Engine - PayU Biz Payment Gateway will be deactivated now.</strong>', 'wte-payu' ) . '</p>';
		echo '</div>';

		// Deactivate our plugin
		deactivate_plugins( __FILE__ );
	}
}

/**
 * Check if all plugin requirements are met.
 *
 * @since 1.0.0
 *
 * @return bool True if requirements are met, otherwise false.
 */
function wte_payu_payment_meets_requirements() {
	return ( defined( 'WP_TRAVEL_ENGINE_VERSION' ) && version_compare( WP_TRAVEL_ENGINE_VERSION, '4.0.0', '>=' ) );
}

/**
 * Load payu payment.
 *
 * @return void
 */
function wte_payu_payment_load() {

	if ( ! wte_payu_payment_meets_requirements() ) {
		return false;
	}

	require WP_TRAVEL_ENGINE_PAYU_BASE_PATH . '/includes/class-payu-biz-handler.php';
	require WP_TRAVEL_ENGINE_PAYU_BASE_PATH . '/class-wte-payu-admin.php';
	require WP_TRAVEL_ENGINE_PAYU_BASE_PATH . '/updater/wte-payu-updater.php';
}
add_action( 'plugins_loaded', 'wte_payu_payment_load' );
