=== WP Travel Engine - PayU Biz Payment Gateway ===
Contributors: wptravelengine
Donate link: https://wptravelengine.com/
Tags: payu, payu-payment, payment-gateway, payu-payment-gateway
Requires at least: 4.4.0
Tested up to: 6.0
Requires PHP: 7.2
Stable tag: 2.1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

PayU Biz Payment Gateway is an extension for WP Travel Engine that allows you to accept trip and tour payments via one of leading financial services in global growth markets, PayU.

== Description ==

Tour operators and travel agencies can enable the PayU Payment gateway for trip booking by setting up PayU Biz Account with key details – Merchant Key and Merchant Salt.

== Changelog ==

= 2.1.1 =
Released on: 5th July 2022

* Fix: Booked seats are not updating for FSD booking
* Fix: Payable amount mismatch when coupon applied.
* Fixes: Minor Issues

= 2.1.0 =

Released on: 19th August, 2021

* Compatible updates for WP Travel Engine 5.0+
* Minor bug fixes

= 2.0.1 =

Released on: 26th March, 2021

Enhancements:
* Partial Payment payable support added from user dashboard.

Fixes:

* Invalid amount issue fix.
* Minor bug fixes.

= 2.0.0 =

Released on: 11th June, 2020

Enhancements:

* Revamped backend UI.
* Assets minification, optimization, and conditional loading.

Fixes:

* Minor bug fixes.

= 1.0.7 =

Released on: 7th April, 2020

Enhancements:

* Compatibility check for WordPress 5.4.
* Requirements check for WP Travel Engine.

Fixes:

* Minor bug fixes.

= 1.0.6 =

Released on: 10th February, 2020

Fixes:

* Removed unused Bolt scripts.
* Minor bug fixes.

= 1.0.5 =

Released on: 14th January, 2020

Fixes:

* Includes folder missing issue resolved.
* Minor bug fixes.

= 1.0.4 =

Released on: 14th January, 2020

Enhancement:

* Compatibility testing with WP Travel Engine 3.0.
* Payments API updated.

Fixes:

* Minor bug fixes.

= 1.0.3 =
* Redirect URL issue fixed

= 1.0.0 =
* Initial release
