<?php
/**
 * Easy Digital Downloads Plugin Updater
 *
 * @package wte_payu_money_bolt_checkout
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Includes the files needed for the plugin updater.
 *
 * @since 1.0.0
 */
if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {

	include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

/**
 * Download ID for the product in Easy Digital Downloads.
 *
 * @since 1.0.0
 */
define( 'WP_TRAVEL_ENGINE_PAYUMONEY_BOLT_ITEM_ID', 30752 );

/**
 * Setup the updater for the WTE_PayuMoney_Bolt Add-on.
 *
 * @since 1.0.0
 */
function wte_payu_money_bolt_checkouts_payment_updater() {

	// retrieve our license key from the DB
	$settings    = get_option( 'wp_travel_engine_license' );
	$license_key = isset( $settings['wte_payu_money_bolt_checkout_license_key'] ) ? esc_attr( $settings['wte_payu_money_bolt_checkout_license_key'] ) : '';

	// setup the updater
	$edd_updater = new EDD_SL_Plugin_Updater( WP_TRAVEL_ENGINE_STORE_URL, WTE_PAYU_MONEY_BOLT_FILE_PATH,
		array(
			'version' => WTE_PAYU_MONEY_BOLT_VERSION,                    // current version number
			'license' => $license_key,             // license key (used get_option above to retrieve from DB)
			'item_id' => WP_TRAVEL_ENGINE_PAYUMONEY_BOLT_ITEM_ID,       // ID of the product
			'author'  => 'WP Travel Engine', // author of this plugin
			'beta'    => false,
		)
	);

}
add_action( 'admin_init', 'wte_payu_money_bolt_checkouts_payment_updater', 0 );

/**
 * Add-ons name for plugin license page.
 *
 * @since 1.0.0
 */
function wte_payu_money_bolt_checkout_name($array)
{
	$array['WP Travel Engine - PayU Money Payment Gateway'] =  'wte_payu_money_bolt_checkout';
	return $array;
}
add_filter( 'wp_travel_engine_addons', 'wte_payu_money_bolt_checkout_name' );

/**
 * Add-ons Item ID for plugin license page.
 *
 * @since 1.0.0
 */
function wte_payu_money_bolt_checkout_id($array)
{
	$array['wte_payu_money_bolt_checkout'] = WP_TRAVEL_ENGINE_PAYUMONEY_BOLT_ITEM_ID;
	return $array;
}
add_filter( 'wp_travel_engine_addons_id', 'wte_payu_money_bolt_checkout_id' );
