/**
 * Handle new booking form.
 */
jQuery(function ($) {

    /**
     * Handle after payu bolt form is closed either sucessfully or failure.
     */
    var handler = {
        responseHandler: function (bolt) {
            if ('SUCCESS' === bolt.response.txnStatus) {

                $('#wp-travel-engine-new-checkout-form input[type="submit"]').off('click', handleBookingForm);

                $('#wp-travel-engine-new-checkout-form').append([
                    '<input type="hidden" id="wp_travel_engine_booking_setting[place_order][payment][key]" name="wp_travel_engine_booking_setting[place_order][payment][key]" value="' + bolt.response.key + '" />',
                    '<input type="hidden" id="wp_travel_engine_booking_setting[place_order][payment][amount]" name="wp_travel_engine_booking_setting[place_order][payment][amount]" value="' + bolt.response.amount + '" />',
                    '<input type="hidden" id="wp_travel_engine_booking_setting[place_order][payment][productinfo]" name="wp_travel_engine_booking_setting[place_order][payment][productinfo]" value="' + bolt.response.productinfo + '" />',
                    '<input type="hidden" id="wp_travel_engine_booking_setting[place_order][payment][firstname]" name="wp_travel_engine_booking_setting[place_order][payment][firstname]" value="' + bolt.response.firstname + '" />',
                    '<input type="hidden" id="wp_travel_engine_booking_setting[place_order][payment][email]" name="wp_travel_engine_booking_setting[place_order][payment][email]" value="' + bolt.response.email + '" />',
                    '<input type="hidden" id="wp_travel_engine_booking_setting[place_order][payment][udf5]" name="wp_travel_engine_booking_setting[place_order][payment][udf5]" value="' + bolt.response.udf5 + '" />',
                    '<input type="hidden" id="wp_travel_engine_booking_setting[place_order][payment][mihpayid]" name="wp_travel_engine_booking_setting[place_order][payment][mihpayid]" value="' + bolt.response.mihpayid + '" />',
                    '<input type="hidden" id="wp_travel_engine_booking_setting[place_order][payment][wte_payment_gateway]" name="wp_travel_engine_booking_setting[place_order][payment][wte_payment_gateway]" value="payu_money_bolt" />',
                    '<input type="hidden" id="wp_travel_engine_booking_setting[place_order][payment][txnid]" name="wp_travel_engine_booking_setting[place_order][payment][txnid]" value="' + bolt.response.txnid + '" />',
                    '<input type="hidden" id="wp_travel_engine_booking_setting[place_order][payment][status]" name="wp_travel_engine_booking_setting[place_order][payment][status]" value="' + bolt.response.txnStatus + '" />',
                    '<input type="hidden" id="wp_travel_engine_booking_setting[place_order][payment][hash]" name="wp_travel_engine_booking_setting[place_order][payment][hash]" value="' + bolt.response.hash + '" />',
                ].join(''));

                $('#wp-travel-engine-new-checkout-form input[type="submit"]').trigger('click');
            }

        },
        catchException: function (bolt) {

            // the code you use to handle the integration errors goes here

        }
    };

    /**
     * Return form data.
     */
    function getFormData() {
        var firstName = $('input[name="wp_travel_engine_booking_setting[place_order][booking][fname]"]').val();
        var lastName = $('input[name="wp_travel_engine_booking_setting[place_order][booking][lname]"]').val();
        var email = $('input[name="wp_travel_engine_booking_setting[place_order][booking][email]"]').val();
        var country = $('select[name="wp_travel_engine_booking_setting[place_order][booking][country]"]').val();
        var address = $('input[name="wp_travel_engine_booking_setting[place_order][booking][address]"]').val();
        var productInfo = $('.wpte-bf-trip-name').text();

        return {
            firstName: firstName,
            lastName: lastName,
            email: email,
            country: country,
            address: address,
            productInfo: productInfo
        };
    }

    var handleBookingForm = function (event) {

        if (!$('#wp-travel-engine-new-checkout-form').parsley().isValid()) {
            return;
        }

        var payment_method = $(document).find('input[name=wpte_checkout_paymnet_method]:checked').val();
        if (payment_method !== 'payu_money_enable') {
            flag = false;
        } else {
            flag = true;
        }

        if ($('#wp-travel-engine-new-checkout-form').parsley().isValid() && flag == true) {
            event.preventDefault();
        }

        var formData = getFormData();

        var payment_mode = $(document).find('input[name=wp_travel_engine_payment_mode]:checked').val();


        var requestData = {
            key: payu.settings.merchantKey,
            txnid: '1234567890',
            hash: '',
            amount: 'partial' == payment_mode ? wte.payments.total_partial : wte.payments.total,
            firstname: formData.firstName,
            lastname: formData.lastName,
            phone: '',
            email: formData.email,
            country: formData.country,
            address1: formData.address,
            productinfo: formData.productInfo,
            surl: 'https://sucess-url.in',
            furl: 'https://fail-url.in',
            udf5: '',
            // enforce_paymethod: 'NB'
        }

        if (wte.payments['total_remaining']) {
            requestData.amount = wte.payments['total_remaining']
        }
        if (wte.payments['billing_info']) {
            requestData.firstname = wte.payments.billing_info.fname
            requestData.lastname = wte.payments.billing_info.lname
            requestData.email = wte.payments.billing_info.email
            requestData.address1 = wte.payments.billing_info.address
            requestData.country = wte.payments.billing_info.country
        }

        var postData = Object.assign({}, requestData);
        postData.action = 'payu_money_bolt_generate_hash';

        // Generate hash.
        if (flag !== false) {
            $.ajax({
                url: WTEAjaxData.ajaxurl,
                method: 'POST',
                data: postData
            }).done(function (data) {
                requestData.hash = data.data.hash;
                bolt.launch(requestData, handler);
            }).fail(function (data) {

            });
        }
    }

    $('input[name="wpte_checkout_paymnet_method"]').change(function (event) {

        if (!$('#wpte-checkout-paymnet-method-payu_money_enable').is(':checked')) {
            $('#wp-travel-engine-new-checkout-form input[type="submit"]').off('click', handleBookingForm);
            return;
        }

        if (!payu.settings.enable) {
            $('#wp-travel-engine-new-checkout-form input[type="submit"]').off('click', handleBookingForm);
            return;
        }

        $('#wp-travel-engine-new-checkout-form input[type="submit"]').on('click', handleBookingForm);

    });

    $('#wp-travel-engine-new-checkout-form input[type="submit"]').on('click', handleBookingForm);

});
