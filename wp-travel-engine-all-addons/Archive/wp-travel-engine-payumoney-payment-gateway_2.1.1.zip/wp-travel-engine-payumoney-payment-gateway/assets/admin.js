jQuery(document).ready(function($){
    if ($('.payu-money').is( ':checked' )) {
        $('.wte-payu-money-form.settings').fadeIn('slow');
    }
    else{
        $('.wte-payu-money-form.settings').fadeOut('slow');
    }
    $('body').on('click', '.payu-money', function (e){ 
        if ($('.payu-money').is( ':checked' )) {
            $('.wte-payu-money-form.settings').fadeIn('slow');
        }
        else{
            $('.wte-payu-money-form.settings').fadeOut('slow');
        }
    });

    

});
