=== WP Travel Engine - PayU Money Payment Gateway ===
Contributors: wptravelengine
Plugin link: https://wptravelengine.com/
Tags: tour-booking, tour-operator, travel, travel-booking, travel-agency, payment, payment-booking, wp-travel-engine
Requires at least: 4.4.0
Tested up to: 5.5
Requires PHP: 5.6
Stable tag: 2.1.1
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Payment addon for WP Travel Engine to checkout trip bookings using PayU Money Payment Gateway.

== Description ==

Payment addon for WP Travel Engine to checkout trip bookings using PayU Money Payment Gateway.

WP Travel Engine - PayU Money Payment Gateway addon requires WP Travel Engine plugin v. 3.0.5 or later installed and activated in the site.

== Changelog ==

= 2.1.1 =
Released on: 11th August, 2021
* Fix: Live payment mode not working on some cases fix

= 2.1.0 =

Released on: 10th June, 2021

Enhancements:
* Compatibility update for WTE and Partial Payment
* Minor Bug Fixes


= 2.0.1 =

Released on: 24th September, 2020

Enhancements:
* Partial Payment payable support added from user dashboard.
* Assets optimization, and conditional loading.

Fixes:

* Minor bug fixes.

= 2.0.0 =

Released on: 11th June, 2020

Enhancements:

* Revamped backend UI.
* Assets minification, optimization, and conditional loading.

= 2.0.0 =

Released on: 11th June, 2020

Enhancements:

* Revamped backend UI.
* Assets minification, optimization, and conditional loading.

Fixes:

* Minor bug fixes.

= 1.0.0 =

Released on: 6th Feb 2020

* Initial release
