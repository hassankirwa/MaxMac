<?php
/**
 * Plugin Name: WP Travel Engine - PayU Money Payment Gateway
 * Plugin URI: https://wptravelengine.com
 * Description: WP Travel Engine payment gateway addon to enable PayU Money Bolt checkout for bookings.
 * Version: 2.1.1
 * Author: WP Travel Engine
 * Author URI: https://wptravelengine.com
 * License: GPL2
 * Text Domain: wte-payumoney-bolt
 * Domain Path: languages
 * WTE requires at least: 4.3
 * WTE tested up to: 5.1.0
 * WTE: 30752:wte_payu_money_bolt_checkout_license_key
 */

/*
Copyright 2019 WP Travel Engine,

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2, as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Main plugin instantiation class.
 *
 * @since 1.0.0
 */
class WTE_PayU_Money_Bolt {

	/**
	 * Track instance of the WTE_PayU_Money_Bolt class.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	private static $instance = null;

	/**
	 * Tracks current plugin version throughout codebase.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	var $version = '2.1.1';

	/**
	 * Main WTE_PayU_Money_Bolt Instance
	 *
	 * Ensures only one instance of WTE_PayU_Money_Bolt is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 *
	 * @return WTE_PayU_Money_Bolt - Main instance
	 */
	public static function instance() {

		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof WTE_PayU_Money_Bolt ) ) {

			self::$instance = new WTE_PayU_Money_Bolt();
			self::$instance->i18n();
			self::$instance->includes();

		}

		return self::$instance;
	}

	/**
	 * Fire up the engines.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		// Define plugin constants
		$this->plugin_file    = __FILE__;
		$this->basename       = plugin_basename( $this->plugin_file );
		$this->directory_path = plugin_dir_path( $this->plugin_file );
		$this->directory_url  = plugin_dir_url( $this->plugin_file );

		define( 'WTE_PAYU_MONEY_BOLT_URL', rtrim( plugin_dir_url( $this->plugin_file ), '/' ) );
		define( 'WTE_PAYU_MONEY_BOLT_VERSION', $this->version );
		define( 'WTE_PAYU_MONEY_BOLT_FILE_PATH', $this->plugin_file );

		// Handle plugin activation and deactivation
		register_activation_hook( $this->plugin_file, array( $this, 'activation' ) );
		register_deactivation_hook( $this->plugin_file, array( $this, 'deactivation' ) );

		$this->init_hooks();
	}

	private function init_hooks() {

		// Basic setup
		add_action( 'wp_enqueue_scripts', array( $this, 'load_scripts' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'load_admin_scripts' ) );
		add_action( 'admin_notices', array( $this, 'maybe_disable_plugin' ) );

		add_action( 'wte_payment_gateway_payu_money_enable', array( $this, 'map_payment_data_to_new_booking_structure' ), 10, 3 );

	}

	public function map_payment_data_to_new_booking_structure( $payment_id, $type = 'full_payment', $gateway = '' ) {
		if ( ! $payment_id ) {
			return;
		}

		$booking = get_post( get_post_meta( $payment_id, 'booking_id', true ) );

		if ( ! empty( wte_array_get( $_REQUEST, 'wp_travel_engine_booking_setting.place_order.payment.status', '' ) ) ) {
			$response       = wte_array_get( $_REQUEST, 'wp_travel_engine_booking_setting.place_order.payment', array() );
			$payment_status = strtolower( wte_array_get( $_REQUEST, 'wp_travel_engine_booking_setting.place_order.payment.status', '' ) );
			$payment_amount = array(
				'value'    => get_post( $payment_id )->payable['amount'],
				'currency' => 'INR',
			);

			$payment_data = array(
				'gateway_response' => $response,
				'payment_status'   => $payment_status,
				'payment_amount'   => $payment_amount,
			);

			WTE_Booking::update_booking(
				$payment_id,
				array(
					'meta_input' => $payment_data,
				)
			);

			if ( 'success' === $payment_status ) {
				$amount = $payment_data['payment_amount']['value'];
				$booking_meta['wp_travel_engine_booking_status'] = 'booked';
				$booking_meta['paid_amount']                     = +$booking->paid_amount + +$amount;
				$booking_meta['due_amount']                      = +$booking->due_amount - +$amount;
				WTE_Booking::update_booking( $booking->ID, array( 'meta_input' => $booking_meta ) );
				WTE_Booking::send_emails( $payment_id, 'order_confirmation', 'all' );
			}
		}
	}

	/**
	 * Undocumented function
	 *
	 * @return void
	 */

	function add_hidden_required_field_before_remaining_payment_form_close() {
		if ( isset( $_GET['action'] ) && $_GET['action'] == 'partial-payment' ) {
			$booking_id     = ( isset( $_GET['booking_id'] ) && ! empty( $_GET['booking_id'] ) ) ? $_GET['booking_id'] : '';
			$booking_metas  = get_post_meta( $booking_id, 'wp_travel_engine_booking_setting', true );
			$trip_id        = isset( $booking_metas['place_order']['tid'] ) ? $booking_metas['place_order']['tid'] : '';
			$currency_code  = wp_travel_engine_get_currency_code( true );
			$trip_price     = isset( $booking_metas['place_order']['due'] ) && $booking_metas['place_order']['due'] != '' ? floatval( $booking_metas['place_order']['cost'] ) + floatval( $booking_metas['place_order']['due'] ) : $booking_metas['total_paid'];
			$payment_amount = wp_travel_engine_get_formated_price( isset( $booking_metas['place_order']['due'] ) ? $booking_metas['place_order']['due'] : 0 );
			$productinfo    = html_entity_decode( get_the_title( $trip_id ) );
			$firstname      = isset( $booking_metas['place_order']['booking']['fname'] ) && ! empty( $booking_metas['place_order']['booking']['fname'] ) ? $booking_metas['place_order']['booking']['fname'] : '';
			$lastname       = isset( $booking_metas['place_order']['booking']['lname'] ) && ! empty( $booking_metas['place_order']['booking']['lname'] ) ? $booking_metas['place_order']['booking']['lname'] : '';
			$email          = isset( $booking_metas['place_order']['booking']['email'] ) && ! empty( $booking_metas['place_order']['booking']['email'] ) ? $booking_metas['place_order']['booking']['email'] : '';
			$country        = isset( $booking_metas['place_order']['booking']['country'] ) && ! empty( $booking_metas['place_order']['booking']['country'] ) ? $booking_metas['place_order']['booking']['country'] : '';
			$address        = isset( $booking_metas['place_order']['booking']['address'] ) && ! empty( $booking_metas['place_order']['booking']['address'] ) ? $booking_metas['place_order']['booking']['address'] : '';
			?>
		<input type="hidden" id="wp_travel_engine_booking_setting[place_order][booking][fname]" name="wp_travel_engine_booking_setting[place_order][booking][fname]" value="<?php echo $firstname; ?>" />
		<input type="hidden" id="wp_travel_engine_booking_setting[place_order][booking][lname]" name="wp_travel_engine_booking_setting[place_order][booking][lname]" value="<?php echo $lastname; ?>" />
		<input type="hidden" id="wp_travel_engine_booking_setting[place_order][booking][country]" name="wp_travel_engine_booking_setting[place_order][booking][country]" value="<?php echo $country; ?>" />
		<input type="hidden" id="wp_travel_engine_booking_setting[place_order][booking][email]" name="wp_travel_engine_booking_setting[place_order][booking][email]" value="<?php echo $email; ?>" />
		<input type="hidden" id="wp_travel_engine_booking_setting[place_order][booking][address]" name="wp_travel_engine_booking_setting[place_order][booking][address]" value="<?php echo $address; ?>" />
			<?php
		}
	}

	/**
	 * Plugin activation hook.
	 *
	 * @since  1.0.0
	 */
	public function activation() {
		$this->includes();
	}

	/**
	 * Plugin deactivation hook.
	 *
	 * @since  1.0.0
	 */
	public function deactivation() {

	}

	/**
	 * Load localization.
	 *
	 * @since 1.0.0
	 */
	public function i18n() {
		load_plugin_textdomain( 'wte-payumoney-bolt', false, $this->directory_path . '/languages/' );
	}

	/**
	 * Include file dependencies.
	 *
	 * @since 1.0.0
	 */
	public function includes() {

		include_once $this->directory_path . 'includes/class-wte-payu-admin.php';

		if ( is_admin() ) :

			include_once $this->directory_path . 'updater/wte-payu-money-bolt-updater.php';

		endif;

	}

	/**
	 * Register frontend CSS and JS files.
	 *
	 * @since 1.0.0
	 */
	public function load_scripts() {

		$wte_settings = get_option( 'wp_travel_engine_settings' );
		$merchant_key = isset( $wte_settings['payu_money_merchant_id'] ) ? $wte_settings['payu_money_merchant_id'] : '';

		$merchant_key = trim( $merchant_key );
		$enable       = isset( $wte_settings['payu_money_enable'] ) ? true : false;

		if ( $enable ) {
			if ( empty( $wte_settings['payment_debug'] ) || 'yes' === $wte_settings['payment_debug'] ) {
				wp_enqueue_script( 'payu-money-bolt', 'https://sboxcheckout-static.citruspay.com/bolt/run/bolt.min.js', null, null, true );
			} else {
				wp_enqueue_script( 'payu-money-bolt', 'https://checkout-static.citruspay.com/bolt/run/bolt.min.js', null, null, true );
			}

			// wp_enqueue_style( 'Wte-PayU-Money-Bolt-Frontend-css', plugin_dir_url( __FILE__ ) . 'assets/public.css', array(), '', 'all' );

			wp_register_script( 'Wte-PayU-Money-Bolt-Frontend-js', plugin_dir_url( __FILE__ ) . 'assets/public.js', array( 'jquery', 'payu-money-bolt' ), $this->version, true );
			$payu_base_url     = isset( $wte_settings['payment_debug'] ) ? 'https://test.payu.in/_payment' : 'https://secure.payu.in/_payment';
			$translation_array = array(
				'settings' => array(
					'merchantKey' => $merchant_key,
					'enable'      => $enable,
				),
			);

			wp_localize_script( 'Wte-PayU-Money-Bolt-Frontend-js', 'payu', $translation_array );

			wp_enqueue_script( 'Wte-PayU-Money-Bolt-Frontend-js' );
		}
	}

	/**
	 * Register backend CSS and JS files.
	 *
	 * @since 1.0.0
	 */
	public function load_admin_scripts() {

		wp_enqueue_script( 'Wte-PayU-Money-Bolt', plugin_dir_url( __FILE__ ) . 'assets/admin.js', array( 'jquery' ), '', false );

		// wp_enqueue_style( 'Wte-PayU-Money-Bolt', plugin_dir_url( __FILE__ ) . 'assets/admin.css', array(), '', 'all' );
	}

	/**
	 * Output error message and disable plugin if requirements are not met.
	 *
	 * This fires on admin_notices.
	 *
	 * @since 1.0.0
	 */
	public function maybe_disable_plugin() {

		if ( ! $this->meets_requirements() ) {

			// Display our error
			echo '<div id="message" class="error">';
			echo '<p>' . sprintf( __( '<strong>WP Travel Engine PayU Money Payment Gateway</strong> addon requires WP Travel Engine plugin <strong>v.4.0.0 or later</strong> and has been <a href="%s">deactivated</a>. Please install, activate, or update WP Travel Engine plugin and then reactivate this plugin.', 'wte-payumoney-bolt' ), admin_url( 'plugins.php' ) ) . '</p>';
			echo '</div>';

			// Deactivate our plugin
			deactivate_plugins( $this->basename );
		}
	}

	/**
	 * Check if all plugin requirements are met.
	 *
	 * @since 1.0.0
	 *
	 * @return bool True if requirements are met, otherwise false.
	 */
	private function meets_requirements() {
		return ( class_exists( 'WP_Travel_Engine' ) && defined( 'WP_TRAVEL_ENGINE_VERSION' ) && version_compare( WP_TRAVEL_ENGINE_VERSION, '4.0.0', '>=' ) );
	}

}

/**
 * Returns the main instance of WTE_PayU_Money_Bolt.
 *
 * @since  1.0.0
 * @return WTE_PayU_Money_Bolt
 */
function wte_payumoney_bolt() {
	if ( ! class_exists( 'WP_Travel_Engine' ) ) {
		return null;
	}

	return WTE_PayU_Money_Bolt::instance();
}
add_action( 'plugins_loaded', 'wte_payumoney_bolt', 10 );
