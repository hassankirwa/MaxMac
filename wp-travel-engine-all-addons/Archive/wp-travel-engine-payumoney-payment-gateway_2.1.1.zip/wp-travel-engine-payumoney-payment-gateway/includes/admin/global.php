<?php 
/**
 * Global settings.
 */
$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', true );
?>
<div class="wpte-field wpte-text wpte-floated">
    <label for="wp_travel_engine_settings[payu_money_merchant_id]" class="wpte-field-label"><?php _e('Merchant Key','wte-payumoney-bolt');?></label>
    <input type="text" id="wp_travel_engine_settings[payu_money_merchant_id]" name="wp_travel_engine_settings[payu_money_merchant_id]" value="<?php echo isset($wp_travel_engine_settings['payu_money_merchant_id']) ? esc_attr( $wp_travel_engine_settings['payu_money_merchant_id'] ): '';?>">
    <span class="wpte-tooltip"><?php esc_html_e( "Enter a valid Merchant Key. All payments will go to this account.", 'wte-payumoney-bolt' ); ?></span>
</div>

<div class="wpte-field wpte-text wpte-floated">
    <label for="wp_travel_engine_settings[payu_money_salt]" class="wpte-field-label"><?php _e('Merchant Salt','wte-payumoney-bolt');?></label>
    <input type="text" id="wp_travel_engine_settings[payu_money_salt]" name="wp_travel_engine_settings[payu_money_salt]" value="<?php echo isset($wp_travel_engine_settings['payu_money_salt']) ? esc_attr( $wp_travel_engine_settings['payu_money_salt'] ): '';?>">
    <span class="wpte-tooltip"><?php esc_html_e( "Enter a valid Merchant Salt.", 'wte-payumoney-bolt' ); ?></span>
</div>
