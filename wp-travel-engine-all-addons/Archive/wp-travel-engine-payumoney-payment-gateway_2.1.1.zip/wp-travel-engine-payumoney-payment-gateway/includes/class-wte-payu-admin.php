<?php
/**
 * Handle Admin settings
 *
 * @package WTE_payumoney_checkout
 */
class WTE_PayU_Money_Admin {

	/**
	 * Class Constructor
	 */
	public function __construct() {

		add_action( 'wte_payu_settings',array( $this, 'wte_payu_settings' ) );
		add_action( 'wte_payu_enable',array( $this, 'wte_payu_enable' ) );

		$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', true );

		add_filter( 'script_loader_tag', array( $this, 'modify_script_tag' ), 10, 3 );
		add_action( 'admin_notices',array( $this, 'show_notifications' ) );

		add_action( 'wp_ajax_payu_money_bolt_generate_hash', array( $this, 'generate_hash' ) );
		add_action( 'wp_ajax_nopriv_payu_money_bolt_generate_hash', array( $this, 'generate_hash' ) );

		// Add filter for the sortable gateway list.
		add_filter( 'wp_travel_engine_available_payment_gateways', array( $this, 'payu_gateway_list' ) );

		// Save paymnet information.
		add_action( 'wp_travel_engine_after_booking_process_completed', array( $this, 'save_payment_information' ) );

		add_filter( 'wpte_settings_get_global_tabs', array( $this, 'add_global_settings' ) );

	}

	/**
	   * Hash generation.
	   *
	   * @return void
	   */
	public function generate_hash() {

		$wte_settings = get_option( 'wp_travel_engine_settings' );
		$data = new stdClass;
		$data->key       = isset( $wte_settings['payu_money_merchant_id'] ) ? $wte_settings['payu_money_merchant_id'] : '';
		$data->salt      = isset( $wte_settings['payu_money_salt'] ) ? $wte_settings['payu_money_salt'] : '';	
		if(isset($_GET['action']) && $_GET['action'] == 'partial-payment') {
			$currency_code 	= wp_travel_engine_get_currency_code(true);
			$payment_mode  	= isset( $_POST['wp_travel_engine_payment_mode'] ) ? $_POST['wp_travel_engine_payment_mode'] : '';
			$booking_metas 	= get_post_meta($booking_id, 'wp_travel_engine_booking_setting', true);
			
			$data->txnid     = isset( $_POST["txnid"] ) ? $_POST["txnid"] : '';
			$data->amount    = isset( $_POST["amount"] ) ? $_POST["amount"] : '';
			$data->pinfo     = isset( $_POST["productinfo"] ) ? $_POST["productinfo"] : '';
			$data->firstname = isset( $_POST["firstname"] ) ? $_POST["firstname"] : '';
			$data->email     = isset( $_POST["email"] ) ? $_POST["email"] : '';
			$data->udf5      = isset( $_POST["udf5"] ) ? $_POST["udf5"] : '';
		}else{
			$data->txnid     = isset( $_POST["txnid"] ) ? $_POST["txnid"] : '';
			$data->amount    = isset( $_POST["amount"] ) ? $_POST["amount"] : '';
			$data->pinfo     = isset( $_POST["productinfo"] ) ? $_POST["productinfo"] : '';
			$data->firstname = isset( $_POST["firstname"] ) ? $_POST["firstname"] : '';
			$data->email     = isset( $_POST["email"] ) ? $_POST["email"] : '';
			$data->udf5      = isset( $_POST["udf5"] ) ? $_POST["udf5"] : '';
			
		}
		

		$hash = hash('sha512', $data->key.'|'.$data->txnid.'|'.$data->amount.'|'.$data->pinfo.'|'.$data->firstname.'|'.$data->email.'|||||'.$data->udf5.'||||||'.$data->salt);

		return wp_send_json_success( array('hash' => $hash) );
	}

	/**
	 * Modify the script tag.
	 *
	 * @param string $tag The <script> tag for the enqueued script.
	 * @param string $handle The script's registered handle.
	 * @param string $src The script's source URL.
	 * @return void
	 */
	public function modify_script_tag( $tag, $handle, $src ) {

		if ( 'payu-money-bolt' === $handle ) {
			$tag = '<script type="text/javascript" src="' . esc_url( $src ) . '" id="bolt" color="e34524" bolt-logo="https://boltiswatching.com/wp-content/uploads/2015/09/Bolt-Logo-e14421724859591.png"></script>';
		}

		return $tag;

	}

	/**
	 * Show notifications.
	 */
	public function show_notifications( ) {

		if ( $this->is_currency_inr() ) {
			return;
		}
	?>

		<div class="notice notice-error">
			<p>
				<strong><?php _e( 'PayU Money Error : ', 'wte-payumoney-bolt' ); ?></strong>
				<?php _e( 'Currency not supported. Change to currency to INR to enable PayU Money checkout.', 'wte-payumoney-bolt' ); ?>
			</p>
		</div>
  	<?php
  	}

	function wte_payu_settings() {

		$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', true );
	?>
		<div class="wte-payu-money-form settings wp-travel-engine-settings">
			<h4><?php _e( 'PayU Money Gateway Settings', 'wte-payumoney-bolt'); ?></h4>
			<label for="wp_travel_engine_settings[payu_money_merchant_id]"><?php _e('Merchant Key : ','wte-payumoney-bolt');?> <span class="tooltip" title="Enter a valid Merchant key from PayU account. All payments will go to this account."><i class="fas fa-question-circle"></i></span></label>
			<input type="text" id="wp_travel_engine_settings[payu_money_merchant_id]" name="wp_travel_engine_settings[payu_money_merchant_id]" value="<?php echo isset($wp_travel_engine_settings['payu_money_merchant_id']) ? esc_attr( $wp_travel_engine_settings['payu_money_merchant_id'] ): '';?>">
			<label for="wp_travel_engine_settings[payu_money_salt]"><?php _e('Merchant Salt : ','wte-payumoney-bolt');?> <span class="tooltip" title="Enter a valid Merchant Salt from PayU account."><i class="fas fa-question-circle"></i></span></label>
			<input type="text" id="wp_travel_engine_settings[payu_money_salt]" name="wp_travel_engine_settings[payu_money_salt]" value="<?php echo isset($wp_travel_engine_settings['payu_money_salt']) ? esc_attr( $wp_travel_engine_settings['payu_money_salt'] ): '';?>">
		</div>
	<?php
	}

	/**
	 * Admin enable settings
	 *
	 * @return void
	 */
	function wte_payu_enable() {

	$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', true );
		?>
		<div class="wte-payu-money-form wp-travel-engine-settings">
			<label for="wp_travel_engine_settings[payu_money_enable]"><?php _e('PayU Money: ','wte-payumoney-bolt');?> <span class="tooltip" title="Please check this to enable PayU booking system for trip booking and fill the account info below."><i class="fas fa-question-circle"></i></span></label>
			<input type="checkbox" id="wp_travel_engine_settings[payu_money_enable]" class="payu" name="wp_travel_engine_settings[payu_money_enable]" value="1" <?php if(isset($wp_travel_engine_settings['payu_money_enable']) && $wp_travel_engine_settings['payu_money_enable']!='' ) echo 'checked'; ?>>
			<label for="wp_travel_engine_settings[payu_money_enable]" class="checkbox-label"></label>
		</div>
		<?php
	}

	public function add_global_settings( $global_tabs ) {

	if ( isset( $global_tabs['wpte-payment'] ) ) {
		$global_tabs['wpte-payment']['sub_tabs']['wte-payu-bolt'] = array(
			'label' => __( 'PayU Money Bolt', 'wte-payumoney-bolt' ),
			'content_path' => plugin_dir_path( WTE_PAYU_MONEY_BOLT_FILE_PATH ) . 'includes/admin/global.php',
			'current' => false,
		);
	}

	return $global_tabs;
	}
	/**
	 * Add PayU to payment gateways list.
	 *
	 * @param [type] $gateway_list
	 * @return void
	 */
	public function payu_gateway_list( $gateway_list ) {

		if ( ! $this->is_currency_inr() ) {
			return $gateway_list;
		}

		$gateway_list['payu_money_enable'] = array(
			'label'       => __( 'PayU Money', 'wte-payumoney-bolt' ),
			'input_class' => 'payu-money',
			'info_text'   => __( 'Please check this to enable PayU booking system for trip booking and fill the account info below.', 'wte-payumoney-bolt' ),
		);

		return $gateway_list;

	}

	/**
	 * Is currency INR check.
	 *
	 * @return boolean
	 */
	public function is_currency_inr() {

		$currency_code = wp_travel_engine_get_currency_code();

		return 'INR' === $currency_code;
	}

	/**
	 * Save Paymnet information for the gateway.
	 *
	 * @param [type] $booking_id
	 * @return void
	 */
	public function save_payment_information( $booking_id, $partial_payment = false ) {

		if ( ! $booking_id ) {
			return;
		}

		// Is partial payment check.
		if ( ! $partial_payment ) {
			do_action( 'wte_payment_process', $booking_id );
		}

		// Check if paypal is selected.
		if ( ! isset( $_POST['wpte_checkout_paymnet_method'] ) || 'payu_money_enable' !== $_POST['wpte_checkout_paymnet_method'] ) {
			return;
		}

		update_post_meta( $booking_id, 'wp_travel_engine_booking_payment_gateway', 'PayU Money' );

		$postdata = $_POST['wp_travel_engine_booking_setting']['place_order']['payment'];
		$msg      = '';

		$wte_settings = get_option( 'wp_travel_engine_settings' );

		if ( isset( $postdata ['key'] ) ) {

			$key				=   $postdata['key'];
			$salt				=   isset( $wte_settings['payu_money_salt'] ) ? $wte_settings['payu_money_salt'] : '';
			$txnid 				= 	$postdata['txnid'];
			$amount      		= 	$postdata['amount'];
			$productInfo  		= 	$postdata['productinfo'];
			$firstname    		= 	$postdata['firstname'];
			$email        		=	$postdata['email'];
			$udf5				=   isset( $postdata['udf5'] ) ? $postdata['udf5'] : '';
			$mihpayid			=	$postdata['mihpayid'];
			$status				= 	strtolower( $postdata['status'] );
			$resphash		    = 	$postdata['hash'];

			/*Calculate response hash to verify*/
			$keyString 	  		=  	$key.'|'.$txnid.'|'.$amount.'|'.$productInfo.'|'.$firstname.'|'.$email.'|||||'.$udf5.'|||||';
			$keyArray 	  		= 	explode("|",$keyString);
			$reverseKeyArray 	= 	array_reverse($keyArray);
			$reverseKeyString	=	implode("|",$reverseKeyArray);
			$CalcHashString 	= 	strtolower(hash('sha512', $salt.'|'.$status.'|'.$reverseKeyString));

			$a = 1;

			if ( $status == 'success'  && $resphash == $CalcHashString ) {

				// $msg = "Transaction Successful and Hash Verified...";

				$payment_status = isset( $_POST['wp_travel_engine_booking_setting']['place_order']['payment']['status'] ) ? $_POST['wp_travel_engine_booking_setting']['place_order']['payment']['status'] : false;

				if ( $payment_status ) {

					update_post_meta( $booking_id, 'wp_travel_engine_booking_payment_status', 'completed' );

				}

				$payment_details = isset( $_POST['wp_travel_engine_booking_setting']['place_order']['payment'] ) ? $_POST['wp_travel_engine_booking_setting']['place_order']['payment'] : array();


				if ( ! empty( $payment_details ) ) :

					$save_paydetails = array();

					foreach ( $payment_details as $key => $val ) {

						$save_paydetails[$key]['label'] = $key;
						$save_paydetails[$key]['value'] = $val;

					}

					update_post_meta( $booking_id, 'wp_travel_engine_booking_payment_details', $save_paydetails );

				endif;

			}
			else {
				/*tampered or failed*/
				// $msg = "Payment failed for Hasn not verified...";
			}
		}

	}

}
new WTE_PayU_Money_Admin;
