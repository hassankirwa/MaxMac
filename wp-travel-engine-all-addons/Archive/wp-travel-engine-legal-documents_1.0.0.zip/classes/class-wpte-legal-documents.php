<?php
/**
 * Main Entry Plugin file
 *
 * @package WP Travel Engine - Legal Documents
 * @since 1.0.0
 */
namespace WP_Travel_Engine_Legal_Documents;

/**
 * Main Entry Class
 */
class Plugin {
	/**
	 * Plugin Name.
	 * 
	 * @var string
	 */
	public $plugin_name = 'wte-legal-documents';

	/**
	 * Version
	 * 
	 * @var string
	 */
	public $version = LEGAL_DOCUMENTS_VERSION;

	/**
	 * The single instance of the class.
	 * 
	 * @vars tring $_instance
	 */
	public static $_instance = null;

	/**
	 * Main WP_Travel_Engine_Legal_Documents Instance.
	 * Ensures onlu one instance of WP_Travel_Engine_Legal_Documents is loaded or can be loaded.
	 * 
	 * @return WP_Treavel_Engine_Legal_Documents - Main instance.
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Class Constructor
	 */
	public function __construct() {
		$this->includes();
		if ( is_admin() ) {
			new \WPTE_Legal_Documents_Admin();
		}
		new \WPTE_Legal_Documents_Shortcode();
	}

	/**
	 * Define constants.
	 * 
	 * @param string $name Constant name.
	 * @param string $value Constant value.
	 */
	public function define( $name, $value ) {
		if ( ! defined( $name ) ) {
			define( $name, $value );
		}
	}

	/**
	 * Includes required function/class files.
	 */
	private function includes() {
		require LEGAL_DOCUMENTS_BASE_PATH . 'public/class-wpte-legal-documents-shortcode.php';
		/**
		 * The class responsible for updating the add-on from EDD
		 */
		if ( is_admin() ) {
			require LEGAL_DOCUMENTS_BASE_PATH . 'admin/class-wpte-legal-documents-admin.php';
		}
	}
}
