=== WP Travel Engine - Legal Documents ===
Contributors: wptravelengine
Donate Link: https://wptravelengine.com/
Tags: legal-documents, legal, documents, wp-travel-engine
Requires at least: 5.0
Tested up to: 6.1
Requires PHP: 7.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WP Travel Engine - Legal Documents is a custom addon for WP Travel Engine plugin that helps you add and show legal documents on your travel website.

== Description ==

Tour operators and travel agencies can enable the Legal Documents system for travel website by setting up Legal Documents with it's shortcode.

== Changelog ==

== 1.0.0 - 6th January, 2023 ==

* Initial Release