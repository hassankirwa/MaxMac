<?php
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://wptravelengine.com/
 * @since             1.0.0
 * @package           Wp_Travel_Engine_Legal_Documents
 *
 * @wordpress-plugin
 * Plugin Name:       WP Travel Engine - Legal Documents
 * Description:       WP Travel Engine - Legal Documents is a custom addon for WP Travel Engine plugin that helps you add and show legal documents on your travel website.
 * Version:           1.0.0
 * Author:            WP Travel Engine
 * Author URI:        https://wptravelengine.com/
 * License:           GPLv3
 * License URI:       http://www.gnu.org/licenses/gpl-3.0.html
 * Text Domain:       wp-travel-engine-legal-documents
 * Domain Path:       /languages
 * WTE requires at least: 5.0
 * WTE tested up to: 5.5
 * WTE: 125931:wte_legal_documents_license_key
 * Requires at least: 6.1
 * Requires PHP: 7.2
 * Tested up to: 6.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'LEGAL_DOCUMENTS_VERSION', '1.0.0' );
define( 'LEGAL_DOCUMENTS_FILE_PATH', __FILE__ );
define( 'LEGAL_DOCUMENTS_BASE_URL', plugin_dir_url( __FILE__ ) );
define( 'LEGAL_DOCUMENTS_BASE_PATH', plugin_dir_path( __FILE__ ) );
define( 'LEGAL_DOCUMENTS_REQUIRES_AT_LEAST', '5.0' );

/**
 * Initiate addon.
 */
function wte_legal_documents_init() {
	return WP_Travel_Engine_Legal_Documents\Plugin::instance();
}

add_action( 'plugins_loaded', 'wte_legal_documents_maybe_disable_plugin' );
/**
 * Output error message and disable plugin if trequirements are not met.
 *
 * This fires on admin_notices.
 *
 * @since 1.0.0
 */
function wte_legal_documents_maybe_disable_plugin() {
	if ( ! defined( 'WP_TRAVEL_ENGINE_VERSION' ) || version_compare( LEGAL_DOCUMENTS_REQUIRES_AT_LEAST, WP_TRAVEL_ENGINE_VERSION, '>' ) ) {
		// Display error message.
		add_action(
			'admin_notices',
			function() {
				echo wp_kses_post(
					sprintf(
						'<div class="error"><p>'
						// translators: 1. WTE Extension Name 2. Link to WTE Plugin
						. sprintf( __( '%1$s requires the %2$s plugin to work. Please install and activate the latest %3$s plugin first.', 'wpte-legal-documents' ), '<strong>WP Travel Engine - Legal Documents</strong>', '<a href="https://wordpress.org/plugins/wp-travel-engine" target="_blank">WP Travel Engine - ' . LEGAL_DOCUMENTS_REQUIRES_AT_LEAST . '+</a>', '<strong>WP Travel Engine</strong>' )
						. '</p></div>'
					)
				);
			}
		);
	} else {
		require_once LEGAL_DOCUMENTS_BASE_PATH . '/classes/class-wpte-legal-documents.php';
		wte_legal_documents_init();
	}
}
