<?php

/**
 * WP Travel Engine - Legal Documents Shortcode
 */
class WPTE_Legal_Documents_Shortcode {
	/**
	 * Constructor
	 */
	public function __construct() {
		// Shortcode to Display Legal Documents.
		add_shortcode( 'WPTE_LIST_LEGAL_DOCUMENTS', array( $this, 'wpte_legal_documents_shortcode' ) );

		// Public Scripts and Styles.
		add_action( 'wp_enqueue_scripts', array( $this, 'wpte_legal_documents_public_scripts' ) );
	}

	/**
	 * Public Scripts and Styles
	 */
	public function wpte_legal_documents_public_scripts() {
		// wp_register_style( 'wpte-legal-documents-public-style', plugins_url( 'css/style.css', __FILE__ ), array(), filemtime( plugin_dir_path( __FILE__ ) . 'css/style.css' ) );
	}

	/**
	 * Shortcode to display legal documents
	 */
	public function wpte_legal_documents_shortcode( $args = array() ) {

		$args = wp_parse_args( $args, array( 'cols' => 2 ) );

		wp_enqueue_script( 'jquery-fancy-box' );
		wp_enqueue_style( 'jquery-fancy-box' );
		$legal_documents = get_option( 'wpte_legal_documents', array() );

		$columns = (int) $args['cols'];
		if ( $columns <= 0 ) {
			$columns = 2;
		}
		ob_start();
		if ( ! empty( $legal_documents ) ) {
			?>
			<style>.wpte-legal-documents{margin:0 0 32px}.wpte-legal-doc-row{display:flex;flex-wrap:wrap;margin:-16px -15px}.wpte-legal-doc-col{flex-basis:100%;max-width:100%;padding:16px 15px}.wpte-legal-documents-container p{margin:0}.wpte-legal-documents-container-link{display:block;width:100%;padding:100% 24px 24px;border:1px solid #011F271A;margin:0 0 30px;position:relative;align-items:center;transition:.3s}.wpte-legal-documents-container-link:hover{background-color:#efefef}.wpte-legal-documents-container-link img{vertical-align:top;max-width:calc(100% - 48px);max-height:calc(100% - 48px);position:absolute;top:50%;left:50%;transform:translate(-50%,-50%)}.wpte-legal-documents-container-link img.pdf-icon{max-width:150px;width:100%;height:auto}.wpte-legal-doc-title{font-size:18px;font-weight:600;margin:0}@media(min-width:768px){.wpte-legal-doc-col{flex-basis:50%;}}</style>

			<div class="wpte-legal-documents">
				<div class="wpte-legal-doc-row">
					<?php
					foreach ( $legal_documents as $legal_document ) {
						$file_title = $legal_document['title'];
						$attach_id  = $legal_document['attach_id'];
						$attach_url = wp_get_attachment_url( $attach_id );

						$post        = get_post( $attach_id );
						$description = $post->post_content;

						// Extract the file extension from the URL.
						$pathinfo = pathinfo( $attach_url );
						$file_ext = $pathinfo['extension'];
						?>
						<div class="wpte-legal-doc-col" style="flex-basis:<?php echo (float) ( 100 / $columns ); ?>%;">
							<div class="wpte-legal-documents-container">
								<a data-src="<?php echo esc_url( $attach_url ); ?>" data-fancybox="wpte-legal-documents" data-fancybox-buttons="[ 'prev', 'next' ]" class="fancybox wpte-legal-documents-container-link" href="<?php echo esc_url( $attach_url ); ?>" rel="fancybox">
									<?php if ( $file_ext == 'pdf' ) { ?>
										<img class="wpte-legal-documents-container-image pdf-icon" src="<?php echo esc_url( plugin_dir_url( __DIR__ ) . 'assets/images/pdf.png' ); ?>" alt="<?php echo esc_attr( $file_title ); ?>">
									<?php } else { ?>
										<img class="wpte-legal-documents-container-image" src="<?php echo esc_url( $attach_url ); ?>" alt="<?php echo esc_attr( $file_title ); ?>">
									<?php } ?>
								</a>
								<h5 class="wpte-legal-doc-title"><?php echo esc_html( $file_title ); ?></h5>
								<div class="wpte-legal-documents-container-description">
									<p class="wpte-legal-document-description" id="wpte-legal-document-content"><?php echo esc_html( $description ); ?></p>
								</div>
							</div>
						</div>
						<?php
					}
					?>
				</div>
			</div>
			<?php
		} else {
			_e( 'There are no legal documents.' );
		}
		return ob_get_clean();
	}
}
