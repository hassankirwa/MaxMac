<?php

/**
 * Easy Digital Downloads Plugin Updater
 *
 * @package Wp_Travel_Engine_Legal_Documents
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Includes the files needed for the plugin updater.
 *
 * @since 1.0.0
 */
if ( ! class_exists( 'EDD_SL_Plugin_Updater' ) ) {
	include dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php';
}

/**
 * Download ID for the product in Easy Digital Downloads.
 *
 * @since 1.0.0
 */
define( 'WTE_LEGAL_DOCUMENTS_ITEM_ID', 125931 );

/**
 * Setup the updater for the WTE Legal Downloads Add-on.
 *
 * @since 1.0.0
 */
function wte_legal_downloads_updater() {
	// retrives our license key from the DB
	$settings    = get_option( 'wp_travel_engine_license' );
	$license_key = isset( $settings['wte_legal_documents_license_key'] ) ? esc_attr( $settings['wte_legal_documents_license_key'] ) : '';

	// setup the updater
	$edd_updater = new EDD_SL_Plugin_Updater(
		WP_TRAVEL_ENGINE_STORE_URL,
		LEGAL_DOCUMENTS_FILE_PATH,
		array(
			'version' => LEGAL_DOCUMENTS_VERSION, // current version number
			'license' => $license_key, // license key ( used get_option above to retrieve from the DB )
			'item_id' => WTE_LEGAL_DOCUMENTS_ITEM_ID, // ID of the product
			'author'  => 'WP Travel Engine', // author of this plugin
			'beta'    => false,
		)
	);
}

add_action( 'admin_init', 'wte_legal_downloads_updater', 0 );

/**
 * Add-ons name for plugin license page.
 *
 * @since 1.0.0
 */
function wte_legal_documents_name( $array ) {
	$array['WP Travel Engine - Legal Documents'] = 'wte_legal_documents';
	return $array;
}

add_filter( 'wp_travel_engine_addons', 'wte_legal_documents_name' );

/**
 * Add-ons Item ID for plugin license page
 *
 * @since 1.0.0
 */
function wte_legal_documents_id( $array ) {
	$array['wte_legal_documents'] = WTE_LEGAL_DOCUMENTS_ITEM_ID;
	return $array;
}

add_filter( 'wp_travel_engine_addons_id', 'wte_legal_documents_id' );
