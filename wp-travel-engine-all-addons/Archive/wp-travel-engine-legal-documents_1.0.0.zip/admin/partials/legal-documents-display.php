<?php

/***
 * Admin Legal Documents partial.
 *
 * @package wte-legal-documents
 */

// Get the legal documents from the database.
$legal_documents = get_option( 'wpte_legal_documents', array() );
$plugin_dir      = plugin_dir_url( __DIR__ );
?>

<div class="wpte-legal-documents-container">
	<h3 class="wpte-legal-title"><?php _e( 'Legal Documents' ); ?></h3>
	<?php
	// Check if legal documents is not empty.
	if ( ! empty( $legal_documents ) ) {
		?>
		<div class="wpte-legal-document-row" id="sortable">
			<?php
			foreach ( $legal_documents as $legal_document ) {
				$file_title = $legal_document['title'];
				$attach_id  = $legal_document['attach_id'];
				$attach_url = wp_get_attachment_url( $attach_id );

				$post        = get_post( $attach_id );
				$description = $post->post_content;

				// Extract the file extension from the URL.
				$pathinfo = pathinfo( $attach_url );
				$file_ext = $pathinfo['extension'];
				?>
				<div class="wpte-legal-document-item drag-row" data-attach-id="<?php echo esc_attr( $attach_id ); ?>">
					<!-- <button class="drag-row" type="button"></button> -->
					<div class="wpte-legal-document-preview">
						<?php
						$base_thumbnail_url = $plugin_dir . '../assets/images';
						$thumbnail_link     = 'pdf' === $file_ext ? $base_thumbnail_url . '/pdf.png' : $attach_url;
						?>
						<img class="wpte-legal-documents-container-image" src="<?php echo esc_url( $thumbnail_link ); ?>">
					</div>
					<div class="wpte-legal-document-content">
						<h5 class="wpte-legal-document-name"><?php echo esc_html( $file_title ); ?></h5>
						<p class="wpte-legal-document-description"><?php echo esc_html( $description ); ?></p>
					</div>
					<div class="wpte-legal-actions">
						<button class="wpte-button wpte-legal-documents-edit-modal is-action" type="button" data-attach-id="<?php echo esc_attr( $attach_id ); ?>" data-title="<?php echo esc_attr( $file_title ); ?>" data-description="<?php echo esc_attr( $description ); ?>" title="Edit Document">
							<svg class="icon">
								<use xlink:href="<?php echo esc_url( $plugin_dir . '../assets/icons/sprit.svg#icon_edit' ); ?>"></use>
							</svg>
						</button>
						<a data-src="<?php echo esc_url( $attach_url ); ?>" data-fancybox="wpte-legal-documents" data-fancybox-buttons="[ 'prev', 'next' ]" class="wpte-button is-action" type="button" title="Preview Document">
							<svg class="icon">
								<use xlink:href="<?php echo esc_url( $plugin_dir . '../assets/icons/sprit.svg#icon_eye' ); ?>"></use>
							</svg>
						</a>
						<form method="POST" action="">
							<input type="hidden" name="wpte-legal-documents-id" value="<?php echo esc_attr( $attach_id ); ?>">
							<button type="submit" name="wpte-legal-documents-container-delete" class="wpte-button is-action" title="Delete Document">
								<svg class="icon">
									<use xlink:href="<?php echo esc_url( $plugin_dir . '../assets/icons/sprit.svg#icon_trash' ); ?>"></use>
								</svg>
							</button>
							<?php wp_nonce_field( 'wpte_legal_documents_delete_nonce', 'delete_nonce' ); ?>
						</form>
					</div>
				</div>
				<?php
			}
			?>
		</div>
	<?php } else { ?>
		<div class="wpte-legal-no-document-message">
			<p><?php _e( 'You have no legal documents. But you can add some.' ); ?></p>
		</div>
	<?php } ?>
</div>

<!-- Modal form for editing legal documents -->
<div id="wpte-legal-documents-modal" style="display: none;" class="modal">
	<div class="modal-content">
		<button class="close">
			<svg class="icon">
				<use xlink:href="<?php echo esc_url( $plugin_dir . '../assets/icons/sprit.svg#times_circle' ); ?>"></use>
			</svg>
		</button>
		<h3 class="wpte-legal-title"><?php _e( 'Edit Document' ); ?></h3>
		<form action="" id="wpte-legal-documents-edit-form" method="POST">
			<input type="text" name="wpte-legal-document-title" placeholder="<?php esc_attr_e( 'Title' ); ?>" required>
			<textarea name="wpte-legal-document-description" placeholder="<?php esc_attr_e( 'Description ( Optional ) ' ); ?>"></textarea>
			<input type="hidden" name="wpte-legal-documents-id">
			<button type="submit" name="wpte-legal-documents-edit" class="wpte-button is-primary large has-arrow"><?php _e( 'Update Now' ); ?></button>
			<?php wp_nonce_field( 'wpte_legal_documents_edit_nonce', 'edit_nonce' ); ?>
		</form>
	</div>
</div>
