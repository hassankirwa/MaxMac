; (function ($) {

	//Get the copy button.
	var copyButton = document.querySelector('.copy-button');

	//Add an event listener to the button.
	copyButton.addEventListener('click', function () {

		//Get the text field.
		var copyText = document.querySelector('#wpte-legal-documents-shortcode-copy-text');

		//Select the text.
		copyText.select();
		copyText.setSelectionRange(0, 99999);

		//Copy the text.
		if (document.execCommand('copy')) {
			toastr.success(WTE_UI.copied);
		}
	});

	//Edit Modal.
	; (function () {
		var ListItems = document.querySelectorAll('.wpte-legal-document-item')
		var modal = document.getElementById('wpte-legal-documents-modal');
		var modalForm = document.getElementById('wpte-legal-documents-edit-form');
		ListItems.forEach(function (_item) {
			var editButton = _item.querySelector('.wpte-button')
			if (editButton) {
				editButton.addEventListener('click', function (event) {
					var _this = this
					modal.style.display = 'block';
					modalForm.querySelector('[name="wpte-legal-documents-id"]').value = _this.dataset.attachId;

					var _titleEl = _item.querySelector('.wpte-legal-document-name')
					var title = _titleEl ? _titleEl.textContent : ''
					var _contentEl = _item.querySelector('.wpte-legal-document-description')
					var content = _contentEl ? _contentEl.textContent : ''
					modalForm.querySelector('[name="wpte-legal-document-title"]').value = title
					modalForm.querySelector('[name="wpte-legal-document-description"]').value = content

					var closeModal = modal.querySelector('button.close');
					if (closeModal) {
						closeModal.addEventListener('click', function () {
							modal.style.display = 'none';
						});
					}

					window.addEventListener('click', function (event) {
						if (event.target == modal) {
							modal.style.display = 'none';
						}
					});
				});
			}
		})

		modalForm.addEventListener('submit', async function (e) {
			e.preventDefault();

			//Get the form data.
			var formData = new FormData(modalForm);

			//Send the AJAX request.
			var response = await fetch(legaldocument.ajax_url + '?action=wpte_legal_documents_update_file', {
				method: 'POST',
				body: formData,
			});
			var result = await response.json();
			var messageDiv = document.querySelector('#wpte-legal-documents-notice');
			if (result.success) {
				modal.style.display = 'none';
				if (messageDiv) {
					var p = document.createElement('p');
					p.innerHTML = result.data.message;
					messageDiv.append(p);
					messageDiv.style.display = 'block';
					var item = document.querySelector('[ data-attach-id="' + result.data.update.attachment_id + '" ]');
					if (item) {
						item.querySelector('.wpte-legal-document-name').textContent = result.data.update.title;
						item.querySelector('.wpte-legal-document-description').textContent = result.data.update.description;
					}
				}
			} else {
				modal.style.display = 'none';
				var p = document.createElement('p');
				p.innerHTML = result.data.message;
				messageDiv.append(p);
				messageDiv.style.display = 'block';
			}
		});
	})();

	//Reordering Functionality.
	jQuery(function ($) {
		$('#sortable').sortable({
			update: function (event, ui) {
				//Get the current order of the legal documents.
				var current_order = [];
				$('#sortable .wpte-legal-document-item').each(function () {
					current_order.push($(this).data('attach-id'));
				});
				//Make and AJAX request to update the option in the database.
				$.ajax({
					url: ajaxurl,
					type: 'POST',
					data: {
						action: 'update_legal_documents_order',
						order: current_order,
					},
					success: function (response) {
						if (response.data && response.data.message) {
							var messageDiv = $('#wpte-legal-documents-notice');
							var p = document.createElement('p');
							p.innerHTML = response.data.message;
							messageDiv.append(p);
							messageDiv.show();
						}
					}
				})
			}
		})
	})
})(jQuery);
