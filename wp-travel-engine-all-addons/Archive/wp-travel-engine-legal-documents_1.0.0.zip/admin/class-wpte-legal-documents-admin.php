<?php
/**
 * Class WPTE_Legal_Documents_Admin
 * 
 * @package WPTE_Legal_Documents_Admin
 */
/**
 * WP Travel Engine - Legal Documents Admin Class
 */
class WPTE_Legal_Documents_Admin {
	/**
	 * Class Constructor
	 * 
	 * @access public
	 */
	public function __construct() {
		// Init Actions.
		add_action( 'init', array( $this, 'wpte_legal_documents_file_uploader' ) );
		add_action( 'init', array( $this, 'wpte_legal_documents_file_deleter' ) );

		// Admin Menu.
		add_action( 'admin_menu', array( $this, 'wpte_legal_documents_add_submenu_page' ) );

		// Admin Scripts and Styles.
		add_action( 'admin_enqueue_scripts', array( $this, 'wpte_legal_documents_admin_scripts' ) );

		//File Edit Ajax Handler
		add_action( 'wp_ajax_wpte_legal_documents_update_file', array( $this, 'wpte_legal_documents_update_file' ) );
		add_action( 'wp_ajax_nopriv_wpte_legal_documents_update_file', array( $this, 'wpte_legal_documents_update_file' ) );

		add_action( 'wp_ajax_update_legal_documents_order', array( $this, 'update_legal_documents_order' ) );
		add_action( 'wp_ajax_nopriv_update_legal_documents_order', array( $this, 'update_legal_documents_order' ) );

		require LEGAL_DOCUMENTS_BASE_PATH . '/updater/wte-legal-documents-updater.php';
	}

	/**
	 * Custom Uploads Directory
	 */
	public function legal_documents_upload_dir( $dir ) {
		$dir['subdir']  = '/wptravelengine/wpte-legal-documents';
		$dir['path']    = $dir['basedir'] . $dir['subdir'];
		$dir['url']     = $dir['baseurl'] . $dir['subdir'];
		return $dir;
	}

	/**
	 * File Uploader Function
	 */
	public function wpte_legal_documents_file_uploader() {
		// Check if form has been submitted.
		if ( ! isset( $_POST['wpte-legal-documents-submit'] ) || ! isset( $_POST['upload_nonce'] ) ) {
			return;
		}

		// Verify Nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['upload_nonce'] ) ), 'wpte_legal_documents_upload_nonce' ) ) {
			return;
		}

		//Check user authority.
		if ( ! current_user_can( 'upload_files' ) ) {
			return;
		}

		// Session from WP Travel Engine.
		$session = WTE()->session;

		// Get WordPress uploads directory and create custom folder if it does not exist.
		$upload_dir           = add_filter( 'upload_dir', array( $this, 'legal_documents_upload_dir' ) );
		$upload_dir           = wp_upload_dir();
		$file_upload_dir_path = $upload_dir['basedir'];
		if ( ! is_dir( $file_upload_dir_path ) ) {
			wp_mkdir_p( $file_upload_dir_path );
		}

		// Check if wp_handle_upload() exists.
		if ( ! function_exists( 'wp_handle_upload' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		// Get legal documents option.
		$legal_documents = get_option( 'wpte_legal_documents', array() );
		if ( ! $legal_documents ) {
			$legal_documents = array();
		}

		// Get file and title data from form.
		$file  = $_FILES['wpte-legal-documents-file']; // phpcs:ignore

		$title = sanitize_file_name( $file['name'] );
		if ( ! empty( $_POST['wpte-legal-documents-title'] ) ) {
			$title = sanitize_text_field( wp_unslash( $_POST['wpte-legal-documents-title'] ) );
		}
		if ( ! empty( $_POST[ 'wpte-legal-documents-description' ] ) ) {
			$description = sanitize_text_field( wp_unslash( $_POST[ 'wpte-legal-documents-description' ] ) );
		} else {
			$description = ' ';
		}

		// Check file type.
		$file_type = wp_check_filetype( basename( $file['name'] ), null );
		$file_ext  = $file_type['ext'];
		if ( in_array( $file_ext, array( 'jpeg', 'jpg', 'png', 'pdf' ), true ) ) {
			$uploaded_file = wp_handle_upload(
				$file,
				array(
					'test_form'  => false,
					'upload_dir' => $upload_dir,
				)
			);
			if ( $uploaded_file && ( ! isset( $uploaded_file['error'] ) ) ) {
				$file_upload_dir_url = $upload_dir['url'];
				$attachment          = array(
					'guid'           => $file_upload_dir_url . '/' . basename( $uploaded_file['file'] ),
					'post_mime_type' => $uploaded_file['type'],
					'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $uploaded_file['file'] ) ),
					'post_content'   => $description,
					'post_status'    => 'inherit',
				);
				$attach_id           = wp_insert_attachment( $attachment, $uploaded_file['file'] );

				// Add new document to legal documents array.
				$legal_documents[ $attach_id ] = array(
					'title'     => $title,
					'attach_id' => $attach_id,
				);

				// Save legal documents array as option.
				update_option( 'wpte_legal_documents', $legal_documents );

				// Display success message.
				$session->set( 'wptravelengine_messages', __( 'File has been saved.' ) );
			}
			remove_filter( 'upload_dir', array( $this, 'legal_documents_upload_dir' ) );
		} else {
			// Display error message if file type is not allowed.
			$session->set( 'wptravelengine_messages', __( 'You can only upload file type of .pdf, .jpeg, .jpg and .png.' ) );
		}
	}

	/**
	 * File Deleter Function
	 */
	public function wpte_legal_documents_file_deleter() {
		// Check if the form submission.
		if ( ! isset( $_POST['wpte-legal-documents-container-delete'] ) || ! isset( $_POST['delete_nonce'] ) || ! isset( $_POST['wpte-legal-documents-id'] ) ) {
			return;
		}

		// Verify nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['delete_nonce'] ) ), 'wpte_legal_documents_delete_nonce' ) ) {
			return;
		}

		// Start Session.
		$session = WTE()->session;

		$attach_id = (int) $_POST['wpte-legal-documents-id'];

		// If file exists delete it.
		$legal_documents = get_option( 'wpte_legal_documents', array() );
		if ( isset( $legal_documents[ $attach_id ] ) ) {
			// Unset data from option.
			unset( $legal_documents[ $attach_id ] );
			// Update wpte_legal_documents option.
			update_option( 'wpte_legal_documents', $legal_documents );

			// Delete attachment.
			wp_delete_attachment( $attach_id, false );

			// File delete message.
			$session->set( 'wptravelengine_messages', __( 'File deleted successfully.' ) );
		}
	}

	/**
	 * File Update Ajax Handler
	 */
	public function wpte_legal_documents_update_file() {
		// Check if nonce was submitted.
		if ( ! isset( $_POST[ 'edit_nonce' ] ) ) {
			return;
		}

		// Verify nonce.
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ 'edit_nonce' ] ) ), 'wpte_legal_documents_edit_nonce' ) ){
			return;
		}

		// Check formdata.
		if ( ! isset( $_POST[ 'wpte-legal-document-title' ], $_POST[ 'wpte-legal-document-description' ], $_POST[ 'wpte-legal-documents-id' ] ) ) {
			return;
		}
		ob_start();

		$attach_id   = $_POST [ 'wpte-legal-documents-id' ];
		$title       = sanitize_text_field( $_POST [ 'wpte-legal-document-title' ] );
		$description = sanitize_textarea_field( $_POST [ 'wpte-legal-document-description' ] );
		
		$attachment = get_post( $attach_id );
		if ( $attachment && $attachment->post_type == 'attachment' ) {
			wp_update_post( array(
				'ID' => $attach_id,
				'post_content' => $description
			) );
		}

		$legal_documents = get_option( 'wpte_legal_documents', array() );
		if ( isset( $legal_documents[ $attach_id ] ) ) {
			$legal_documents[ $attach_id ][ 'title' ] = $title;
		} else {
			ob_end_flush();
			wp_send_json_error(['message' => __( 'File does not exist.' ) ]);
			die;
		}
		update_option( 'wpte_legal_documents', $legal_documents );

		ob_end_flush();

		wp_send_json_success( [ 
			'message' => __( 'File was updated succesfully.' ),
			'update' => [
				'title' => $title,
				'description' => $description,
				'attachment_id' => $attach_id,
			],
		] );
		die;
	}

	/**
	 * Order Ajax Handler
	 */
	public function update_legal_documents_order() {
		// Check if the current user has the necessary permissions.
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( new \WP_Error(
				'AUTHORIZATION_FAILED',
				__( 'Current user cannot manage options.' )
			) );
			die;
		}

		if ( ! isset( $_POST[ 'order' ] ) ) {
			wp_send_json_error( new \WP_Error(
				'INSUFFICIENT_DATA',
				__( 'You must provide order to update existing documents order.' )
			) );
			die;
		}

		// Get the current order of legal documents.
		$new_order = wp_unslash( $_POST[ 'order' ] );

		// Get the current legal documents from the database.
		$legal_documents = get_option( 'wpte_legal_documents', array() );

		// Create a new array to hold the sorted legal documents.
		$sorted_legal_documents = array();

		foreach ( $new_order as $document_id ) {
			if ( isset( $legal_documents[ $document_id ] ) ) {
				// Add the found document to the sorted array.
				$sorted_legal_documents[ $document_id ] = $legal_documents[ $document_id ];
			}
		}

		// Update the wpte_legal_documents option with teh sorted array.
		update_option( 'wpte_legal_documents', $sorted_legal_documents );
		
		wp_send_json_success( [ 'message' => __( 'Documents\'s order updated successfully.' ) ] );

		wp_die();
	}

	/**
	 * Admin Scripts and Styles
	 */
	public function wpte_legal_documents_admin_scripts() {
		wp_register_style(
			'wpte-legal-documents-admin-style',
			plugins_url( 'css/admin.css', __FILE__ ),
			array(),
			filemtime( plugin_dir_path( __FILE__ ) . 'css/admin.css' )
		);
		wp_enqueue_style( 'wpte-legal-documents-admin-style' );

		wp_register_script(
			'legal-documents-js',
			plugins_url( 'js/legal-documents.js', __FILE__ ),
			array( 'jquery' ),
			filemtime( plugin_dir_path( __FILE__ ) . 'js/legal-documents.js' ),
			true
		);
		wp_localize_script( 'legal-documents-js', 'legaldocument', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );

		wp_enqueue_script( 'jquery' );
		wp_enqueue_script( 'jquery-ui-core' );
		wp_enqueue_script( 'jquery-ui-sortable' );
	}

	/**
	 * Add Submenu Page for Legal Documents
	 */
	public function wpte_legal_documents_add_submenu_page() {
		add_submenu_page(
			'edit.php?post_type=booking',
			__( 'Legal Documents' ),
			__( 'Legal Documents' ),
			'manage_options',
			'wpte_legal_documents',
			array( $this, 'wpte_legal_documents_uploader' )
		);
	}

	/**
	 * Callback function for Legal Docuements Submenu Page
	 *
	 * Includes form to upload legal docuemtns and display them
	 */
	public function wpte_legal_documents_uploader() {
		// Enqueue Styles and Scripts.
		wp_enqueue_style( 'jquery-fancy-box' );
		wp_enqueue_script( 'jquery-fancy-box' );
		wp_enqueue_script( 'legal-documents-js' );

		$session  = WTE()->session;
		$messages = $session->get( 'wptravelengine_messages' );

		// Check for message in session variable.
		if ( ! empty( $messages ) ) {
			?>
			<div id="setting-error-settings_updates" class="updated settings-error notice is-dismissible">
				<p><?php esc_html_e( $messages ); ?></p>
			</div>
			<?php
			// Unset message variable.
			$session->delete( 'wptravelengine_messages' );
		}
		?>
		<div id="wpte-legal-documents-notice" style="display: none;" class="updated settings-error notice is-dismissible"></div>
		<div class="wpte-legal-documents">
			<?php include __DIR__ . '/partials/legal-documents-display.php'; ?>
			<div class="wpte-legal-docs-sidebar">
				<div class="wpte-legal-documents-info-bar">
					<p><?php echo wp_kses( sprintf( 'Use the following %1$sShortcode%2$s to display %1$sLegal Documents%2$s in Post/Pages/Tabs/Widgets.', '<b>', '</b>' ), array( 'b' => array() ) ); ?></p>
					<div class="wpte-legal-document-copy-box">
						<input type="text" readonly value="<?php _e( '[WPTE_LIST_LEGAL_DOCUMENTS]' ); ?>" id="wpte-legal-documents-shortcode-copy-text" >
						<button type="button" class="copy-button" title="Copy shortcode"><?php _e( 'Copy' ); ?></button>
					</div>
				</div>
				<div class="wpte-legal-document-form-wrap">
					<h3 class="wpte-legal-title"><?php _e( 'Upload Documents' ); ?></h3>
					<form id="wpte-legal-documents-form" method="post" enctype="multipart/form-data">
						<div class="wpte-legal-documents-form-group">
							<input type="text" name="wpte-legal-documents-title" id="wpte-legal-documents-title" placeholder="<?php esc_attr_e( 'Document Name' ); ?>" required>
						</div>
						<div class="wpte-legal-documents-form-group">
							<textarea name="wpte-legal-documents-description" id="wpte-legal-documents-description" cols="57" rows="10" placeholder="<?php esc_attr_e( 'Description ( Optional )' ); ?>"></textarea>
						</div>
						<div class="wpte-legal-documents-form-group">
							<input type="file" name="wpte-legal-documents-file" id="wpte-legal-documents-file formFile" class="form-control" required accept="application/pdf, image/jpeg, image/png, image/jpg" >
						</div>
						<div class="wpte-legal-documents-form-group">
							<button type="submit" name="wpte-legal-documents-submit" id="wpte-legal-documents-submit" class="wpte-button is-primary large has-arrow"><?php _e( 'Upload Now' ); ?></button>
							<?php wp_nonce_field( 'wpte_legal_documents_upload_nonce', 'upload_nonce' ); ?>
						</div>
					</form>
				</div>
			</div>
		</div>
		<?php
	}
}