<?php
/**
 * Settings tab - content for authorize.net.
 *
 * @package wte-authorize-net
 * @since 2.0.0
 */

$payment_settings = get_option( 'wp_travel_engine_settings', array() );

$api_login_id    = '';
$transaction_key = '';
if ( isset( $payment_settings['authorizenet'] ) ) {
	$api_login_id    = $payment_settings['authorizenet']['api_login_id'];
	$transaction_key = $payment_settings['authorizenet']['transaction_key'];
}

$debug_class = isset( $payment_settings['payment_debug'] ) && 'yes' === $payment_settings['payment_debug'] ? ' wpte-debug' : '';

?>
<div class="wpte-authorize-net-content-wrap<?php echo esc_attr( $debug_class ); ?>"
	data-test-mode="<?php echo esc_attr__( 'DEBUG MODE: ON', 'wte-authorize-gateway' ); ?>">
	<div class="wpte-block-content">
		<div class="wpte-field wpte-floated">
			<label class="wpte-field-label"
				for="wp_travel_engine_settings__authorizenet_api_login_id"><?php echo esc_html__( 'API Login ID', 'wte-authorize-gateway' ); ?></label>
			<input type="text" id="wp_travel_engine_settings__authorizenet_api_login_id"
				name="wp_travel_engine_settings[authorizenet][api_login_id]"
				value="<?php echo esc_attr( $api_login_id ); ?>">
		</div>
		<div class="wpte-field wpte-floated">
			<label class="wpte-field-label"
				for="wp_travel_engine_settings__authorizenet_transation_key"><?php echo esc_html__( 'Transaction Key', 'wte-authorize-gateway' ); ?></label>
			<input type="password" id="wp_travel_engine_settings__authorizenet_transation_key"
				name="wp_travel_engine_settings[authorizenet][transaction_key]"
				value="<?php echo esc_attr( $transaction_key ); ?>">
		</div>
		<div style="margin-bottom: 40px;" class="wpte-info-block">
			<p>
				<?php
				$link    = 'https://www.authorize.net/sign-up/pricing.html';
				$account = __( 'Affiliate', 'wte-authorize-gateway' );
				if ( isset( $payment_settings['payment_debug'] ) && 'yes' === $payment_settings['payment_debug'] ) {
					$link    = 'https://developer.authorize.net/hello_world/sandbox.html';
					$account = __( 'Developer', 'wte-authorize-gateway' );
				}
				echo wp_kses(
					// translators: 1. Account Type [Developer | Affilitate] 2. Opening anchor tag. 3. Closing anchor tag.
					sprintf( esc_html__( 'Create %1$s Account %2$sHere%3$s to get API Credentials.', 'wte-authorize-gateway' ), $account, '<a href="' . $link . '">', '</a>' ),
					array( 'a' => array( 'href' => array() ) )
				);
				?>
			</p>
		</div>
	</div>
</div>
