<?php
/**
 * Main Class.
 *
 * @since 2.0.0
 */

use WTE\PaymentAddon\AuthorizeNet as ANet;

/**
 * Class WTE_Authorize_Net.
 */
class WTE_Authorize_Net {

	/**
	 * Plugin Version.
	 *
	 * @var string
	 */
	public $version = '2.0.0';

	/**
	 * Class instance.
	 *
	 * @var string
	 */
	protected static $instance = null;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->define_constants();
		$this->includes();
		$this->init_hooks();
	}

	/**
	 * Defines constants.
	 */
	private function define_constants() {
		$constants = array(
			'WP_TRAVEL_ENGINE_AUTHORIZE_NET_BASE_PATH' => dirname( WTE_AUTHORIZE_NET_PLUGIN_FILE ) . '/',
			'WP_TRAVEL_ENGINE_AUTHORIZE_NET_ITEM_ID'   => 577,
			'WP_TRAVEL_ENGINE_AUTHORIZE_NET_VERSION'   => $this->version,
			'WTE_AUTHORIZE_NET_PLUGIN_URL'             => plugins_url( '/', WTE_AUTHORIZE_NET_PLUGIN_FILE ),
		);

		foreach ( $constants as $constant => $value ) {
			defined( $constant ) || define( $constant, $value );
		}
	}

	private function includes() {
		require_once WP_TRAVEL_ENGINE_AUTHORIZE_NET_BASE_PATH . 'updater/wte-authorize-net-updater.php';
		require_once WP_TRAVEL_ENGINE_AUTHORIZE_NET_BASE_PATH . 'includes/class-api.php';
	}

	/**
	 * Returns class instance.
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}


	public function init_hooks() {

		add_action( 'init', array( $this, 'init' ) );

		add_filter(
			'wpte_settings_get_global_tabs',
			function( $tabs ) {
				wp_enqueue_style( 'wte-authorizenet-checkout-setting' );
				$tabs['wpte-payment']['sub_tabs']['authorize-net'] = array(
					'label'        => __( 'Authorize.net payment', 'wte-authorize-gateway' ),
					'content_path' => plugin_dir_path( WTE_AUTHORIZE_NET_PLUGIN_FILE ) . 'includes/admin/settings/payments/authorize-net.php',
					'current'      => false,
				);

				return $tabs;
			}
		);

		add_filter(
			'wp_travel_engine_available_payment_gateways',
			function( $gateways ) {
				$gateways['authorize-net-payment'] = array(
					'label'        => __( 'Authorize.net', 'wte-authorize-gateway' ),
					'input_class'  => 'authorize-net-payment',
					'public_label' => __( 'Authorize.net Payment', 'wte-authorize-gateway' ),
					'icon_url'     => '',
					'info_text'    => __( 'Pay via Authorize.net.', 'wte-authorize-gateway' ),
				);

				return $gateways;
			}
		);

		add_action(
			'wp_enqueue_scripts',
			array( $this, 'enqueue_scripts' )
		);
		add_action(
			'admin_enqueue_scripts',
			array( $this, 'enqueue_scripts' )
		);

		add_action( 'wte_payment_gateway_authorize-net-payment', array( $this, 'process' ), 11, 3 );

		add_action( 'wte_booking_after_submit_button', array( $this, 'render_payment_button' ) );
		add_action( 'wte_before_remaining_payment_form_close', array( $this, 'render_payment_button' ) );

		add_action(
			'wp_head',
			function() {
				?>
				<style>
					[name="wp_travel_engine_nw_bkg_submit"].wteanet-is-active {
						display: none !important;
					}
				</style>
				<?php
			}
		);
	}

	public function render_payment_button() {
		if ( ! $this->enabled_authorize_net() ) {
			return;
		}
		wp_enqueue_script( 'wte-authorizenet-checkout' );

		$payment_setting = get_option( 'wp_travel_engine_settings', array() );
		$response        = Anet\API::get_merchant_details();

		if ( ! is_wp_error( $response ) ) :
			$public_client_key = $response->{'publicClientKey'};
			$api_login_id      = ! empty( $payment_setting['authorizenet']['api_login_id'] ) ? $payment_setting['authorizenet']['api_login_id'] : '';
			?>
			<input type="hidden" name="dataValue" id="dataValue" />
			<input type="hidden" name="dataDescriptor" id="dataDescriptor" />
			<button type="button"
				id="AcceptUI"
				class="AcceptUI"
				data-billingAddressOptions='{"show":true, "required":false}' 
				data-apiLoginID="<?php echo esc_attr( $api_login_id ); ?>" 
				data-clientKey="<?php echo esc_attr( $public_client_key ); ?>"
				data-acceptUIFormBtnTxt="<?php echo esc_attr_x( 'Submit', 'Auhtorize.net UI form button text', 'wte-authorize-gateway' ); ?>" 
				data-acceptUIFormHeaderTxt="<?php echo esc_attr_x( 'Card information', 'Authorize.net Form Header Text', 'wte-authorize-gateway' ); ?>"
				data-paymentOptions='{"showCreditCard": true, "showBankAccount": true}' 
				data-responseHandler="anetResponseHandler"><?php echo esc_html__( 'Pay', 'wte-authorize-gateway' ); ?>
			</button>
			<?php
		endif;
	}

	public function enqueue_scripts() {
		$payment_setting = get_option( 'wp_travel_engine_settings', array() );
		$acceptui_url    = isset( $payment_setting['payment_debug'] ) && 'yes' === $payment_setting['payment_debug'] ? 'https://jstest.authorize.net/v3/AcceptUI.js' : 'https://js.authorize.net/v3/AcceptUI.js';
		wp_register_script( 'authorizenet-acceptui', $acceptui_url, array(), wp_rand(), true );
		wp_register_script( 'wte-authorizenet-checkout', plugin_dir_url( WTE_AUTHORIZE_NET_PLUGIN_FILE ) . 'dist/public/booking/checkout.js', array( 'authorizenet-acceptui' ), wp_rand(), true );

		wp_register_style( 'wte-authorizenet-checkout-setting', plugin_dir_url( WTE_AUTHORIZE_NET_PLUGIN_FILE ) . 'dist/admin/settings/setting.css', array(), $this->version );
	}

	private function enabled_authorize_net() {
		$payment_setting = get_option( 'wp_travel_engine_settings' );
		return isset( $payment_setting['authorize-net-payment'] ) && '1' === $payment_setting['authorize-net-payment'];
	}

	private function is_payment_via_authorize_net() {
		return isset( $_REQUEST['wpte_checkout_paymnet_method'] ) && 'authorize-net-payment' === $_REQUEST['wpte_checkout_paymnet_method'];
	}

	public function process( int $payment_id, string $payment_mode = 'full_payment', $payment_method = '' ) {

		$response = Anet\API::create_transaction_request( $payment_id, $payment_mode );

		$booking_id = get_post_meta( $payment_id, 'booking_id', true );

		if ( is_wp_error( $response ) ) {
			WTE_Booking::error( $response, '', array( 'back_link' => ! 0 ), $booking_id );
		}

		$booking = get_post( $booking_id );

		$payable = get_post( $payment_id )->payable;

		WTE_Booking::update_booking(
			+$payment_id,
			array(
				'meta_input' => array(
					'payment_status'   => 'completed',
					'payment_gateway'  => 'authorize-net-payment',
					'gateway_response' => $response,
					'payment_amount'   => array(
						'value'    => +$payable['amount'],
						'currency' => $payable['currency'],
					),
				),
			)
		);

		$amount = $payable['amount'];

		$booking_meta['wp_travel_engine_booking_status'] = 'booked';
		$booking_meta['paid_amount']                     = +$booking->paid_amount + +$amount;
		$booking_meta['due_amount']                      = +$booking->due_amount - +$amount;

		WTE_Booking::update_booking( $booking_id, array( 'meta_input' => $booking_meta ) );
		WTE_Booking::send_emails( $payment_id, 'order_confirmation', 'all' );

	}

	/**
	 *
	 * Hook on init action.
	 */
	public function init() {

	}

}
