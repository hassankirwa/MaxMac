<?php
/**
 *
 * @since 2.0.0
 */

namespace WTE\PaymentAddon\AuthorizeNet;

/**
 * Class WTE_Authorize_Net_API.
 */
class API {

	public static function get_merchant_details() {

		$data = new \StdClass();

		$data->{'getMerchantDetailsRequest'} = array(
			'merchantAuthentication' => self::get_merchant_credentials(),
		);

		return self::request( $data );
	}

	private static function is_live_mode() {
		return ! self::is_debug_mode();
	}

	private static function is_debug_mode() {
		$settings = get_option( 'wp_travel_engine_settings', array() );
		return isset( $settings['payment_debug'] ) && 'yes' === $settings['payment_debug'];
	}

	private static function request( $data ) {

		$url = self::is_live_mode() ? 'https://api.authorize.net/xml/v1/request.api' : 'https://apitest.authorize.net/xml/v1/request.api';

		$data = wp_json_encode( $data );

		$response = (object) wp_remote_request(
			$url,
			array(
				'method'  => 'POST',
				'headers' => array(
					'Content-Type' => 'application/json',
				),
				'body'    => $data,
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$body = $response->body;

		if ( 1 === preg_match( '/({.+}$)/', $body, $matches, PREG_UNMATCHED_AS_NULL, 1 ) && isset( $matches[1] ) ) {
			$body = json_decode( $matches[1] );

			if ( 'Ok' === $body->messages->{'resultCode'} ) {
				return $body;
			} else {
				return new \WP_Error(
					'WTE_ANET_ERROR',
					$body->messages->message[0]->text,
					$body
				);
			}
		};

	}

	private static function get_merchant_credentials() {
		$settings      = get_option( 'wp_travel_engine_settings', array() );
		$anet_settings = isset( $settings['authorizenet'] ) ? $settings['authorizenet'] : array();
		return array(
			'name'           => isset( $anet_settings['api_login_id'] ) ? $anet_settings['api_login_id'] : '',
			'transactionKey' => isset( $anet_settings['transaction_key'] ) ? $anet_settings['transaction_key'] : '',
		);
	}

	public static function create_transaction_request( $payment_id, $payment_mode ) {

		$payment = get_post( $payment_id );

		$booking_id = get_post_meta( $payment_id, 'booking_id', true );

		$booking = get_post( $booking_id );

		$booking_data = get_post_meta( $booking_id, 'wp_travel_engine_booking_setting', true );

		$posted_data = $_POST; // phpcs:ignore

		$billto = $booking->billing_info;

		$cart_items = $booking->order_trips;

		$line_items = array();

		foreach ( $cart_items as $cart_id => $item ) {
			$item = (object) $item;
			// $trip                     = get_post( $item['ID'] );
			$line_items['lineItem'][] = array(
				'itemId'    => $cart_id,
				'name'      => $item->title,
				'quantity'  => 1,
				'unitPrice' => $item->cost,
			);

			if ( isset( $item->trip_extras ) ) {
				foreach ( $item->trip_extras as $i => $tx ) {
					$line_items['lineItem'][] = array(
						'itemId'    => "tx_{$i}",
						'name'      => $tx['extra_service'],
						'quantity'  => $tx['qty'],
						'unitPrice' => $tx['price'],
					);
				}
			}
		}

		$data = array();

		$ref_id = "trr_" . uniqid();

		$data['createTransactionRequest'] = array(
			'merchantAuthentication' => self::get_merchant_credentials(),
			'refId'                  => $ref_id,
			'transactionRequest'     => array(
				'transactionType' => 'authCaptureTransaction',
				'amount'          => +$payment->payable['amount'],
				'payment'         => array(
					'opaqueData' => array(
						'dataDescriptor' => $posted_data['dataDescriptor'],
						'dataValue'      => $posted_data['dataValue'],
					),
				),
				'lineItems'       => $line_items,
				'poNumber'        => $payment_mode === 'full_payment' ? $booking_id : 'dp' . $booking_id,
				'billTo'          => array(
					'firstName' => $billto['fname'],
					'lastName'  => $billto['lname'],
					'company'   => get_bloginfo( 'name' ),
					'address'   => $billto['address'],
					'city'      => $billto['city'],
					'country'   => $billto['country'],
				),
			),
		);

		if ( in_array( $payment_mode, array( 'due' ), true ) ) {
			unset( $data['createTransactionRequest']['transactionRequest']['lineItems'] );
		}

		return self::request( $data );

	}
}
