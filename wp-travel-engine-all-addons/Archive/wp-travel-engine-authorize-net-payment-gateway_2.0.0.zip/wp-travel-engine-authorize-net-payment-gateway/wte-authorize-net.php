<?php
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://wptravelengine.com/
 * @since             1.0.0
 * @package           WP_Travel_Engine
 *
 * @wordpress-plugin
 * Plugin Name:       WP Travel Engine - Authorize.net Payment Gateway
 * Plugin URI:        https://wptravelengine.com/
 * Description:       An extension of WP Travel Engine plugin to accept credit cards directly on your website through your Authorize.net account.
 * Version:           2.0.0
 * Author:            WP Travel Engine
 * Author URI:        https://wptravelengine.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wte-authorize-gateway
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
defined( 'ABSPATH' ) || exit;

defined( 'WTE_AUTHORIZE_NET_PLUGIN_FILE' ) || define( 'WTE_AUTHORIZE_NET_PLUGIN_FILE', __FILE__ );
define( 'WP_TRAVEL_ENGINE_AUTHORIZE_NET_FILE_PATH', __FILE__ );

// Take Main Class File Here.
class_exists( 'WTE_Authorize_Net', false ) || require_once dirname( WTE_AUTHORIZE_NET_PLUGIN_FILE ) . '/includes/class-wte-authorize-net.php';

add_action( 'admin_notices', 'wte_authorize_net_maybe_disable_plugin' );

/**
 * Output error message and disable plugin if requirements are not met.
 *
 * This fires on admin_notices.
 *
 * @since 2.0.0
 */
function wte_authorize_net_maybe_disable_plugin() {

	if ( ! wte_authorize_net_meets_requirements() ) {

		// Display our error
		echo '<div id="message" class="error">';
		echo '<p>' . __( '<strong>WP Travel Engine - Authorize.net</strong> requires WP Travel Engine <strong>v.4.3.7 or later.</strong> Please install and activate the latest WP Travel Engine plugin first. <strong>WP Travel Engine - Authorize.net will be deactivated now.</strong>', 'wte-authorize-gateway' ) . '</p>';
		echo '</div>';

		// Deactivate our plugin.
		deactivate_plugins( __FILE__ );
	}
}

/**
 * Check if all plugin requirements are met.
 *
 * @since 2.0.0
 *
 * @return bool True if requirements are met, otherwise false.
 */
function wte_authorize_net_meets_requirements() {
	return ( class_exists( 'WP_Travel_Engine' ) && defined( 'WP_TRAVEL_ENGINE_VERSION' ) && version_compare( WP_TRAVEL_ENGINE_VERSION, '4.3.7', '>=' ) );
}

/**
 * Returns Main instance of WTE_Authorize_Net
 */
function wte_authorize_net() {
	return WTE_Authorize_Net::instance();
}

/**
 * Run the show.
 */ 
add_action(
	'plugins_loaded',
	function() {
		if ( ! wte_authorize_net_meets_requirements() ) {
			return false;
		}
		wte_authorize_net();
	}
);
