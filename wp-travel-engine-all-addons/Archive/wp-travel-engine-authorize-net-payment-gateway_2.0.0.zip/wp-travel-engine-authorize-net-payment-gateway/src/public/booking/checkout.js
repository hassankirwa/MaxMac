(function () {

	const checkoutForm = document.getElementById('wp-travel-engine-new-checkout-form')


	let anetRadio = document.getElementById('wpte-checkout-paymnet-method-authorize-net-payment')

	const toggleBtns = (showAnetBtn = true) => {
		let submitBtn = checkoutForm?.querySelector('input[type=submit]')
		if (showAnetBtn) {
			if (submitBtn?.style) {
				submitBtn.style.display = 'none'
				submitBtn.classList.toggle('wteanet-is-active', !0)
			}
			if (document?.getElementById('AcceptUI')?.style)
			document.getElementById('AcceptUI').style.removeProperty('display');
		} else {
			if (submitBtn?.style) {
				submitBtn.style.removeProperty('display')
				submitBtn.classList.toggle('wteanet-is-active', !1)
			}
			if (document?.getElementById('AcceptUI')?.style)
				document.getElementById('AcceptUI').style.display = 'none'
		}
	}

	document.querySelectorAll('[name=wpte_checkout_paymnet_method]')?.forEach((node, i) => {
		if (i === 0) node.checked = true
		node.addEventListener('change', e => {
			toggleBtns(e.target.id === 'wpte-checkout-paymnet-method-authorize-net-payment' && e?.target.checked)
		})
	})

	function paymentFormUpdate(opaqueData) {
		document.getElementById("dataDescriptor").value = opaqueData.dataDescriptor;
		document.getElementById("dataValue").value = opaqueData.dataValue;
		toggleBtns(false);
		let submitBtn = checkoutForm?.querySelector('input[type=submit]')
		if(submitBtn) {
			submitBtn.click();
			if(jQuery(checkoutForm).parsley().isValid()) {
				submitBtn.disabled = true;
			}
		}
	}

	window.anetResponseHandler = response => {
		if (response.messages.resultCode === "Error") {
			var i = 0;
			while (i < response.messages.message.length) {
				console.info(
					response.messages.message[i].code + ": " +
					response.messages.message[i].text
				);
				i = i + 1;
			}
		} else {
			paymentFormUpdate(response.opaqueData);
		}
	}
	toggleBtns(anetRadio?.checked)

})()
