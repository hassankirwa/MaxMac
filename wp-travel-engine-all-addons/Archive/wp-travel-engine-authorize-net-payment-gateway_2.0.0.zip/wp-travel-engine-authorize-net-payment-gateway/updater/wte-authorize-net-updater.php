<?php
/**
 * Easy Digital Downloads Plugin Updater
 *
 * @package wte-authorize-net/updater
 */
namespace WTE\Anet\Updater;

defined( 'ABSPATH' ) || exit;

/**
 * Includes the files needed for the plugin updater.
 *
 * @since 2.0.0
 */
if ( ! class_exists( 'EDD_SL_Plugin_Updater' ) ) {
	include dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php';
}

/**
 * Download ID for the product in Easy Digital Downloads.
 *
 * @since 2.0.0
 */
define( 'WTE_AUTHORIZE_NET_ITEM_ID', 577 );

/**
 * Setup the updater for the WTE Authorize.net Add-on.
 *
 * @since 2.0.0
 */
function updater() {

	// retrieve our license key from the DB
	$settings    = get_option( 'wp_travel_engine_license' );
	$license_key = isset( $settings['wte_authorize_net_license_key'] ) ? esc_attr( $settings['wte_authorize_net_license_key'] ) : '';

	// setup the updater
	$edd_updater = new \EDD_SL_Plugin_Updater(
		WP_TRAVEL_ENGINE_STORE_URL,
		WTE_AUTHORIZE_NET_PLUGIN_FILE,
		array(
			'version' => WP_TRAVEL_ENGINE_AUTHORIZE_NET_VERSION,                    // current version number
			'license' => $license_key,             // license key (used get_option above to retrieve from DB)
			'item_id' => WTE_AUTHORIZE_NET_ITEM_ID,       // ID of the product
			'author'  => 'WP Travel Engine', // author of this plugin
			'beta'    => false,
		)
	);

}
add_action( 'admin_init', __NAMESPACE__ . '\updater', 0 );

/**
 * Add-ons name for plugin license page.
 *
 * @since 1.0.0
 */
function addon_name( $array ) {
	$array['WP Travel Engine - Authorize.net Payment Gateway'] = 'wte_authorize_net';
	return $array;
}
add_filter( 'wp_travel_engine_addons', __NAMESPACE__ . '\addon_name' );

/**
 * Add-ons Item ID for plugin license page.
 *
 * @since 1.0.0
 */
function item_id( $array ) {
	$array['wte_authorize_net'] = WTE_AUTHORIZE_NET_ITEM_ID;
	return $array;
}
add_filter( 'wp_travel_engine_addons_id', __NAMESPACE__ . '\item_id' );
