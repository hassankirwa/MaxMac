<?php
/**
 * Easy Digital Downloads Plugin Updater
 *
 * @package Wte_Stripe_Gateway
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Includes the files needed for the plugin updater.
 *
 * @since 1.0.0
 */
if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {

	include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

/**
 * Download ID for the product in Easy Digital Downloads.
 *
 * @since 1.0.0
 */
define( 'WP_TRAVEL_ENGINE_STRIPE_ITEM_ID', 557 ); 

/**
 * Setup the updater for the Wte_Stripe_Gateway Add-on.
 *
 * @since 1.0.0
 */
function wte_stripe_payment_updater() {

	// retrieve our license key from the DB
	$settings = get_option( 'wp_travel_engine_license' );
	$license_key = isset( $settings['wte_stripe_gateway_license_key'] ) ? esc_attr( $settings['wte_stripe_gateway_license_key'] ):'';

	// setup the updater
	$edd_updater = new EDD_SL_Plugin_Updater( WP_TRAVEL_ENGINE_STORE_URL, WTE_STRIPE_GATEWAY_FILE_PATH,
		array(
			'version' => WTE_STRIPE_GATEWAY_VERSION,                    // current version number
			'license' => $license_key,             // license key (used get_option above to retrieve from DB)
			'item_id' => WP_TRAVEL_ENGINE_STRIPE_ITEM_ID,       // ID of the product
			'author'  => 'WP Travel Engine', // author of this plugin
			'beta'    => false,
		)
	);

}
add_action( 'admin_init', 'wte_stripe_payment_updater', 0 );

/**
 * Add-ons name for plugin license page.
 *
 * @since 1.0.0
 */
function wte_stripe_gateway_name($array)
{
	$array['WP Travel Engine - Stripe Payment Gateway'] =  'wte_stripe_gateway';
	return $array;
}
add_filter( 'wp_travel_engine_addons', 'wte_stripe_gateway_name' );

/**
 * Add-ons Item ID for plugin license page.
 *
 * @since 1.0.0
 */
function wte_stripe_gateway_id($array)
{
	$array['wte_stripe_gateway'] = WP_TRAVEL_ENGINE_STRIPE_ITEM_ID;
	return $array;
}
add_filter( 'wp_travel_engine_addons_id', 'wte_stripe_gateway_id' );

/**
 * Add-ons License details for showing updates in plugin license page.
 *
 * @since 1.0.0
 */
function wte_stripe_gateway_license($array)
{
	$settings = get_option( 'wp_travel_engine_license' );
	$license_key = isset( $settings['wte_stripe_gateway_license_key'] ) ? esc_attr( $settings['wte_stripe_gateway_license_key'] ):'';// setup the updater

	$array[] = 
		array( 
	    'version' => WTE_STRIPE_GATEWAY_VERSION,     // current version number
	    'license' => $license_key,   // license key (used get_option above to retrieve from DB)
	    'item_id' => WP_TRAVEL_ENGINE_STRIPE_ITEM_ID,   // id of this product in EDD
	    'author'  => 'WP Travel Engine',  // author of this plugin
	    'url'     => home_url()
	  );
	return $array;
}

$wp_travel_engine = get_option( 'wp_travel_engine_license' );
$wte_stripe_gateway_license_status  = isset( $wp_travel_engine['wte_stripe_gateway_license_status'] ) ? esc_attr( $wp_travel_engine['wte_stripe_gateway_license_status'] ): '';

if( isset( $wte_stripe_gateway_license_status ) && $wte_stripe_gateway_license_status == 'valid' ){
	add_filter( 'wp_travel_engine_licenses', 'wte_stripe_gateway_license' );
}
