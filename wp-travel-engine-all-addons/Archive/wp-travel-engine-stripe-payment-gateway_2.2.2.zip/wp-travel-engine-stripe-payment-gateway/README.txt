=== WP Travel Engine - Stripe Payment Gateway ===
Contributors: wptravelengine
Donate link: https://wptravelengine.com/
Tags: stripe, stripe-payment, payment-gateway
Requires at least: 4.4.0
Tested up to: 6.2
Requires PHP: 5.6
Stable tag: 2.2.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Stripe Payment Gateway extension allows you to accept credit cards directly on your website through Stripe.com account.

== Description ==

Tour operators and travel agencies can enable the Stripe Payment system for trip booking by setting up Stripe Account with key details - Secret Key and Publishable Key.


== Changelog ==

= 2.2.2 =
Released on: 14th June, 2023

* Fix: Multiple Payment Intents are created.
* Add: Option to enable/disable Postal Code in Stripe Card Detail Form.

= 2.2.1 =
Released on: 5th April, 2023
* Fix: Clients detail on Stripe Dashboard was displayed as undefined

= 2.2.0 =
Released on: 7th March, 2023
* Compatibility update for WTE

= 2.1.1 =
Released on: 9th July, 2021
* Compatibility update for WTE and Partial Payment
* Fix: Paid amount is different on Stripe Dashboard than actual paid during checkout
* Enhancement: The pay button will show the exact paying amount in both normal checkout and dashboard checkout

= 2.1.0 =
Released on: 10th June, 2021
* Compatibility update for WTE and Partial Payment

= 2.0.2 =

Released on: 22nd October, 2020

Fixes:

* Minor design fixes.

= 2.0.1 =

Released on: 28th September, 2020

Enhancements:

* Partial Payment payable support added from user dashboard.
* Design udpated for stripe payment form.

Fixes:

* Minor bug fixes.

= 2.0.0 =

Released on: 11th June, 2020

Enhancements:

* Revamped backend UI.
* Assets minification, optimization, and conditional loading.

Fixes:

* Minor bug fixes.

= 1.0.6 =

Released on: 14th January, 2020

Enhancement:

* Compatibility testing with WP Travel Engine 3.0.
* Payments API updated.

Fixes:

* Minor bug fixes.

= 1.0.3 =
* Dynamic Currency

= 1.0.2 =
* Added Product ID

= 1.0.1 =
* Fixed bug in the licensing feature

= 1.0.0 =
* Initial release
