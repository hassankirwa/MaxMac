<?php
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://wptravelengine.com/
 * @since             1.0.0
 * @package           Wte_Stripe_Gateway
 *
 * @wordpress-plugin
 * Plugin Name:       WP Travel Engine - Stripe Payment Gateway
 * Plugin URI:        https://wptravelengine.com/
 * Description:       An extension of WP Travel Engine plugin to accept payment directly on your website through your Stripe account.
 * Version:           2.2.2
 * Author:            WP Travel Engine
 * Author URI:        https://wptravelengine.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wte-stripe-gateway
 * Domain Path:       /languages
 * WTE Requires at least: 4.3.0
 * WTE Tested up to: 5.1.0
 * WTE: 557:wte_stripe_gateway_license_key
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Include the autoloader.
require_once __DIR__ . '/vendor/autoload.php';

if ( ! class_exists( 'WTE_Stripe_Checkout' ) ) :
	/**
	 * Class WTE_Stripe_Checkout.
	 *
	 * @package WTE Stripe Checkout.
	 */
	class WTE_Stripe_Checkout {

		/**
		 * Plugin Name.
		 *
		 * @var string
		 */
		public $plugin_name = 'wte-stripe-checkout';

		/**
		 * Version.
		 *
		 * @var string
		 */
		public $version = '2.2.2';

		/**
		 * The single instance of the class.
		 *
		 * @var string $_instance
		 */
		protected static $_instance = null;

		/**
		 * Main WTE_Stripe_Checkout Instance.
		 * Ensures only one instance of WTE_Stripe_Checkout is loaded or can be loaded.
		 *
		 * @return WTE_Stripe_Checkout - Main instance.
		 */
		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}
			return self::$_instance;
		}

		/**
		 * Class Constructor.
		 */
		public function __construct() {
			$this->define_constants();
			add_action( 'admin_notices', array( $this, 'check_dependency' ) );
			if ( class_exists( 'WP_Travel_Engine' ) ) {
				$this->init_hooks();
			}
		}

		/**
		 * Plugin constants.
		 */
		private function define_constants() {

			$this->define( 'WTE_STRIPE_GATEWAY_FILE_PATH', __FILE__ );
			$this->define( 'WTE_STRIPE_GATEWAY_BASE_PATH', dirname( __FILE__ ) );
			$this->define( 'WTE_STRIPE_GATEWAY_VERSION', $this->version );

		}

		/**
		 * Define constants.
		 *
		 * @param string $name Constant name.
		 * @param string $value Constant value.
		 */
		public function define( $name, $value ) {
			if ( ! defined( $name ) ) {
				define( $name, $value );
			}
		}

		/**
		 * Include  required function/ class files.
		 */
		private function includes() {

			require_once WTE_STRIPE_GATEWAY_BASE_PATH . '/admin/class-admin-settings.php';
			require_once WTE_STRIPE_GATEWAY_BASE_PATH . '/public/class-asp.php';
			require_once WTE_STRIPE_GATEWAY_BASE_PATH . '/public/includes/class-shortcode-asp.php';
			require_once WTE_STRIPE_GATEWAY_BASE_PATH . '/admin/includes/class-order.php';
			require_once WTE_STRIPE_GATEWAY_BASE_PATH . '/includes/stripe/lib/Wte_Stripe.php';

			require WTE_STRIPE_GATEWAY_BASE_PATH . '/includes/wte-stripe-helpers.php';
			require_once WTE_STRIPE_GATEWAY_BASE_PATH . '/includes/class-wte-stripe-request.php';


			/**
			 * The class responsible for updating the add-on from EDD.
			 */
			if ( is_admin() ) {
				require WTE_STRIPE_GATEWAY_BASE_PATH . '/updater/wte-stripe-updater.php';
			}
		}

		/**
		 * Hooks to init in start.
		 */
		public function init_hooks() {

			$this->includes();

			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );

			add_action( 'wp_travel_engine_checkout_payment', array( $this, 'wp_travel_engine_checkout_payment' ) );
			add_action( 'wp_ajax_wp_travel_engine_checkout_payment', array( $this, 'wp_travel_engine_checkout_payment' ) );
			add_action( 'wp_ajax_nopriv_wp_travel_engine_checkout_payment', array( $this, 'wp_travel_engine_checkout_payment' ) );
			add_action( 'stripe_payment_process', array( $this, 'stripe_payment_process' ) );
			add_action( 'wp_travel_engine_after_booking_process_completed', array( $this, 'wte_stripe_payment_process' ) );
			add_action( 'wp_travel_engine_stripe_payment_button', array( $this, 'wp_travel_engine_stripe_payment_button' ) );

			add_action( 'wte_booking_after_checkout_form_close', array( $this, 'append_stripe_pay_form' ) );

			add_action( 'wte_payment_gateway_stripe_payment', array( $this, 'map_payment_data_to_new_booking_structure' ), 10, 3 );
		}

		public function map_payment_data_to_new_booking_structure( $payment_id, $type = 'full_payment', $gateway = '' ) {
			if ( ! $payment_id ) {
				return;
			}

			$booking = get_post( get_post_meta( $payment_id, 'booking_id', true ) );

			$pi_id = '';

			if ( isset( $_REQUEST['stripeToken'] ) ) {
				$pi_id = $_REQUEST['stripeToken'];

				if ( defined( 'WTE_STRIPE_GATEWAY_BASE_PATH' ) ) {
					require_once WTE_STRIPE_GATEWAY_BASE_PATH . '/includes/stripe-php/init.php';
				}

				$sk = wte_array_get( get_option( 'wp_travel_engine_settings' ), 'stripe_secret', '' );

				if ( empty( $sk ) ) {
					wp_die(
						new \WP_Error(
							'WTE_BOOKING_ERROR',
							__( 'Empty Stripe secret key.', 'wte-stripe-gateway' )
						)
					);
				}

				$stripe = \Stripe\Stripe::setApiKey( $sk );

				$response = \Stripe\PaymentIntent::retrieve( $pi_id );

				$response = $response->toArray();

				$payment_data = array(
					'gateway_response' => $response,
					'payment_status'   => $response['amount'] === $response['amount_received'] ? 'captured' : 'completed',
					'payment_amount'   => array(
						'value'    => +$response['amount'] / 100,
						'currency' => $response['currency'],
					),
				);

				WTE_Booking::update_booking(
					$payment_id,
					array(
						'meta_input' => $payment_data,
					)
				);

				if ( in_array( $payment_data['payment_status'], array( 'completed', 'success', 'captured' ), false ) ) {
					$amount = $payment_data['payment_amount']['value'];
					$booking_meta['wp_travel_engine_booking_status'] = 'booked';
					$booking_meta['paid_amount']                     = +$booking->paid_amount + +$amount;
					$booking_meta['due_amount']                      = +$booking->due_amount - +$amount;
					WTE_Booking::update_booking( $booking->ID, array( 'meta_input' => $booking_meta ) );
					WTE_Booking::send_emails( $payment_id, 'order_confirmation', 'all' );
				}
			}

		}

		/**
		 * admin scripts
		 *
		 * @return void
		 */
		public function enqueue_admin_scripts() {
			wp_enqueue_script( 'wte-stripe-gateway-admin-js', plugin_dir_url( __FILE__ ) . 'admin/js/admin.js', array( 'jquery' ), '', false );
		}

		/**
		 * Enqueue Scripts
		 *
		 * @return void
		 */
		public function enqueue_scripts() {

			global $wte_cart;

			if ( ! wp_travel_engine_is_checkout_page() && ! wp_travel_engine_is_account_page() ) {
				return;
			}
			wp_enqueue_script( 'wte-stripe-checkout-js', 'https://js.stripe.com/v3/', array( 'jquery' ), WTE_STRIPE_GATEWAY_VERSION, true );

			$wte_options              = get_option( 'wp_travel_engine_settings', array() );
			$wp_travel_engine_confirm = isset( $wte_options['pages']['wp_travel_engine_confirmation_page'] ) ? esc_attr( $wte_options['pages']['wp_travel_engine_confirmation_page'] ) : '';
			$wp_travel_engine_confirm = get_permalink( $wp_travel_engine_confirm );
			// if ( ! class_exists( '\WPTravelEngine\Payments\Payment_Gateway' ) ) {
				wp_enqueue_script( 'wte-stripe-gateway-public', plugin_dir_url( __FILE__ ) . 'public/includes/js/wte-stripe-gateway-public.js', array( 'jquery', 'wte-stripe-checkout-js', 'parsley' ), '', true );
				if ( $this->is_wte_stripe_enabled() && isset( $wte_options['stripe_publishable'] ) && ! empty( $wte_options['stripe_publishable'] ) ) :
					$translation_array = array(
						'link'             => $wp_travel_engine_confirm,
						'partial'          => ! empty( $wte_cart ) && wp_travel_engine_is_cart_partially_payable() ? true : false,
						'publishable_key'  => isset( $wte_options['stripe_publishable'] ) && ! empty( $wte_options['stripe_publishable'] ) ? esc_attr( $wte_options['stripe_publishable'] ) : '',
						'button_label'     => isset( $wte_options['stripe_btn_label'] ) ? esc_attr( $wte_options['stripe_btn_label'] ) : '',
						'hide_postal_code' => isset( $wte_options['stripe_hide_postal_code'] ) && 'yes' === $wte_options['stripe_hide_postal_code'],
					);
					wp_localize_script( 'wte-stripe-gateway-public', 'wte_stripe', $translation_array );
				endif;
			// }
			wp_enqueue_style( 'wte-stripe-gateway-public-css', plugin_dir_url( __FILE__ ) . 'public/includes/css/wte-stripe-gateway-public.css', '', '', false );
		}

		/**
		 * Undocumented function
		 *
		 * @return void
		 */
		public function wp_travel_engine_stripe_payment_button() {

			if ( isset( $_SESSION['place_order'] ) ) {
				$_SESSION = $_SESSION['place_order'];
			}
			$response       = '';
			$obj            = new Wp_Travel_Engine_Functions();
			$post           = get_post( $_SESSION['trip-id'] );
			$usercode       = $obj->trip_currency_code( $post );
			$cost           = $_SESSION['trip-cost'] * 100;
			$currency_codes = $wp_travel_engine_settings['vendor_currency_code'];

			$billing_options           = $obj->order_form_billing_options();
			$personal_options          = $obj->order_form_personal_options();
			$relation_options          = $obj->order_form_relation_options();
			$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', true );
			$wp_travel_engine_confirm  = isset( $wp_travel_engine_settings['pages']['wp_travel_engine_confirmation_page'] ) ? esc_attr( $wp_travel_engine_settings['pages']['wp_travel_engine_confirmation_page'] ) : '';
			ob_start();

			$result['type'] = 'success';

			$btn = __( 'Pay', 'wte-stripe-gateway' );
			if ( isset( $wp_travel_engine_settings['stripe_btn_label'] ) && $wp_travel_engine_settings['stripe_btn_label'] != '' ) {
				$btn = $wp_travel_engine_settings['stripe_btn_label'];
			}

			$publishable_key = $wp_travel_engine_settings['stripe_publishable'];

			$response .= '<div class="stripe-form-wrap">';
			$response .= "<input type='hidden' name='wp_travel_engine_booking_setting[place_order][cost]' value='" . esc_attr( $_SESSION['trip-cost'] ) . "'>";
			$response .= "<input type='hidden' name='wp_travel_engine_booking_setting[place_order][traveler]' value='" . esc_attr( $_SESSION['travelers'] ) . "'>";
			$response .= "<input type='hidden' name='wp_travel_engine_booking_setting[place_order][tid]' value='" . esc_attr( $_SESSION['trip-id'] ) . "'>";
			$response .= "<input type='hidden' name='wp_travel_engine_booking_setting[place_order][tname]' value='" . esc_attr( get_the_title( $_SESSION['trip-id'] ) ) . "'>";
			$nonce     = wp_create_nonce( 'wp_travel_engine_confirm_booking_nonce' );
			$response .= "<input type='hidden' name='custom' value=" . $nonce . '!' . $_SESSION['trip-date'] . '>';
			$response .= "<input type='hidden' name='wp_travel_engine_booking_setting[place_order][datetime]' value=" . $_SESSION['trip-date'] . '>';
			$response .= '</div>';

			echo $response;

			$userid         = get_post_field( 'post_author', $_SESSION['trip-id'] );
			$currency_codes = $wp_travel_engine_settings['vendor_currency_code'];
			$cost           = $_SESSION['trip-cost'] * 100;
			$code           = 'USD';
			if ( isset( $wp_travel_engine_settings['currency_code'] ) && $wp_travel_engine_settings['currency_code'] != '' ) {
				$code = $wp_travel_engine_settings['currency_code'];
			}

			echo "<script src='https://checkout.stripe.com/checkout.js' class='stripe-button'
            data-key='" . $publishable_key . "'
            data-panel-label='" . esc_attr( $btn ) . "'
            data-amount='" . esc_attr( $cost ) . "'
            data-name='" . esc_attr( get_the_title( $_SESSION['trip-id'] ) ) . "'
            data-currency='" . $code . "'
            data-label='" . $btn . "'";
			echo apply_filters( 'asp_additional_stripe_checkout_data_parameters', '' );
			echo '></script>';
			wp_reset_postdata();
			$data = ob_get_clean();
			echo $data;
		}

		/**
		 * Undocumented function
		 *
		 * @return void
		 */
		public function wp_travel_engine_checkout_payment() {
			if ( isset( $_SESSION['place_order'] ) ) {
				$_SESSION = $_SESSION['place_order'];
			}
			$response                  = '';
			$obj                       = new Wp_Travel_Engine_Functions();
			$billing_options           = $obj->order_form_billing_options();
			$personal_options          = $obj->order_form_personal_options();
			$relation_options          = $obj->order_form_relation_options();
			$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', true );
			$wp_travel_engine_confirm  = isset( $wp_travel_engine_settings['pages']['wp_travel_engine_confirmation_page'] ) ? esc_attr( $wp_travel_engine_settings['pages']['wp_travel_engine_confirmation_page'] ) : '';
			ob_start();

					$result['type'] = 'success';
					$code           = 'USD';
			if ( isset( $wp_travel_engine_settings['currency_code'] ) && $wp_travel_engine_settings['currency_code'] != '' ) {
				$code = $wp_travel_engine_settings['currency_code'];
			}
					$btn = __( 'Pay', 'wte-stripe-gateway' );
			if ( isset( $wp_travel_engine_settings['stripe_btn_label'] ) && $wp_travel_engine_settings['stripe_btn_label'] != '' ) {
				$btn = $wp_travel_engine_settings['stripe_btn_label'];
			}
					$publishable_key = $wp_travel_engine_settings['stripe_publishable'];

					$response .= '<div class="stripe-form-wrap">';
					$response .= "<input type='hidden' name='wp_travel_engine_booking_setting[place_order][cost]' value='" . esc_attr( $_SESSION['trip-cost'] ) . "'>";
					$response .= "<input type='hidden' name='wp_travel_engine_booking_setting[place_order][traveler]' value='" . esc_attr( $_SESSION['travelers'] ) . "'>";
					$response .= "<input type='hidden' name='wp_travel_engine_booking_setting[place_order][tid]' value='" . esc_attr( $_SESSION['trip-id'] ) . "'>";
					$response .= "<input type='hidden' name='wp_travel_engine_booking_setting[place_order][tname]' value='" . esc_attr( get_the_title( $_SESSION['trip-id'] ) ) . "'>";
					$nonce     = wp_create_nonce( 'wp_travel_engine_confirm_booking_nonce' );
					$response .= "<input type='hidden' name='custom' value=" . $nonce . '!' . $_SESSION['trip-date'] . '>';
					$response .= "<input type='hidden' name='wp_travel_engine_booking_setting[place_order][datetime]' value=" . $_SESSION['trip-date'] . '>';
					$response .= '</div>';

					echo $response;

			echo "<script src='https://checkout.stripe.com/checkout.js' class='stripe-button'
            data-key='" . $publishable_key . "'
            data-panel-label='" . esc_attr( $btn ) . "'
            data-amount='" . esc_attr( $_SESSION['trip-cost'] * 100 ) . "'
            data-name='" . esc_attr( get_the_title( $_SESSION['trip-id'] ) ) . "'
            data-currency='" . $code . "'
            data-label='" . $btn . "'";
			echo apply_filters( 'asp_additional_stripe_checkout_data_parameters', '' );
			echo '></script>';
			wp_reset_postdata();
			$data = ob_get_clean();
			wp_send_json_success( $data );
			wp_die();
		}

		/**
		 * Undocumented function
		 *
		 * @return void
		 */
		public function stripe_payment_process() {
			$options         = get_option( 'wp_travel_engine_settings', true );
			$item_name       = sanitize_text_field( get_the_title( $_SESSION['trip-id'] ) );
			$stripeToken     = sanitize_text_field( $_POST['stripeToken'] );
			$stripeTokenType = sanitize_text_field( $_POST['stripeTokenType'] );
			$stripeEmail     = sanitize_email( $_POST['stripeEmail'] );
			$item_quantity   = sanitize_text_field( $_SESSION['travelers'] );

			$currency_code = 'USD';
			$paymentAmount = round( $_SESSION['trip-cost'] * 100 );

			$item_price = ( $paymentAmount / $item_quantity );

			$charge_description = '';

			$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', true );

			$code = 'USD';

			if ( isset( $wp_travel_engine_settings['currency_code'] ) && $wp_travel_engine_settings['currency_code'] != '' ) {
				$code = $wp_travel_engine_settings['currency_code'];
			}

			$currencyCodeType = strtolower( $code );

			$secret_key = $options['stripe_secret'];
			Wte_Stripe::setApiKey( $secret_key );

			$GLOBALS['asp_payment_success'] = false;

			$customer = Wte_Stripe_Customer::create(
				array(
					'email' => $stripeEmail,
					'card'  => $stripeToken,
				)
			);

			$charge = Wte_Stripe_Charge::create(
				array(
					'customer'    => $customer->id,
					'amount'      => $paymentAmount,
					'currency'    => $currencyCodeType,
					'description' => $charge_description,
				)
			);

			// Grab the charge ID and set it as the transaction ID.
			$txn_id = $charge->id;// $charge->balance_transaction;

			// Core transaction data
			$data                    = array();
			$data['item_name']       = $item_name;
			$data['stripeToken']     = $stripeToken;
			$data['stripeTokenType'] = $stripeTokenType;
			$data['stripeEmail']     = $stripeEmail;
			$data['item_quantity']   = $item_quantity;
			$data['item_price']      = $item_price;
			$data['currency_code']   = $currency_code;
			$data['txn_id']          = $txn_id;// The Stripe charge ID

			$post_data = array_map( 'sanitize_text_field', $data );

			// Action hook with the checkout post data parameters.
			do_action( 'asp_stripe_payment_completed', $post_data, $charge );

			// Action hook with the order object.
			do_action( 'AcceptStripePayments_payment_completed', '', $charge );

			$GLOBALS['asp_payment_success'] = true;
		}

		/**
		 * Process stripe payments.
		 *
		 * @return void
		 */
		public function wte_stripe_payment_process( $booking_id ) {

			if ( ! $this->is_wte_stripe_enabled() ) {
				return;
			}

			if ( ! $this->checkout_uses_stripe() ) {
				return;
			}

			if ( ! $booking_id ) {
				return;
			}

			if ( isset( $_REQUEST['stripe_payment_details'] ) && ! empty( $_REQUEST['stripe_payment_details'] ) ) :

				do_action( 'wp_travel_engine_before_payment_process', $booking_id );

				$seriliazed_paydata = sanitize_text_field( wp_unslash( $_REQUEST['stripe_payment_details'] ) );
				$payment_details    = json_decode( $seriliazed_paydata );

				$booking_metas = get_post_meta( $booking_id, 'wp_travel_engine_booking_setting', true );

				// payment completed.
				// Update booking status and Payment args.
				$booking_metas['place_order']['payment']['stripeToken']     = $_POST['stripeToken'];
				$booking_metas['place_order']['payment']['stripeTokenType'] = $_POST['stripeTokenType'];
				$booking_metas['place_order']['payment']['stripeEmail']     = $_POST['stripeEmail'];
				$booking_metas['place_order']['payment']['payment_gateway'] = 'stripe';

				update_post_meta( $booking_id, 'wp_travel_engine_booking_setting', $booking_metas );

				// TODO: For future implementation
				$payment_method = 'stripe_checkout';

				update_post_meta( $booking_id, sprintf( '_%s_details', $payment_method ), stripslashes_deep( $payment_details ) );

				do_action( 'wp_travel_engine_after_payment_process', $booking_id );

			endif;

		}

		/**
		 * Check if Stripe is enabled.
		 *
		 * @return boolean
		 */
		public function is_wte_stripe_enabled() {

			$wte_options = get_option( 'wp_travel_engine_settings', true );

			return isset( $wte_options['stripe_payment'] ) && $wte_options['stripe_payment'] != '';

		}

		/**
		 * Check if Stripe is default payment gateway.
		 *
		 * @return boolean
		 */
		public function is_wte_stripe_selected_as_default_payment() {

			$wte_options = get_option( 'wp_travel_engine_settings', true );

			return isset( $wte_options['default_gateway'] ) && $wte_options['default_gateway'] == 'stripe_payment';

		}

		/**
		 * Check if Stripe Publishable Key is not empty
		 *
		 * @return boolean
		 */
		public function is_wte_stripe_publishable_key_not_empty() {

			$wte_options = get_option( 'wp_travel_engine_settings', true );

			return isset( $wte_options['stripe_publishable'] ) && ! empty( $wte_options['stripe_publishable'] );

		}

		/**
		 * Check if checkout process uses paypal express checkout.
		 *
		 * @return void
		 */
		public function checkout_uses_stripe() {

			return 'POST' === $_SERVER['REQUEST_METHOD'] && array_key_exists( 'wpte_checkout_paymnet_method', $_REQUEST ) && 'stripe_payment' === $_REQUEST['wpte_checkout_paymnet_method'] && array_key_exists( 'stripe_payment_details', $_REQUEST ) && ! empty( $_REQUEST['stripe_payment_details'] );

		}

		/**
		 * This will uninstall this plugin if parent WP Travel plugin not found.
		 */
		public function check_dependency() {

			if ( ! class_exists( 'Wp_Travel_Engine' ) || ! $this->meets_requirements() ) {
				echo '<div class="error">';
				echo wp_kses_post( '<p><strong>WP Travel Engine Stripe Checkout</strong> requires the <a href="https://wptravelengine.com" target="__blank">WP Travel Engine</a> to work. Please install and activate the latest WP Travel Engine plugin first. <b>WP Travel Engine Stripe Checkout will now be deactivated now.</b></p>' );
				echo '</div>';

				// Deactivate Plugins.
				deactivate_plugins( plugin_basename( __FILE__ ) );
			}
		}

		/**
		 * Check if all plugin requirements are met.
		 *
		 * @since 1.0.0
		 *
		 * @return bool True if requirements are met, otherwise false.
		 */
		private function meets_requirements() {
			return ( class_exists( 'WP_Travel_Engine' ) && defined( 'WP_TRAVEL_ENGINE_VERSION' ) && version_compare( WP_TRAVEL_ENGINE_VERSION, '4.0.0', '>=' ) );
		}

		/**
		 * Append stripe pay form.
		 *
		 * @return void
		 */
		public function append_stripe_pay_form() {
			if ( $this->is_wte_stripe_enabled() && $this->is_wte_stripe_selected_as_default_payment() ) {
				$stripe_shown = 'block';
			} else {
				$stripe_shown = 'none';
			}
			$wte_options = get_option( 'wp_travel_engine_settings', true );
			?>
				<div id="wte-stripe-payment-form" style="display:<?php echo $stripe_shown; ?>;">
					<div id="card-element"></div><div id="card-errors" role="alert"></div>
					<?php
					if ( $this->is_wte_stripe_publishable_key_not_empty() ) {
						$checkout_label = __( 'Pay', 'wte-stripe-gateway' );
						if ( isset( $wte_options['stripe_btn_label'] ) && ! empty( $wte_options['stripe_btn_label'] ) ) {
							$checkout_label = esc_attr( $wte_options['stripe_btn_label'] );
						}
						?>
						<button id="wte-stripe-payment-button" data-checkout-label="<?php echo esc_attr( $checkout_label ); ?>"><?php echo $checkout_label; ?></button>
					<?php } ?>
					<input id="wte-stripe-payment-Client-SS" type="hidden" value=""/>
				</div>
			<?php
		}

	}

	/**
	 * Initiate addon.
	 */
	function wte_stripe_checkout_init() {
		return WTE_Stripe_Checkout::instance();
	}

	add_action( 'plugins_loaded', 'wte_stripe_checkout_init' );
endif;
