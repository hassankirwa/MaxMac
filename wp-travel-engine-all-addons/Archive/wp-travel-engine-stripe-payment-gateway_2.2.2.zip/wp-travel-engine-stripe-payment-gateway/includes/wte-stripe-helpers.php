<?php
/**
 * Stripe Functions.
 *
 * @package wte-stripe-gateway
 */
add_action( 'wp_ajax_nopriv_wte_payment_stripe_charge', 'wp_travel_engine_stripe_payment_intent' );
add_action( 'wp_ajax_wte_payment_stripe_charge', 'wp_travel_engine_stripe_payment_intent' );

/**
 * Helper function for AJAX stripe charge action.
 *
 * @return void
 */
function wp_travel_engine_stripe_payment_intent() {

    require_once( WTE_STRIPE_GATEWAY_BASE_PATH . '/includes/stripe-php/init.php' );

	if ( ! empty( $_POST['gateway'] ) && 'stripe_payment' == $_POST['gateway'] ) {

        ini_set( 'display_errors', 0 );

        $wte_settings = get_option( 'wp_travel_engine_settings', true );

		// Settings api key.
		$publishable_key = $wte_settings['stripe_publishable'];
		$secret_key      = $wte_settings['stripe_secret'];

		$stripe = array(
			'publishable_key' => $publishable_key,
			'secret_key'      => $secret_key,
		);

		\Stripe\Stripe::setApiKey( $stripe['secret_key'] );
		// Settings api key Ends.

		if ( isset( $_POST['payment_intent_id'] ) ) {
			$stripe = new \Stripe\StripeClient( $secret_key );
			$stripe->paymentIntents->update(
				wp_unslash( $_POST['payment_intent_id'] ),
				[
					'amount'   => isset( $_POST['total'] ) ? wte_payment_stripe_convert_amount($_POST['total']) : '',
					'currency' => isset( $_POST['currency'] ) ? wp_unslash( $_POST['currency'] ) : '',
				]
			);
			wp_send_json([
				'id' => $intent->id,
				'client_secret' => $intent->client_secret,
			]);
			wp_die();
		}

		$intent = \Stripe\PaymentIntent::create([
			'amount'   => isset($_POST['total'])? wte_payment_stripe_convert_amount($_POST['total']):'' ,
			'currency' => isset($_POST['currency'])?$_POST['currency']:'',
			// Verify your integration in this guide by including this parameter
			'metadata' => ['integration_check' => 'accept_a_payment'],
			// 'automatic_payment_methods' => [
			// 	'enabled' => 'true',
			// ],
		]);

		wp_send_json( array(
			'id' => $intent->id,
			'client_secret' => $intent->client_secret
		) );

	}
	die;
}

/**
 * With decimal currencies like USD
 * $5 must be multiplied by 100
 * to give a cent amount of "500".
 * But for zero-decimal currencies (like JPY),
 * ¥500 is just ¥500.
 *
 * The following currencies should be excluded from multiplication:
 * BIF, CLP, DJF, GNF, JPY, KMF, KRW, MGA, PYG, RWF, VND, VUV, XAF, XOF, XPF
 *
 * https://support.stripe.com/questions/which-zero-decimal-currencies-does-stripe-support
 *
 * @var int (total)
 * @return int (converted total)
 */
function wte_payment_stripe_convert_amount( $total=null, $currency=null ){

	if ( ! $currency ) {
		$currency = 'USD';
	}
	$zero_decimal_currencies = array( 'BIF', 'CLP', 'DJF', 'GNF', 'JPY', 'KMF', 'KRW', 'MGA', 'PYG', 'RWF', 'VND', 'VUV', 'XAF', 'XOF', 'XPF' );

	if ( in_array( $currency, $zero_decimal_currencies ) ) {
		$new_total = intval( $total );
	} else {
		$new_total = round( ( float ) $total, 2 ) * 100;
	}
	return $new_total;
}
