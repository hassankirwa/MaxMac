<?php

class Wte_Stripe_ApiConnectionError extends Wte_Stripe_Error
{
}
