<?php

class Wte_Stripe_AuthenticationError extends Wte_Stripe_Error
{
}
