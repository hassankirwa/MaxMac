<?php

class Wte_Stripe_Balance extends Wte_Stripe_SingletonApiResource
{
  /**
    * @param string|null $apiKey
    *
    * @return Wte_Stripe_Balance
    */
  public static function retrieve($apiKey=null)
  {
    $class = get_class();
    return self::_scopedSingletonRetrieve($class, $apiKey);
  }
}
