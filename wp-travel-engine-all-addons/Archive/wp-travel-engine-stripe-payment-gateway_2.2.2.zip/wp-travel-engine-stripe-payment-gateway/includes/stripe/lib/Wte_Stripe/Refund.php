<?php

class Wte_Stripe_Refund extends Wte_Stripe_ApiResource
{
  /**
   * @return string The API URL for this Wte_Stripe refund.
   */
  public function instanceUrl()
  {
    $id = $this['id'];
    $charge = $this['charge'];
    if (!$id) {
      throw new Wte_Stripe_InvalidRequestError(
          "Could not determine which URL to request: " .
          "class instance has invalid ID: $id",
          null
      );
    }
    $id = Wte_Stripe_ApiRequestor::utf8($id);
    $charge = Wte_Stripe_ApiRequestor::utf8($charge);

    $base = self::classUrl('Wte_Stripe_Charge');
    $chargeExtn = urlencode($charge);
    $extn = urlencode($id);
    return "$base/$chargeExtn/refunds/$extn";
  }

  /**
   * @return Wte_Stripe_Refund The saved refund.
   */
  public function save()
  {
    $class = get_class();
    return self::_scopedSave($class);
  }
}
