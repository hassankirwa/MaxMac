<?php

class Wte_Stripe_ApplicationFeeRefund extends Wte_Stripe_ApiResource
{
  /**
   * @return string The API URL for this Wte_Stripe refund.
   */
  public function instanceUrl()
  {
    $id = $this['id'];
    $fee = $this['fee'];
    if (!$id) {
      throw new Wte_Stripe_InvalidRequestError(
          "Could not determine which URL to request: " .
          "class instance has invalid ID: $id",
          null
      );
    }
    $id = Wte_Stripe_ApiRequestor::utf8($id);
    $fee = Wte_Stripe_ApiRequestor::utf8($fee);

    $base = self::classUrl('Wte_Stripe_ApplicationFee');
    $feeExtn = urlencode($fee);
    $extn = urlencode($id);
    return "$base/$feeExtn/refunds/$extn";
  }

  /**
   * @return Wte_Stripe_ApplicationFeeRefund The saved refund.
   */
  public function save()
  {
    $class = get_class();
    return self::_scopedSave($class);
  }
}
