<?php

class Wte_Stripe_ApiError extends Wte_Stripe_Error
{
}
