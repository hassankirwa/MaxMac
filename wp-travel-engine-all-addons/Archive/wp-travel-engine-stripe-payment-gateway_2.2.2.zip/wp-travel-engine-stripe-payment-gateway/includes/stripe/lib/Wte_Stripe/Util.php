<?php

abstract class Wte_Stripe_Util
{
  /**
   * Whether the provided array (or other) is a list rather than a dictionary.
   *
   * @param array|mixed $array
   * @return boolean True if the given object is a list.
   */
  public static function isList($array)
  {
    if (!is_array($array))
      return false;

    // TODO: generally incorrect, but it's correct given Wte_Stripe's response
    foreach (array_keys($array) as $k) {
      if (!is_numeric($k))
        return false;
    }
    return true;
  }

  /**
   * Recursively converts the PHP Wte_Stripe object to an array.
   *
   * @param array $values The PHP Wte_Stripe object to convert.
   * @return array
   */
  public static function convertWte_StripeObjectToArray($values)
  {
    $results = array();
    foreach ($values as $k => $v) {
      // FIXME: this is an encapsulation violation
      if ($k[0] == '_') {
        continue;
      }
      if ($v instanceof Wte_Stripe_Object) {
        $results[$k] = $v->__toArray(true);
      } else if (is_array($v)) {
        $results[$k] = self::convertWte_StripeObjectToArray($v);
      } else {
        $results[$k] = $v;
      }
    }
    return $results;
  }

  /**
   * Converts a response from the Wte_Stripe API to the corresponding PHP object.
   *
   * @param array $resp The response from the Wte_Stripe API.
   * @param string $apiKey
   * @return Wte_Stripe_Object|array
   */
  public static function convertToWte_StripeObject($resp, $apiKey)
  {
    $types = array(
      'card' => 'Wte_Stripe_Card',
      'charge' => 'Wte_Stripe_Charge',
      'coupon' => 'Wte_Stripe_Coupon',
      'customer' => 'Wte_Stripe_Customer',
      'list' => 'Wte_Stripe_List',
      'invoice' => 'Wte_Stripe_Invoice',
      'invoiceitem' => 'Wte_Stripe_InvoiceItem',
      'event' => 'Wte_Stripe_Event',
      'transfer' => 'Wte_Stripe_Transfer',
      'plan' => 'Wte_Stripe_Plan',
      'recipient' => 'Wte_Stripe_Recipient',
      'refund' => 'Wte_Stripe_Refund',
      'subscription' => 'Wte_Stripe_Subscription',
      'fee_refund' => 'Wte_Stripe_ApplicationFeeRefund',
      'bitcoin_receiver' => 'Wte_Stripe_BitcoinReceiver',
      'bitcoin_transaction' => 'Wte_Stripe_BitcoinTransaction'
    );
    if (self::isList($resp)) {
      $mapped = array();
      foreach ($resp as $i)
        array_push($mapped, self::convertToWte_StripeObject($i, $apiKey));
      return $mapped;
    } else if (is_array($resp)) {
      if (isset($resp['object'])
          && is_string($resp['object'])
          && isset($types[$resp['object']])) {
        $class = $types[$resp['object']];
      } else {
        $class = 'Wte_Stripe_Object';
      }
      return Wte_Stripe_Object::scopedConstructFrom($class, $resp, $apiKey);
    } else {
      return $resp;
    }
  }
}
