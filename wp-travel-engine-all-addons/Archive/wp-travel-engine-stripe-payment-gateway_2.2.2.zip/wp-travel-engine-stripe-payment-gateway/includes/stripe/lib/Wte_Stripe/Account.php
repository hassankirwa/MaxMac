<?php

class Wte_Stripe_Account extends Wte_Stripe_SingletonApiResource
{
  /**
    * @param string|null $apiKey
    *
    * @return Wte_Stripe_Account
    */
  public static function retrieve($apiKey=null)
  {
    $class = get_class();
    return self::_scopedSingletonRetrieve($class, $apiKey);
  }
}
