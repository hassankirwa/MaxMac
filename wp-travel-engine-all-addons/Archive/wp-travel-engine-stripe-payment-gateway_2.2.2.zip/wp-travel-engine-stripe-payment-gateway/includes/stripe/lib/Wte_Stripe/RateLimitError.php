<?php

class Wte_Stripe_RateLimitError extends Wte_Stripe_InvalidRequestError
{
  public function __construct($message, $param, $httpStatus=null,
      $httpBody=null, $jsonBody=null
  )
  {
    parent::__construct($message, $httpStatus, $httpBody, $jsonBody);
  }
}
