<?php

class Wte_Stripe_BitcoinTransaction extends Wte_Stripe_ApiResource
{

}

