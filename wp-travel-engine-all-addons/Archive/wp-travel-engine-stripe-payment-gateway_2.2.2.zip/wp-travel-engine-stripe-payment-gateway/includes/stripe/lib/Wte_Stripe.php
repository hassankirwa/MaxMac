<?php

// Tested on PHP 5.2, 5.3

// This snippet (and some of the curl code) due to the Facebook SDK.
if (!function_exists('curl_init')) {
  throw new Exception('Wte_Stripe needs the CURL PHP extension.');
}
if (!function_exists('json_decode')) {
  throw new Exception('Wte_Stripe needs the JSON PHP extension.');
}
if (!function_exists('mb_detect_encoding')) {
  throw new Exception('Wte_Stripe needs the Multibyte String PHP extension.');
}

// Wte_Stripe singleton
require(dirname(__FILE__) . '/Wte_Stripe/Wte_Stripe.php');

// Utilities
require(dirname(__FILE__) . '/Wte_Stripe/Util.php');
require(dirname(__FILE__) . '/Wte_Stripe/Util/Set.php');

// Errors
require(dirname(__FILE__) . '/Wte_Stripe/Error.php');
require(dirname(__FILE__) . '/Wte_Stripe/ApiError.php');
require(dirname(__FILE__) . '/Wte_Stripe/ApiConnectionError.php');
require(dirname(__FILE__) . '/Wte_Stripe/AuthenticationError.php');
require(dirname(__FILE__) . '/Wte_Stripe/CardError.php');
require(dirname(__FILE__) . '/Wte_Stripe/InvalidRequestError.php');
require(dirname(__FILE__) . '/Wte_Stripe/RateLimitError.php');

// Plumbing
require(dirname(__FILE__) . '/Wte_Stripe/Object.php');
require(dirname(__FILE__) . '/Wte_Stripe/ApiRequestor.php');
require(dirname(__FILE__) . '/Wte_Stripe/ApiResource.php');
require(dirname(__FILE__) . '/Wte_Stripe/SingletonApiResource.php');
require(dirname(__FILE__) . '/Wte_Stripe/AttachedObject.php');
require(dirname(__FILE__) . '/Wte_Stripe/List.php');
require(dirname(__FILE__) . '/Wte_Stripe/RequestOptions.php');

// Wte_Stripe API Resources
require(dirname(__FILE__) . '/Wte_Stripe/Account.php');
require(dirname(__FILE__) . '/Wte_Stripe/Card.php');
require(dirname(__FILE__) . '/Wte_Stripe/Balance.php');
require(dirname(__FILE__) . '/Wte_Stripe/BalanceTransaction.php');
require(dirname(__FILE__) . '/Wte_Stripe/Charge.php');
require(dirname(__FILE__) . '/Wte_Stripe/Customer.php');
require(dirname(__FILE__) . '/Wte_Stripe/FileUpload.php');
require(dirname(__FILE__) . '/Wte_Stripe/Invoice.php');
require(dirname(__FILE__) . '/Wte_Stripe/InvoiceItem.php');
require(dirname(__FILE__) . '/Wte_Stripe/Plan.php');
require(dirname(__FILE__) . '/Wte_Stripe/Subscription.php');
require(dirname(__FILE__) . '/Wte_Stripe/Token.php');
require(dirname(__FILE__) . '/Wte_Stripe/Coupon.php');
require(dirname(__FILE__) . '/Wte_Stripe/Event.php');
require(dirname(__FILE__) . '/Wte_Stripe/Transfer.php');
require(dirname(__FILE__) . '/Wte_Stripe/Recipient.php');
require(dirname(__FILE__) . '/Wte_Stripe/Refund.php');
require(dirname(__FILE__) . '/Wte_Stripe/ApplicationFee.php');
require(dirname(__FILE__) . '/Wte_Stripe/ApplicationFeeRefund.php');
require(dirname(__FILE__) . '/Wte_Stripe/BitcoinReceiver.php');
require(dirname(__FILE__) . '/Wte_Stripe/BitcoinTransaction.php');
