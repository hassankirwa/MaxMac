<?php
/**
 * Stripe payment gateway.
 *
 * @since 2.2.0
 * @package WP_Travel_Engine/includes/payment-gateways
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
if ( class_exists( '\WPTravelEngine\Payments\Payment_Gateway' ) ) {
	/**
	 * Class stripe payment gateway
	 */
	class WTE_Payment_Gateway_Stripe extends \WPTravelEngine\Payments\Payment_Gateway {


		/**
		 * Payment Method Id.
		 *
		 * @var mixed
		 */
		public $id = 'stripe_payment';

		/**
		 * Get Label Name
		 *
		 * @return string
		 */
		protected function get_label() {
			return __( 'Stripe', 'wte-stripe-gateway' );
		}

		/**
		 * Get Input Class Name
		 *
		 * @return string
		 */
		protected function get_input_class() {
			return 'stripe-payment';
		}

		/**
		 * Process payment for stripe
		 *
		 * @param object $booking Booking object.
		 * @param object $payment Payment object.
		 */
		public function process_payment( $booking, $payment ) {

			$redirect_uri = $this->get_return_url( $booking, $payment );
			// Get Payment Method.
			$payment_method = ( ! empty( $_POST['wpte_checkout_paymnet_method'] ) ) ? sanitize_text_field( wp_unslash( $_POST['wpte_checkout_paymnet_method'] ) ) : '';
			// Get Payment Mode.
			$payment_mode = isset( $_POST['wp_travel_engine_payment_mode'] ) ? sanitize_text_field( wp_unslash( $_POST['wp_travel_engine_payment_mode'] ) ) : 'full_payment';

			/**
			 * Apply action to update payment.
			 */
			do_action( 'wte_payment_gateway_stripe_payment', $payment->ID, $payment_mode, $payment_method );

			if ( ! wp_doing_ajax() ) {
				wp_safe_redirect( $redirect_uri );
				exit;
			}

			return array(
				'result'   => 'success',
				'redirect' => $redirect_uri,
			);

		}
	}
}
