"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _regeneratorRuntime() { "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ _regeneratorRuntime = function _regeneratorRuntime() { return exports; }; var exports = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function (obj, key, desc) { obj[key] = desc.value; }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag"; function define(obj, key, value) { return Object.defineProperty(obj, key, { value: value, enumerable: !0, configurable: !0, writable: !0 }), obj[key]; } try { define({}, ""); } catch (err) { define = function define(obj, key, value) { return obj[key] = value; }; } function wrap(innerFn, outerFn, self, tryLocsList) { var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []); return defineProperty(generator, "_invoke", { value: makeInvokeMethod(innerFn, self, context) }), generator; } function tryCatch(fn, obj, arg) { try { return { type: "normal", arg: fn.call(obj, arg) }; } catch (err) { return { type: "throw", arg: err }; } } exports.wrap = wrap; var ContinueSentinel = {}; function Generator() {} function GeneratorFunction() {} function GeneratorFunctionPrototype() {} var IteratorPrototype = {}; define(IteratorPrototype, iteratorSymbol, function () { return this; }); var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([]))); NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype); var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype); function defineIteratorMethods(prototype) { ["next", "throw", "return"].forEach(function (method) { define(prototype, method, function (arg) { return this._invoke(method, arg); }); }); } function AsyncIterator(generator, PromiseImpl) { function invoke(method, arg, resolve, reject) { var record = tryCatch(generator[method], generator, arg); if ("throw" !== record.type) { var result = record.arg, value = result.value; return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) { invoke("next", value, resolve, reject); }, function (err) { invoke("throw", err, resolve, reject); }) : PromiseImpl.resolve(value).then(function (unwrapped) { result.value = unwrapped, resolve(result); }, function (error) { return invoke("throw", error, resolve, reject); }); } reject(record.arg); } var previousPromise; defineProperty(this, "_invoke", { value: function value(method, arg) { function callInvokeWithMethodAndArg() { return new PromiseImpl(function (resolve, reject) { invoke(method, arg, resolve, reject); }); } return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg(); } }); } function makeInvokeMethod(innerFn, self, context) { var state = "suspendedStart"; return function (method, arg) { if ("executing" === state) throw new Error("Generator is already running"); if ("completed" === state) { if ("throw" === method) throw arg; return doneResult(); } for (context.method = method, context.arg = arg;;) { var delegate = context.delegate; if (delegate) { var delegateResult = maybeInvokeDelegate(delegate, context); if (delegateResult) { if (delegateResult === ContinueSentinel) continue; return delegateResult; } } if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) { if ("suspendedStart" === state) throw state = "completed", context.arg; context.dispatchException(context.arg); } else "return" === context.method && context.abrupt("return", context.arg); state = "executing"; var record = tryCatch(innerFn, self, context); if ("normal" === record.type) { if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue; return { value: record.arg, done: context.done }; } "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg); } }; } function maybeInvokeDelegate(delegate, context) { var methodName = context.method, method = delegate.iterator[methodName]; if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel; var record = tryCatch(method, delegate.iterator, context.arg); if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel; var info = record.arg; return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel); } function pushTryEntry(locs) { var entry = { tryLoc: locs[0] }; 1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry); } function resetTryEntry(entry) { var record = entry.completion || {}; record.type = "normal", delete record.arg, entry.completion = record; } function Context(tryLocsList) { this.tryEntries = [{ tryLoc: "root" }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0); } function values(iterable) { if (iterable) { var iteratorMethod = iterable[iteratorSymbol]; if (iteratorMethod) return iteratorMethod.call(iterable); if ("function" == typeof iterable.next) return iterable; if (!isNaN(iterable.length)) { var i = -1, next = function next() { for (; ++i < iterable.length;) if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next; return next.value = undefined, next.done = !0, next; }; return next.next = next; } } return { next: doneResult }; } function doneResult() { return { value: undefined, done: !0 }; } return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", { value: GeneratorFunctionPrototype, configurable: !0 }), defineProperty(GeneratorFunctionPrototype, "constructor", { value: GeneratorFunction, configurable: !0 }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) { var ctor = "function" == typeof genFun && genFun.constructor; return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name)); }, exports.mark = function (genFun) { return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun; }, exports.awrap = function (arg) { return { __await: arg }; }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () { return this; }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) { void 0 === PromiseImpl && (PromiseImpl = Promise); var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl); return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) { return result.done ? result.value : iter.next(); }); }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () { return this; }), define(Gp, "toString", function () { return "[object Generator]"; }), exports.keys = function (val) { var object = Object(val), keys = []; for (var key in object) keys.push(key); return keys.reverse(), function next() { for (; keys.length;) { var key = keys.pop(); if (key in object) return next.value = key, next.done = !1, next; } return next.done = !0, next; }; }, exports.values = values, Context.prototype = { constructor: Context, reset: function reset(skipTempReset) { if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined); }, stop: function stop() { this.done = !0; var rootRecord = this.tryEntries[0].completion; if ("throw" === rootRecord.type) throw rootRecord.arg; return this.rval; }, dispatchException: function dispatchException(exception) { if (this.done) throw exception; var context = this; function handle(loc, caught) { return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught; } for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i], record = entry.completion; if ("root" === entry.tryLoc) return handle("end"); if (entry.tryLoc <= this.prev) { var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc"); if (hasCatch && hasFinally) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } else if (hasCatch) { if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0); } else { if (!hasFinally) throw new Error("try statement without catch or finally"); if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc); } } } }, abrupt: function abrupt(type, arg) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) { var finallyEntry = entry; break; } } finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null); var record = finallyEntry ? finallyEntry.completion : {}; return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record); }, complete: function complete(record, afterLoc) { if ("throw" === record.type) throw record.arg; return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel; }, finish: function finish(finallyLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel; } }, "catch": function _catch(tryLoc) { for (var i = this.tryEntries.length - 1; i >= 0; --i) { var entry = this.tryEntries[i]; if (entry.tryLoc === tryLoc) { var record = entry.completion; if ("throw" === record.type) { var thrown = record.arg; resetTryEntry(entry); } return thrown; } } throw new Error("illegal catch attempt"); }, delegateYield: function delegateYield(iterable, resultName, nextLoc) { return this.delegate = { iterator: values(iterable), resultName: resultName, nextLoc: nextLoc }, "next" === this.method && (this.arg = undefined), ContinueSentinel; } }, exports; }
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _iterableToArrayLimit(arr, i) { var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"]; if (null != _i) { var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1; try { if (_x = (_i = _i.call(arr)).next, 0 === i) { if (Object(_i) !== _i) return; _n = !1; } else for (; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0); } catch (err) { _d = !0, _e = err; } finally { try { if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return; } finally { if (_d) throw _e; } } return _arr; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }
function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }
if (typeof Stripe !== "undefined" && jQuery("#card-element").length > 0) {
  /**
   * With decimal currencies like USD
   * $5 must be multiplied by 100
   * to give a cent amount of "500".
   * But for zero-decimal currencies (like JPY),
   * ¥500 is just ¥500.
   *
   * The following currencies should be excluded from multiplication:
   * BIF, CLP, DJF, GNF, JPY, KMF, KRW, MGA, PYG, RWF, VND, VUV, XAF, XOF, XPF
   *
   * https://support.stripe.com/questions/which-zero-decimal-currencies-does-stripe-support
   *
   * @var int (amount)
   * @return int (converted amount)
   */
  var convert_amount = function convert_amount(final_amount) {
    var currency_code = wte.currency.code;
    if ("" == currency_code) {
      var currency_code = "USD";
    }

    // Currency conversion
    var zero_decimal_currencies = ["BIF", "CLP", "DJF", "GNF", "JPY", "KMF", "KRW", "MGA", "PYG", "RWF", "VND", "VUV", "XAF", "XOF", "XPF"];
    if ($.inArray(currency_code, zero_decimal_currencies) === -1) {
      final_amount = final_amount * 100;
    }
    return final_amount;
  };
  jQuery( /*#__PURE__*/function () {
    var _ref = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee3($) {
      var _window, _window2, _window2$wte_stripe, _wte_stripe;
      var stripe, elements, style, card, mountCard, getBillingDetails, createPaymentIntent, _createPaymentIntent, handleError, handlePaymentButtonClick, _handlePaymentButtonClick, is_stripe, toggleStripeForm, fields;
      return _regeneratorRuntime().wrap(function _callee3$(_context3) {
        while (1) switch (_context3.prev = _context3.next) {
          case 0:
            toggleStripeForm = function _toggleStripeForm() {
              var show = is_stripe();
              $('.wpte-bf-field.wpte-bf-submit > input[name="wp_travel_engine_nw_bkg_submit"]').toggle(!show);
              $("#wte-stripe-payment-form").toggle(show);
            };
            is_stripe = function _is_stripe() {
              var activeGateway = document.querySelector('input[name=wpte_checkout_paymnet_method]:checked');
              return activeGateway && activeGateway.value == 'stripe_payment';
            };
            _handlePaymentButtonClick = function _handlePaymentButtonC2() {
              _handlePaymentButtonClick = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee2(event) {
                var wte_parsley_validate, _yield$elements$submi, submitError, _yield$createPaymentI, clientSecret, _getBillingDetails, name, country, email, city, result, form_id;
                return _regeneratorRuntime().wrap(function _callee2$(_context2) {
                  while (1) switch (_context2.prev = _context2.next) {
                    case 0:
                      event.currentTarget.disabled = true;
                      wte_parsley_validate = $("#wp-travel-engine-new-checkout-form").parsley();
                      if (wte_parsley_validate.isValid()) {
                        _context2.next = 5;
                        break;
                      }
                      event.currentTarget.disabled = false;
                      return _context2.abrupt("return", wte_parsley_validate.validate());
                    case 5:
                      _context2.next = 7;
                      return elements.submit();
                    case 7:
                      _yield$elements$submi = _context2.sent;
                      submitError = _yield$elements$submi.error;
                      if (!submitError) {
                        _context2.next = 13;
                        break;
                      }
                      handleError(submitError);
                      event.currentTarget.disabled = false;
                      return _context2.abrupt("return");
                    case 13:
                      _context2.next = 15;
                      return createPaymentIntent();
                    case 15:
                      _yield$createPaymentI = _context2.sent;
                      clientSecret = _yield$createPaymentI.client_secret;
                      _getBillingDetails = getBillingDetails(), name = _getBillingDetails.name, country = _getBillingDetails.country, email = _getBillingDetails.email, city = _getBillingDetails.city;
                      _context2.next = 20;
                      return stripe.confirmCardPayment(clientSecret, {
                        payment_method: {
                          card: card,
                          billing_details: {
                            address: {
                              city: city
                            },
                            email: email,
                            name: name
                          }
                        }
                      });
                    case 20:
                      result = _context2.sent;
                      $("#card-errors").html("");
                      if (result.error) {
                        // Show error to your customer (e.g., insufficient funds)
                        handleError(result.error);
                        event.currentTarget.disabled = false;
                      } else {
                        // The payment has been processed!
                        if (result.paymentIntent.status === "succeeded") {
                          form_id = "form#wp-travel-engine-new-checkout-form";
                          jQuery("[name=stripeToken]").remove();
                          jQuery(form_id).append(jQuery("<input type='hidden' name='stripeToken' />").attr("value", result.paymentIntent.id));
                          jQuery("[name=stripeTokenType]").remove();
                          jQuery(form_id).append(jQuery("<input type='hidden' name='stripeTokenType' />").attr("value", result.paymentIntent.object));
                          jQuery("[name=stripeEmail]").remove();
                          jQuery(form_id).append(jQuery("<input type='hidden' name='stripeEmail' />").attr("value", result.paymentIntent.receipt_email));
                          jQuery("[name=wte_paypal_express_payment_details]").remove();
                          jQuery(form_id).find('input[name="wp_travel_engine_nw_bkg_submit"]').click();
                          // Show a success message to your customer
                          // There's a risk of the customer closing the window before callback
                          // execution. Set up a webhook or plugin to listen for the
                          // payment_intent.succeeded event that handles any business critical
                          // post-payment actions.
                        }
                      }
                    case 23:
                    case "end":
                      return _context2.stop();
                  }
                }, _callee2);
              }));
              return _handlePaymentButtonClick.apply(this, arguments);
            };
            handlePaymentButtonClick = function _handlePaymentButtonC(_x2) {
              return _handlePaymentButtonClick.apply(this, arguments);
            };
            handleError = function _handleError(error) {
              $("#card-errors").html(error.message);
              console.log(error.message);
              setTimeout(function () {
                $("#card-errors").html('');
              }, 4000);
            };
            _createPaymentIntent = function _createPaymentIntent3() {
              _createPaymentIntent = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
                var amountsByPaymentMode, payment_mode, data, formData;
                return _regeneratorRuntime().wrap(function _callee$(_context) {
                  while (1) switch (_context.prev = _context.next) {
                    case 0:
                      amountsByPaymentMode = {
                        full_payment: Math.round(wte.payments.total),
                        partial: Math.round(wte.payments.total_partial),
                        remaining_payment: Math.round(wte.payments.total) - Math.round(wte.payments.total_partial)
                      };
                      payment_mode = $("input[name=wp_travel_engine_payment_mode]:checked").val();
                      data = {
                        action: "wte_payment_stripe_charge",
                        gateway: $('input[name="wpte_checkout_paymnet_method"]:checked').val(),
                        currency: wte.currency.code,
                        title: 'Trip Booking',
                        description: 'Trip Description',
                        total: amountsByPaymentMode[payment_mode] || amountsByPaymentMode['full_payment']
                      };
                      formData = new FormData();
                      Object.entries(data).forEach(function (_ref2) {
                        var _ref3 = _slicedToArray(_ref2, 2),
                          key = _ref3[0],
                          value = _ref3[1];
                        formData.append(key, value);
                      });
                      _context.next = 7;
                      return fetch(WTEAjaxData.ajaxurl, {
                        method: 'POST',
                        body: formData,
                        crossDomain: true
                      }).then(function (res) {
                        return res.json();
                      });
                    case 7:
                      return _context.abrupt("return", _context.sent);
                    case 8:
                    case "end":
                      return _context.stop();
                  }
                }, _callee);
              }));
              return _createPaymentIntent.apply(this, arguments);
            };
            createPaymentIntent = function _createPaymentIntent2() {
              return _createPaymentIntent.apply(this, arguments);
            };
            getBillingDetails = function _getBillingDetails2() {
              var fullName = [$('input[name="wp_travel_engine_booking_setting[place_order][booking][fname]"]').val(), $('input[name="wp_travel_engine_booking_setting[place_order][booking][lname]"]').val()];
              var email = $('input[name="wp_travel_engine_booking_setting[place_order][booking][email]"]').val();
              var city = $('input[name="wp_travel_engine_booking_setting[place_order][booking][city]"]').val();
              var country = $('input[name="wp_travel_engine_booking_setting[place_order][booking][country]"]').val();
              return {
                country: country,
                name: fullName.join(' '),
                email: email,
                city: city
              };
            };
            mountCard = function _mountCard() {
              // Custom styling can be passed to options when creating an Element.
              // (Note that this demo uses a wider set of styles than the guide below.)
              card.mount("#card-element");
            };
            if (!(!((_window = window) !== null && _window !== void 0 && _window.Stripe) || !((_window2 = window) !== null && _window2 !== void 0 && (_window2$wte_stripe = _window2.wte_stripe) !== null && _window2$wte_stripe !== void 0 && _window2$wte_stripe.publishable_key))) {
              _context3.next = 11;
              break;
            }
            return _context3.abrupt("return");
          case 11:
            stripe = Stripe(wte_stripe.publishable_key);
            elements = stripe.elements();
            style = {
              base: {
                color: "#32325d",
                fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
                fontSmoothing: "antialiased",
                fontSize: "16px",
                "::placeholder": {
                  color: "#aab7c4"
                }
              },
              invalid: {
                color: "#fa755a",
                iconColor: "#fa755a"
              }
            };
            card = elements.create("card", {
              hidePostalCode: ((_wte_stripe = wte_stripe) === null || _wte_stripe === void 0 ? void 0 : _wte_stripe.hide_postal_code) == '1',
              style: style
            });
            /**
             *
             * @param {Event} event
             * @returns
             */
            fields = ['input[name="wpte_checkout_paymnet_method"]', 'input[name="wp_travel_engine_payment_mode"]'];
            window.wte_stripe && window.wte_stripe.publishable_key && mountCard();
            toggleStripeForm();
            $(document).on("change", fields.join(','), toggleStripeForm);
            $(document).on("click", "#wte-stripe-payment-button", handlePaymentButtonClick);
          case 20:
          case "end":
            return _context3.stop();
        }
      }, _callee3);
    }));
    return function (_x) {
      return _ref.apply(this, arguments);
    };
  }());
}
