<?php
/**
 * The admin-specific functionality of the plugin.
 *
 *
 * @package    Wte_stripe_Gateway
 * @subpackage Wte_Wte_Stripe_Gateway/admin
 * @author     codwing <test@test.com>
 */
class Wte_Admin_Settings
{
	function __construct()
	{
		add_action( 'wte_stripe_form', array( $this, 'wte_stripe_form' ) );
    add_action( 'admin_notices', array( $this, 'wte_stripe_gateway_notice' ) );
    add_action( 'admin_init', array( $this,'wte_stripe_gateway_notice_ignore' ) );
		add_action( 'add_meta_boxes', array( $this, 'wpte_stripe_pay_add_meta_boxes' ) );
    add_action( 'save_post', array( $this, 'wp_travel_engine_stripe_pay_meta_box_data' ) );

    // Add filter for the sortable gateway list.
    add_filter( 'wp_travel_engine_available_payment_gateways', array( $this, 'stripe_gateway_list' ) );

    add_filter( 'wpte_settings_get_global_tabs', array( $this, 'stripe_add_settings' ) );
    /**
		 * New booking flow support.
		 *
		 * @since 2.2.0
		 */
		add_filter( 'wptravelengine_payment_gateways', array( $this, 'add_stripe_payment_gateway' ) );

	}

	/**
	* Adding Wte_Stripe Information.
	* @since 1.0
	*/
	function wte_stripe_form()
	{ 
		$wp_travel_engine_settings = get_option('wp_travel_engine_settings', true);
		?>
		<div class="wte-stripe-gateway-form wp-travel-engine-settings">
      <h4><?php _e( 'Stripe Gateway Settings', 'wte-stripe-gateway'); ?></h4>
			<label for="wp_travel_engine_settings[stripe_secret]"><?php _e('Stripe Secret Key : ','wte-stripe-gateway');?> <span class="tooltip" title="Enter a valid Stripe Secret Key. All payments will go to this account."><i class="fas fa-question-circle"></i></span></label> 
			<input type="text" id="wp_travel_engine_settings[stripe_secret]" name="wp_travel_engine_settings[stripe_secret]" value="<?php echo isset($wp_travel_engine_settings['stripe_secret']) ? esc_attr( $wp_travel_engine_settings['stripe_secret'] ): '';?>">

			<label for="wp_travel_engine_settings[stripe_publishable]"><?php _e('Stripe Publishable Key : ','wte-stripe-gateway');?> <span class="tooltip" title="Enter a valid Stripe Publishable Key."><i class="fas fa-question-circle"></i></span></label> 
			<input type="text" id="wp_travel_engine_settings[stripe_publishable]" name="wp_travel_engine_settings[stripe_publishable]" value="<?php echo isset($wp_travel_engine_settings['stripe_publishable']) ? esc_attr( $wp_travel_engine_settings['stripe_publishable'] ): '';?>">

			<label for="wp_travel_engine_settings[stripe_btn_label]"><?php _e('Stripe Pay Button Label : ','wte-stripe-gateway');?> <span class="tooltip" title="Enter the label for the pay button for stripe."><i class="fas fa-question-circle"></i></span></label> 
			<input type="text" id="wp_travel_engine_settings[stripe_btn_label]" name="wp_travel_engine_settings[stripe_btn_label]" value="<?php echo isset($wp_travel_engine_settings['stripe_btn_label']) ? esc_attr( $wp_travel_engine_settings['stripe_btn_label'] ): '';?>">
		</div>
	<?php
	}


  /**
    * Payment Details.
    * @since 1.0
    */
    function wpte_stripe_pay_add_meta_boxes(){
        $screens = array( 'booking' );
        foreach ( $screens as $screen ) {
            add_meta_box(
                'stripepay_id',
                __( 'Stripe Payment Details', 'wte-stripe-gateway' ),
                array($this,'wte_stripe_pay_metabox_callback'),
                $screen,
                'side',
                'high'
            );
        }
    }

    public function stripe_add_settings( $global_tabs ) {

      if ( isset( $global_tabs['wpte-payment'] ) ) {
          $global_tabs['wpte-payment']['sub_tabs']['wte-stripe'] = array(
						'label' => __( 'Stripe Payment', 'wte-stripe-gateway' ),
						'content_path' => plugin_dir_path( WTE_STRIPE_GATEWAY_FILE_PATH ) . 'admin/includes/backend/global-settings.php',
						'current' => false,
					);
      }

      return $global_tabs;
    }

    // Tab for notice listing and settings
    public function wte_stripe_pay_metabox_callback(){
        include WTE_STRIPE_GATEWAY_BASE_PATH.'/admin/includes/backend/stripe-pay.php';
    }

    /**
     * When the post is saved, saves our custom data.
     *
     * @param int $post_id The ID of the post being saved.
     */
    function wp_travel_engine_stripe_pay_meta_box_data( $post_id ) {
        
        /*
         * We need to verify this came from our screen and with proper authorization,
         * because the save_post action can be triggered at other times.
         */
        // Sanitize user input.
        if(isset($_POST['wp_travel_engine_booking_setting']))
        {
            $settings = $_POST['wp_travel_engine_booking_setting'];
            update_post_meta( $post_id, 'wp_travel_engine_booking_setting', $settings );
        }  
    }

    /**
      * Stripe activation notice.
      * @since 1.0
      */
    function wte_stripe_gateway_notice() {
      global $current_user;
      $user_id = $current_user->ID;
      if (get_user_meta($user_id, 'wte-stripe-admin-notice',true)!='true') {
        $link = '<a href="https://stripe.com/" target="_blank">Stripe</a>';
        $wp_travel_engine_settings = get_option( 'wp_travel_engine_settings' );
        $message = sprintf( esc_html__( 'Please put your valid %1$s %2$sSecret key%3$s and %4$sPublishable key%5$s in %6$s WP Travel Engine Settings > Payment > Stripe Secret Key %7$s and %8$s WP Travel Engine Settings > Payment > Stripe Publishable Key %9$s.', 'wte-stripe-gateway' ),  $link, '<strong>', '</strong>','<strong>', '</strong>', '<strong>', '</strong>', '<strong>', '</strong>' );
        printf( '<div class="updated notice"><p>%1$s <a href="?wte-stripe-admin-notice=1">Dismiss</a></p></div>', wp_kses_post( $message ) );
      }
    }

    function wte_stripe_gateway_notice_ignore() {
    
      global $current_user;
      
      $user_id = $current_user->ID;
      
      if (isset($_GET['wte-stripe-admin-notice']) && $_GET['wte-stripe-admin-notice']=='1') {
        add_user_meta($user_id, 'wte-stripe-admin-notice', 'true', true);
      }
    }

    /**
     * Add Stripe to payment gateways list.
     *
     * @param [type] $gateway_list
     * @return void
     */
    public function stripe_gateway_list( $gateway_list ) {

      $gateway_list['stripe_payment'] = array(
        'label'       => __( 'Stripe', 'wte-stripe-gateway' ),
        'input_class' => 'stripe-payment',
        'info_text'   => __( 'Please check this to enable Stripe booking system for trip booking and fill the account info below.', 'wte-stripe-gateway' ),
        'icon_url'    => plugin_dir_url( WTE_STRIPE_GATEWAY_FILE_PATH ) . 'public/includes/images/stripe.png',
        );

      return $gateway_list;

    }

    /**
	 * New booking flow support
	 *
	 * @since 2.2
	 * @param array $payment_gateways list of active payment gateways.
	 * @return array
	 */
	public static function add_stripe_payment_gateway( $payment_gateways ) {
		$payment_gateways['stripe_payment'] = new \WTE_Payment_Gateway_Stripe();
		return $payment_gateways;
	}

  }
  new Wte_Admin_Settings;
