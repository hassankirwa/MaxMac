<?php
global $post;
$wp_travel_engine_postmeta_settings = get_post_meta( $post->ID, 'wp_travel_engine_booking_setting', true );
?>
<div class="trip-info-meta">
	<div>
	<label for="wp_travel_engine_booking_setting[place_order][payment][stripeToken]"><?php _e('Stripe Token: ','wte-stripe-gateway');?></label>	
	<input type="text" id="wp_travel_engine_booking_setting[place_order][payment][stripeToken]" name="wp_travel_engine_booking_setting[place_order][payment][stripeToken]" value="<?php echo isset($wp_travel_engine_postmeta_settings['place_order']['payment']['stripeToken']) ? esc_attr($wp_travel_engine_postmeta_settings['place_order']['payment']['stripeToken']):''?>">
	</div>
	<div>
	<label for="wp_travel_engine_booking_setting[place_order][payment][stripeTokenType]"><?php _e('Token Type: ','wte-stripe-gateway');?></label>	
	<input type="text" id="wp_travel_engine_booking_setting[place_order][payment][stripeTokenType]" name="wp_travel_engine_booking_setting[place_order][payment][stripeTokenType]" value="<?php echo isset($wp_travel_engine_postmeta_settings['place_order']['payment']['stripeTokenType']) ? esc_attr($wp_travel_engine_postmeta_settings['place_order']['payment']['stripeTokenType']):'';?>">
	</div>
	<div>
	<label for="wp_travel_engine_booking_setting[place_order][payment][stripeEmail]"><?php _e('Stripe Email: ','wte-stripe-gateway');?></label>	
	<input type="text" id="wp_travel_engine_booking_setting[place_order][payment][stripeEmail]" name="wp_travel_engine_booking_setting[place_order][payment][stripeEmail]" value="<?php echo isset($wp_travel_engine_postmeta_settings['place_order']['payment']['stripeEmail']) ? esc_attr($wp_travel_engine_postmeta_settings['place_order']['payment']['stripeEmail']):'';?>">
	</div>
</div>