<?php
/**
 * Global Settings
 */
$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', array() );
?>
<div class="wpte-field wpte-text wpte-floated">
    <label for="wp_travel_engine_settings[stripe_secret]" class="wpte-field-label"><?php _e('Stripe Secret Key','wte-stripe-gateway');?></label>
    <input type="text" id="wp_travel_engine_settings[stripe_secret]" name="wp_travel_engine_settings[stripe_secret]" value="<?php echo isset($wp_travel_engine_settings['stripe_secret']) ? esc_attr( $wp_travel_engine_settings['stripe_secret'] ): '';?>">
    <span class="wpte-tooltip"><?php esc_html_e( "Enter a valid Stripe Secret Key. All payments will go to this account.", 'wte-stripe-gateway' ); ?></span>
</div>

<div class="wpte-field wpte-text wpte-floated">
    <label for="wp_travel_engine_settings[stripe_publishable]" class="wpte-field-label"><?php _e('Stripe Publishable Key','wte-stripe-gateway');?></label>
    <input type="text" id="wp_travel_engine_settings[stripe_publishable]" name="wp_travel_engine_settings[stripe_publishable]" value="<?php echo isset($wp_travel_engine_settings['stripe_publishable']) ? esc_attr( $wp_travel_engine_settings['stripe_publishable'] ): '';?>">
    <span class="wpte-tooltip"><?php esc_html_e( "Enter a valid Stripe Publishable Key.", 'wte-stripe-gateway' ); ?></span>
</div>

<div class="wpte-field wpte-text wpte-floated">
    <label for="wp_travel_engine_settings[stripe_btn_label]" class="wpte-field-label"><?php _e('Stripe Pay Button Label','wte-stripe-gateway');?></label>
    <input type="text" id="wp_travel_engine_settings[stripe_btn_label]" name="wp_travel_engine_settings[stripe_btn_label]" value="<?php echo isset($wp_travel_engine_settings['stripe_btn_label']) ? esc_attr( $wp_travel_engine_settings['stripe_btn_label'] ): '';?>">
    <span class="wpte-tooltip"><?php esc_html_e( "Enter the label for the pay button for stripe.", 'wte-stripe-gateway' ); ?></span>
</div>
<?php
$hide_postal_code = isset( $wp_travel_engine_settings['stripe_hide_postal_code'] ) && 'yes' === $wp_travel_engine_settings['stripe_hide_postal_code'];
?>
<div class="wpte-field wpte-checkbox advance-checkbox">
	<label class="wpte-field-label" for="wp_travel_engine_settings[stripe_hide_postal_code]"><?php _e( 'Hide Postal Code', 'wte-stripe-gateway' ); ?></label>
	<div class="wpte-checkbox-wrap">
		<input type="hidden" value="no" name="wp_travel_engine_settings[stripe_hide_postal_code]">
		<input type="checkbox"
            <?php checked( $hide_postal_code, true ); ?>
            id="wp_travel_engine_settings[stripe_hide_postal_code]"
            name="wp_travel_engine_settings[stripe_hide_postal_code]"
            value="yes"/>
		<label for="wp_travel_engine_settings[stripe_hide_postal_code]"></label>
	</div>
	<span class="wpte-tooltip"><?php _e( 'Check this option to hide Postal Code.', 'wte-stripe-gateway' ); ?></span>
</div>
<?php
