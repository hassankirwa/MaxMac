<?php

class Wte_ASPOrder {

	/**
	 * Instance of this class.
	 *
	 * @since    1.0.0
	 *
	 * @var      object
	 */
	protected static $instance = null;

	function __construct()
	{
		$this->Wte_AcceptStripePayments = Wte_AcceptStripePayments::get_instance();
		$this->text_domain = $this->Wte_AcceptStripePayments->get_plugin_slug();
	}

	public function register_post_type()
	{
		$text_domain = $this->Wte_AcceptStripePayments->get_plugin_slug();
		$labels = array(
			'name'                => _x( 'Orders', 'Post Type General Name', 'wte-stripe-gateway' ),
			'singular_name'       => _x( 'Order', 'Post Type Singular Name', 'wte-stripe-gateway' ),
			'menu_name'           => __( 'Wte_Stripe Orders', 'wte-stripe-gateway' ),
			'parent_item_colon'   => __( 'Parent Order:', 'wte-stripe-gateway' ),
			'all_items'           => __( 'All Orders', 'wte-stripe-gateway' ),
			'view_item'           => __( 'View Order', 'wte-stripe-gateway' ),
			'add_new_item'        => __( 'Add New Order', 'wte-stripe-gateway' ),
			'add_new'             => __( 'Add New', 'wte-stripe-gateway' ),
			'edit_item'           => __( 'Edit Order', 'wte-stripe-gateway' ),
			'update_item'         => __( 'Update Order', 'wte-stripe-gateway' ),
			'search_items'        => __( 'Search Order', 'wte-stripe-gateway' ),
			'not_found'           => __( 'Not found', 'wte-stripe-gateway' ),
			'not_found_in_trash'  => __( 'Not found in Trash', 'wte-stripe-gateway' ),
		);
		$args = array(
			'label'               => __( 'orders', 'wte-stripe-gateway' ),
			'description'         => __( 'Wte_Stripe Orders', 'wte-stripe-gateway' ),
			'labels'              => $labels,
			'supports'            => array( 'title', 'editor', 'excerpt', 'revisions', 'custom-fields', ),
			'hierarchical'        => false,
			'public'              => false,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_nav_menus'   => true,
			'show_in_admin_bar'   => true,
			'menu_position'       => 80,
			'menu_icon'           => 'dashicons-clipboard',
			'can_export'          => true,
			'has_archive'         => false,
			'exclude_from_search' => true,
			'publicly_queryable'  => false,
			'capability_type'     => 'post',
			'capabilities' => array(
   				'create_posts' => false, // Removes support for the "Add New" function
  			),
  			'map_meta_cap' => true,
		);

		register_post_type( 'stripe_order', $args );
	}
	
	/**
	 * Return an instance of this class.
	 *
	 * @since     1.0.0
	 *
	 * @return    object    A single instance of this class.
	 */
	public static function get_instance() {

		// If the single instance hasn't been set, set it now.
		if ( null == self::$instance ) {
			self::$instance = new self;
		}

		return self::$instance;
	}
	/**
	 * Receive Response of GetExpressCheckout and ConfirmPayment function returned data.
	 * Returns the order ID.
	 *
	 * @since     1.0.0
	 *
	 * @return    Numeric    Post or Order ID.
	 */
	public function insert($order_details, $charge_details)
	{
		$post = array();
		$post['post_title'] = $order_details['item_quantity'].' '.$order_details['item_name'].' - '.$order_details['item_price'].' '.$order_details['currency_code'];
		$post['post_status'] = 'pending';

		$output = '';

		// Add error info in case of failure
		if( !empty($charge_details->failure_code) ) {

			$output .= "<h2>Payment Failure Details</h2>"."\n";
			$output .= $charge_details->failure_code.": ".$charge_details->failure_message;
			$output .= "\n\n";
		}
		else {
			$post['post_status'] = 'publish';
		}

		$output .= __("<h2>Order Details</h2>", 'wte-stripe-gateway')."\n";
		$output .= __("Order Time: ", 'wte-stripe-gateway').date("F j, Y, g:i a",strtotime('now'))."\n";
		$output .= __("Transaction ID: ", 'wte-stripe-gateway').$charge_details->id."\n";
		$output .= __("Wte_Stripe Token: ", 'wte-stripe-gateway').$order_details['stripeToken']."\n";
                $output .= __("Description: ", 'wte-stripe-gateway').$order_details['charge_description']."\n";
		$output .= "--------------------------------"."\n";
		$output .= __("Product Name: ", 'wte-stripe-gateway').$order_details['item_name']."\n";
		$output .= __("Quantity: ", 'wte-stripe-gateway'). $order_details['item_quantity']."\n";
		$output .= __("Amount: ", 'wte-stripe-gateway'). $order_details['item_price'].' '.$order_details['currency_code']."\n";
		$output .= "--------------------------------"."\n";
		$output .= __("Total Amount: ", 'wte-stripe-gateway'). ($order_details['item_price']*$order_details['item_quantity']).' '.$order_details['currency_code']."\n";

		
		$output .= "\n\n";

		$output .= __("<h2>Customer Details</h2>", 'wte-stripe-gateway')."\n";
		$output .= __("E-Mail Address: ", 'wte-stripe-gateway').$order_details['stripeEmail']."\n";
                
                //Billing address data (if any)
                if(strlen($order_details['billing_address']) > 5){
                    $output .= __("<h2>Billing Address</h2>", 'wte-stripe-gateway')."\n";
                    $output .= $order_details['billing_address'];
                }

                //Shipping address data (if any)
                if(strlen($order_details['shipping_address']) > 5){
                    $output .= __("<h2>Shipping Address</h2>", 'wte-stripe-gateway')."\n";
                    $output .= $order_details['shipping_address'];
                }
                
		$post['post_content'] = $output;
		$post['post_type'] = 'stripe_order';

		return wp_insert_post( $post );//Return post ID
	}

}

