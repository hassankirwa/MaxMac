jQuery(document).ready(function($){
    if ($('.stripe-payment').is( ':checked' )) {
        $('.wte-stripe-gateway-form').fadeIn('slow');
    }
    else{
        $('.wte-stripe-gateway-form').fadeOut('slow');
    }
    $('body').on('click', '.stripe-payment', function (e){ 
        if ($('.stripe-payment').is( ':checked' )) {
            $('.wte-stripe-gateway-form').fadeIn('slow');
        }
        else{
            $('.wte-stripe-gateway-form').fadeOut('slow');
        }
    });
});