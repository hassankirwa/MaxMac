<?php
global $post;
$final_content = trim( preg_replace( '/ +/', ' ', preg_replace( '/[^A-Za-z0-9 ]/', ' ', urldecode( html_entity_decode( strip_tags( $content ) ) ) ) ) );
$sku           = apply_filters( 'wte_trip_schema_sku', "WTE-$post->ID", $post->ID );

$rating_data = wptravelengine_reviews_get_trip_reviews( $post->ID );
?>
<script type="application/ld+json">
{
	"@context": "http://schema.org",
	"@type": "Review",
	"author": {
		"@type": "Person",
		"name": "<?php echo get_the_author_meta( 'user_nicename' ); ?>"
	},
	"itemReviewed": {
		"@type": "Product",
		"image": "<?php echo get_the_post_thumbnail_url( $post->ID ); ?>",
		"name": "<?php echo get_the_title( $post->ID ); ?>",
		"url": "<?php echo get_permalink( $post->ID ); ?>",
		"description": "<?php echo $final_content; ?>",
		"sku": "<?php echo $sku; ?>",
		"brand": {
			"@type": "Thing",
			"name": "<?php echo get_bloginfo( 'name' ); ?>"
		},
		"aggregateRating": {
			"@type": "AggregateRating",
			"ratingValue": "<?php echo $rating_data['average']; ?>",
			"bestRating": "<?php echo $rating_data['bestRating']; ?>",
			"reviewCount": "<?php echo (int) $rating_data['count']; ?>"
		}
	},
	"reviewRating": {
		"@type": "Rating",
		"ratingValue": "<?php echo $rating_data['average']; ?>",
		"bestRating": "<?php echo $rating_data['bestRating']; ?>",
		"worstRating": "<?php echo $rating_data['worstRating']; ?>"
	}
}
</script>
