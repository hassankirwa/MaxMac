<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://wptravelengine.com
 * @since             1.0.0
 * @package           Wte_Currency_Converter
 *
 * @wordpress-plugin
 * Plugin Name:       WP Travel Engine - Currency Converter
 * Plugin URI:        https://wptravelengine.com
 * Description:       An Addon to WP Travel Engine plugin that lets users display and compare trip prices in available currencies or Geolocate.
 * Version:           1.1.6
 * Author:            WP Travel Engine
 * Author URI:        https://wptravelengine.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wte-currency-converter
 * Domain Path:       /languages
 * WTE requires at least: 4.3
 * WTE tested up to: 6.2.2
 * WTE: 30074:wte_currency_converter_license_key
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'WTE_CURRENCY_CONVERTER_VERSION', '1.1.6' );
define( 'WTE_CURRENCY_CONVERTER_ABSPATH', __FILE__ );
define( 'WTE_CURRENCY_CONVERTER_REQUIRES_AT_LEAST', '4.3.0' );
if ( ! defined( 'WTE_CURRENCY_CONVERTER_DIR' ) ) {
	define( 'WTE_CURRENCY_CONVERTER_DIR', dirname( __FILE__ ) . '/' );
}
/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wte-currency-converter-activator.php
 */
function activate_wte_currency_converter() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wte-currency-converter-activator.php';
	Wte_Currency_Converter_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-wte-currency-converter-deactivator.php
 */
function deactivate_wte_currency_converter() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wte-currency-converter-deactivator.php';
	Wte_Currency_Converter_Deactivator::deactivate();
}

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_wte_currency_converter() {

	$plugin = new Wte_Currency_Converter();
	$plugin->run();

}

add_action(
	'plugins_loaded',
	function() {
		if ( ! defined( 'WP_TRAVEL_ENGINE_VERSION' ) || version_compare( WP_TRAVEL_ENGINE_VERSION, WTE_CURRENCY_CONVERTER_REQUIRES_AT_LEAST, '<' ) ) {
			add_action(
				'admin_notices',
				function() {
					echo wp_kses_post(
						sprintf(
							'<div class="error"><p>'
							// translators: 1. WTE Extension Name 2. Link to WTE Plugin.
							. sprintf( __( '%1$s requires the %2$s plugin to work. Please install and activate the latest <strong>WP Travel Engine</strong> plugin first.', 'wte-currency-converter' ), '<strong>WP Travel Engine - Currency Converter</strong>', '<a href="https://wordpress.org/plugins/wp-travel-engine/" target="__blank">WP Travel Engine</a>' )
							. '</p></div>'
						)
					);
				}
			);
		} else {
			register_activation_hook( __FILE__, 'activate_wte_currency_converter' );
			register_deactivation_hook( __FILE__, 'deactivate_wte_currency_converter' );

			/**
			 * The core plugin class that is used to define internationalization,
			 * admin-specific hooks, and public-facing site hooks.
			 */
			require plugin_dir_path( __FILE__ ) . 'includes/class-wte-currency-converter.php';

			run_wte_currency_converter();

		}
	}
);
