<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/admin
 * @author     WP Travel Engine <support@wptravelengine.com>
 */
class Wte_Currency_Converter_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wte_Currency_Converter_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wte_Currency_Converter_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		if ( defined( 'SCRIPT_DEBUG') && true === SCRIPT_DEBUG ) {
			wp_enqueue_style( 
				$this->plugin_name, 
				plugin_dir_url( __FILE__ ) . 'css/wte-currency-converter-admin.css', 
				array(), 
				$this->version, 
				'all' 
			);			
		} else {
			wp_enqueue_style( 
				$this->plugin_name, 
				plugin_dir_url( __FILE__ ) . 'dist/css/wte-currency-converter-admin-' . WTE_CURRENCY_CONVERTER_VERSION . '.min.css', 
				array(), 
				$this->version, 
				'all' 
			);
		}
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wte_Currency_Converter_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wte_Currency_Converter_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		$screen = get_current_screen();
		
		if ( 'booking_page_class-wp-travel-engine-admin' == $screen->id ) {

			if ( defined( 'SCRIPT_DEBUG') && true === SCRIPT_DEBUG ) {
				wp_enqueue_script( 
					$this->plugin_name, 
					plugin_dir_url( __FILE__ ) . 'js/wte-currency-converter-admin.js', 
					array( 'jquery' ), 
					$this->version, 
					false 
				);
			} else {
				wp_enqueue_script( 
					$this->plugin_name, 
					plugin_dir_url( __FILE__ ) . 'dist/js/wte-currency-converter-admin-' . WTE_CURRENCY_CONVERTER_VERSION . '.min.js', 
					array( 'jquery' ), 
					$this->version, 
					false 
				);
			}

			wp_localize_script( 
				$this->plugin_name,
				'wteCc',
				array(
					'currencyCodes' => Wte_Currency_Converter_Helper_Functions::get_instance()->get_currency_codes(),
				)
			);
		}
	}

	/**
	 * Enqueue js templates.
	 *
	 * @return void
	 */
	public function enqueue_js_templates() {
		require_once plugin_dir_path( __FILE__ ) . 'partials/wte-currency-converter-currency-list-template.php';
	}

	/**
	 * This will uninstall this plugin if parent WP Travel plugin not found.
	 * 
	 * @since 1.0.0
	 */
	public function check_dependency() {
		if ( ! class_exists( 'Wp_Travel_Engine' ) || ! $this->meets_requirements() ) {
			echo '<div class="error">';
			echo wp_kses_post( '
				<p>
					<strong>
						WP Travel Engine - Currency Converter 
					</strong> 
					requires the <a href="https://wptravelengine.com" target="__blank">WP Travel Engine</a>
					 <b>version - 4.1.1 or later</b> to work. 
					 Please install and activate the latest WP Travel Engine plugin first. 
					 <b>WP Travel Engine - Currency Converter will now be deactivated now.</b>
				</p>' );
			echo '</div>';

			// Deactivate Plugins.
			deactivate_plugins( plugin_basename( WTE_CURRENCY_CONVERTER_ABSPATH ) );
		}
	}

	/**
	 * Check if all plugin requirements are met.
	 *
	 * @since 1.0.0
	 *
	 * @return bool True if requirements are met, otherwise false.
	 */
	private function meets_requirements() {
		return ( class_exists( 'WP_Travel_Engine' ) && defined( 'WP_TRAVEL_ENGINE_VERSION' ) && version_compare( WP_TRAVEL_ENGINE_VERSION, '4.1.1', '>=' ) );
	}

	/**
	 * Remove all the currency pair transients.
	 * 
	 * @since 1.0.0
	 * @access public
	 * 
	 * @return void
	 */
	public function remove_currency_rate_transients( $old_value, $new_value ) {
		$helper = Wte_Currency_Converter_Helper_Functions::get_instance();
		$helper->purge_transients( 'wte_cc_rate_' );

		if ( ! isset( $_POST['wp_travel_engine_settings']['currency_converter']['api_key'] ) ) {
			$_POST['wp_travel_engine_settings']['currency_converter']['api_key'] = '';
		}
		$api_key = trim( $_POST['wp_travel_engine_settings']['currency_converter']['api_key'] );

		// Check whether the api key is valid or not.
		$api = Wte_Currency_Converter_Api::get_instance();

		if ( ! empty( $api_key ) && ! $api->is_api_key_valid( $api_key ) ) {
			update_option( 'wte_cc_api_key_invalid', true );
		} else {
			update_option( 'wte_cc_api_key_invalid', false );
		}
	}

	/**
	 * Check errors and add notices.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return void
	 */
	public function check_errors() {
		if ( get_option( 'wte_cc_api_key_invalid' ) ) {
			$notice = Wte_Currency_Converter_Notice::get_instance();
			$message = sprintf(
				__( "Invalid Free API Key. If you're a premium user, use the api key on %sPremium%s instead of %sFree%s", 'wte-currency-converter' ),
				'<a href="https://www.currencyconverterapi.com/pricing">',
				'</a>',
				'<a href="https://free.currencyconverterapi.com/free-api-key">',
				'</a>'
			);
			$notice->set_error_message( $message );
		}
	}
}
