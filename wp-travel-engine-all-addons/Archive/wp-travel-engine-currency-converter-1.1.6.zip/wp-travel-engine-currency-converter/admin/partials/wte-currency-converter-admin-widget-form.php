<?php
/**
 * WTE Currency Converter widget form
 */
?>
<p>
    <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>">
        <?php echo esc_html__( 'Title:', 'wte-currency-converter' ); ?>
    </label>
    <input class="widefat" type="text" 
        id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" 
        name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" 
        value="<?php echo esc_attr( $title ); ?>" />
</p>
<?php
