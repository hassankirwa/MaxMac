<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/admin/partials
 */
$helper_functions = Wte_Currency_Converter_Helper_Functions::get_instance();
$settings         = $helper_functions->get_settings();

// Get currency codes and country names.
$currency_codes = $helper_functions->get_currency_codes();

$currency_converter_enabled = $helper_functions->is_currency_converter_enabled();

$show_before_bkg = isset( $settings['show_before_bkg'] ) ? $settings['show_before_bkg'] : 'yes';

$sticky_enable = isset( $settings['sticky_enable'] ) ? $settings['sticky_enable'] : 'no';

$license_type = isset( $settings['key_type'] ) ? $settings['key_type'] : 'free';
?>
<div class="group-status-options" id="wte-currency-converter">

    <div class="wpte-form-block">
        <div class="wpte-field wpte-checkbox advance-checkbox">
            <label class="wpte-field-label" for="wp_travel_engine_settings[currency_converter][enable]"><?php _e( 'Enable Currency Converter', 'wte-currency-converter' ); ?></label>
            <div class="wpte-checkbox-wrap">
                <input type="hidden" name="wp_travel_engine_settings[currency_converter][enable]" value="0">
                <input type="checkbox"
                value="yes"
                <?php checked( $helper_functions->is_currency_converter_enabled(), true ); ?>
                name="wp_travel_engine_settings[currency_converter][enable]"
                class="disable_notif" id="wp_travel_engine_settings[currency_converter][enable]" />
            <label for="wp_travel_engine_settings[currency_converter][enable]" class="checkbox-label"></label>
            </div>
            <span class="wpte-tooltip"><?php _e( 'Check this if you want to enable currency converter functionality in the frontend.', 'wte-currency-converter'); ?></span>
        </div>

        <div class="wpte-field wpte-checkbox advance-checkbox">
            <label class="wpte-field-label" for="wp_travel_engine_settings[currency_converter][sticky_enable]"><?php _e( 'Enable Sticky Currency Switcher', 'wte-currency-converter' ); ?></label>
            <div class="wpte-checkbox-wrap">
                <input type="hidden" name="wp_travel_engine_settings[currency_converter][sticky_enable]" value="no">
                <input type="checkbox"
                value="yes"
                <?php checked( $sticky_enable, 'yes' ); ?>
                name="wp_travel_engine_settings[currency_converter][sticky_enable]"
                class="disable_notif" id="wp_travel_engine_settings[currency_converter][sticky_enable]" />
            <label for="wp_travel_engine_settings[currency_converter][sticky_enable]" class="checkbox-label"></label>
            </div>
            <span class="wpte-tooltip"><?php _e( 'Check this if you want to enable sticky currency converter dropdown in the frontend.', 'wte-currency-converter'); ?></span>
        </div>

        <div class="wpte-field wpte-checkbox advance-checkbox">
            <label class="wpte-field-label" for="wp_travel_engine_settings[currency_converter][show_before_bkg]"><?php _e( 'Show Currency Converter Before Booking Calender', 'wte-currency-converter' ); ?></label>
            <div class="wpte-checkbox-wrap">
                <input type="hidden" name="wp_travel_engine_settings[currency_converter][show_before_bkg]" value="no">
                <input type="checkbox"
                value="yes"
                <?php checked( $show_before_bkg, 'yes' ); ?>
                name="wp_travel_engine_settings[currency_converter][show_before_bkg]"
                class="disable_notif" id="wp_travel_engine_settings[currency_converter][show_before_bkg]" />
            <label for="wp_travel_engine_settings[currency_converter][show_before_bkg]" class="checkbox-label"></label>
            </div>
            <span class="wpte-tooltip"><?php _e( 'Check this if you want to display currency converter dropdown before the booking calender on trip page.', 'wte-currency-converter'); ?></span>
        </div>

        <div class="wpte-field wpte-floated departure-dates-options">
            <label class="wpte-field-label" for="wp_travel_engine_settings[currency_converter][title]">
                <?php _e( 'Currency Converter Title: ', 'wte-currency-converter' ); ?>
            </label>
            <input type="text" class="disable_notif"
                name="wp_travel_engine_settings[currency_converter][title]"
                id="wp_travel_engine_settings[currency_converter][title]"
                value="<?php echo esc_attr( $settings['title'] ); ?> " />
            <span class="wpte-tooltip"><?php _e( 'Title for currency converter.', 'wte-currency-converter' ); ?></span>
        </div>

        <div class="wpte-field wpte-text wpte-floated departure-dates-options">
            <label class="wpte-field-label" for="wp_travel_engine_settings[currency_converter][api_key]">
                <?php _e( 'API Key: ', 'wte-currency-converter' ); ?>
            </label>
            <input type="text" class="disable_notif"
                name="wp_travel_engine_settings[currency_converter][api_key]"
                id="wp_travel_engine_settings[currency_converter][api_key]"
                value="<?php echo esc_attr( $settings['api_key'] ); ?>" />
            <span class="wpte-tooltip"><?php printf(
                    __( 'Get an %sFree API Key%s or %sPremium API Key%s' , 'wte-currency-converter' ),
                    '<a href="https://currencyfreaks.com/" target="_blank" rel="nofollow">',
                    '</a>',
                    '<a href="https://www.currencyconverterapi.com/pricing" target="_blank" rel="nofollow">',
                    '</a>'
                ); ?></span>

        </div>

        <div class="wpte-field wpte-multi-field">
            <div class="wpte-floated">
                <label class="wpte-field-label"><?php esc_html_e( 'License Type', 'wte-currency-converter' ) ?></label>
                <div class="wpte-field wpte-radio wpte-alignleft">
                    <label class="wpte-field-label" for="free"><?php esc_html_e( 'Free', 'wte-currency-converter' ) ?></label>
                    <div class="wpte-radio-wrap">
                        <input type="radio" id="free" value="free" <?php checked( $license_type, 'free' ); ?> name="wp_travel_engine_settings[currency_converter][key_type]" class="currency-converter">
                        <label for="free"></label>
                    </div>
                </div>
                <div class="wpte-field wpte-radio wpte-alignleft">
                    <label class="wpte-field-label" for="premium"><?php esc_html_e( 'Premium', 'wte-currency-converter' ) ?></label>
                    <div class="wpte-radio-wrap">
                        <input type="radio" id="premium" value="premium" name="wp_travel_engine_settings[currency_converter][key_type]" <?php checked( $license_type, 'premium' ); ?> class="currency-converter">
                        <label for="premium"></label>
                    </div>
                </div>
                <span class="wpte-tooltip"><?php esc_html_e( 'Choose either license type is free or premium.', 'wte-currency-converter' ); ?></span>
            </div>
        </div>

        <div class="wpte-title-wrap">
            <h4 class="wpte-title"><?php _e( 'Currencies', 'wte-currency-converter' ); ?></h4>
        </div>
        <div class="group-dates-options">
            <!-- Geo locate -->
            <div class="wpte-field wpte-checkbox advance-checkbox wp-travel-engine-settings">
                <label class="wpte-field-label" for="wp_travel_engine_settings[currency_converter][geo_locate]"><?php _e( 'Geo Locate', 'wte-currency-converter' ); ?></label>
                <div class="wpte-checkbox-wrap">
                    <input type="hidden" name="wp_travel_engine_settings[currency_converter][geo_locate]" value="0">
                    <input type="checkbox"
                        value="yes"
                        <?php checked( $helper_functions->is_geo_locate(), true ); ?>
                        id="wp_travel_engine_settings[currency_converter][geo_locate]"
                        name="wp_travel_engine_settings[currency_converter][geo_locate]" />
                    <label for="wp_travel_engine_settings[currency_converter][geo_locate]"
                        class="checkbox-label"></label>
                </div>
                <span class="wpte-tooltip"><?php _e( 'Check this option to enable geo locate.', 'wte-currency-converter'); ?></span>
            </div>
            <!-- ./ Geo Locate -->

            <!-- Auto update -->
            <div class="wpte-field wpte-checkbox advance-checkbox wp-travel-engine-settings">
                <label class="wpte-field-label" for="wp_travel_engine_settings[currency_converter][auto_update]">
                    <?php _e( 'Auto update rate', 'wte-currency-converter' ); ?></label>
                <div class="wpte-checkbox-wrap">
                    <input type="hidden" name="wp_travel_engine_settings[currency_converter][auto_update]" value="0">
                    <input type="checkbox"
                    value="yes"
                    <?php checked( $helper_functions->is_auto_update(), true ); ?>
                    id="wp_travel_engine_settings[currency_converter][auto_update]"
                    name="wp_travel_engine_settings[currency_converter][auto_update]" />
                    <label for="wp_travel_engine_settings[currency_converter][auto_update]"
                    class="checkbox-label"></label>
                </div>
                <span class="wpte-tooltip"><?php _e( 'Check this option to enable auto rate update ', 'wte-currency-converter'); ?></span>
            </div>
            <!-- ./ Auto Update -->
            <div class="wpte-repeater-wrap" >
            <div id="wte-cc-currency-conversion-list">
            <?php
            foreach( $settings['code'] as $index => $code ) : ?>
                <div class="wte-cc-currency-conversion-item">
                    <select class="wpte-enhanced-select wte-cc-currenctcode-sld" name="wp_travel_engine_settings[currency_converter][code][<?php echo esc_attr( $index ); ?>]">
                        <option value=""><?php _e( 'Select a currency code', 'wte-currency-converter' ); ?></option>
                    <?php foreach( $currency_codes  as $currency_code => $currency ) : ?>
                        <option value="<?php echo esc_attr( $currency_code ); ?>"
                            <?php echo esc_attr( $currency_code === $code ? 'selected' : '' ); ?>>
                            <?php echo esc_html( $currency ); ?>
                        </option>
                    <?php endforeach; ?>
                    </select>

                    <input class="wte-cc-currenctrate-ipt" type="text"
                        name="wp_travel_engine_settings[currency_converter][rate][<?php echo esc_attr( $index ); ?>]"
                        value="<?php echo esc_attr( $settings['rate'][ $index ] ); ?>" />

                    <button type="button" class="button wte-cc-refresh">
                        <i class="fas fa-sync"></i>
                    </button>

                    <button type="button" class="button wte-cc-remove">
                        <i class="fas fa-times-circle"></i>
                    </button>

                    <a class="button wte-cc-move">
                        <i class="fas fa-arrows-alt"></i>
                    </a>
                </div>
            <?php endforeach; ?>
            </div>
            <div class="wpte-add-btn-wrap">
                <button type="button" class="wpte-add-btn"
                    id="wte-cc-add-currency"><?php _e( 'Add Currency', 'wte-currency-converter' ); ?></button>
                <button type="button" class="wpte-update-btn"
                    id="wte-cc-update-all-rates"><?php _e( 'Update all rates', 'wte-currency-converter' ); ?></button>
            </div>
            </div>
        </div>
    </div>
</div>
