<?php
/**
 * Currency list item template.
 */
?>
<script type="text/html" id="tmpl-wte-cc-currency-item">
    <div class="wte-cc-currency-conversion-item">
        <select class="wpte-enhanced-select wte-cc-currenctcode-sld" name="wp_travel_engine_settings[currency_converter][code][{{data.index}}]" width="200px">
            <option value=""><?php _e( 'Select a currency code', 'wte-currency-converter' ); ?></option>
        <# _.each(data.currencyCodes, function(Currency, currencyCode){ #>
            <option value="{{currencyCode}}">{{Currency}}</option>
        <# }); #>
        </select>

        <input class="wte-cc-currenctrate-ipt" type="text" name="wp_travel_engine_settings[currency_converter][rate][{{data.index}}]"
            value="" />

        <button type="button" class="button wte-cc-refresh">
            <i class="fas fa-sync"></i>
        </button>

        <button type="button" class="button wte-cc-remove">
            <i class="fas fa-times-circle"></i>
        </button>
            
        <button type="button" class="button wte-cc-move">
            <i class="fas fa-arrows-alt"></i>
        </button>
    </div>
</script>