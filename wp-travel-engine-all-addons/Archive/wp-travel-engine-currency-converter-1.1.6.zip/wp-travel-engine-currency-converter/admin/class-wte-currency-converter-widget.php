<?php

/**
 * Currency Shortcode
 *
 * @link       https://wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/includes
 */

/**
 * Admin settings.
 *
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/includes
 * @author     WP Travel Engine <support@wptravelengine.com>
 */
class Wte_Currency_Converter_Widget extends WP_Widget {
    /**
     * Widget arguments.
     * 
     * @since 1.0.0
     * @access public
     * 
     * @var array $args Wiget arguments.
     */
    public $args = array(
        'before_title'  => '<h4 class="widgettitle">',
        'after_title'   => '</h4>',
        'before_widget' => '<div class="widget-wrap>',
        'after_widget'  => '</div></div>'
    );

    /**
     * Register widget with WordPress.
     * 
     * @since 1.0.0
     * @access public
     * 
     * @return void
     */
    public function __construct() {
        parent::__construct(
            'wte_ccsadsad',
            __( 'WP Travel Engine: Currency Converter', 'wte-currency-converter' )
        );
        $helper = Wte_Currency_Converter_Helper_Functions::get_instance();
		if ( $helper->is_currency_converter_enabled() ) {
            add_action( 'widgets_init', function() {
                register_widget( 'Wte_Currency_Converter_Widget');
            });
        }
    }

    /**
     * Front-end display of widget.
     *
     * @since 1.0.0
     * @access public
     * 
     * @see WP_Widget::widget()
     *
     * @param array $args     Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget( $args, $instance ) {
        $public = new Wte_Currency_Converter_Public();

        echo $args['before_widget'];

        if ( ! empty ( $instance['title'] ) ) {
            echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
        }

        echo '<div class="textwidget">';

        $public->display_currency_list_alt();

        echo '</div>';

        echo $args['after_widget'];
    }

  /**
     * Back-end widget form.
     *
     * @since 1.0.0
     * @access public
     * 
     * @see WP_Widget::form()
     *
     * @param array $instance Previously saved values from database.
     */
    public function form( $instance ) {
        $title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( '', 'wte-currency-converter' );
        require plugin_dir_path( dirname( __FILE__ ) ) . 'admin/partials/wte-currency-converter-admin-widget-form.php';
    }

    /**
     * Sanitize widget form values as they are saved.
     *
     * @since 1.0.0
     * @access public
     * 
     * @see WP_Widget::update()
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     *
     * @return array Updated safe values to be saved.
     */
    public function update( $new_instance, $old_instance ) {    
        $instance = $old_instance;
        $instance['title'] = ( !empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
 
        return $instance;
    }
}