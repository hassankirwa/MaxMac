<?php

/**
 * Admin settings.
 *
 * @link       https://wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/admin
 */

/**
 * Admin settings.
 *
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/admin
 * @author     WP Travel Engine <support@wptravelengine.com>
 */
class Wte_Currency_Converter_Settings {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 * 
	 * @return void
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

    /**
     * Display settings.
	 * 
	 * @since 1.0.0
	 * @access public
	 * 
	 * @return void Display settings.
	 * 
     */
	public function display_settings($sub_tabs) {
		// $helper_functions = Wte_Currency_Converter_Helper_Functions::get_instance();
		// $settings         = $helper_functions->get_settings();
		
		// // Get currency codes and country names.
		// $currency_codes = $helper_functions->get_currency_codes();
		
		// if ( ! isset ( $settings['title'] ) ) {
		// 	$settings['title'] = '';
		// }

		// if ( empty( $settings['title'] ) ) {
		// 	$settings['title'] = __( 'Currency Converter', 'wte-currency-converter' );
		// }

		// require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/partials/wte-currency-converter-admin-display.php';

		$sub_tabs['wte_currency_converter'] = array(
			'label'        => __( 'Currency Converter', 'wte-currency-converter' ),
			'content_path' => WTE_CURRENCY_CONVERTER_DIR . 'admin/partials/wte-currency-converter-admin-display.php',
			'current'      => false
		);
		return $sub_tabs;
	}
}
