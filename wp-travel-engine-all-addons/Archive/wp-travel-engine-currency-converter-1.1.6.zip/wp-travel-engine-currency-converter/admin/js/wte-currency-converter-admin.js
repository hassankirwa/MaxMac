function wpte_cur_new_Ui(content_key) {
	// Bail if content key is not availibility.
	if( content_key[0] != 'wpte-extensions' ) {
		return;
	}

	jQuery('#wte-cc-currency-conversion-list').sortable({
		handle: '.wte-cc-move'
	});
	jQuery('#wte-cc-currency-conversion-list').disableSelection();
}
jQuery(document).ready(function($){
	wpte_add_action( 'wpte_after_global_settings_tab_shown', 'wpte_cur_new_Ui', 30 );
	/**
	 * All of the code for your admin-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */

	/**
	 * Handle add currency.
	 */
	jQuery(document).on("click","#wte-cc-add-currency",function(event) {
		event.preventDefault();
		var template = wp.template('wte-cc-currency-item');
		var index  = ( 0 < $( '#wte-cc-currency-conversion-list > .wte-cc-currency-conversion-item' ).length ) ? $( '#wte-cc-currency-conversion-list > .wte-cc-currency-conversion-item' ).length + 1 : 1 ;
		jQuery('#wte-cc-currency-conversion-list').append(template({ 
			currencyCodes: wteCc.currencyCodes,
			index: index
		}));
		++index;
		// debugger;
		$( 'select.wpte-enhanced-select' ).select2();
		
		// Make the currency list sortable.
		jQuery('#wte-cc-currency-conversion-list').sortable({
			handle: '.wte-cc-move'
		});
		jQuery('#wte-cc-currency-conversion-list').disableSelection();
	});

	/**
	 * Handle update all rates.
	 */
	jQuery(document).on("click","#wte-cc-update-all-rates",function(event) {
		event.preventDefault();
		var $selects = jQuery('#wte-cc-currency-conversion-list select.wte-cc-currenctcode-sld');
		jQuery.each($selects, function(select){
			setRate(this);
		})
	});

	/**
	 * Get new rates when the currency code is changed.
	 */
	jQuery(document).on('change', 'select.wte-cc-currenctcode-sld', function(event){
		event.preventDefault();
		setRate(this);
	});

	/**
	 * Handle individual rate refresh.
	 */
	jQuery(document).on('click', '#wte-cc-currency-conversion-list .wte-cc-refresh', function(event){
		event.preventDefault();
		jQuery(this).siblings('input.wte-cc-currenctrate-ipt').val('');
		var $select = jQuery(this).siblings('select.wte-cc-currenctcode-sld');
		setRate($select);
	});

	/**
	 * Handle currencies list item removal.
	 */
	jQuery(document).on('click', '#wte-cc-currency-conversion-list .wte-cc-remove', function(event){
		event.preventDefault();
		jQuery(this).parent('.wte-cc-currency-conversion-item').fadeOut(500, function(){
			jQuery(this).remove();
		});
	});

	// Make the currency list sortable.
	jQuery('#wte-cc-currency-conversion-list').sortable({
		handle: '.wte-cc-move'
	});
	jQuery('#wte-cc-currency-conversion-list').disableSelection();

	/**
	 * Set the rate.
	 * 
	 * @param {select} $select Currency code select element.
	 */
	function setRate($select) {
		var currencyCode = jQuery($select).val();
		if ('' == currencyCode) {
			return;
		}

		jQuery($select).siblings('input.wte-cc-currenctrate-ipt').val('');

		jQuery.ajax({
			url: ajaxurl,
			data: { action: 'wte_cc_get_rate', from : '', to : currencyCode }
		}).done( jQuery.proxy(function(data) {
			jQuery(this).siblings('input.wte-cc-currenctrate-ipt').val(data.data.rate);
		}, $select)).fail(jQuery.proxy(function(data){
			jQuery(this).siblings('input.wte-cc-currenctrate-ipt').val(data.responseJSON.data.message);
		}, $select));
	}

	/**
	 * Handle currency converter enable/disable.
	 */
	jQuery('#wte-currency-converter').on('change', 'input[type="checkbox"]', function(event){
		if( true == jQuery(this).prop('checked') )  {
			jQuery(this).val('1');
		} else if ( false == jQuery(this).prop('checked')) {
			jQuery(this).val('0');
		}
	});
});
