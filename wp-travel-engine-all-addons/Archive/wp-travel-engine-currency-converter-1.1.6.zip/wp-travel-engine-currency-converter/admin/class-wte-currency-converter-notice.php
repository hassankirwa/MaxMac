<?php

/**
 * Handle ajax requests.
 *
 * @link       https://wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/admin
 */

/**
 * Handles ajax requests.
 *
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/admin
 * @author     WP Travel Engine <support@wptravelengine.com>
 */
class Wte_Currency_Converter_Notice {

	 /**
     * Instance.
     * 
     * @since 1.0.0
     * @static
     * @access private
     * 
     * @var Wte_Currency_Converter_Notice $_instance Instance.
     */
    private static $_instance = null;

    /**
     * Notices
     * 
     * @since 1.0.0
     * @static
     * @access private
     * 
     * @var array $notices Notices.
     */
    private $notices = array();

    /**
     * Constructor
     * 
     * @since 1.0.0
     * @access private
     * 
     * @return void
     */
    private function __construct() {     
        $this->init_hooks();   
    }

    /**
     * Get instance.
     * 
     * @since 1.0.0
     * @static
     * @access public
     *
     * @return Wte_Currency_Converter_Ajax Instance.
     */
    public static function get_instance() {
        if ( null === self::$_instance ) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }

	/**
	 * Initialization.
	 *
     * @since 1.0.0
     * @access private
     * 
	 * @return void
	 */
	private function init(){
		$this->init_hooks();
	}

	/**
	 * Initialize hooks.
	 *
     * @since 1.0.0
     * @access private
     * 
	 * @return void
	 */
	private function init_hooks() {
        add_action( 'admin_notices', array( $this, 'display_notices' ) );
    }

    /**
     * Display notices.
     *
     * @since 1.0.0
     * @access public
     * 
     * @return void
     */
    public function display_notices() {
        if ( empty( $this->notices ) ) {
            return;
        }

        $html_notice = '';
        foreach( $this->notices as $notice ) {
            $dismissible = '';
            if( true === $notice['dismissible'] ) {
                $dismissible = ' is-dismissible';                
            }

            $html_notice .= "<div class=\"notice notice-{$notice['type']}{$dismissible}\">";
            $html_notice .= "<p><strong>WTE Currency Converter: </strong>{$notice['message']}</p>";

            if ( true === $notice['dismissible'] ) {
                $html_notice .= '<button type="button" class="notice-dismiss">';
		        $html_notice .= '<span class="screen-reader-text">' . __( 'Dismiss this notice.', 'wte-currency-converter' ) . '</span>';
	            $html_notice .= '</button>';
            }
            
            $html_notice .= '</div>';
        }

        echo $html_notice;
    }

    /**
     * Set the notices.
     *
     * @since 1.0.0
     * @access public
     * 
     * @param string $type Notice type.
     * @param string $message Notice message.
     * @param boolean $dismissible Notice dismisable.
     * 
     * @return void
     */
    public function set_message( $type = 'error', $message = '', $dismissible = true ) {
        $notice = array(
            'type'        => $type,
            'message'     => $message,
            'dismissible' => $dismissible
        );

        $messages = wp_list_pluck( $this->notices, 'message' );

        if ( ! in_array( $message, $messages ) ) {
            array_push( $this->notices, $notice );
        }

    }

    /**
     * Set error notices.
     *
     * @since 1.0.0
     * @access public
     * 
     * @param string $message Notice message.
     * @param boolean $dismissible Notice dismissible.
     * 
     * @return void
     */
    public function set_error_message( $message = '', $dismissible = true ) {
        $this->set_message( 'error', $message, $dismissible );
    }

    /**
     * Set warning notices.
     *
     * @since 1.0.0
     * @access public
     * 
     * @param string $message Notice message.
     * @param boolean $dismissible Notice dismissible.
     * 
     * @return void
     */
    public function set_warning_message( $message = '', $dismissible = true ) {
        $this->set_message( 'warning', $message, $dismissible );
    }

    /**
     * Set success notices.
     *
     * @since 1.0.0
     * @access public
     * 
     * @param string $message Notice message.
     * @param boolean $dismissible Notice dismissible.
     * 
     * @return void
     */
    public function set_success_message( $message = '', $dismissible = true ) {
        $this->set_message( 'success', $message, $dismissible );
    }

    /**
     * Set info notices.
     *
     * @since 1.0.0
     * @access public
     * 
     * @param string $message Notice message.
     * @param boolean $dismissible Notice dismissible.
     * 
     * @return void
     */
    public function set_info_message( $message = '', $dismissible = true ) {
        $this->set_message( 'info', $message, $dismissible );
    }

    /**
     * Get notices
     * 
     * @since 1.0.0
     * @access public
     *
     * @return void
     */
    public function get_notices() {
        return $this->notices;
    }
}