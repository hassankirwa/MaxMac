<?php

/**
 * Handle ajax requests.
 *
 * @link       https://wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/admin
 */

/**
 * Handles ajax requests.
 *
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/admin
 * @author     WP Travel Engine <support@wptravelengine.com>
 */
class Wte_Currency_Converter_Ajax {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		
		$this->init();
	}

	/**
	 * Initialization.
	 *
	 * @return void
	 */
	private function init(){
		$this->init_hooks();
	}

	/**
	 * Initialize hooks.
	 *
	 * @return void
	 */
	private function init_hooks() {
		add_action( 'wp_ajax_wte_cc_get_rate', array( $this, 'get_rate' ) );
		add_action( 'wp_ajax_nopriv_wte_cc_get_rate', array( $this, 'get_rate' ) );
	}

	/**
	 * Get rate.
	 */
	public function get_rate() {
		$helper_functions = Wte_Currency_Converter_Helper_Functions::get_instance();
		$api  = Wte_Currency_Converter_Api::get_instance();

		if ( ! isset( $_REQUEST['from'] ) || empty( $_REQUEST['from'] ) ) {
			$_REQUEST['from'] = wp_travel_engine_get_currency_code();
		}

		if ( ! isset( $_REQUEST['from'] ) ) {
			wp_send_json_error(array(
				'message' => 'To currency is required.'
			), 400);
			exit;
		}

		if ( ! $helper_functions->is_valid_currency_code( $_REQUEST['from'] ) ) {
			wp_send_json_error(array(
				'message' => 'Invalid from currency code.'
			), 400);
			exit;
		}

		if ( ! $helper_functions->is_valid_currency_code( $_REQUEST['to'] ) ) {
			wp_send_json_error(array(
				'message' => 'Invalid to currency code.'
			), 400);
			exit;
		}

		$rate = $api->get_rate( $_REQUEST['from'], $_REQUEST['to'] );

		if ( false === $rate ) {
			wp_send_json_error( array(
				'message' => 'Failed to obtain the rate.'
			), 400 );
		}

		wp_send_json_success( array(
			'from' => $_REQUEST['from'],
			'to'   => $_REQUEST['to'],
			'rate' => $rate,
		) );
	}
}