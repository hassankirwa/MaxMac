<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/public/partials
 */
?>
<div class="wte-currency-switcher-drpdown">
    <select class="wte-cc-currency-list-display lp-bf-altd">
    <?php foreach( $currencies['code'] as $index => $code ) : 
        $symbol   = wp_travel_engine_get_currency_symbol( $code );
        $obj      = new Wp_Travel_Engine_Functions();
        $currency = $obj->wp_travel_engine_currencies();
        $cur_name = isset( $currency[$code] ) ? $currency[$code] : '';
        ?>
        <option data-display="<?php echo esc_html( $symbol ) . ' ' . esc_html( $code ); ?>" value="<?php echo esc_attr( $code ); ?>"
            <?php echo esc_attr( $default_code === $code ? 'selected' : '' ); ?> >
                <?php echo esc_html( $symbol ) . ' ' . esc_html( $code ) . '  ' . esc_html( $cur_name );?>
        </option>
    <?php endforeach; ?>
    </select>
</div>