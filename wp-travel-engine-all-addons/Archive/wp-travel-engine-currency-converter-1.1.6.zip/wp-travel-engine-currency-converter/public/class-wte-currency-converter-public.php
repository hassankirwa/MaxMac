<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/public
 * @author     WP Travel Engine <support@wptravelengine.com>
 */
class Wte_Currency_Converter_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @access public
	 *
	 * @param      string $plugin_name       The name of the plugin.
	 * @param      string $version    The version of this plugin.
	 *
	 * @return void
	 */

	public function __construct( $plugin_name = '', $version = '' ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wte_Currency_Converter_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wte_Currency_Converter_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( 'nice-select', plugin_dir_url( __FILE__ ) . 'css/nice-select.css', array(), '1.0.0', 'all' );

		if ( defined( 'SCRIPT_DEBUG' ) && true === SCRIPT_DEBUG ) {
			wp_enqueue_style(
				$this->plugin_name,
				plugin_dir_url( __FILE__ ) . 'css/wte-currency-converter-public.css',
				array(),
				$this->version,
				'all'
			);
		} else {
			wp_enqueue_style(
				$this->plugin_name,
				plugin_dir_url( __FILE__ ) . 'dist/css/wte-currency-converter-public-' . WTE_CURRENCY_CONVERTER_VERSION . '.min.css',
				array(),
				$this->version,
				'all'
			);
		}

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wte_Currency_Converter_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wte_Currency_Converter_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_script( 'jquery-nice-select', plugin_dir_url( __FILE__ ) . 'js/jquery.nice-select.min.js', array( 'jquery' ), '1.0.0', true );

		if ( defined( 'SCRIPT_DEBUG' ) && true === SCRIPT_DEBUG ) {
			wp_enqueue_script(
				$this->plugin_name,
				plugin_dir_url( __FILE__ ) . 'js/wte-currency-converter-public.js',
				array( 'jquery', 'jquery-nice-select' ),
				$this->version,
				false
			);
		} else {
			wp_enqueue_script(
				$this->plugin_name,
				plugin_dir_url( __FILE__ ) . 'dist/js/wte-currency-converter-public-' . WTE_CURRENCY_CONVERTER_VERSION . '.min.js',
				array( 'jquery', 'jquery-nice-select' ),
				$this->version,
				false
			);
		}

		wp_localize_script(
			$this->plugin_name,
			'wteCc',
			Wte_Currency_Converter_Helper_Functions::get_instance()->get_settings()
		);

		if ( ! wp_travel_engine_is_checkout_page() ) {

			$api               = Wte_Currency_Converter_Api::get_instance();
			$base_code         = wte_currency_code_in_db();
			$helper            = Wte_Currency_Converter_Helper_Functions::get_instance();
			$geo_currency_code = $helper->get_geo_currency_code();
			$to_code           = isset( $_COOKIE['cc_code'] ) ? $_COOKIE['cc_code'] : ( isset( $geo_currency_code ) ? $geo_currency_code : $base_code );
			$rate              = $api->get_rate( $base_code, $to_code );
			$reverse_rate      = $api->get_rate( $to_code, $base_code );

			wp_localize_script(
				$this->plugin_name,
				'WTE_CC_convData',
				array(
					'base'         => $base_code,
					'to'           => $to_code,
					'rate'         => $rate,
					'reverse_rate' => $reverse_rate,
				)
			);
		}
	}

	/**
	 * Display currency list.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function display_currency_list() {
		$helper = Wte_Currency_Converter_Helper_Functions::get_instance();
		$api    = Wte_Currency_Converter_Api::get_instance();

		$currencies = $helper->get_currency_converter_list();

		// Get default currency code.
		$default_code = wp_travel_engine_get_currency_code();

		// If the currency stored in the database is not in the
		// currency converter list, append it as well.
		$code_in_db = wte_currency_code_in_db();

		// If the default code is not set in the currencies code, set it.
		if ( ! in_array( $default_code, $currencies['code'] ) ) {
			$currencies['code'][] = $default_code;
			$currencies['rate'][] = $api->get_rate( $code_in_db, $default_code );
		}

		if ( ! in_array( $code_in_db, $currencies['code'] ) ) {
			$currencies['code'][] = $code_in_db;
			$currencies['rate'][] = '1';
		}

		// Add geo located currency code.
		if ( $helper->is_geo_locate() ) {
			$geo_currency_code = $helper->get_geo_currency_code();
			if ( null !== $geo_currency_code && ! in_array( $geo_currency_code, $currencies['code'] ) ) {
				$currencies['code'][] = $geo_currency_code;
				$currencies['rate'][] = $api->get_rate( $code_in_db, $geo_currency_code );
			}
		}

		$template = plugin_dir_path( __FILE__ ) . 'partials/wte-currency-converter-public-display.php';

		$template = apply_filters( 'wte_cc_display_list', $template );

		require $template;
	}

	/**
	 * Display currency list.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function display_currency_list_alt() {
		$helper = Wte_Currency_Converter_Helper_Functions::get_instance();
		$api    = Wte_Currency_Converter_Api::get_instance();

		$currencies = $helper->get_currency_converter_list();

		// Get default currency code.
		$default_code = wp_travel_engine_get_currency_code();

		// If the currency stored in the database is not in the
		// currency converter list, append it as well.
		$code_in_db = wte_currency_code_in_db();

		// If the default code is not set in the currencies code, set it.
		if ( ! in_array( $default_code, $currencies['code'] ) ) {
			$currencies['code'][] = $default_code;
			$currencies['rate'][] = $api->get_rate( $code_in_db, $default_code );
		}

		if ( ! in_array( $code_in_db, $currencies['code'] ) ) {
			$currencies['code'][] = $code_in_db;
			$currencies['rate'][] = '1';
		}

		// Add geo located currency code.
		if ( $helper->is_geo_locate() ) {
			$geo_currency_code = $helper->get_geo_currency_code();
			if ( null !== $geo_currency_code && ! in_array( $geo_currency_code, $currencies['code'] ) ) {
				$currencies['code'][] = $geo_currency_code;
				$currencies['rate'][] = $api->get_rate( $code_in_db, $geo_currency_code );
			}
		}

		$template = plugin_dir_path( __FILE__ ) . 'partials/wte-currency-converter-public-display-alt.php';

		$template = apply_filters( 'wte_cc_display_list', $template );

		require $template;
	}

	/**
	 * Sticky currency converter.
	 *
	 * @return void
	 */
	public function sticky_currency_switcher() {

		if ( wp_travel_engine_is_checkout_page() || wp_travel_engine_is_dashboard_page() || wp_travel_engine_is_thank_you_page() ) {
			return;
		}

		$helper = Wte_Currency_Converter_Helper_Functions::get_instance();
		$api    = Wte_Currency_Converter_Api::get_instance();

		$currencies = $helper->get_currency_converter_list();

		// Get default currency code.
		$default_code = wp_travel_engine_get_currency_code();

		// If the currency stored in the database is not in the
		// currency converter list, append it as well.
		$code_in_db = wte_currency_code_in_db();

		// If the default code is not set in the currencies code, set it.
		if ( ! in_array( $default_code, $currencies['code'] ) ) {
			$currencies['code'][] = $default_code;
			$currencies['rate'][] = $api->get_rate( $code_in_db, $default_code );
		}

		if ( ! in_array( $code_in_db, $currencies['code'] ) ) {
			$currencies['code'][] = $code_in_db;
			$currencies['rate'][] = '1';
		}

		// Add geo located currency code.
		if ( $helper->is_geo_locate() ) {
			$geo_currency_code = $helper->get_geo_currency_code();
			if ( null !== $geo_currency_code && ! in_array( $geo_currency_code, $currencies['code'] ) ) {
				$currencies['code'][] = $geo_currency_code;
				$currencies['rate'][] = $api->get_rate( $code_in_db, $geo_currency_code );
			}
		}

		$template = plugin_dir_path( __FILE__ ) . 'partials/wte-currency-converter-public-display.php';
		$template = apply_filters( 'wte_cc_display_list', $template );

		require $template;
	}

	/**
	 * add body class
	 *
	 * @param [type] $body_class
	 * @return void
	 */
	public function add_sticky_class( $body_class ) {
		return array_merge( $body_class, array( 'wpte-cc-sticky-converter' ) );
	}
	/**
	 * Change the default currency code.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param string $code Currency code.
	 *
	 * @return string Modified currency code.
	 */
	public function change_default_currency_code( $code, $use_default_currency_code ) {

		global $post;
		$currency_code_in_db = wte_currency_code_in_db();

		if ( $use_default_currency_code ) {
			return $currency_code_in_db;
		}

		$helper   = Wte_Currency_Converter_Helper_Functions::get_instance();
		$settings = get_option( 'wp_travel_engine_settings', array() );

		if ( wp_doing_ajax() && isset( $_REQUEST['action'] ) && 'filter_departure_dates' === $_REQUEST['action'] ) {
			return ( isset( $_COOKIE['cc_code'] ) && ! empty( $_COOKIE['cc_code'] ) ) ? $_COOKIE['cc_code'] : '';
		}

		if ( wp_doing_ajax() && isset( $_REQUEST['action'] ) && 'wte_show_ajax_result' === $_REQUEST['action'] ) {
			return ( isset( $_COOKIE['cc_code'] ) && ! empty( $_COOKIE['cc_code'] ) ) ? $_COOKIE['cc_code'] : '';
		}

		// Bail early if is is requested in admin.
		if ( is_admin() ) {
			return $code;
		}

		// if ( wp_travel_engine_is_dashboard_page() || wp_travel_engine_is_account_page()) {
		// return $code;
		// }

		// if ( wp_travel_engine_post_content_has_shortcode( 'wp_travel_engine_dashboard' )) {
		// return $code;
		// }

		if ( isset( $_COOKIE['cc_code'] ) && ! empty( $_COOKIE['cc_code'] ) ) {
			return $_COOKIE['cc_code'];
		}

		// Check for geo locate.
		if ( $helper->is_geo_locate() ) {
			$geo_currency_code = $helper->get_geo_currency_code();
			if ( null !== $geo_currency_code ) {
				return $geo_currency_code;
			}
		}

		return $code;
	}

	/**
	 * Convert the price.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param double $price Price.
	 * @param int    $trip_id Trip id.
	 *
	 * @return double Modified sale price
	 */
	public function convert_price( $price, $trip_id ) {
		global $post;

		$helper   = Wte_Currency_Converter_Helper_Functions::get_instance();
		$settings = get_option( 'wp_travel_engine_settings' );

		// Bail early if the regular price is empty.
		if ( empty( $price ) ) {
			return $price;
		}

		if ( wp_travel_engine_is_checkout_page() || wp_travel_engine_is_dashboard_page() ) {
			return $price;
		}

		if ( wp_travel_engine_is_account_page() ) {
			return $price;
		}

		// Get the currency stored in db.
		$currency_code_in_db = wte_currency_code_in_db();

		$currency_code = wp_travel_engine_get_currency_code();

		// Bail early if the currency converter cookie is not set.
		if ( ! isset( $_COOKIE['cc_code'] ) && ! $helper->is_geo_locate() ) {
			return $price;
		} elseif ( $helper->is_geo_locate() && ! isset( $_COOKIE['cc_code'] ) ) {
			$currency_code = $helper->get_geo_currency_code();
		} elseif ( isset( $_COOKIE['cc_code'] ) ) {
			$currency_code = $_COOKIE['cc_code'];
		}

		// Return the currency code stored in the db in the checkout page.
		if ( isset( $settings['pages']['wp_travel_engine_place_order'] )
			&& is_page( $settings['pages']['wp_travel_engine_place_order'] ) ) {
			$currency_code_in_db = $currency_code;
			$currency_code       = wte_currency_code_in_db();
		}

		// Return the price as it is in the Thank you page.
		if ( isset( $settings['pages']['wp_travel_engine_thank_you'] )
			&& is_page( $settings['pages']['wp_travel_engine_thank_you'] ) ) {
			return $price;
		}

		// Return the price as it is in the User Dashboard you page.
		if ( isset( $settings['pages']['wp_travel_engine_dashboard_page'] )
			&& is_page( $settings['pages']['wp_travel_engine_dashboard_page'] ) ) {
			return $price;
		}

		// Bail early if the current code in db is same as to the currency code
		// in use.
		if ( $currency_code_in_db === $currency_code ) {
			return $price;
		}

		// Convert the sale price.
		$currencies = $helper->get_currency_converter_list();

		if ( is_array( $price ) ) {
			$new_price = array_map(
				function( $p ) use ( $helper, $currency_code_in_db, $currency_code ) {
					return round( $helper->get_price( $currency_code_in_db, $currency_code, $p ) );
				},
				$price
			);
		} else {
			$new_price = round( $helper->get_price( $currency_code_in_db, $currency_code, $price ) );
		}

		return $new_price;
	}

	/**
	 * Change the group discount in localize.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param int $group Group discount.
	 * @param int $trip_id Trip ID.
	 * @return void
	 */
	public function group_discount_change_price_before_localize( $group, $trip_id ) {
		$helper              = Wte_Currency_Converter_Helper_Functions::get_instance();
		$currency_code_in_db = wte_currency_code_in_db();
		$currency_code       = wp_travel_engine_get_currency_code();

		if ( isset( $group['cost'] ) ) {
			$group['cost'] = array_map(
				function( $cost ) use ( $helper, $currency_code_in_db, $currency_code ) {
					return round( $helper->get_price( $currency_code_in_db, $currency_code, $cost ) );
				},
				$group['cost']
			);
		}

		if ( isset( $group['child_cost'] ) ) {
			$group['child_cost'] = array_map(
				function( $cost ) use ( $helper, $currency_code_in_db, $currency_code ) {
					return round( $helper->get_price( $currency_code_in_db, $currency_code, $cost ) );
				},
				$group['child_cost']
			);
		}

		if ( isset( $group['infant_cost'] ) ) {
			$group['infant_cost'] = array_map(
				function( $cost ) use ( $helper, $currency_code_in_db, $currency_code ) {
					return round( $helper->get_price( $currency_code_in_db, $currency_code, $cost ) );
				},
				$group['infant_cost']
			);
		}

		return $group;
	}

	/**
	 * Modify the cart after the items is added in the cart.
	 *
	 * @param int    $trip_id                  Trip id or cart item id.
	 * @param double $trip_price            Trip Price
	 * @param double $trip_price_partial    Trip partial price.
	 * @param array  $pax                    Person.
	 * @param string $price_key             Price key
	 * @param string $attrs                 Extra attributes.
	 * @return void
	 */
	public function modify_price_in_cart( $trip_id, $trip_price, $trip_price_partial, $pax, $price_key, $attrs ) {
		global $wte_cart;
		$helper = Wte_Currency_Converter_Helper_Functions::get_instance();

		$currency_code_in_db = wte_currency_code_in_db();

		if ( isset( $_COOKIE['cc_code'] ) ) {
			$currency_code_in_cookie = $_COOKIE['cc_code'];
		} elseif ( $helper->is_geo_locate() ) {
			$currency_code_in_cookie = $helper->get_geo_currency_code();
		} else {
			$currency_code_in_cookie = $currency_code_in_db;
		}

		if ( $currency_code_in_cookie === $currency_code_in_db ) {
			return;
		}

		$cart_items = $wte_cart->getItems();

		foreach ( $cart_items as $cart_item_id => $cart_item ) {

			if ( isset( $cart_item['trip_price'] ) ) {
				$trip_price = $helper->get_price( $currency_code_in_cookie, $currency_code_in_db, $cart_item['trip_price'] );
				$trip_price = round( $trip_price );
			}

			if ( isset( $cart_item['trip_price_partial'] ) ) {
				$trip_price_partial = $helper->get_price( $currency_code_in_cookie, $currency_code_in_db, $cart_item['trip_price_partial'] );
				$trip_price_partial = round( $trip_price_partial );
			}

			if ( isset( $cart_item['pax_cost'] ) ) {
				$attrs = $cart_item;
				unset( $attrs['trip_id'] );
				unset( $attrs['trip_price'] );
				unset( $attrs['trip_price_partial'] );

				foreach ( $cart_item['pax_cost'] as $key => $pax_cost ) {
					$attrs['pax_cost'][ $key ] = $helper->get_price( $currency_code_in_cookie, $currency_code_in_db, $pax_cost );
					$attrs['pax_cost'][ $key ] = round( $attrs['pax_cost'][ $key ] );
				}
			}

			if ( isset( $cart_item['trip_extras'] ) ) {
				foreach ( $cart_item['trip_extras'] as $key => $trip_extra ) {
					$trip_extra['price']          = $helper->get_price( $currency_code_in_cookie, $currency_code_in_db, $trip_extra['price'] );
					$trip_extra['price']          = round( $trip_extra['price'] );
					$attrs['trip_extras'][ $key ] = $trip_extra;
				}
			}

			$wte_cart->add( $cart_item_id, $trip_price, $trip_price_partial, array(), '', $attrs );
		}
	}

	/**
	 * Modify the extra services cost.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $extra_services Extra services cost.
	 * @param int   $booking_id Booking Id.
	 * @return array Modifiec extra services cost.
	 */
	public function modify_extra_services_cost( $extra_services, $booking_id ) {
		$helper = Wte_Currency_Converter_Helper_Functions::get_instance();

		if ( ! isset( $extra_services['extra_service_cost'] ) ) {
			return $extra_services;
		}

		// Get the currency stored in db.
		$currency_code_in_db = wte_currency_code_in_db();

		$currency_code = wp_travel_engine_get_currency_code();

		// Bail early if the currency converter cookie is not set.
		if ( ! isset( $_COOKIE['cc_code'] ) && ! $helper->is_geo_locate() ) {
			return $extra_services;
		} elseif ( $helper->is_geo_locate() && ! isset( $_COOKIE['cc_code'] ) ) {
			$currency_code = $helper->get_geo_currency_code();
		} elseif ( isset( $_COOKIE['cc_code'] ) ) {
			$currency_code = $_COOKIE['cc_code'];
		}

		// Bail early if the current code in db is same as to the currency code
		// in use.
		if ( $currency_code_in_db === $currency_code ) {
			return $extra_services;
		}

		// Convert the sale price.
		$currencies = $helper->get_currency_converter_list();

		$extra_services['extra_service_cost'] = array_map(
			function( $p ) use ( $helper, $currency_code_in_db, $currency_code ) {
				return round( $helper->get_price( $currency_code, $currency_code_in_db, $p ) );
			},
			$extra_services['extra_service_cost']
		);

		return $extra_services;
	}

	/**
	 * Return cc code back from db.
	 *
	 * @return void
	 */
	function cc_code_supported() {
		if ( wp_travel_engine_is_checkout_page() || wp_travel_engine_is_dashboard_page() ) {
			return false;
		}

		return true;

	}

	public function wte_price_cost_reverse_callback( $price ) {
		$api          = Wte_Currency_Converter_Api::get_instance();
		$base_code    = wte_currency_code_in_db();
		$to_code      = isset( $_COOKIE['cc_code'] ) ? $_COOKIE['cc_code'] : $base_code;
		$reverse_rate = $api->get_rate( $to_code, $base_code );

		return round( $price * $reverse_rate );
	}
}
