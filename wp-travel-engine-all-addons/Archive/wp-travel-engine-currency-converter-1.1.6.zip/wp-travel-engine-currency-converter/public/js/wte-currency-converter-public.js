jQuery(document).ready(function () {
  /**
   * All of the code for your public-facing JavaScript source
   * should reside in this file.
   *
   * Note: It has been assumed you will write jQuery code here, so the
   * $ function reference has been prepared for usage within the scope
   * of this function.
   *
   * This enables you to define handlers, for when the DOM is ready:
   *
   * $(function() {
   *
   * });
   *
   * When the window is loaded:
   *
   * $( window ).load(function() {
   *
   * });
   *
   * ...and/or other possibilities.
   *
   * Ideally, it is not considered best practise to attach more than a
   * single DOM-ready or window-load handler for a particular page.
   * Although scripts in the WordPress core, Plugins and Themes may be
   * practising this, we should strive to set a better example in our own work.
   */

  jQuery(".wte-cc-currency-list-display").niceSelect();

  // jQuery('.wte-cc-currency-list-display-alt').niceSelect();

  jQuery(".wte-cc-currency-list-display").change(function (event) {
    var currencyCode = jQuery(this).val();
    var cookieName = "cc_code";

    setCookie(cookieName, currencyCode, null);

    // Construct URLSearchParams object instance from current URL querystring.
    var queryParams = new URLSearchParams(window.location.search);

    // Set new or modify existing parameter value.
    queryParams.set("wte_cc", currencyCode);

    // Replace current querystring with the new one.
    history.replaceState(null, null, "?" + queryParams.toString());

    location.reload();
  });

  /**
   *
   * @param {string} name 		Cookie name.
   * @param {string} value		Cookie value.
   * @param {string} expireDays 	Cookie expire days.
   */
  function setCookie(name, value, expireDays) {
    var d = new Date();

    if (null !== expireDays) {
      d.setTime(d.getTime() + expireDays * 24 * 60 * 60 * 1000);
      var expireDays = "expires=" + d.toUTCString();
      document.cookie = name + "=" + value + ";" + expireDays + ";path=/";
    } else {
      document.cookie = name + "=" + value + ";path=/";
    }
  }

  /**
   * Get a cookie value.
   *
   * @param {string} name Cookdie name.
   */
  function getCookie(name) {
    var name = name + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(";");
    for (var i = 0; i < ca.length; i++) {
      var c = ca[i];

      while (c.charAt(0) == " ") {
        c = c.substring(1);
      }

      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }

  /**
   * Check whether the cookie is set or not.
   *
   * @param {string} name Cookie name.
   * @return boolean
   */
  function checkCookie(name) {
    var value = getCookie(name);
    if (value != "") {
      return true;
    } else {
      return false;
    }
  }
});
