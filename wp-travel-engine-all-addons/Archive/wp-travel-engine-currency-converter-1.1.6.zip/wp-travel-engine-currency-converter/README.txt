=== WP Travel Engine - Currency Converter ===
Contributors: wptravelengine
Plugin link: https://wptravelengine.com/
Tags: tour-booking, tour-operator, travel, travel-booking, travel-agency
Requires at least: 4.4.0
Tested up to: 6.2.2
Requires PHP: 5.6
Stable tag: 1.1.6
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Currency Converter lets users display and compare trip prices in available currencies or Geolocate.

== Description ==

Currency Converter is an extension for WP Travel Engine that lets you convert the trip price between multiple currencies. You can add multiple currencies of your choice and let your customers have an easy conversion of currencies and display of prices.

== Changelog ==

= 1.1.6 =
Released on: 20th September 2023
* Fix - Error on api key missing.

= 1.1.5 =
Released on: 29th June 2023
* Fixes - Currency converter issue on geo locate enable.

= 1.1.4 =
Released on: 4th January 2023
* Enhancement - Updated API Key URL
* Fixes - Minor bug fixes

= 1.1.3 =

Released on: 3rd June 2021
* Enhancement - Compatibility Update for WP Travel Engine 5.0.0.
* Fixes - Minor Bug Fixes.

= 1.1.2 =

Released on: 17th May 2021

* Fixes - Minor Bug Fixes.

= 1.1.1 =

Released on: 17th May 2021

* Dev - fixed issue that caused premium API key not working properly.
* Fixes - Minor Bug Fixes.

= 1.1.0 =

Released on: 5th May 2021

* Dev - Adds new filter(wte_before_formatting_price_figure) to convert price
  to get rid of multiple filters for same purpose and confusion
* Dev - Adds WTE Plugin Headers
* Fixes - Minor Bug Fixes.

= 1.0.4 =

Released on: 24th November 2020

* Enhancements - Added Support for Premium Currency Converter API key.
* Fixes - Minor Bug Fixes.

= 1.0.3 =

Released on: 11th September 2020

* Enhancements - Conditional checks added for admin assets.
* Fixes - Minor Bug Fixes.

= 1.0.2 =

Released on: 1st September 2020

* Enhancements - Conditional checks added for unsupported pages.
* Enhancements - Price filter updates.
* Fixes - Minor Bug Fixes.

= 1.0.1 =

* Minor Bug Fixes

= 1.0.0 =

* Initial Release
