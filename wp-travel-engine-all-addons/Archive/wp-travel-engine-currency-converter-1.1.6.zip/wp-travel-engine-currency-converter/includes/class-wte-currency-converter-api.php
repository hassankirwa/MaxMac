<?php
/**
 * Currency API
 *
 * @link       https://wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/includes
 */

/**
 * Admin settings.
 *
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/includes
 * @author     WP Travel Engine <support@wptravelengine.com>
 */
class Wte_Currency_Converter_Api {

	/**
	 * API Key.
	 *
	 * @since 1.0.0
	 * @access private
	 *
	 * @var string API key.
	 */
	private $api_key = '2197ea9af3d0d2c9aee8';

	/**
	 * Instance.
	 *
	 * @since 1.0.0
	 * @access private
	 *
	 * @var Wte_Currency_Converter_Api $_instance instance
	 */
	private static $_instance = null;

	/**
	 * Server address.
	 *
	 * @since 1.0.0
	 * @access private
	 *
	 * @var string $server_address Server address.
	 */
	private $server_address = 'https://api.currencyfreaks.com/';

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @access private
	 *
	 * @return void
	 */
	private function __construct() {
		$wte_settings         = get_option( 'wp_travel_engine_settings' );
		$license_type         = isset( $wte_settings['currency_converter']['key_type'] ) ? $wte_settings['currency_converter']['key_type'] : 'free';
		$this->server_address = 'free' === $license_type ? 'https://api.currencyfreaks.com' : 'https://api.currconv.com/api/v7';
		$this->api_key        = isset( $wte_settings['currency_converter']['api_key'] ) ? $wte_settings['currency_converter']['api_key'] : '';
	}

	/**
	 * Get instance.
	 *
	 * @since 1.0.0
	 * @static
	 * @access public
	 *
	 * @return Wte_Currency_Converter_Api Instance.
	 */
	public static function get_instance() {
		if ( null === static::$_instance ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Get currency conversion rate.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param string $base_currency Base currency
	 * @param string $to_currency To currency.
	 *
	 * @return double Conversion rate.
	 */
	public function get_rate( $base_currency = 'USD', $to_currency = 'USD' ) {
		$wte_settings  = get_option( 'wp_travel_engine_settings' );
		$license_type  = isset( $wte_settings['currency_converter']['key_type'] ) ? $wte_settings['currency_converter']['key_type'] : 'free';
		$pair          = "{$base_currency}_{$to_currency}";
		$transient_key = "wte_cc_rate_{$pair}";
		$rate          = get_transient( $transient_key );

		// Return 1 if the base currency and to currency is same.
		if ( $base_currency === $to_currency ) {
			return 1;
		}

		// Return rate from the transient.
		if ( false !== $rate ) {
			return $rate;
		}

		// Request for new rate.
		$url = add_query_arg(
			array(
				'apiKey'  => $this->api_key,
				'q'       => $pair,
				'compact' => 'y',
			),
			"{$this->server_address}/convert"
		);
		if ( $license_type == 'free' ) {
			$url = add_query_arg(
				array(
					'apikey' => $this->api_key,
				),
				"{$this->server_address}/latest"
			);
		}

		$response = wp_remote_get(
			$url,
			array(
				'timeout' => 5,
			)
		);

		if ( is_wp_error( $response ) ) {
			return false;
		}

		if ( 400 === wp_remote_retrieve_response_code( $response ) ) {
			$body = wp_remote_retrieve_body( $response );

			$notice = Wte_Currency_Converter_Notice::get_instance();
			$notice->set_error_message( $body );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ) );
		if ( $license_type == 'free' ) {
			if ( isset( $body->rates ) ) {
				$rate = ( 1 / $body->rates->$base_currency ) * $body->rates->$to_currency;
			}
			else{
				$rate = '';
			}
		}
		else{
			$rate = $body->$pair->val;
		}

		set_transient( $transient_key, $rate, $this->get_currency_update_interval() );

		return $rate;
	}

	/**
	 * Get the currency update interval.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return int Currency update interval.
	 */
	public function get_currency_update_interval() {
		$helper = Wte_Currency_Converter_Helper_Functions::get_instance();

		$interval = DAY_IN_SECONDS;

		if ( $helper->is_auto_update() ) {
			$interval = 3 * HOUR_IN_SECONDS;
		}

		return apply_filters( 'wte_cc_currency_update_interval', $interval );
	}

	/**
	 * Check whether the api key is valid or not.
	 *
	 * @param [type] $api_key
	 * @return boolean
	 */
	public function is_api_key_valid( $api_key ) {
		$backup = $this->api_key;
		$valid  = false;

		if ( ! empty( $this->get_rate() ) ) {
			$valid = true;
		}

		$this->api_key = $backup;

		return $valid;

	}
}
