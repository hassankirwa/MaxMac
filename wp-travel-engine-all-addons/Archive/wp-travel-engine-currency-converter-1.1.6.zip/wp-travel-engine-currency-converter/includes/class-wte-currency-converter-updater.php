<?php

/**
 * Handle initializaiton of EDD updater.
 *
 * @link       https://wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/includes
 */

/**
 * Register all actions and filters for the plugin.
 *
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/includes
 * @author     WP Travel Engine <support@wptravelengine.com>
 */
class Wte_Currency_Converter_Updater {

    /**
     * Instance variable.
     * 
     * @since 1.0.0
     * @access private
     *
     * @var Wte_Currency_Converter_Updater $_instance Single instance of the class.
     */
    private static $_instance = null;

    /**
     * Constructor.
     * 
     * @since 1.0.0
     * @access private
     * 
     * @return void
     */
    private function __construct() {
        $this->init();
    }

    /**
     * Get the instance of the class
     *
     * @since 1.0.0
     * 
     * @static
     * @access public
     * 
     * @return Wte_Currency_Converter_Updater Instance
     */
    public static function get_instance() {
        if ( null === self::$_instance ) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }

    /**
     * Initialization
     *
     * @since 1.0.0
     * @access private
     * 
     * @return void
     */
    private function init() {
        /**
         * Includes the files needed for the plugin updater.
         *
         * @since 1.0.0
         */
        if ( ! class_exists( 'EDD_SL_Plugin_Updater' ) ) {
            require_once plugin_dir_path( WTE_CURRENCY_CONVERTER_ABSPATH ) . 'includes/lib/edd/EDD_SL_Plugin_Updater.php';
        }

        /**
         * Download ID for the product in Easy Digital Downloads.
         *
         * @since 1.0.0
         */
        define( 'WTE_CURRENCY_CONVERTER_ID', 30074 );
    }

    /**
     * Setup the updater for the WTE Extra Services Add-on.
     *
     * @since 1.0.0
     * @access public
     * 
     * @return void
     */
    public function wte_extra_services_updater() {
        // Bail early if the store url is not found.
        if ( version_compare( WP_TRAVEL_ENGINE_VERSION, '4.3.8', '>=' ) || ! defined( 'WP_TRAVEL_ENGINE_STORE_URL' ) ) {
            return;
        }

        // Retrieve our license key from the DB
        $settings = get_option( 'wp_travel_engine_license' );

        $license_key = '';
        if ( isset ( $settings['wte_currency_converter_license_key' ] ) ) {
            $license_key = $settings['wte_currency_converter_license_key' ];
        }

        // Setup the updater
        $edd_updater = new EDD_SL_Plugin_Updater(
            WP_TRAVEL_ENGINE_STORE_URL, 
            WTE_CURRENCY_CONVERTER_ABSPATH,
            array(
                'version' => WTE_CURRENCY_CONVERTER_VERSION, 
                'license' => $license_key,             
                'item_id' => WTE_CURRENCY_CONVERTER_ID,
                'author'  => 'WP Travel Engine',
                'beta'    => false,
            )
        );
    }

    /**
     * Add-on name for plugin license page.
     *
     * @since 1.0.0
     * @access public
     * 
     * @param array $addons Addons list.
     * @return array Modified addons list.
     */
    public function add_to_license_page( $addons ) {
        $addons['WP Travel Engine - Currency Converter'] = 'wte_currency_converter';
        return $addons;
    }

    /**
     * Add-ons Item ID for plugin license page.
     *
     * @since 1.0.0
     * @access public
     * 
     * @param array $array Addons item id list.
     * @return array Modified addons item id list.
     */
    public function add_item_id( $array ) {
        $array['wte_currency_converter'] = WTE_CURRENCY_CONVERTER_ID;
        return $array;
    }
}
