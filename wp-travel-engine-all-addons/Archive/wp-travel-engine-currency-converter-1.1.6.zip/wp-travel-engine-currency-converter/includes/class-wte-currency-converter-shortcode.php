<?php

/**
 * Currency Shortcode
 *
 * @link       https://wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/includes
 */

/**
 * Admin settings.
 *
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/includes
 * @author     WP Travel Engine <support@wptravelengine.com>
 */
class Wte_Currency_Converter_Shortcode {
    /**
     * Instance.
     * 
     * @since 1.0.0
     * @access private
     * 
     * @var Wte_Currency_Converter_Shortcode $_instance instance
     */
    private static $_instance = null;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
     * @access private
     * 
     * @return void
	 */
	private function __construct() {        
        $this->init();
    }

    /**
     * Get instance.
     * 
     * @since 1.0.0
     * @static
     * @access public
     *
     * @return Wte_Currency_Converter_Shortcode Instance.
     */
    public static function get_instance() {
        if ( null === static::$_instance ) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }

    /**
     * Initialize
     * 
     * @since 1.0.0
     * @access private
     *
     * @return void
     */
    private function init() {
        $this->init_hooks();
    }

    /**
     * Initialize hooks.
     * 
     * @since 1.0.0
     * @access private
     *
     * @return void
     */
    private function init_hooks() {
        add_action( 'init', array( $this, 'register_shortcodes' ) );
    }

    /**
     * Register shortcodes.
     * 
     * @since 1.0.0
     * @access private
     *
     * @return void
     */
    public function register_shortcodes() {
        add_shortcode( 'wte_currency_converter', array( $this, 'display_currency_converter') );        
    }

    /**
     * Display currency converter list.
     * 
     * @since 1.0.0
     * @access public
     * 
     * @return void
     */
    public function display_currency_converter() {
        ob_start();
        $public = new Wte_Currency_Converter_Public();
        $public->display_currency_list_alt();

        $data = ob_get_clean();

        return $data;
    }
}
