<?php

/**
 * Currency API
 *
 * @link       https://wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/includes
 */

/**
 * Admin settings.
 *
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/includes
 * @author     WP Travel Engine <support@wptravelengine.com>
 */
class Wte_Currency_Converter_Helper_Functions {
	/**
	 * Instance.
	 *
	 * @static
	 * @since 1.0.0
	 *
	 * @var $_instance Wte_Currency_Converter_Ajax Instance.
	 */
	private static $_instance = null;

	/**
	 * Geo located currency code.
	 *
	 * @since 1.0.0
	 * @access private
	 *
	 * @var string $geo_currency_code Geo located currency code.
	 */
	private $geo_currency_code = null;

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 * @access private
	 */
	private function __construct() {
	}

	/**
	 * Get instance.
	 *
	 * @since 1.0.0
	 * @static
	 * @access public
	 *
	 * @return Wte_Currency_Converter_Helper_Functions Instance.
	 */
	public static function get_instance() {
		if ( null === self::$_instance ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}


	/**
	 * Check whether the currency code is valid or not.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param string $currency_code
	 * @return boolean
	 */
	public function is_valid_currency_code( $currency_code ) {
		$wte_functions = new Wp_Travel_Engine_Functions();
		$wte_functions->init();

		// Return currency codes with country codes.
		$currencies = $wte_functions->wp_travel_engine_currencies();

		foreach ( $currencies as $code => $country_name ) {
			if ( $code === $currency_code ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Get currency codes list.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string[] Currency codes.
	 */
	public function get_currency_codes() {
		if ( ! class_exists( 'Wp_Travel_Engine_Functions' ) ) {
			return array();
		}

		$wte_functions = new Wp_Travel_Engine_Functions();
		$wte_functions->init();

		$currencies = $wte_functions->wp_travel_engine_currencies();

		return $currencies;
	}

	/**
	 * Get stored currency list.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Currency list.
	 */
	public function get_currency_converter_list() {
		$settings = $this->get_settings();

		if ( isset( $settings['enable'] ) ) {
			unset( $settings['enable'] );
		}
		if ( isset( $settings['auto_update'] ) ) {
			unset( $settings['auto_update'] );
		}

		return $settings;
	}

	/**
	 * Check whether the currency converter is enabled or not.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return boolean True when currency converter is enabled in extension page.
	 */
	public function is_currency_converter_enabled() {
		$wte_settings = get_option( 'wp_travel_engine_settings' );

		$enable = isset( $wte_settings['currency_converter']['enable'] ) ? $wte_settings['currency_converter']['enable'] : 'yes';

		return 'yes' === $enable;
	}

	/**
	 * Check whether the geo locate is enabled or not.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return boolean.
	 */
	public function is_geo_locate() {
		$wte_settings = get_option( 'wp_travel_engine_settings' );

		// Return false if the settings is not set.
		if ( ! isset( $wte_settings['currency_converter']['geo_locate'] ) ) {
			return false;
		}

		// Return false if the update is set to zero.
		if ( '0' === $wte_settings['currency_converter']['geo_locate'] ) {
			return false;
		}

		// Return false if the auto update is set to empty.
		if ( '' === $wte_settings['currency_converter']['geo_locate'] ) {
			return false;
		}

		return true;
	}

	/**
	 * Check whether the currency converter is auto update or not.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return boolean
	 */
	public function is_auto_update() {
		$wte_settings = get_option( 'wp_travel_engine_settings' );

		// Return false if the settings is not set.
		if ( ! isset( $wte_settings['currency_converter']['auto_update'] ) ) {
			return false;
		}

		// Return false if the update is set to zero.
		if ( '0' === $wte_settings['currency_converter']['auto_update'] ) {
			return false;
		}

		// Return false if the auto update is set to empty.
		if ( '' === $wte_settings['currency_converter']['auto_update'] ) {
			return false;
		}

		return true;
	}

	/**
	 * Convert price from default currency to another.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param string $base_code Base currency code.
	 * @param string $to        To currency code.
	 * @param string $price     Price to change
	 *
	 * @return double Converted price.
	 */
	public function get_price( $base_code, $to_code, $price ) {
		$helper = self::get_instance();
		$api    = Wte_Currency_Converter_Api::get_instance();

		if ( $helper->is_auto_update() ) {
			$rate      = $api->get_rate( $base_code, $to_code );
			$new_price = $price;
			if ( is_numeric( $rate ) ) {
				$new_price = $price * $rate;
			}
			return $new_price;
		}

		$currencies = $this->get_currency_converter_list();

		foreach ( $currencies['code'] as $index => $code ) {
			if ( $code === $to_code ) {
				$new_price = floatval( $price ) * $currencies['rate'][ $index ];
				return $new_price;
			}
		}

		return $price * $api->get_rate( $base_code, $to_code );
	}

	/**
	 * Get settings.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Settings.
	 */
	public function get_settings() {
		if ( ! function_exists( 'wte_currency_code_in_db' ) ) {
			return false;
		}

		$api                 = Wte_Currency_Converter_Api::get_instance();
		$currency_code_in_db = wte_currency_code_in_db();
		$wte_settings        = get_option( 'wp_travel_engine_settings' );

		if ( ! isset( $wte_settings['currency_converter'] ) ) {
			$wte_settings['currency_converter'] = array();
		}

		$wte_settings['currency_converter'] = wp_parse_args(
			$wte_settings['currency_converter'],
			array(
				'title'       => __( 'Currency Converter', 'wte-currency-converter' ),
				'auto_update' => '0',
				'enable'      => '1',
				'api_key'     => '',
				'code'        => array(),
				'rate'        => array(),
			)
		);

		$settings = $wte_settings['currency_converter'];

		// Remove empty currency code and rate.
		foreach ( $settings['code'] as $index => $code ) {
			if ( '' === $code || '' === $settings['rate'][ $index ] ) {
				unset( $settings['code'][ $index ] );
				unset( $settings['rate'][ $index ] );
			}
		}

		// Fix indices.
		$settings['code'] = array_values( $settings['code'] );
		$settings['rate'] = array_values( $settings['rate'] );

		// Storing geo located data in settings to fetch data in js.
		$helper = self::get_instance();
		if ( $helper->is_geo_locate() ) {
			$geo_currency_code = $helper->get_geo_currency_code();
			if ( null !== $geo_currency_code && ! in_array( $geo_currency_code, $settings['code'] ) ) {
				$settings['code'][] = $geo_currency_code;
				$settings['rate'][] = $api->get_rate( $currency_code_in_db, $geo_currency_code );
			}
		}

		// Get the updated rate if the auto update is enabled.
		if ( $this->is_auto_update() ) {
			foreach ( $settings['code'] as $index => $code ) {
				$rate = $api->get_rate( $currency_code_in_db, $code );

				if ( false !== $rate ) {
					$settings['rate'][ $index ] = $rate;
				}
			}
		}

		return $settings;
	}

	/**
	 * Delete all the transients with a prefix.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void Remove all the transients storing the currency rates.
	 */
	public function purge_transients( $prefix ) {
		global $wpdb;

		$prefix = esc_sql( $prefix );

		$options = $wpdb->options;

		$t = esc_sql( "_transient_timeout_{$prefix}%" );

		$sql = $wpdb->prepare(
			"
                SELECT option_name
                FROM $options
                WHERE option_name LIKE '%s'
            ",
			$t
		);

		$transients = $wpdb->get_col( $sql );

		// For each transient...
		foreach ( $transients as $transient ) {

			// Strip away the WordPress prefix in order to arrive at the transient key.
			$key = str_replace( '_transient_timeout_', '', $transient );

			// Now that we have the key, use WordPress core to the delete the transient.
			delete_transient( $key );

		}
	}

	/**
	 * Get geo located currency code.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Geo located currency code.
	 */
	public function get_geo_currency_code() {
		$geo_currency_code = wte_currency_code_in_db();
		$remote_addr       = '';

		if ( isset( $_SERVER['REMOTE_ADDR'] ) ) {
			$remote_addr = $_SERVER['REMOTE_ADDR'];
		}

		if ( null !== $this->geo_currency_code ) {
			return $this->geo_currency_code;
		}

		$remote_addr = defined( 'WTE_CC_TEST_REMOTE_ADDR' ) ? WTE_CC_TEST_REMOTE_ADDR : $remote_addr;

		$url = "https://ipapi.co/{$remote_addr}/json";

		$response = wp_remote_get(
			$url,
			array(
				'timeout' => 5,
			)
		);

		if ( is_wp_error( $response ) ) {
			return null;
		}

		if ( 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return null;
		}

		$response = json_decode( wp_remote_retrieve_body( $response ) );
		if ( isset( $response->currency ) ) {
			$geo_currency_code = $response->currency;
		}

		if ( null !== $geo_currency_code ) {
			$this->geo_currency_code = $geo_currency_code;
		}
		return $this->geo_currency_code;
	}

	/**
	 * Get API key.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string API Key.
	 */
	public function get_api_key() {
		$settings = $this->get_settings();
		if ( ! is_array( $settings ) || ! isset( $settings['api_key'] ) ) {
			return '';
		}
		return $settings['api_key'];
	}
}
