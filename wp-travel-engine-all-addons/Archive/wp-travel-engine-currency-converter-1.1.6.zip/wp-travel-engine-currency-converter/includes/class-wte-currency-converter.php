<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Wte_Currency_Converter
 * @subpackage Wte_Currency_Converter/includes
 * @author     WP Travel Engine <support@wptravelengine.com>
 */
class Wte_Currency_Converter {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Wte_Currency_Converter_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {
		if ( defined( 'WTE_CURRENCY_CONVERTER_VERSION' ) ) {
			$this->version = WTE_CURRENCY_CONVERTER_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->plugin_name = 'wte-currency-converter';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();
		$this->init_hooks();

	}

	private function init_hooks() {
		add_filter(
			'wte_before_formatting_price_figure',
			function( $price, $trip_id = null ) {
				global $post;
				// Bail early if the regular price is empty.
				if ( empty( $price ) ) {
					return $price;
				}

				$helper   = Wte_Currency_Converter_Helper_Functions::get_instance();
				$settings = get_option( 'wp_travel_engine_settings', [] );

				if ( wp_travel_engine_is_checkout_page() || wp_travel_engine_is_dashboard_page() || wp_travel_engine_is_account_page() ) {
					return $price;
				}

				// Get the currency stored in db.
				$currency_code_in_db = wte_currency_code_in_db();

				$currency_code = wp_travel_engine_get_currency_code();

				// Bail early if the currency converter cookie is not set.
				if ( ! isset( $_COOKIE['cc_code'] ) && ! $helper->is_geo_locate() ) {
					return $price;
				} elseif ( $helper->is_geo_locate() && ! isset( $_COOKIE['cc_code'] ) ) {
					$currency_code = $helper->get_geo_currency_code();
				} elseif ( isset( $_COOKIE['cc_code'] ) ) {
					$currency_code = $_COOKIE['cc_code'];
				}

				// Return the currency code stored in the db in the checkout page.
				if ( isset( $settings['pages']['wp_travel_engine_place_order'] )
				&& is_page( $settings['pages']['wp_travel_engine_place_order'] ) ) {
					$currency_code_in_db = $currency_code;
					$currency_code       = wte_currency_code_in_db();
				}

				// Return the price as it is in the Thank you page.
				if ( isset( $settings['pages']['wp_travel_engine_thank_you'] )
				&& is_page( $settings['pages']['wp_travel_engine_thank_you'] ) ) {
					return $price;
				}

				// Return the price as it is in the User Dashboard you page.
				if ( isset( $settings['pages']['wp_travel_engine_dashboard_page'] )
				&& is_page( $settings['pages']['wp_travel_engine_dashboard_page'] ) ) {
					return $price;
				}

				// Bail early if the current code in db is same as to the currency code
				// in use.
				if ( $currency_code_in_db === $currency_code ) {
					return $price;
				}

				// Convert the sale price.
				$currencies = $helper->get_currency_converter_list();

				if ( is_array( $price ) ) {
					$new_price = array_map(
						function( $p ) use ( $helper, $currency_code_in_db, $currency_code ) {
							return $helper->get_price( $currency_code_in_db, $currency_code, $p );
						},
						$price
					);
				} else {
					$new_price = $helper->get_price( $currency_code_in_db, $currency_code, $price );
				}

				$decimal_digits = ! empty( $settings['decimal_digits'] ) ? (float) $settings['decimal_digits'] : 2;

				return round( $new_price, $decimal_digits );
			},
			11,
			2
		);
	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Wte_Currency_Converter_Loader. Orchestrates the hooks of the plugin.
	 * - Wte_Currency_Converter_i18n. Defines internationalization functionality.
	 * - Wte_Currency_Converter_Admin. Defines all hooks for the admin area.
	 * - Wte_Currency_Converter_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies() {

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wte-currency-converter-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wte-currency-converter-i18n.php';

		/**
		 * The class responsible fetching rates and countries from api.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wte-currency-converter-api.php';

		/**
		 * Helper functions.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wte-currency-converter-helper-functions.php';

		/**
		 * EDD Updater.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wte-currency-converter-updater.php';
		$helper = Wte_Currency_Converter_Helper_Functions::get_instance();
		if ( $helper->is_currency_converter_enabled() ) {
			/**
			 * Shortcode.
			 */
			require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wte-currency-converter-shortcode.php';
		}

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-wte-currency-converter-admin.php';

		/**
		 * The class responsible for handling admin settings.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-wte-currency-converter-settings.php';

		/**
		 * The class responsible for handling ajax requests.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-wte-currency-converter-ajax.php';

		/**
		 * The class responsible for displaying admin notices.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-wte-currency-converter-notice.php';

		/**
		 * The class responsible for widget.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-wte-currency-converter-widget.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-wte-currency-converter-public.php';

		$this->loader = new Wte_Currency_Converter_Loader();

	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Wte_Currency_Converter_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Wte_Currency_Converter_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {

		$plugin_admin = new Wte_Currency_Converter_Admin( $this->get_plugin_name(), $this->get_version() );
		$settings     = new Wte_Currency_Converter_Settings( $this->get_plugin_name(), $this->get_version() );
		$widget       = new Wte_Currency_Converter_Widget();
		$api          = Wte_Currency_Converter_Api::get_instance();
		$ajax         = new Wte_Currency_Converter_Ajax( $this->get_plugin_name(), $this->get_version() );
		$updater      = Wte_Currency_Converter_Updater::get_instance();
		$notice       = Wte_Currency_Converter_Notice::get_instance();

		$this->loader->add_action( 'admin_notices', $plugin_admin, 'check_dependency' );

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );
		$this->loader->add_action( 'admin_head', $plugin_admin, 'enqueue_js_templates' );
		// $this->loader->add_action( 'wte_currency_converter_settings', $settings, 'display_settings' );
		$this->loader->add_filter( 'wpte_get_global_extensions_tab', $settings, 'display_settings' );
		// Delete all the currency rate transients if the auto enable is set.
		$this->loader->add_action( 'update_option_wp_travel_engine_settings', $plugin_admin, 'remove_currency_rate_transients', 10, 2 );

		// Initialize EDD Updater.
		$this->loader->add_action( 'admin_init', $updater, 'wte_extra_services_updater', 0 );
		$this->loader->add_action( 'admin_init', $plugin_admin, 'check_errors', 0 );
		// Add addon name in the wp travel engine plugin license page.
		$this->loader->add_filter( 'wp_travel_engine_addons', $updater, 'add_to_license_page' );
		// Add addon item id for plugin license page.
		$this->loader->add_filter( 'wp_travel_engine_addons_id', $updater, 'add_item_id' );
	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {
		$settings = get_option( 'wp_travel_engine_settings' );

		$show_before_bkg = isset( $settings['currency_converter']['show_before_bkg'] ) ? $settings['currency_converter']['show_before_bkg'] : 'yes';

		$sticky_enable = isset( $settings['currency_converter']['sticky_enable'] ) ? $settings['currency_converter']['sticky_enable'] : 'yes';

		// Don't add any public hooks if the plugin is not enabled.
		$helper = Wte_Currency_Converter_Helper_Functions::get_instance();
		if ( ! $helper->is_currency_converter_enabled() ) {
			return;
		}

		$plugin_public = new Wte_Currency_Converter_Public( $this->get_plugin_name(), $this->get_version() );
		$shortcode     = Wte_Currency_Converter_Shortcode::get_instance();

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );

		if ( 'yes' === $show_before_bkg ) {
			$this->loader->add_action( 'wte_before_price_info', $plugin_public, 'display_currency_list_alt' );
		}

		if ( 'yes' === $sticky_enable ) {
			$this->loader->add_action( 'wp_footer', $plugin_public, 'sticky_currency_switcher' );
			$this->loader->add_filter( 'body_class', $plugin_public, 'add_sticky_class' );
		}

		// WP Travel Engine.
		$this->loader->add_filter( 'wp_travel_engine_currency_code', $plugin_public, 'change_default_currency_code', 10, 2 );
		// $this->loader->add_filter( 'wp_travel_engine_trip_prev_price', $plugin_public, 'convert_price', 20, 2 );
		$this->loader->add_filter( 'wp_travel_engine_trip_sale_price', $plugin_public, 'convert_price', 20, 2 );
		$this->loader->add_filter( 'wte_multi_pricing', $plugin_public, 'convert_price', 20, 2 );

		// Group Discounts.
		$this->loader->add_filter( 'wte_gd_adult_price', $plugin_public, 'convert_price', 20, 2 );
		$this->loader->add_filter( 'wte_gd_child_price', $plugin_public, 'convert_price', 20, 2 );
		$this->loader->add_filter( 'wte_gd_infant_price', $plugin_public, 'convert_price', 20, 2 );
		$this->loader->add_filter( 'wte_gd_child_cost', $plugin_public, 'convert_price', 20, 2 );
		$this->loader->add_filter( 'wpte_formated_befor_price_currency_code_symbol', $plugin_public, 'convert_price', 20, 3 );

		$this->loader->add_filter( 'wte_es_price_in_bkg_row', $plugin_public, 'convert_price', 20, 2 );

		$this->loader->add_filter( 'wpte_cc_allow_payment_with_switcher', $plugin_public, 'cc_code_supported' );

		$this->loader->add_filter( 'wte_price_cost_reverse', $plugin_public, 'wte_price_cost_reverse_callback' );
	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Wte_Currency_Converter_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}
}
