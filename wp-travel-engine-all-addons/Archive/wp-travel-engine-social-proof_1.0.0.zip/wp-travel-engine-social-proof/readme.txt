=== WP Travel Engine - Social Proof ===
Tags: wp-travel-engine, social-proof, notification
Requires at least: 5.7
Tested up to: 6.0
Requires PHP: 7.0
Stable tag: 1.0.0

The Social Proof add-on for the WP Travel Engine plugin allows you to display real time notifications.

== Description ==

The Social Proof add-on for the WP Travel Engine plugin allows you to display real time notifications of the user activities on your website such as Trip booking, Trip enquiry and Trip review. Just as the name suggests, these popups works as a social proof of the customer interaction and conversion on your website for the website visitors. This further builds up their trust on your business and inclines a potential customer to buy your product or package.

== Installation ==

* Navigate to the `Admin Dashboard > Plugins > Add New`
* Click on the `Upload Plugin` button
* Select and upload the `wp-travel-engine-social-proof.zip` file from your computer
* Click on `Install Now` button
* Activate the plugin

== Changelog ==

= 1.0.0 =

* Initial Release
