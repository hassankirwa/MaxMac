<?php
/**
 * Notification API.
 */

namespace WP_Travel_Engine_Social_Proof;

use WP_Travel_Engine_Social_Proof\Functions;

class API {


	public function __construct() {

		add_action( 'wp_ajax_wte_sf_notification', array( $this, 'handle_ajax_request' ) );
		add_action( 'wp_ajax_nopriv_wte_sf_notification', array( $this, 'handle_ajax_request' ) );

	}

	public function request_raw_data() {
		// Cart Data sent as JSON body.
		$raw_data = wte_get_request_raw_data();

		// Decoded JSON data.
		return json_decode( $raw_data, ! 0 );
	}

	private function get_request_method() {
		return isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : 'GET';
	}

	public function handle_ajax_request() {

		$request_method = $this->get_request_method();

		switch ( $request_method ) {
			case 'POST':
				$this->handle_post_request();
				break;
			case 'GET':
				$this->handle_get_request();
				break;
			case 'DELETE':
				if ( isset( $_GET['id'] ) ) {
					$this->handle_delete_request( sanitize_text_field( wp_unslash( $_GET['id'] ) ) );
				} else {
					$this->handle_error( __( 'Missing required parameters.', 'wptravelengine-social-proof' ), 'MISSING_REQUIRED_PARAMS' );
				}
				break;
			default:
				$this->handle_error( __( 'Invalid request method', 'wptravelengine-social-proof' ), 'INVALID_REQUEST_METHOD' );
				break;
		}

	}

	private function handle_error( $message, $code ) {
		wp_send_json_error( new \WP_Error( $code, $message ) );
		die;
	}

	private function replace_tags( $replaceble = array(), $variables = array(), $content = '' ) {
		extract( $variables );
		$_replaceable = array();
		foreach ( $replaceble as $tag => $keys ) {
			$_keys = explode( '|', $keys['keys'] );
			foreach ( $_keys as $key ) {
				list($variable_name,  $_key) = explode( '.', $key );
				$_replaceable[ $tag ]        = isset( $$variable_name[ $_key ] ) ? sprintf( $keys['wrapper'], $$variable_name[ $_key ] ) : '';
			}
		}
		return array( str_replace( array_keys( $_replaceable ), array_values( $_replaceable ), $content ), $_replaceable );
	}

	public function get_booking_notification_entries( $notification ) {
		$notification   = (array) $notification;
		$query          = new \WP_Query();
		$days_ago       = isset( $notification['displaydays'] ) ? (int) $notification['displaydays'] : 5;
		$posts_per_page = isset( $notification['notificationnum'] ) ? (int) $notification['notificationnum'] : 5;

		$query_args = array(
			'post_type'  => 'booking',
			'date_query' => array(
				array(
					'column' => 'post_date_gmt',
					'after'  => "{$days_ago} days ago",
				),
			),
		);

		if ( ! isset( $notification['tripNotficationSelection'] ) || 'select-trip' !== $notification['tripNotficationSelection'] ) {
			$query_args['posts_per_page'] = $posts_per_page;
		}

		$results    = $query->query( $query_args );
		$replaceble = array(
			'%full_name%'        => array(
				'wrapper' => '<strong>%s</strong>',
				'keys'    => 'billing_info.full_name',
			),
			'%first_name%'       => array(
				'wrapper' => '<strong>%s</strong>',
				'keys'    => 'billing_info.booking_first_name',
			),
			'%last_name%'        => array(
				'wrapper' => '<strong>%s</strong>',
				'keys'    => 'billing_info.booking_last_name',
			),
			'%custom_name%'      => array(
				'wrapper' => '<strong>%s</strong>',
				'keys'    => 'notification.customName',
			),
			'%trip_name%'        => array(
				'wrapper' => '<span class="wte-sp-notification_title">%s</span>',
				'keys'    => 'order_trip.title',
			),
			'%custom_trip_name%' => array(
				'wrapper' => '<span class="wte-sp-notification_title">%s</span>',
				'keys'    => 'notification.customtitle',
			),
			'%custom_time%'      => array(
				'wrapper' => '<span class="wte-sp-notification_updated-time">%s</span>',
				'keys'    => 'notification.customTime',
			),
			'%time%'             => array(
				'wrapper' => '<span class="wte-sp-notification_updated-time">%s</span>',
				'keys'    => 'order_trip.time',
			),
		);

		$_results = array();
		foreach ( $results as $index => $result ) {
			if ( $posts_per_page <= 0 ) {
				break;
			}

			$order_trip = array_values( get_post_meta( $result->ID, 'order_trips', true ) )[0];

			if ( ! isset( $query_args['posts_per_page'] ) && isset( $notification['tripdata'] ) ) {
				$trip_data = is_array( $notification['tripdata'] ) ? array_column( $notification['tripdata'], 'value', 'value' ) : array();
				if ( ! isset( $trip_data[ $order_trip['ID'] ] ) ) {
					continue;
				}
			}

			$content      = $notification['content'];
			$billing_info = get_post_meta( $result->ID, 'billing_info', true );
			$full_name    = array();
			if ( isset( $billing_info['booking_first_name'] ) ) {
				$full_name['fname'] = $billing_info['booking_first_name'];
			} elseif ( isset( $billing_info['fname'] ) ) {
				$full_name['fname'] = $billing_info['fname'];
			}
			if ( isset( $billing_info['booking_last_name'] ) ) {
				$full_name['lname'] = $billing_info['booking_last_name'];
			} elseif ( isset( $billing_info['lname'] ) ) {
				$full_name['lname'] = $billing_info['fname'];
			}
			$billing_info['full_name']          = implode( ' ', $full_name );
			$billing_info['booking_first_name'] = $full_name['fname'];
			$billing_info['booking_last_name']  = $full_name['lname'];

			$created            = new \DateTime( $result->post_date_gmt );
			$order_trip['time'] = human_time_diff( $created->getTimestamp() ) . ' ago';

			$replaced_content = $this->replace_tags(
				$replaceble,
				array(
					'billing_info' => $billing_info,
					'notification' => $notification,
					'order_trip'   => $order_trip,
				),
				$content
			);

			$_results[ $index ]['content']           = $replaced_content[0];
			$_results[ $index ]['replacement_pairs'] = $replaced_content[1];
			$_results[ $index ]['link']              = get_post_permalink( $order_trip['ID'] );
			$posts_per_page--;
		}
		return $_results;
	}

	public function get_enquiry_notification_entries( $notification ) {
		$notification = (array) $notification;
		$query        = new \WP_Query();

		$days_ago       = isset( $notification['displaydays'] ) ? (int) $notification['displaydays'] : 5;
		$posts_per_page = isset( $notification['notificationnum'] ) ? (int) $notification['notificationnum'] : 5;
		$results        = $query->query(
			array(
				'post_type'      => 'enquiry',
				'posts_per_page' => $posts_per_page,
				'date_query'     => array(
					array(
						'column' => 'post_date_gmt',
						'after' => "{$days_ago} days ago",
					),
				),
			)
		);

		$replaceble = array(
			'%full_name%'        => array(
				'wrapper' => '<strong>%s</strong>',
				'keys'    => 'data1.enquiry_name',
			),
			'%first_name%'       => array(
				'wrapper' => '<strong>%s</strong>',
				'keys'    => 'data1.enquiry_name',
			),
			'%last_name%'        => array(
				'wrapper' => '<strong>%s</strong>',
				'keys'    => 'data1.enquiry_name',
			),
			'%custom_name%'      => array(
				'wrapper' => '<strong>%s</strong>',
				'keys'    => 'notification.customName',
			),
			'%trip_name%'        => array(
				'wrapper' => '<span class="wte-sp-notification_title">%s</span>',
				'keys'    => 'data1.package_name',
			),
			'%custom_trip_name%' => array(
				'wrapper' => '<span class="wte-sp-notification_title">%s</span>',
				'keys'    => 'notification.customtitle',
			),
			'%custom_time%'      => array(
				'wrapper' => '<span class="wte-sp-notification_updated-time">%s</span>',
				'keys'    => 'notification.customTime',
			),
			'%time%'             => array(
				'wrapper' => '<span class="wte-sp-notification_updated-time">%s</span>',
				'keys'    => 'data1.time',
			),
		);

		$_results = array();
		foreach ( $results as $index => $result ) {
			$content = $notification['content'];
			$data1   = get_post_meta( $result->ID, 'wp_travel_engine_enquiry_formdata', true );

			$created = new \DateTime( $result->post_date_gmt );

			$data1['time'] = human_time_diff( $created->getTimestamp() ) . ' ago';

			$replaced_content                        = $this->replace_tags(
				$replaceble,
				array(
					'data1'        => $data1,
					'notification' => $notification,
				),
				$content
			);
			$_results[ $index ]['content']           = $replaced_content[0];
			$_results[ $index ]['replacement_pairs'] = $replaced_content[1];
			$_results[ $index ]['link']              = '#';
		}
		return $_results;
	}

	public function get_review_notification_entries( $notification ) {
		$notification = (array) $notification;

		$days_ago       = isset( $notification['displaydays'] ) ? (int) $notification['displaydays'] : 5;
		$posts_per_page = isset( $notification['notificationnum'] ) ? (int) $notification['notificationnum'] : 5;

		$replaceble = array(
			'%full_name%'        => array(
				'wrapper' => '<strong>%s</strong>',
				'keys'    => 'data1.full_name',
			),
			'%first_name%'       => array(
				'wrapper' => '<strong>%s</strong>',
				'keys'    => 'data1.first_name',
			),
			'%last_name%'        => array(
				'wrapper' => '<strong>%s</strong>',
				'keys'    => 'data1.last_name',
			),
			'%custom_name%'      => array(
				'wrapper' => '<strong>%s</strong>',
				'keys'    => 'data1.custom_name',
			),
			'%trip_name%'        => array(
				'wrapper' => '<span class="wte-sp-notification_title">%s</span>',
				'keys'    => 'data1.trip_name',
			),
			'%custom_trip_name%' => array(
				'wrapper' => '<span class="wte-sp-notification_title">%s</span>',
				'keys'    => 'data1.custom_trip_name',
			),
			'%custom_time%'      => array(
				'wrapper' => '<span class="wte-sp-notification_updated-time">%s</span>',
				'keys'    => 'data1.custom_time',
			),
			'%time%'             => array(
				'wrapper' => '<span class="wte-sp-notification_updated-time">%s</span>',
				'keys'    => 'data1.time',
			),
		);

		$args = array(
			'post_type'  => 'trip',
			'order'      => 'desc',
			'orderby'    => 'comment_date',
			'number'     => $posts_per_page,
			'date_query' => array(
				array(
					'column' => 'comment_date_gmt',
					'after' => "{$days_ago} days ago",
				),
			),
		);

		$results = get_comments( $args );

		foreach ( $results as $index => $result ) {
			$content = $notification['content'];

			$created = new \DateTime( $result->comment_date_gmt );

			$full_name                               = explode( ' ', $result->comment_author );
			$replaced_content                        = $this->replace_tags(
				$replaceble,
				array(
					'data1' => array(
						'full_name'        => implode( ' ', $full_name ),
						'first_name'       => isset( $full_name[0] ) ? $full_name[0] : '',
						'last_name'        => isset( $full_name[1] ) ? $full_name[1] : '',
						'custom_name'      => $notification['customName'],
						'trip_name'        => get_the_title( $result->comment_post_ID ),
						'custom_trip_name' => $notification['customtitle'],
						'custom_time'      => $notification['customTime'],
						'time'             => human_time_diff( $created->getTimestamp() ) . ' ago',
					),
				),
				$content
			);
			$_results[ $index ]['content']           = $replaced_content[0];
			$_results[ $index ]['replacement_pairs'] = $replaced_content[1];
			$_results[ $index ]['link']              = get_the_permalink( $result->comment_post_ID );
		}

		return $_results;
	}

	/**
	 * Get Entries By Notification types.
	 */
	public function get_notification_entries( $notification ) {
		if ( is_callable( array( $this, "get_{$notification->notificationType}_notification_entries" ) ) ) {
			if ( 'review' === $notification->notificationType && ! defined( 'WTE_TRIP_REVIEW_VERSION' ) ) {
				return array();
			}
			return $this->{"get_{$notification->notificationType}_notification_entries"}( $notification );
		}
	}

	/**
	 * Handle GET request.
	 */
	private function handle_get_request() {
		if ( isset( $_GET['type'] ) ) {
			$type = sanitize_text_field( wp_unslash( $_GET['type'] ) );
			switch ( trim( $type ) ) {
				case 'settings':
					$data = $this->get_notification_data( 'notifications_settings' );
					break;
				case 'conversion_data':
					$data = $this->get_notification_data( 'conversion_data' );
					break;
			}
		} else {
			$data = (array) $this->get_notifications();

			$_data = array();

			foreach ( $data as $notification ) {
				$and = true;
				foreach ( array(
					'status'  => array( 'type' => 'string' ),
					'enabled' => array( 'type' => 'boolean' ),
				) as $meta => $args ) {
					if ( ! $and ) {
						break;
					}
					if ( isset( $_GET[ $meta ] ) && isset( $notification[ $meta ] ) ) {
						$and = wp_unslash( sanitize_text_field( $_GET[ $meta ] ) ) === (string) $notification[ $meta ];
					}
				}
				if ( $and && isset( $_GET['entries'] ) && '1' === $_GET['entries'] ) {
					$notification['entries'] = $this->get_notification_entries( (object) $notification );
				}

				if ( $and ) {
					$_data[] = $notification;
				}
			}

			$data = $_data;

		}
		wp_send_json_success( $data );
		die;
	}

	public function get_schema() {
		return array(
			'$schema'    => 'http://json-schema.org/draft-04/schema#',
			'title'      => 'Notification',
			'type'       => 'object',
			'properties' => array(
				'id' => array(
					'type'              => 'string',
					'sanitize_callback' => 'sanitize_text_field',
				),
			),
		);
	}

	private function handle_user_request( $data ) {
		$conversion_data = (array) $this->get_notification_data( 'conversion_data' );

		$conversion_data['clicks'] = isset( $conversion_data['clicks'] ) ? (int) $conversion_data['clicks'] : 0;
		$conversion_data['views']  = isset( $conversion_data['views'] ) ? (int) $conversion_data['views'] : 0;

		if ( isset( $data['id'] ) ) {
			if ( isset( $data['type'] ) && in_array( $data['type'], array( 'click', 'view' ) ) ) {
				if ( isset( $conversion_data[ trim( $data['id'] ) ][ $data['type'] ] ) ) {
					$conversion_data[ trim( $data['id'] ) ][ $data['type'] ]++;
				} else {
					$conversion_data[ trim( $data['id'] ) ][ $data['type'] ] = 1;
				}
				$conversion_data[ $data['type'] . 's' ]++;
			}
		}

		if ( update_option( 'wte_sf_conversion_data', wp_json_encode( $conversion_data ) ) ) {
			wp_send_json_success(
				array(
					'message' => __( 'Successfully updated', 'wptravelengine-social-proof' ),
				)
			);
			die;
		} else {
			$this->handle_error( __( 'Failed to update conversion data.', 'wptravelengine-social-proof' ), 'FAILED_TO_UPDATE_NOTIFICATION_SETTINGS' );
		}
	}

	/**
	 * Handle POST request.
	 */
	private function handle_post_request() {
		$data = $this->request_raw_data();

		if ( isset( $data['settings'] ) ) {
			$notification_settings = $this->get_notification_settings();
			$notification_settings = array_merge( $notification_settings, $data['settings'] );

			if ( $this->update_notification_settings( $notification_settings ) ) {
				wp_send_json_success( $notification_settings );
				die;
			} else {
				$this->handle_error( __( 'Failed to update notification settings.', 'wptravelengine-social-proof' ), 'FAILED_TO_UPDATE_NOTIFICATION_SETTINGS' );
			}
		}

		if ( isset( $data['user_conversion'] ) ) {
			$this->handle_user_request( $data['user_conversion'] );
		}

		$notifications = $this->get_notifications();
		$notifications = array_column( $notifications, null, 'id' );
		if ( isset( $data['id'] ) ) {
			if ( isset( $notifications[ $data['id'] ] ) ) {

				$schema = $this->get_schema();

				// @TODO: Use schema later.
				$notifications[ $data['id'] ] = $data;

				if ( $this->update_notifications( array_values( $notifications ) ) ) {
					wp_send_json_success( $data );
					die;
				} else {
					$this->handle_error( __( 'Failed to update notification.', 'wptravelengine-social-proof' ), 'FAILED_TO_UPDATE_NOTIFICATION' );
				};
			} else {
				$this->handle_error( __( 'Invalid notification ID.', 'wptravelengine-social-proof' ), 'INVALID_NOTIFICATION_ID' );
			}
		} else {
			$data['id']                   = Functions\uniqid( 8 );
			$notifications[ $data['id'] ] = $data;

			if ( $this->update_notifications( array_values( $notifications ) ) ) {
				wp_send_json_success( $data );
				die;
			}
		}
	}

	/**
	 * Handles DELETE request.
	 */
	private function handle_delete_request( $id ) {
		$notifications = $this->get_notifications();
		$notifications = array_column( $notifications, null, 'id' );

		$ids = explode( ',', $id );

		if ( isset( $ids[0] ) ) {
			foreach ( $ids as $_id ) {
				$_id = trim( $_id );
				if ( isset( $notifications[ $_id ] ) ) {
					unset( $notifications[ $_id ] );
				}
			}
		}
		if ( $this->update_notifications( array_values( $notifications ) ) ) {
			wp_send_json_success( array() );
			die;
		}
	}

	private function update_notifications( $data ) {
		return update_option( 'wte_sf_notifications', wp_json_encode( $data ) );
	}

	private function update_notification_settings( $data ) {
		return update_option( 'wte_sf_notifications_settings', wp_json_encode( $data ) );
	}

	public function get_notifications() {
		return $this->get_notification_data( 'notifications' );
	}

	/**
	 * Get Notification Settings
	 */
	public function get_notification_settings() {
		return $this->get_notification_data( 'notifications_settings' );
	}

	/**
	 * Gets Notification related data from option table.
	 *
	 * @param string $option_name Option Name.
	 * @param mixed  $default Default Data.
	 */
	public function get_notification_data( $option_name, $default = '[]' ) {
		$data = get_option( 'wte_sf_' . preg_replace( '/^wte_sf_/', '', $option_name ), $default );
		return json_decode( $data, ! 0 );
	}

}


new API();
