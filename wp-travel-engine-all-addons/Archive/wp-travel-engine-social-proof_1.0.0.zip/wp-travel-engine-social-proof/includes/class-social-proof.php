<?php
/**
 * Core Class.
 *
 * @package    WP_Travel_Engine_Social_Proof
 * @subpackage WP_Travel_Engine_Social_Proof/includes
 */

namespace WP_Travel_Engine_Social_Proof;

class Social_Proof {

	/**
	 * Instance of this class.
	 *
	 * @var      object
	 */
	protected static $instance = null;

	/**
	 * Consturctor.
	 */
	public function __construct() {
		$this->includes();
		$this->init_hooks();
	}

	/**
	 * Return an instance of this class.
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function includes() {
		require_once WPTRAVELENGINE_SC_PROOF_DIR__ . '/includes/helpers.php';
		require_once WPTRAVELENGINE_SC_PROOF_DIR__ . '/includes/class-notification-api.php';
		require_once WPTRAVELENGINE_SC_PROOF_DIR__ . '/updater/updater.php';
	}

	/**
	 * Init Hooks.
	 */
	private function init_hooks() {
		add_action( 'admin_menu', array( $this, 'add_submenu_page' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'frontend_enqueue_scripts' ) );
		add_action( 'wp_footer', array( $this, 'frontend_display_notification' ) );
	}

	/**
	 * Add submenu page for social-proof.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function add_submenu_page() {

		add_submenu_page(
			'edit.php?post_type=booking',
			__( 'WP Travel Engine Social Proof', 'wptravelengine-social-proof' ),
			__( 'Social Proof', 'wptravelengine-social-proof' ),
			'manage_options',
			'wte_social_proof_admin',
			array( $this, 'display_submenu_page' ),
			10
		);

	}

	/**
	 * Display submenu page template
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function display_submenu_page() {
		require WPTRAVELENGINE_SC_PROOF_DIR__ . '/includes/admin/social-proof.php';
	}

	/**
	 * Display submenu page template
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function frontend_display_notification() {
		require WPTRAVELENGINE_SC_PROOF_DIR__ . '/includes/frontend/frontend-social-proof.php';
	}

	/**
	 * Enqueue a script with jQuery as a dependency.
	 */
	public function admin_enqueue_scripts() {
		$sp_dependencies = include_once plugin_dir_path( WPTRAVELENGINE_SC_PROOF_FILE__ ) . 'dist/admin.dist.asset.php';
		wp_register_script( 'social-proof-admin', plugin_dir_url( WPTRAVELENGINE_SC_PROOF_FILE__ ) . 'dist/admin.dist.js', $sp_dependencies['dependencies'], $sp_dependencies['version'], true );
		wp_register_style( 'social-proof-admin', plugin_dir_url( WPTRAVELENGINE_SC_PROOF_FILE__ ) . 'dist/style-admin.dist.css', array(), $sp_dependencies['version'] );
	}

	/**
	 * Enqueue a script with jQuery as a dependency.
	 */
	public function frontend_enqueue_scripts() {
		$sp_frontend_dependencies = include_once plugin_dir_path( WPTRAVELENGINE_SC_PROOF_FILE__ ) . 'dist/public.dist.asset.php';
		wp_register_script( 'social-proof-frontend', plugin_dir_url( WPTRAVELENGINE_SC_PROOF_FILE__ ) . 'dist/public.dist.js', $sp_frontend_dependencies['dependencies'], $sp_frontend_dependencies['version'], true );
		wp_register_style( 'social-proof-frontend', plugin_dir_url( WPTRAVELENGINE_SC_PROOF_FILE__ ) . 'dist/style-public.dist.css', array(), $sp_frontend_dependencies['version'] );
	}
}
/**
 * Run the class Social_proof.
 */
function wte_social_proof_init() {
	return Social_Proof::instance();
}
wte_social_proof_init();
