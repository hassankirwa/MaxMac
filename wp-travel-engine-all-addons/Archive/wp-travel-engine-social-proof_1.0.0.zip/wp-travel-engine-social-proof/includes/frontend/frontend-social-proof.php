<?php
/**
 * Social Proof Frontend Page.
 *
 * @package WP_Travel_Engine_Social_proof
 */
wp_enqueue_script( 'social-proof-frontend' );
wp_enqueue_style( 'social-proof-frontend' );
?>
<div id="wte-sp-notification"></div>
