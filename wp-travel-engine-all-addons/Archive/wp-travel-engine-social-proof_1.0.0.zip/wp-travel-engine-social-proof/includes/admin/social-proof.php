<?php
/**
 * Social Proof Page.
 *
 * @package WP_Travel_Engine_Social_proof
 */
wp_enqueue_script( 'social-proof-admin' );
wp_enqueue_style( 'social-proof-admin' );
?>
<div id="wte_social_proof"></div>
