<?php
/**
 * Plugin Name:     WP Travel Engine - Social Proof
 * Plugin URI:      https://wptravelengine.com/plugins/social-proof/
 * Description:     The plugin adds different notification type in your site in accordance with WP Travel Engine.
 * Version: 1.0.0
 * Author: WP Travel Engine
 * Author URI: https://wptravelengine.com
 * Text Domain:     wptravelengine-social-proof
 * Domain Path:     /languages
 * Requires at least: 5.7
 * Requires PHP: 7.0
 * WTE Requires at least: 5.0
 * WTE tested up to: 5.4
 * WTE: 120625:wptravelengine_social_proof_license_key
 *
 * @package         WP_Travel_Engine_Social_Proof
 */

defined( 'ABSPATH' ) || exit;

define( 'WPTRAVELENGINE_SC_PROOF_FILE__', __FILE__ );
define( 'WPTRAVELENGINE_SC_PROOF_DIR__', __DIR__ );
define( 'WPTRAVELENGINE_SC_PROOF_VERSION', '1.0.0' );
define( 'WPTRAVELENGINE_SC_PROOF_REQUIRES_AT_LEAST', '5.4' );

add_action( 'plugins_loaded', 'wptravelengine_social_proof' );
/**
 * Runs on plugins_loaded hook.
 */
function wptravelengine_social_proof() {

	$meet_requirements = defined( 'WP_TRAVEL_ENGINE_VERSION' ) && version_compare( '5.4.0', WPTRAVELENGINE_SC_PROOF_REQUIRES_AT_LEAST, '>=' );

	/**
	 * Load plugin updater file
	 */
	if ( ! $meet_requirements ) {
		add_action(
			'admin_notices',
			function() {
				echo wp_kses(
					sprintf(
						'<div class="wte-admin-notice error"><p>%1$s</p></div>',
						sprintf( __( 'The %1$s requires at least WP Travel Engine %2$s. the plugin is currently NOT RUNNING.', 'wptravelengine-social-proof' ), '<b>WP Travel Engine - Social Proof</b>', '<code>' . WPTRAVELENGINE_SC_PROOF_REQUIRES_AT_LEAST . '</code>' )
					),
					array(
						'div'  => array( 'class' => array() ),
						'p'    => array(),
						'b'    => array(),
						'code' => array(),
					)
				);
			}
		);
	} else {
		/**
		 * The core plugin class that is used to define internationalization,
		 * admin-specific hooks, and public-facing site hooks.
		 */
		if ( ! class_exists( 'WPTRAVELENGINE_SC_PROOF\Social_Proof', false ) ) {
			require WPTRAVELENGINE_SC_PROOF_DIR__ . '/includes/class-social-proof.php';
		}
	}
}
