<?php
/**
 * Metaboxes controller.
 *
 * @since 2.0.4
 */


class WTE_Extra_Services_metaboxes {


	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );
		// add_action( 'save_post_wte-services', array( $this, 'save_meta' ), 11, 2 );
		add_action( 'save_post', array( $this, 'save_meta' ), 11, 2 );
	}

	/**
	 * Per tag label
	 *
	 * @since 2.1.2
	 */
	public static function get_service_unit_labels() {
		$labels = array(
			'unit'     => array(
				'label'               => __( 'Unit', 'wte-extra-services' ),
				'select_option_label' => __( 'Per Unit', 'wte-extra-services' ),
			),
			'traveler' => array(
				'label'               => __( 'Traveler', 'wte-extra-services' ),
				'select_option_label' => __( 'Per Traveler', 'wte-extra-services' ),
			),
		);

		return apply_filters( 'wte_es_service_unit_labels', $labels );
	}

	public function add_meta_boxes() {
		add_meta_box(
			'wte_extra_services',
			__( 'Extra Services', 'wte-extra-services' ),
			function() {
				function wte_es_show( $current, $saved ) {
					if ( $current !== $saved ) {
						echo ' style="display:none"';
					}
				}
				function wte_es_readonly( $current, $saved ) {
					if ( $current === $saved ) {
						echo ' readonly';
					}
				}
				global $post;
				wp_enqueue_style( 'wp-travel-engine_core_ui' );
				wp_enqueue_style( 'wte-extra-services' );
				wp_enqueue_script( 'wte-services_edit' );
				$services         = get_post_meta( $post->ID, 'wte_services', true );
				$cost             = wtees_get( $services, 'service_cost', '' );
				$service_type     = wtees_get( $services, 'service_type', 'default' );
				$service_required = wtees_get( $services, 'service_required', false );
				$field_type       = wtees_get( $services, 'field_type', 'select' );
				$pricing_type     = wtees_get( $services, 'pricing_type', 'single-price' );
				$unit             = wtees_get( $services, 'service_unit', 'unit' );
				$options          = wtees_get( $services, 'options', array( '' ) );
				$prices           = wtees_get( $services, 'prices', array() );
				$descriptions     = wtees_get( $services, 'descriptions', array() );
				$attributes       = wtees_get( $services, 'attributes', array() );
				$single_price     = wtees_get( $services, 'single_price', '' );
				?>
				<div id="wte-extra-services-metabox">
					<?php if ( version_compare( WP_TRAVEL_ENGINE_VERSION, '5.7.4', '>=' ) ) { ?>
						<div class="wte-extra-service-required">
							<div class="wpte-field">
								<label class="wpte-field-label" for="service-required"><?php esc_html_e( 'Required', 'wte-extra-services' ); ?> </label>
								<div class="wpte-floated">
									<div class="wpte-field-group">
										<input id="service-required" type="checkbox" name="wte_services[service_required]" value="1" <?php checked( true, $service_required ); ?>>
										<label for="service-required"><?php echo esc_html__( 'Required', 'wte-extra-services' ); ?></label>
									</div>
								</div>
							</div>
							<div class="wte-info">
								<?php echo esc_html__( 'When this feature is enabled, a minimum of one selection is required during the booking process.', 'wte-extra-services' ); ?>
							</div>
						</div>
					<?php } ?>
					<div class="wte-extra-service-type">
						<div class="wpte-field">
							<label class="wpte-field-label" for="service-type"><?php esc_html_e( 'Choose Service Type', 'wte-extra-services' ); ?> </label>
							<div class="wpte-floated">
								<div class="wpte-field-group">
									<input id="service-type-1" type="radio" name="wte_services[service_type]" value="default" <?php checked( 'default', $service_type ); ?>>
									<label for="service-type-1"><?php echo esc_html__( 'Default', 'wte-extra-services' ); ?></label>
								</div>
								<div class="wpte-field-group">
									<input id="service-type-2" type="radio" name="wte_services[service_type]" value="custom" <?php checked( 'custom', $service_type ); ?>>
									<label for="service-type-2"><?php echo esc_html__( 'Advanced', 'wte-extra-services' ); ?></label>
								</div>
							</div>
						</div>
					</div>
					<div class="wte-extra-service-fields wte-es-field-default" id="wte-es-field-default" data-wte-es-template="default" <?php wte_es_show( $service_type, 'default' ); ?>>
						<div class="wpte-floated">
							<div class="wpte-field wpte-col2">
								<label class="wpte-field-label" for="service-cost"><?php echo esc_html__( 'Service Cost', 'wte-extra-services' ); ?></label>
								<input name="wte_services[service_cost]" type="text" value="<?php echo esc_attr( $cost ); ?>"/>
							</div>
							<div class="wpte-field wpte-col2">
								<label class="wpte-field-label" for="service-unit"><?php echo esc_html__( 'Service Unit', 'wte-extra-services' ); ?></label>
								<select name="wte_services[service_unit]" id="service-unit">
									<?php
									$label_options = self::get_service_unit_labels();
									foreach ( $label_options as $label_value => $label_option ) :
										?>
									<option value="<?php echo esc_attr( $label_value ); ?>" <?php selected( $unit, $label_value ); ?>><?php echo esc_html( $label_option['select_option_label'] ); ?></option>
									<?php endforeach; ?>
								</select>
							</div>
						</div>
					</div>
					<div class="wte-extra-service-fields wte-es-field-custom" id="wte-es-field-custom" data-wte-es-template="custom" <?php wte_es_show( $service_type, 'custom' ); ?>>
						<div class="wpte-field wpte-col2">
							<label class="wpte-field-label" for="service-field-type"><?php echo esc_html__( 'Field Types', 'wte-extra-services' ); ?></label>
							<div class="wpte-field-group">
								<input id="field-type-1" type="radio" name="wte_services[field_type]"  value="select" <?php checked( $field_type, 'select' ); ?> />
								<label for="field-type-1"><?php echo esc_html__( 'User can select one service option while booking.', 'wte-extra-services' ); ?></label>
							</div>
							<div class="wpte-field-group">
								<input id="field-type-2" type="radio" name="wte_services[field_type]" value="checkbox" <?php checked( $field_type, 'checkbox' ); ?> />
								<label for="field-type-2"><?php echo esc_html__( 'User can select multiple service options while booking.', 'wte-extra-services' ); ?></label>
							</div>
							<div class="wte-info"><?php esc_html_e( 'The field types defines the type of the service you are providing.', 'wte-extra-services' ); ?></div>
						</div>
						<div class="wpte-field">
							<div class="wpte-col2">
								<label class="wpte-field-label" for="service-pricing-type"><?php echo esc_html__( 'Pricing', 'wte-extra-services' ); ?></label>
								<div class="wpte-field-group">
									<input id="pricing-type-1" type="radio" name="wte_services[pricing_type]"  value="single-price" <?php checked( $pricing_type, 'single-price' ); ?> />
									<label for="pricing-type-1"><?php echo esc_html__( 'Options have same price.', 'wte-extra-services' ); ?></label>
								</div>
								<div class="wpte-field-group">
									<input id="pricing-type-2" type="radio" name="wte_services[pricing_type]" value="multiple-price" <?php checked( $pricing_type, 'multiple-price' ); ?> />
									<label for="pricing-type-2"><?php echo esc_html__( 'Options have different prices.', 'wte-extra-services' ); ?></label>
								</div>
								<input type="number" id="service-single-price" <?php wte_es_show( $pricing_type, 'single-price' ); ?> value="<?php echo esc_attr( $single_price ); ?>" name="wte_services[single_price]" step=".1" min="0" placeholder="<?php echo esc_attr( 'Service Price' ); ?>"/>
							</div>
							<div class="wte-info"><?php esc_html_e( 'The Pricing types controls if options below will have same price or different price.', 'wte-extra-services' ); ?></div>
						</div>
						<div class="wpte-repeat-service-options" <?php wte_es_show( ( count( $options ) > 0 || in_array( $field_type, array( 'select', 'checkbox' ), true ) ), true ); ?>>
							<h3 class="wpte-field-label"><?php echo esc_html__( 'Service Options', 'wte-extra-services' ); ?></h3>
							<div class="wpte-repeator-wrap">
							<style>
							.extra-service-options-table {
								width: 100%;
							}
							.extra-service-options-table td {
								vertical-align: top;
							}
							.attribute-row {
								display:flex;
								wrap:nowrap;
							}
							.attribute-row span {
								margin-right: 16px;
							}
							.attribute-row button {
								background: transparent;
								border: none;
								margin-left:16px;
							}
							.attributes-options {
								list-style: none;
								padding:0;
								margin:0;
							}
							.wte-badge {
								display: inline-block;
								padding: .25em .4em;
								font-size: 75%;
								font-weight: 700;
								line-height: 1;
								text-align: center;
								white-space: nowrap;
								vertical-align: baseline;
								border-radius: .25rem;
								transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
							}
							.wte-badge-pill {
								padding-right: .6em;
								padding-left: .6em;
								border-radius: 10rem;
							}
							.wte-badge-primary {
								color: #fff;
								background-color: #007bff;
							}
							.extra-service-options-table tr > td{
								width: calc( (100% - 80px) * 0.33 );
							}
							.extra-service-options-table tr td:last-child{
								width: 80px;
							}
							</style>

								<table class="extra-service-options-table">
									<thead>
										<tr>
											<th><?php echo esc_html__( 'Service Options', 'wte-extra-services' ); ?></th>
											<th><?php echo esc_html__( 'Service Costs', 'wte-extra-services' ); ?></th>
											<th><?php echo esc_html__( 'Service Descriptions', 'wte-extra-services' ); ?></th>
											<!-- <th><?php echo esc_html__( 'Service Attributes', 'wte-extra-services' ); ?></th> -->
											<th>&nbsp;</th>
										</tr>
									</thead>
									<tbody class="wpte-repeator-block wte-es-option">
										<?php
										foreach ( $options as $index => $option ) :
											$option_price       = isset( $prices[ $index ] ) ? $prices[ $index ] : '';
											$option_description = isset( $descriptions[ $index ] ) ? $descriptions[ $index ] : '';
											$option_attributes  = ! empty( $attributes[ $index ] ) ? $attributes[ $index ] : array();
											?>
												<tr class="wpte-field wpte-field-option-row">
													<td>
														<input type="text" class="wte_services-option" id="wte_services-option-<?php echo +$index; ?>" name="wte_services[options][<?php echo +$index; ?>]" value="<?php echo esc_attr( $option ); ?>"/>
													</td>
													<td>
														<input type="text" class="wte_services-price" <?php wte_es_readonly( $pricing_type, 'single-price' ); ?> id="wte_services-price-<?php echo +$index; ?>" name="wte_services[prices][<?php echo +$index; ?>]" value="<?php echo esc_attr( $option_price ); ?>"/>
													</td>
													<td>
														<textarea style="min-height:145px;" data-dt-max-height="175" class="wte_services-description" id="wte_services-description-<?php echo +$index; ?>" name="wte_services[descriptions][<?php echo +$index; ?>]"><?php echo esc_attr( $option_description ); ?></textarea>
													</td>
													<!-- <td>
														<input type="text" placeholder="<?php echo esc_attr_x( 'e.g. Color: Red, Blue, Green', 'Service Attributes Input Example', 'wte-extra-services' ); ?>" class="wte_services-attributes-input" id="wte_services-attributes-<?php echo +$index; ?>" value="" />
														<textarea style="display:none;" class="wte_services-attributes" name="wte_services[attributes][<?php echo +$index; ?>]"><?php echo wp_json_encode( $option_attributes ); ?></textarea>
														<div class="rendered-service-attributes"></div>
													</td> -->
													<td>
														<button class="wpte-delete wpte-remove-es-option" data-delete data-target=".wpte-field-option-row" <?php wte_es_show( $index > 0, true ); ?>></button>
													</td>
												</tr>
										<?php endforeach; ?>
									</tbody>
								</table>
								<button class="wpte-add-btn add-extra-service wte-add-service-option"><?php echo esc_html__( 'Add Service Option', 'wte-extra-services' ); ?></button>
							</div>
						</div>
					</div>
				</div>
				<?php
			},
			'wte-services'
		);
	}

	public function save_meta( int $post_id, WP_Post $post ) {

		if ( empty( $_REQUEST['wte_services'] ) ) { // phpcs:ignore
			return;
		}
		$services  = wp_unslash( $_REQUEST['wte_services'] ); // phpcs:ignore
		$meta_sub_keys = array(
			'service_cost'     => '',
			'service_type'     => 'default',
			'service_required' => false,
			'service_unit'     => 'unit',
			'field_type'       => 'text',
			'pricing_type'     => 'text',
			'single_price'     => 'text',
			'options'          => array(),
			'prices'           => array(),
			'descriptions'     => array(),
			'attributes'       => array(),
		);

		$meta_value = array();
		$actions    = array(
			'default' => function() use ( $meta_sub_keys, $post_id, $post, $services ) {
				$meta_value = array();
				foreach ( $meta_sub_keys as $meta_sub_key => $default ) {
					if ( isset( $services[ $meta_sub_key ] ) ) {
						$meta_value[ $meta_sub_key ] = $services[ $meta_sub_key ];
					}
				}
				update_post_meta( $post_id, 'wte_services', $meta_value );
			},
			'custom'  => function() use ( $meta_sub_keys, $post_id, $post, $services ) {
				$meta_value = array();
				foreach ( $meta_sub_keys as $meta_sub_key => $default ) {
					if ( isset( $services[ $meta_sub_key ] ) ) {
						if ( 'attributes' === $meta_sub_key ) {
							$meta_value[ $meta_sub_key ] = array_map(
								function( $sm ) {
									return json_decode( $sm );
								},
								$services[ $meta_sub_key ]
							);
							continue;
						}
						$meta_value[ $meta_sub_key ] = $services[ $meta_sub_key ];
					} else {
						$meta_value[ $meta_sub_key ] = $default;
					}
				}
				update_post_meta( $post_id, 'wte_services', $meta_value );
			},
		);

		if ( isset( $services['service_type'] ) && in_array( $services['service_type'], array_keys( $actions ) ) ) {
			$actions[ $services['service_type'] ]();
		}

	}
}

new WTE_Extra_Services_metaboxes();
