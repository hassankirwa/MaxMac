<?php

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

/**
 * Plugin Name: WP Travel Engine - Advanced Itinerary Builder
 * Plugin URI: https://wptravelengine.com
 * Description: WP Travel Engine - Advanced Itinerary Builder is a custom addon for WP Travel Engine plugin that helps you build advanced itinerary.
 * Author: WP Travel Engine
 * Author URI: https://wptravelengine.com
 * Version: 2.1.1
 * License: GPL2+
 * License URI: https://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: wte-advanced-itinerary
 * Domain Path: /languages
 *
 * WTE Tested up to: 5.6
 * WTE requires at least: 4.3.0
 * WTE: 31567:wte_advanced_itinerary_license_key
 *
 * @package WTE Advanced Itinerary.
 */
defined( 'WTEAI_VERSION' ) || define( 'WTEAI_VERSION', '2.1.1' );
defined( 'WTEAD_IMAGE_DIR' ) || define( 'WTEAD_IMAGE_DIR', plugin_dir_url( __FILE__ ) . 'assets/images/' );
defined( 'WTEAD_JS_DIR' ) || define( 'WTEAD_JS_DIR', plugin_dir_url( __FILE__ ) . 'assets/js/' );
defined( 'WTEAD_CSS_DIR' ) || define( 'WTEAD_CSS_DIR', plugin_dir_url( __FILE__ ) . 'assets/css/' );
defined( 'WTEAD_ADMIN_DIR' ) || define( 'WTEAD_ADMIN_DIR', dirname( __FILE__ ) . '/admin/' );
defined( 'WTEAD_FRONT_TEMPLATE_DIR' ) || define( 'WTEAD_FRONT_TEMPLATE_DIR', dirname( __FILE__ ) . '/templates/' );
defined( 'WTEAD_CLASSES_DIR' ) || define( 'WTEAD_CLASSES_DIR', dirname( __FILE__ ) . '/classes' );
defined( 'WTEAD_FILE_ROOT_DIR' ) || define( 'WTEAD_FILE_ROOT_DIR', plugin_dir_path( __FILE__ ) );
defined( 'WTEAD_FILE_PATH' ) || define( 'WTEAD_FILE_PATH', __FILE__ );
defined( 'WTEAD_REQUIRES_AT_LEAST' ) || define( 'WTEAD_REQUIRES_AT_LEAST', '4.3.0' );

add_action(
	'plugins_loaded',
	function() {
		if ( ! defined( 'WP_TRAVEL_ENGINE_VERSION' ) || version_compare( WP_TRAVEL_ENGINE_VERSION, WTEAD_REQUIRES_AT_LEAST, '<' ) ) {
			add_action(
				'admin_notices',
				function() {
					echo wp_kses_post(
						sprintf(
							'<div class="error"><p>'
							// translators: 1. WTE Extension Name 2. Link to WTE Plugin.
							. sprintf( __( '%1$s requires the %2$s plugin to work. Please install and activate the latest <strong>WP Travel Engine</strong> plugin first.', 'wte-advanced-itinerary' ), '<strong>WP Travel Engine - Advanced Ititnerary Builder</strong>', '<a href="https://wordpress.org/plugins/wp-travel-engine/" target="__blank">WP Travel Engine</a>' )
							. '</p></div>'
						)
					);
				}
			);
		} else {
			if ( ! class_exists( 'WTE_Advanced_Itinerary' ) ) {
				include_once WTEAD_CLASSES_DIR . '/class-wte-advanced-itinerary.php';
			}
			new \WTE_Advanced_Itinerary();
		}
	}
);
