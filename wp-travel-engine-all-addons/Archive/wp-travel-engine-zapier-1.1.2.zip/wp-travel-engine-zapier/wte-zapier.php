<?php
/**
 * Plugin Name:     WP Travel Engine - Zapier
 * Plugin URI:      https://wptravelengine.com
 * Description:     Zapier addon for WP Travel Engine plugin.
 * Author:          WP Travel Engine
 * Author URI:      https://wptravelengine.com
 * Text Domain:     wte-zapier
 * Domain Path:     /languages
 * Version:         1.1.2
 * WTE tested up to: 6.2
 * WTE requires at least: 4.0.0
 * WTE: 44702:wte_zapier_license_key
 *
 * @package         WTE_Zapier
 */

use WTE_Zapier\ZapierCore;

defined( 'ABSPATH' ) || exit;

// Include the autoloader.
require_once __DIR__ . '/vendor/autoload.php';

if ( ! defined( 'WTE_ZAPIER_PLUGIN_FILE' ) ) {
	define( 'WTE_ZAPIER_PLUGIN_FILE', __FILE__ );
}

define( 'WTE_ZAPIER_REQUIRES_AT_LEAST', '4.0.0' );

/**
 * Return the main instance of ZapierCore.
 *
 * @since 1.0.0
 * @return ZapierCore
 */
function RUN_WTE_ZAPIER() { // phpcs:ignore WordPress.NamingConventions.ValidFunctionName.FunctionNameInvalid
	return ZapierCore::instance();
}

add_action( 'plugins_loaded', 'wtezapier_fail_requirements' );
/**
 *
 * @since
 */
function wtezapier_fail_requirements() {
	if ( ! defined( 'WP_TRAVEL_ENGINE_VERSION' ) || version_compare( WP_TRAVEL_ENGINE_VERSION, WTE_ZAPIER_REQUIRES_AT_LEAST, '<' ) ) {
		add_action(
			'admin_notices',
			function() {
				echo wp_kses_post(
					sprintf(
						'<div class="error"><p>'
						// translators: 1. WTE Extension Name 2. Link to WTE Plugin.
						. sprintf( __( '%1$s requires the %2$s plugin to work. Please install and activate the latest <strong>%2$s</strong> plugin first.', 'wte-zapier' ), '<strong>WP Travel Engine - Zapier</strong>', '<a href="https://wordpress.org/plugins/wp-travel-engine/" target="__blank">WP Travel Engine</a>' )
						. '</p></div>'
					)
				);
			}
		);
	} else {
		// Global for backwards compatibility.
		$GLOBALS['WTE_ZAP'] = RUN_WTE_ZAPIER();
	}
}
