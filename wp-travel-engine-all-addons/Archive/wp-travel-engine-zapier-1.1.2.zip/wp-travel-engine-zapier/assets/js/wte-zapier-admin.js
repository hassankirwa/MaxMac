jQuery(document).ready(function () {
	wpte_add_action(
		"wpte_after_global_settings_tab_shown",
		"wpte_zapier_addon_new_Ui",
		30
	);
});
function wpte_zapier_addon_new_Ui(content_key) {
	// Bail if content key is not availibility.
	if (content_key[0] != "wpte-extensions") {
		return;
	}

	var zapier_index =
		0 < jQuery(".wpte-booking-zapier-wbhk-rep").length
			? jQuery(".wpte-booking-zapier-wbhk-rep").length + 1
			: 1;
	jQuery(document).on("click", ".add-wte-booking-zapier-webhook", function (
		e
	) {
		debugger;
		e.preventDefault();
		var template = wp.template("wte-booking-zapier-webhooks-rep");
		jQuery("#wpte-booking-zapier-wbhk-rep-holder").append(
			template({ index: zapier_index })
		);
		++zapier_index;
	});
	var zapier_enq_indx =
		0 < jQuery(".wpte-enquiry-zapier-wbhk-rep").length
			? jQuery(".wpte-enquiry-zapier-wbhk-rep").length + 1
			: 1;
	jQuery(document).on("click", ".add-wte-enquiry-zapier-webhook", function (
		e
	) {
		e.preventDefault();
		var template = wp.template("wte-enquiry-zapier-webhooks-rep");
		jQuery("#wpte-enquiry-zapier-wbhk-rep-holder").append(
			template({ index: zapier_enq_indx })
		);
		++zapier_enq_indx;
	});
	jQuery(document).on("click", ".wpte-remove-wbhkrep", function (e) {
		e.preventDefault();
		jQuery(this).parents(".wpte-zapier-wbhk-rep").remove();
	});

	jQuery(document).on("click", ".wpte-test-wbhkrep", function (e) {
		e.preventDefault();
		var hook_type = jQuery(this).data("hook-type");
		var hook_id = jQuery(this).data("hook-id");
		var data = {
			hook_type: hook_type,
			hook_id: hook_id,
			action: "wte_zapier_trigger_hook_test",
		};
		jQuery.ajax({
			url: ajaxurl,
			data: data,
			type: "post",
			dataType: "json",
			success: function (data) {
				if (data.success) {
					toastr.success("Zapier webhook successfully triggered.");
				} else {
					toastr.error("Zapier webhook trigger failed.");
				}
			},
		});
	});
}
