<?php
// Silence is Golden.
