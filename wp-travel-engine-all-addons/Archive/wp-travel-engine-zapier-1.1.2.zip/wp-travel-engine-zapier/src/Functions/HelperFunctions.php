<?php
/**
 * Helper functions for our plugin.
 * 
 * @package Delicious_Recipies
 */

/**
  * Send CURL request to zapier webhooks.
  *
  * @param [type] $action
  * @param array $parameters
  * @param string $url
  * @return void
  */
function wte_zapier_curl( $action, $parameters=array(), $url='' ){

    $parameters = http_build_query($parameters);
    
    if( empty( $url ) ){
        return false;
    }
    
    $args = array(
        'body'        => $parameters,
        'timeout'     => '30',
        'redirection' => '5',
        'httpversion' => '1.0',
        'blocking'    => true,
        'headers'     => array(),
        'cookies'     => array()
    );
    $server_output_all = wp_remote_post( $url, $args );
    $server_output     = wp_remote_retrieve_body( $server_output_all );
    
    if(substr($server_output, 0, 5) == "<?xml") {
        $server_output = simplexml_load_string($server_output);
    }else{
        $server_output = json_decode($server_output);
    }

    return $server_output;
}

