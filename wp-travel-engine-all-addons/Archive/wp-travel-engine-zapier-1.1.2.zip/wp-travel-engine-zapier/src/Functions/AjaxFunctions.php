<?php
/**
 * AJAX Functions.
 *
 * @package WTE_Zapier
 * @subpackage  WTE_Zapier
 */

namespace WTE_Zapier;

defined( 'ABSPATH' ) || exit;

/**
 * Global Settings.
 */
class AjaxFunctions {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->init();
	}

	/**
	 * Initialization.
	 *
	 * @since 1.0.0
	 * @access private
	 *
	 * @return void
	 */
	private function init() {
		// Initialize hooks.
		$this->init_hooks();
	}

	/**
	 * Initialize hooks.
	 *
	 * @since 1.0.0
	 * @access private
	 *
	 * @return void
	 */
	private function init_hooks() {
		add_action( 'wp_ajax_wte_zapier_trigger_hook_test', array( $this, 'test_zapier_hooks' ) );
	}

	/**
	 * Test zapier hooks
	 *
	 * @return void
	 */
	public function test_zapier_hooks() {
		$hook_type = isset( $_POST['hook_type'] ) && ! empty( $_POST['hook_type'] ) ? $_POST['hook_type'] : false;
		$hook_id   = isset( $_POST['hook_id'] ) && ! empty( $_POST['hook_id'] ) ? $_POST['hook_id'] : false;

		if ( ! $hook_type || ! $hook_id ) {
			wp_send_json_error( [ 'msg' => __( 'Invalid hook type/id provided', 'wte-zapier' ) ] );
		}

		$global_settings = wp_travel_engine_get_settings();

		if ( 'enquiry' === $hook_type ) {
			$enquiry_zaps = isset( $global_settings['zapier']['enquiry_zaps'] ) && ! empty( $global_settings['zapier']['enquiry_zaps'] ) ? $global_settings['zapier']['enquiry_zaps'] : false;

			if ( ! $enquiry_zaps ) {
				wp_send_json_error( [ 'msg' => __( 'Invalid hook type/id provided', 'wte-zapier' ) ] );
			}
			
			$chosen_zap = isset(  $enquiry_zaps[$hook_id] ) && ! empty( $enquiry_zaps[$hook_id] ) ? $enquiry_zaps[$hook_id] : false;

			if ( ! $chosen_zap || ! isset( $chosen_zap['url'] ) || empty( $chosen_zap['url'] ) ) {
				wp_send_json_error( [ 'msg' => __( 'Invalid hook type/id provided', 'wte-zapier' ) ] );
			}

			$enquiry_args = [
				'enquiry_subject'  => __( 'Trip Enquiry', 'wte-zapier' ),
				'enquiry_name'     => __( 'John Doe', 'wte-zapier' ),
				'enquiry_email'    => __( 'test@dev.co', 'wte-zapier' ),
				'enquiry_country'  => __( 'Country Name', 'wte-zapier' ),
				'enquiry_contact'  => __( '1234567890', 'wte-zapier' ),
				'enquiry_adults'   => 2,
				'enquiry_children' => 1,
				'enquiry_message'  => __( 'This is the test enquiry message', 'wte-zapier' )
			];

			$output = wte_zapier_curl( 'new_enquiry', $enquiry_args, $chosen_zap['url'] );

			wp_send_json_success( [$output] );

        } elseif( 'booking' === $hook_type ) {

			$booking_zaps = isset( $global_settings['zapier']['booking_zaps'] ) && ! empty( $global_settings['zapier']['booking_zaps'] ) ? $global_settings['zapier']['booking_zaps'] : false;

			if ( ! $booking_zaps ) {
				wp_send_json_error( [ 'msg' => __( 'Invalid hook type/id provided', 'wte-zapier' ) ] );
			}
			
			$chosen_zap = isset( $booking_zaps[$hook_id] ) && ! empty( $booking_zaps[$hook_id] ) ? $booking_zaps[$hook_id] : false;

			if ( ! $chosen_zap || ! isset( $chosen_zap['url'] ) || empty( $chosen_zap['url'] ) ) {
				wp_send_json_error( [ 'msg' => __( 'Invalid hook type/id provided', 'wte-zapier' ) ] );
			}

			$booking_data = [
				'id'         => rand( 1, 9999 ),
				'trip_name'  => 'Trip Name',
				'start_date' =>  date('Y-m-d'),
				'fname'      => 'John',
				'lname'      => 'Doe',
				'email'      => 'john@example.com',
				'address'    => 'Some address',
				'city'       => 'City Name',
				'country'    => 'Country Name',
			];

			$output = wte_zapier_curl( 'new_booking', $booking_data, $chosen_zap['url'] );

			wp_send_json_success( [$output] );

		}
	}

}

new AjaxFunctions();
