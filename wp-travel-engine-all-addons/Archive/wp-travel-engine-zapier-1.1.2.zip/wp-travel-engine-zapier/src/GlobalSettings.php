<?php
/**
 * Settings page under Settings for global settings.
 *
 * @package Delicious_Recipies
 * @subpackage  Delicious_Recipies
 */

namespace WTE_Zapier;

defined( 'ABSPATH' ) || exit;

/**
 * Global Settings.
 */
class GlobalSettings {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->init();
	}

	/**
	 * Initialization.
	 *
	 * @since 1.0.0
	 * @access private
	 *
	 * @return void
	 */
	private function init() {
		
		// Initialize hooks.
		$this->init_hooks();

		// Allow 3rd party to remove hooks.
		do_action( 'wte_zapier_options_unhook', $this );
	}

	/**
	 * Initialize hooks.
	 *
	 * @since 1.0.0
	 * @access private
	 *
	 * @return void
	 */
	private function init_hooks() {
		add_filter( 'wpte_get_global_extensions_tab', array( $this, 'add_global_settings_page' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
	}

	/**
	 * Add Global settings tab in the Global Settings page.
	 *
	 * @param [type] $setting_tabs
	 * @return void
	 */
	public function add_global_settings_page( $setting_tabs ) {
		$setting_tabs['wte_zapier_addon'] = array(
            'label'        => __( 'Zapier Integration', 'wte-zapier' ),
            'content_path' => WTE_ZAPIER_ABSPATH . '/src/admin/global-settings.php',
            'current'      => false
        );
        return $setting_tabs;
	}

	/**
	 * Enqueue Admin Scripts for global settings.
	 * 
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function enqueue_admin_scripts() {

		$min    = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
		$screen = get_current_screen();

		if ( 'booking_page_class-wp-travel-engine-admin' == $screen->id ) {
			wp_enqueue_script( 'wte-zapier-admin', plugin_dir_url( WTE_ZAPIER_PLUGIN_FILE ) . 'assets/js/wte-zapier-admin'. $min .'.js', array( 'jquery' ), WTE_ZAPIER_VERSION , true );
		}

	}

}
