<?php
/**
 * Admin area settings and hooks.
 *
 * @package WP_Zapier
 * @subpackage  WP_Zapier
 */

namespace WTE_Zapier;

defined( 'ABSPATH' ) || exit;

/**
 * Global Settings.
 */
class ZapierPublic {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->init();
	}

	/**
	 * Initialization.
	 *
	 * @since 1.0.0
	 * @access private
	 *
	 * @return void
	 */
	private function init() {

		// Initialize hooks.
		$this->init_hooks();
	}

	/**
	 * Initialize hooks.
	 *
	 * @since 1.0.0
	 * @access private
	 *
	 * @return void
	 */
	private function init_hooks() {
		add_action( 'wp_travel_engine_after_booking_process_completed', array( $this, 'trigger_booking_zaps' ) );
		add_action( 'wp_travel_engine_after_enquiry_sent', array( $this, 'trigger_enquiry_zaps' ) );
	}

	/**
	 * Trigger zapier booking webhooks after booking success.
	 *
	 * @param [type] $booking_id
	 * @return void
	 */
	public function trigger_booking_zaps( $booking_id ) {

		$global_settings       = wp_travel_engine_get_settings();
		$automate_booking_zaps = isset( $global_settings['zapier']['enable_automation_booking'] ) && 'yes' === $global_settings['zapier']['enable_automation_booking'] ? true : false;

		if ( ! $automate_booking_zaps ) {
			return;
		}

		$booking_zaps = isset( $global_settings['zapier']['booking_zaps'] ) && ! empty( $global_settings['zapier']['booking_zaps'] ) ? $global_settings['zapier']['booking_zaps'] : false;

		if ( ! $booking_zaps ) {
			return;
		}

		$order_metas  = get_post_meta( $booking_id, 'wp_travel_engine_booking_setting', true );
		$booking_info = isset( $order_metas['place_order']['booking'] ) && is_array( $order_metas['place_order']['booking'] ) ? $order_metas['place_order']['booking'] : array();

		foreach ( $booking_info as $info => $value ) {
			$booking_form_data = array();
			if ( is_array( $value ) ) {
				foreach ( $value as $val ) {
					$booking_form_data[ $info ] .= $val . ',';
					foreach ( $booking_form_data as $booking_value ) {
						$booking_data[ $info ] = $booking_value;
					}
				}
			} else {
				$booking_data[ $info ] = $value;
			}
		}

		/**
		 * @since 1.1.2
		 *
		 * Added extra services data to zapier
		 */
		$services = array();
		if ( isset( $order_metas['place_order']['extra_services'] ) ) {
			foreach ( $order_metas['place_order']['extra_services'] as $service => $extra_service ) {
				$booking_data['extra_services'] = '';
				$extra_service['total_cost']    = $extra_service['qty'] * $extra_service['price'];
				$services[ $service ]           = '';
				$services[ $service ]          .= $extra_service['qty'] . ' * ' . $extra_service['extra_service'] . '[ ' . html_entity_decode( wte_get_formated_price( $extra_service['price'] ) ) . ' ] = ' . html_entity_decode( wte_get_formated_price( $extra_service['total_cost'] ) );
			}
			$counter = 0;
			foreach ( $services as $ex_service ) {
				$counter++;
				$booking_data['extra_services'] .= $ex_service . "\n";
			}
		}

		$booking_data['id']           = $booking_id;
		$booking_data['trip_name']    = isset( $order_metas['place_order']['tname'] ) ? $order_metas['place_order']['tname'] : '';
		$booking_data['start_date']   = isset( $order_metas['place_order']['datetime'] ) ? $order_metas['place_order']['datetime'] : '';
		$booking_data['cost']         = isset( $order_metas['place_order']['cost'] ) ? html_entity_decode( wte_get_formated_price( $order_metas['place_order']['cost'] ) ) : '';
		$booking_data['trip_package'] = isset( $order_metas['place_order']['trip_package'] ) ? $order_metas['place_order']['trip_package'] : '';
		$booking_data['tax']          = isset( $order_metas['place_order']['tax'] ) ? $order_metas['place_order']['tax'] : '';
		$pricing_categories           = get_terms(
			array(
				'taxonomy'   => 'trip-packages-categories',
				'hide_empty' => false,
				'orderby'    => 'term_id',
				'fields'     => 'id=>name',
			)
		);

		//Added trip enddate and trip duration.
		if( isset( $order_metas['place_order']['tenddate'] ) ){
			$booking_data['end_date']  = $order_metas['place_order']['tenddate'];
		}
		if( isset( $order_metas['place_order']['tduration'] ) ){
			$booking_data['trip_duration']  = $order_metas['place_order']['tduration'];
		}
		foreach ( $pricing_categories as $category ) {
			if ( isset( $order_metas['place_order'] ) ) {
				foreach ( $order_metas['place_order'] as $key => $val ) {
					if ( $key == $category ) {
						$booking_data[ $key ] = $val;
					}
				}
			}
		}

		foreach ( $booking_zaps as $zap_key => $zap ) {
			wte_zapier_curl( 'new_booking', $booking_data, $zap['url'] );
		}
	}

	/**
	 * Enquiry Zaps trigger.
	 *
	 * @param [type] $enquiry_id
	 * @return void
	 */
	public function trigger_enquiry_zaps( $enquiry_id ) {
		$global_settings       = wp_travel_engine_get_settings();
		$automate_enquiry_zaps = isset( $global_settings['zapier']['enable_automation_enquiry'] ) && 'yes' === $global_settings['zapier']['enable_automation_enquiry'] ? true : false;

		if ( ! $automate_enquiry_zaps ) {
			return;
		}

		$enquiry_zaps = isset( $global_settings['zapier']['enquiry_zaps'] ) && ! empty( $global_settings['zapier']['enquiry_zaps'] ) ? $global_settings['zapier']['enquiry_zaps'] : false;

		if ( ! $enquiry_zaps ) {
			return;
		}

		$main_fields = get_post_meta( $enquiry_id, 'wp_travel_engine_setting', true );

		// Added new meta key for form editor addon support.
		$add_fields = get_post_meta( $enquiry_id, 'wp_travel_engine_enquiry_formdata', true );

		foreach ( $add_fields as $form => $fields ) {
			$enquiry_args[ $form ] = $fields;
		}

		foreach ( $enquiry_zaps as $zap_key => $zap ) {
			wte_zapier_curl( 'new_enquiry', $enquiry_args, $zap['url'] );
		}
	}

}
