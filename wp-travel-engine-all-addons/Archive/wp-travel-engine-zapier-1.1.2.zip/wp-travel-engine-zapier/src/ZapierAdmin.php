<?php
/**
 * Admin area settings and hooks.
 *
 * @package WP_Zapier
 * @subpackage  WP_Zapier
 */

namespace WTE_Zapier;

defined( 'ABSPATH' ) || exit;

/**
 * Global Settings.
 */
class ZapierAdmin {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->init();
	}

	/**
	 * Initialization.
	 *
	 * @since 1.0.0
	 * @access private
	 *
	 * @return void
	 */
	private function init() {
		
		// Initialize hooks.
		$this->init_hooks();
	}

	/**
	 * Initialize hooks.
	 *
	 * @since 1.0.0
	 * @access private
	 *
	 * @return void
	 */
	private function init_hooks() {
		add_filter( 'bulk_actions-edit-booking', [ $this, 'zapier_booking_bulk_actions' ] );
		add_filter( 'handle_bulk_actions-edit-booking', [$this, 'wte_trigger_booking_zaps_bulk_action_handler'], 10, 3 );
		add_action( 'admin_notices', [ $this, 'booking_trigger_zaps_bulk_action_notices' ] );

		add_filter( 'bulk_actions-edit-enquiry', [ $this, 'zapier_enquiry_bulk_actions' ] );
		add_filter( 'handle_bulk_actions-edit-enquiry', [$this, 'wte_trigger_enquiry_zaps_bulk_action_handler'], 10, 3 );
		add_action( 'admin_notices', [ $this, 'enquiry_trigger_zaps_bulk_action_notices' ] );
	}

	/**
	 * Add customer bulk action for migration from post type to users.
	 *
	 * @return void
	 */
	public function zapier_booking_bulk_actions( $bulk_array ) {
		$bulk_array['wte_trigger_booking_zaps'] = __( 'Trigger Booking Zaps', 'wte-zapier' );
		return $bulk_array;
	}

	/**
	 * Handle customers to users bulk action.
	 *
	 * @param [type] $redirect
	 * @param [type] $doaction
	 * @param [type] $object_ids
	 * @return void
	 */
	public function wte_trigger_booking_zaps_bulk_action_handler( $redirect, $doaction, $object_ids ) {

		// let's remove query args first
		$redirect = remove_query_arg( array( 'wte_trigger_booking_zaps_done' ), $redirect );

		// do something for "Migrate to users" bulk action.
		if ( $doaction == 'wte_trigger_booking_zaps' ) {
			foreach ( $object_ids as $post_id ) {
				
				$public_class = new ZapierPublic();
				$public_class->trigger_booking_zaps( $post_id );

			}
			// do not forget to add query args to URL because we will show notices later
			$redirect = add_query_arg(
				'wte_trigger_booking_zaps_done', // just a parameter for URL (we will use $_GET['wte_trigger_booking_zaps_done'] )
				count( $object_ids ), // parameter value - how much posts have been affected
			$redirect );
		}
		return $redirect;
	}

	/**
	 * Add notice after completion of user migration.
	 *
	 * @return void
	 */
	public function booking_trigger_zaps_bulk_action_notices() {
		// first of all we have to make a message,
		// of course it could be just "Posts updated." like this:
		if ( ! empty( $_REQUEST['wte_trigger_booking_zaps_done'] ) ) {
			echo '<div id="message" class="updated notice is-dismissible">
				<p>'. esc_html__( 'Booking Zaps triggered for selected bookings.', 'wte-zapier' ) .'</p>
			</div>';
		}
	}

	/**
	 * Add customer bulk action for migration from post type to users.
	 *
	 * @return void
	 */
	public function zapier_enquiry_bulk_actions( $bulk_array ) {
		$bulk_array['wte_trigger_enquiry_zaps'] = __( 'Trigger Enquiry Zaps', 'wte-zapier' );
		return $bulk_array;
	}

	/**
	 * Handle customers to users bulk action.
	 *
	 * @param [type] $redirect
	 * @param [type] $doaction
	 * @param [type] $object_ids
	 * @return void
	 */
	public function wte_trigger_enquiry_zaps_bulk_action_handler( $redirect, $doaction, $object_ids ) {

		// let's remove query args first
		$redirect = remove_query_arg( array( 'wte_trigger_enquiry_zaps_done' ), $redirect );

		// do something for "Migrate to users" bulk action.
		if ( $doaction == 'wte_trigger_enquiry_zaps' ) {
			foreach ( $object_ids as $post_id ) {
				
				$public_class = new ZapierPublic();
				$public_class->trigger_enquiry_zaps( $post_id );

			}
			// do not forget to add query args to URL because we will show notices later
			$redirect = add_query_arg(
				'wte_trigger_enquiry_zaps_done', // just a parameter for URL (we will use $_GET['wte_trigger_enquiry_zaps_done'] )
				count( $object_ids ), // parameter value - how much posts have been affected
			$redirect );
		}
		return $redirect;
	}

	/**
	 * Add notice after completion of user migration.
	 *
	 * @return void
	 */
	public function enquiry_trigger_zaps_bulk_action_notices() {
		// first of all we have to make a message,
		// of course it could be just "Posts updated." like this:
		if ( ! empty( $_REQUEST['wte_trigger_enquiry_zaps_done'] ) ) {
			echo '<div id="message" class="updated notice is-dismissible">
				<p>'. esc_html__( 'Enquiry Zaps triggered for selected enquiries.', 'wte-zapier' ) .'</p>
			</div>';
		}
	}

}
