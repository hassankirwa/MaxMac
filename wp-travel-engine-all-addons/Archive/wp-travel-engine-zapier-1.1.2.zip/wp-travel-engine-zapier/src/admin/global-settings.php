<?php
/**
 * Global Settings for zapier addon.
 * 
 * @package WTE_Zapier
 */
$options              = wp_travel_engine_get_settings();
$automate_booking_zap = isset( $options['zapier']['enable_automation_booking'] ) ? $options['zapier']['enable_automation_booking'] : 'no';
$automate_enquiry_zap = isset( $options['zapier']['enable_automation_enquiry'] ) ? $options['zapier']['enable_automation_enquiry'] : 'no';
$booking_zaps         = isset( $options['zapier']['booking_zaps'] ) && is_array( $options['zapier']['booking_zaps'] ) ? $options['zapier']['booking_zaps'] : array();
$enquiry_zaps         = isset( $options['zapier']['enquiry_zaps'] ) && is_array( $options['zapier']['enquiry_zaps'] ) ? $options['zapier']['enquiry_zaps'] : array();
?>
<div class="wpte-field wpte-checkbox advance-checkbox">
    <label class="wpte-field-label"  for="wp_travel_engine_settings[zapier][enable_automation_booking]"><?php _e('Enable Automation for Bookings','wte-zapier');?></label>
    <input type="hidden" name="wp_travel_engine_settings[zapier][enable_automation_booking]" value="no">
    <div class="wpte-checkbox-wrap">
        <input type="checkbox" id="wp_travel_engine_settings[zapier][enable_automation_booking]" name="wp_travel_engine_settings[zapier][enable_automation_booking]" value="yes" <?php checked( $automate_booking_zap, 'yes' ); ?>>
    <label for="wp_travel_engine_settings[zapier][enable_automation_booking]" class="checkbox-label"></label>
    </div>
    <span class="wpte-tooltip"><?php _e('Check this option to automatically trigger booking Zaps when new booking is created.','wte-zapier');?></span>
</div>

<div class="wpte-field wpte-checkbox advance-checkbox">
    <label class="wpte-field-label"  for="wp_travel_engine_settings[zapier][enable_automation_enquiry]"><?php _e('Enable Automation for Enquiries','wte-zapier');?></label>
    <input type="hidden" name="wp_travel_engine_settings[zapier][enable_automation_enquiry]" value="no">
    <div class="wpte-checkbox-wrap">
        <input type="checkbox" id="wp_travel_engine_settings[zapier][enable_automation_enquiry]" name="wp_travel_engine_settings[zapier][enable_automation_enquiry]" value="yes" <?php checked( $automate_enquiry_zap, 'yes' ); ?>>
    <label for="wp_travel_engine_settings[zapier][enable_automation_enquiry]" class="checkbox-label"></label>
    </div>
    <span class="wpte-tooltip"><?php _e('Check this option to automatically trigger enquiry Zaps when new enquiry is created.','wte-zapier');?></span>
</div>

<div class="wpte-form-content">
    <div class="wpte-repeater-wrap">
        <div class="wpte-repeater-h wpte-rep-heading">
            <label class="wpte-field-label"><?php _e('Booking Zapier Webhooks','wte-zapier');?></label>
            <span class="wpte-tooltip"><?php _e('Enter the name and webhook URLs for zaps used for bookings','wte-zapier');?></span>
        </div>
        <div class="wpte-block-content trip_info-content">
			<div class="wpte-repeater-wrap">
                <div class="wpte-repeater-block-holder" id="wpte-booking-zapier-wbhk-rep-holder">
                    <?php foreach( $booking_zaps as $key => $zap ) { 
                        $zap_name = isset( $zap['name'] ) && ! empty( $zap['name'] ) ? $zap['name'] : false;
                        $zap_url  = isset( $zap['url'] ) && ! empty( $zap['url'] ) ? $zap['url'] : false;
                        
                        if ( $zap_name && $zap_url ) {
                    ?>
                            <div class="wpte-repeater-block wpte-sortable wpte-zapier-wbhk-rep wpte-booking-zapier-wbhk-rep">
                                <div class="wpte-field">
                                    <input name="wp_travel_engine_settings[zapier][booking_zaps][<?php echo esc_attr( $key ); ?>][name]" value="<?php echo esc_attr( $zap['name'] ); ?>" placeholder="<?php esc_attr_e( 'webhook name', 'wte-zapier' ); ?>" type="text" />
                                </div>
                                <div class="wpte-field">
                                    <input name="wp_travel_engine_settings[zapier][booking_zaps][<?php echo esc_attr( $key ); ?>][url]" value="<?php echo esc_url( $zap['url'] ); ?>" placeholder="<?php esc_attr_e( 'webhook URL', 'wte-zapier' ); ?>" type="text"/>
                                </div>
                                <div class="wpte-system-btns">
                                    <button title="<?php esc_attr_e( 'Delete', 'wte-zapier' ) ?>" class="wpte-delete wpte-remove-wbhkrep"></button>
                                    <button data-hook-type="booking" data-hook-id="<?php echo esc_attr( $key ); ?>" title="<?php esc_attr_e( 'Trigger webhook', 'wte-zapier' ) ?>" class="wpte-test-wbhkrep"><i class="fa fa-check-circle"></i></button>
                                </div>
                            </div>
                    <?php 
                        }
                    } ?>
                </div>
            </div> <!-- .wpte-repeater-wrap -->
            <div class="wpte-add-btn-wrap">
                <button data-name="booking_zaps" class="wpte-add-btn add-wte-booking-zapier-webhook"><?php echo esc_html( 'Add zapier webhook' ); ?></button>
            </div>
            <script type="text/html" id="tmpl-wte-booking-zapier-webhooks-rep">
                <div class="wpte-repeater-block wpte-sortable wpte-zapier-wbhk-rep wpte-booking-zapier-wbhk-rep">
                    <div class="wpte-field">
                        <input name="wp_travel_engine_settings[zapier][booking_zaps][{{data.index}}][name]" placeholder="<?php esc_attr_e( 'webhook name', 'wte-zapier' ); ?>" type="text" />
                    </div>
                    <div class="wpte-field">
                        <input name="wp_travel_engine_settings[zapier][booking_zaps][{{data.index}}][url]" placeholder="<?php esc_attr_e( 'webhook URL', 'wte-zapier' ); ?>" type="text"/>
                    </div>
                    <div class="wpte-system-btns">
                        <button title="<?php esc_html_e( 'Delete', 'wte-zapier' ); ?>" class="wpte-delete wpte-remove-wbhkrep"></button>
                        <button data-hook-type="booking" data-hook-id="{{data.index}}" title="<?php esc_attr_e( 'Trigger webhook', 'wte-zapier' ) ?>" class="wpte-test-wbhkrep"><i class="fa fa-check-circle"></i></button>
                    </div>
                </div>
            </script>
		</div>  
    </div>
    <div class="wpte-repeater-wrap">
        <div class="wpte-repeater-h wpte-rep-heading">
            <label class="wpte-field-label"><?php _e('Enquiry Zapier Webhooks','wte-zapier');?></label>
            <span class="wpte-tooltip"><?php _e('Enter the name and webhook URLs for zaps used for enquiries.','wte-zapier');?></span>
        </div>
        <div class="wpte-block-content trip_info-content">
			<div class="wpte-repeater-wrap">
                <div class="wpte-repeater-block-holder" id="wpte-enquiry-zapier-wbhk-rep-holder">
                    <?php foreach( $enquiry_zaps as $key => $zap ) {
                        $zap_name = isset( $zap['name'] ) && ! empty( $zap['name'] ) ? $zap['name'] : false;
                        $zap_url  = isset( $zap['url'] ) && ! empty( $zap['url'] ) ? $zap['url'] : false;

                        if ( $zap_name && $zap_url ) {
                    ?>
                            <div class="wpte-repeater-block wpte-sortable wpte-zapier-wbhk-rep wpte-enquiry-zapier-wbhk-rep">
                                <div class="wpte-field">
                                    <input name="wp_travel_engine_settings[zapier][enquiry_zaps][<?php echo esc_attr( $key ); ?>][name]" value="<?php echo esc_attr( $zap['name'] ); ?>" placeholder="<?php esc_attr_e( 'webhook name', 'wte-zapier' ); ?>" type="text" />
                                </div>
                                <div class="wpte-field">
                                    <input name="wp_travel_engine_settings[zapier][enquiry_zaps][<?php echo esc_attr( $key ); ?>][url]" value="<?php echo esc_url( $zap['url'] ); ?>" placeholder="<?php esc_attr_e( 'webhook URL', 'wte-zapier' ); ?>" type="text"/>
                                </div>
                                <div class="wpte-system-btns">
                                    <button title="<?php esc_attr_e( 'Delete', 'wte-zapier' ) ?>" class="wpte-delete wpte-remove-wbhkrep"></button>
                                    <button data-hook-type="enquiry" data-hook-id="<?php echo esc_attr( $key ); ?>" title="<?php esc_attr_e( 'Trigger webhook', 'wte-zapier' ) ?>" class="wpte-test-wbhkrep"><i class="fa fa-check-circle"></i></button>
                                </div>
                            </div>
                    <?php 
                        }
                    } ?>
                </div>
            </div> <!-- .wpte-repeater-wrap -->
            <div class="wpte-add-btn-wrap">
                <button data-name="enquiry_zaps" class="wpte-add-btn add-wte-enquiry-zapier-webhook"><?php echo esc_html( 'Add zapier webhook' ); ?></button>
            </div>
            <script type="text/html" id="tmpl-wte-enquiry-zapier-webhooks-rep">
                <div class="wpte-repeater-block wpte-sortable wpte-zapier-wbhk-rep wpte-enquiry-zapier-wbhk-rep">
                    <div class="wpte-field">
                        <input name="wp_travel_engine_settings[zapier][enquiry_zaps][{{data.index}}][name]" placeholder="<?php esc_attr_e( 'webhook name', 'wte-zapier' ); ?>" type="text"/>
                    </div>
                    <div class="wpte-field">
                        <input name="wp_travel_engine_settings[zapier][enquiry_zaps][{{data.index}}][url]" placeholder="<?php esc_attr_e( 'webhook URL', 'wte-zapier' ); ?>" type="text"/>
                    </div>
                    <div class="wpte-system-btns">
                        <button title="<?php esc_html_e( 'Delete', 'wte-zapier' ); ?>" class="wpte-delete wpte-remove-wbhkrep"></button>
                        <button data-hook-type="enquiry" data-hook-id="{{data.index}}" title="<?php esc_attr_e( 'Trigger webhook', 'wte-zapier' ) ?>" class="wpte-test-wbhkrep"><i class="fa fa-check-circle"></i></button>
                    </div>
                </div>
            </script>
		</div>  
    </div>
</div>