<?php
/**
 * Main ZapierCore class
 *
 * @package WTE_Zapier
 */

namespace WTE_Zapier;

defined( 'ABSPATH' ) || exit;

/**
 * Main ZapierCore Cass.
 *
 * @class ZapierCore
 */
final class ZapierCore {
	/**
	 * ZapierCore verison.
	 *
	 * @var string
	 */
	public $version = '1.1.2';

	/**
	 * The single instance of the class.
	 *
	 * @var ZapierCore
	 * @since 1.0.0
	 */
	protected static $_instance = null;

	/**
	 * Main ZapierCore Instance.
	 *
	 * Ensures only one instance of ZapierCore is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 * @static
	 * @see RUN_DEL_RECIPIE()
	 * @return ZapierCore - Main instance.
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * ZapierCore Constructor.
	 */
	public function __construct() {

        $this->define_constants();
		$this->init_hooks();
		$this->includes();

		// Load class instances.
		$this->global_settings = new GlobalSettings();
		$this->admin_settings  = new ZapierAdmin();
		$this->public_hooks    = new ZapierPublic();
	}

	/**
	 * When WP has loaded all plugins, trigger the 'wp_zapier_admin; hook.
	 *
	 * This ensures 'wp_zapier_admin' is called only after all the other plugins
	 * are loaded, to avoid issues caused by plugin directory naming changing
	 * the load order.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function on_plugins_loaded() {
		do_action( 'wp_zapier_admin' );
	}

	/**
	 * Hook into actions and filters.
	 *
	 * @since 1.0.0
	 * @access private
	 */
	private function init_hooks() {
		add_action( 'init', array( $this, 'init' ) );
		add_action( 'admin_notices', array( $this, 'check_dependency' ) );
	}

	/**
	 * Check dependency.
	 *
	 * @return void
	 */
	public function check_dependency() {

		if ( ! class_exists( 'Wp_Travel_Engine' ) || ! $this->meets_requirements() ) {
			echo '<div class="error">';
			echo wp_kses_post( '
				<p>
					<strong>
						WP Travel Engine - Zapier
					</strong>
					requires the <a href="https://wptravelengine.com" target="__blank">WP Travel Engine</a>
					<b>version - 4.0.6 or later</b> to work.
					Please install and activate the latest WP Travel Engine plugin first.
					<b>WP Travel Engine - Zapier will now be deactivated now.</b>
				</p>' );
			echo '</div>';

			// Deactivate Plugins.
			deactivate_plugins( plugin_basename( WTE_ZAPIER_PLUGIN_FILE ) );
		}

	}

	/**
	 * Define WTE_FORM_EDITOR Constants.
	 *
	 * @since 1.0.0
	 * @access private
	 */
	private function define_constants() {
		$this->define( 'WTE_ZAPIER_PLUGIN_NAME', 'wte-zapier' );
		$this->define( 'WTE_ZAPIER_ABSPATH', dirname( WTE_ZAPIER_PLUGIN_FILE ) . '/' );
		$this->define( 'WTE_ZAPIER_PLUGIN_BASENAME', plugin_basename( WTE_ZAPIER_PLUGIN_FILE ) );
		$this->define( 'WTE_ZAPIER_VERSION', $this->version );
		$this->define( 'WTE_ZAPIER_TEMPLATE_DEBUG_MODE', false );
		$this->define( 'WTE_ZAPIER_PLUGIN_URL', $this->plugin_url() );
	}

	/**
	 * Define constant if not already set.
	 *
	 * @param string      $name       Constant name.
	 * @param string|bool $value      Constant value.
	 * @return void
	 */
	private function define( $name, $value ) {
		if ( ! defined( $name ) ) {
			define( $name, $value );
		}
	}

	/**
	 * Init ZapierCore when WordPress initializes.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function init() {
		// Before init action.
		do_action( 'before_delicious_recipies_init' );

		// Set up localization.
		$this->load_plugin_textdomain();

	}

	/**
	 * Include required files.
	 *
	 * @return void
	 */
	public function includes() {
		if ( is_admin() ) {
			require plugin_dir_path( WTE_ZAPIER_PLUGIN_FILE ) . '/src/updater/wte-zapier-updater.php';
		}
	}

	/**
	 * Enqueue Frontend scripts.
	 *
	 * @return void
	 */
	public function enqueue_scripts() {

	}

	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 *
	 * Note: the first-loaded translation file overrides any following ones if the same translation is present.
	 *
	 * Locales found in:
	 *      - WP_LANG_DIR/wte-zapier/wte-zapier-LOCALE.mo
	 *      - WP_LANG_DIR/plugins/wte-zapier-LOCALE.mo
	 */
	public function load_plugin_textdomain() {
		if ( function_exists( 'determine_locale' ) ) {
			$locale = determine_locale();
		} else {
			// TODO Remove when start supporting WP 5.0 or later.
			$locale = is_admin() ? get_user_locale() : get_locale();
		}

		$locale = apply_filters( 'plugin_locale', $locale, 'wte-zapier' );

		unload_textdomain( 'wte-zapier' );
		load_textdomain( 'wte-zapier', WP_LANG_DIR . '/wte-zapier/wte-zapier-' . $locale . '.mo' );
		load_plugin_textdomain(
			'wte-zapier',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);
	}

	/**
	 * Get the plugin URL.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string
	 */
	public function plugin_url() {
		return untrailingslashit( plugins_url( '/', WTE_ZAPIER_PLUGIN_FILE ) );
	}

	/**
	 * Get the plugin path.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string
	 */
	public function plugin_path() {
		return untrailingslashit( plugin_dir_path( WTE_ZAPIER_PLUGIN_FILE ) );
	}

	/**
	 * Get Ajax URL.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string
	 */
	public function ajax_url() {
		return admin_url( 'admin-ajax.php', 'relative' );
	}

	/**
	 * Get the template path.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string
	 */
	public function template_path() {
		return apply_filters( 'wte_zapier_template_path', '/wte-zapier' );
	}

	/**
	 * Output error message and disable plugin if requirements are not met.
	 *
	 * This fires on admin_notices.
	 *
	 * @since 1.0.0
	 */
	public function maybe_disable_plugin() {

		if ( ! $this->meets_requirements() ) {
			// Deactivate our plugin
			deactivate_plugins( WTE_ZAPIER_PLUGIN_BASENAME );
		}
	}

	/**
	 * Check if all plugin requirements are met.
	 *
	 * @since 1.0.0
	 *
	 * @return bool True if requirements are met, otherwise false.
	 */
	private function meets_requirements() {
		return ( class_exists( 'WP_Travel_Engine' ) && defined( 'WP_TRAVEL_ENGINE_VERSION' ) && version_compare( WP_TRAVEL_ENGINE_VERSION, '4.0.6', '>=' ) );
	}

}
