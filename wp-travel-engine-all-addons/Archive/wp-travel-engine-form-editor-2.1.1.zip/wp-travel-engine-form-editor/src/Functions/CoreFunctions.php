<?php
/**
 * WTE_Form_Editor Core Functions.
 *
 * General core functions avaiable on both the front-end and backend.
 *
 * @package WTE_Form_Editor\Functions
 *
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH') ) {
exit;
}

/**
 * Define a constant if is is not already defined.
 *
 * @since 1.0.0
 * @param string $name Constant name.
 * @param string $value Constant value.
 */
function wtefe_maybe_define_constant( $name, $value ) {
	if ( ! defined( $name ) ) {
		define( $name, $value );
	}
}

/**
 * Wrapper for wptfe_doing_it_wrong.
 *
 * @since 1.0.0
 *
 * @param string $function Function used.
 * @param string $message Message to log.
 * @param string $version Version the message added in.
 *
 * @return void
 */

/**
 * Locate a template and return the path for inclusion.
 *
 * This is the load order:
 *
 * yourtheme/$template_path/$template_name
 * yourtheme/$template_name
 * $default_path/$template_name
 *
 * @since 1.0.0
 *
 * @param string $template_name Template name.
 * @param string $template_path Template path. (default: '').
 * @param string $default_path Default path. (default: '').
 *
 * @return string Template path.
 */
function wtefe_locate_template( $template_name, $template_path = '', $default_path = '' ) {
	if ( ! $template_path ) {
		$template_path = WTE_FE()->template_path();
	}

	if ( ! $default_path ) {
		$default_path = WTE_FE()->plugin_path() . '/templates/';
	}

	// Look within passed path within the theme - this is priority.
	$template = locate_template(
		array(
			trailingslashit(  $template_path ) . $template_name,
			$template_name
		)
	);

	// Get default template.
	if ( ! $template || WTE_FORM_EDITOR_TEMPLATE_DEBUG_MODE ) {
		$template = $default_path . $template_name;
	}

	// Return what we found.
	return apply_filters( 'wptfe_locate_template', $template, $template_name, $template_path );
}

/**
 * Get other templates (e.g. article attributes) passing attributes and including the file.
 *
 * @since 1.0.0
 *
 * @param string $template_name   Template name.
 * @param array  $args            Arguments. (default: array).
 * @param string $template_path   Template path. (default: '').
 * @param string $default_path    Default path. (default: '').
 */
function wtefe_get_template( $template_name, $args = array(), $template_path = '', $default_path = '' ) {
	$cache_key = sanitize_key ( implode( '-', array( 'template', $template_name, $template_path, $default_path, WTE_FORM_EDITOR_VERSION ) ) );
	$template = (string) wp_cache_get( $cache_key, 'wte-form-editor' );

	if ( ! $template ) {
		$template = wtefe_locate_template( $template_name, $template_path, $default_path );
		wp_cache_set( $cache_key, $template, 'wte-form-editor' );
	}

	// Allow 3rd party plugin filter template file from their plugin.
	$filter_template = apply_filters( 'wtefe_get_template', $template, $template_name, $args, $template_path, $default_path );

	if( $filter_template !== $template ) {
		if ( ! file_exists( $filter_template ) ) {
			/* translators: %s template */
			wtefe_doing_it_wrong( __FUNCTION__, sprintf( __( '%s does not exist.', 'wte-form-editor' ), '<code>' . $template . '</code>' ), '1.0.0' );
			return;
		}
		$template = $filter_template;
	}

	$action_args = array(
		'template_name' => $template_name,
		'template_path' => $template_path,
		'located'       => $template,
		'args'          => $args,
	);

	if ( ! empty( $args ) && is_array( $args ) ) {
		if ( isset( $args['action_args'] ) ) {
			wtefe_doing_it_wrong(
				__FUNCTION__,
				__( 'action_args should not be overwritten when calling wtefe_get_template.', 'wte-form-editor' ),
				'1.0.0'
			);
			unset( $args['action_args'] );
		}
		extract( $args );
	}

	do_action( 'wtefe_before_template_part', $action_args['template_name'], $action_args['template_path'], $action_args['located'], $action_args['args'] );

	include $action_args['located'];

	do_action( 'wtefe_after_template_part', $action_args['template_name'], $action_args['template_path'], $action_args['located'], $action_args['args'] );
}

/**
 * Get template part.
 *
 * WTE_FORM_EDITOR_TEMPLATE_DEBUG_MODE will prevent overrides in themes from taking priority.
 *
 * @param mixed $slug Template slug.
 * @param string $name Template name (default: '').
 *
 */
function wptfe_get_template_part( $slug, $name = '' ) {
	$cache_key = sanitize_key( implode( '-', array( 'template-part', $slug, $name, WTE_FORM_EDITOR_VERSION ) ) );
	$template  = (string) wp_cache_get( $cache_key, 'wte-form-editor' );

	if ( ! $template ) {
		if ( $name ) {
			$template = WTE_FORM_EDITOR_TEMPLATE_DEBUG_MODE ? '' : locate_template(
				array(
					"{$slug}-{$name}.php",
					WTE_FE()->template_path() . "{$slug}-{$name}.php",
				)
			);

			if ( ! $template ) {
				$fallback = WTE_FE()->plugin_path() . "/templates/{$slug}-{$name}.php";
				$template = file_exists( $fallback ) ? $fallback : '';
			}
		}

		if ( ! $template ) {
			// If template file doesn't exist, look in yourtheme/slug.php and yourtheme/affiliate-engine/slug.php.
			$template = WTE_FORM_EDITOR_TEMPLATE_DEBUG_MODE ? '' : locate_template(
				array(
					"{$slug}.php",
					WTE_FE()->template_path() . "{$slug}.php",
				)
			);
		}

		wp_cache_set( $cache_key, $template, 'wte-form-editor' );
	}

	// Allow 3rd party plugins to filter template file from their plugin.
	$template = apply_filters( 'wptfe_get_template_part', $template, $slug, $name );

	if ( $template ) {
		load_template( $template, false );
	}
}

/**
 * Like wptfe_get_template, but return the HTML instaed of outputting.
 *
 * @see wptfe_get_template
 * @since 1.0.0
 *
 * @param string $template_name Template name.
 * @param array $args           Arguments. (default: array).
 * @param string $template_path Template path. (default: '').
 * @param string $default_path  Default path. (default: '').
 *
 * @return string.
 */
function wptfe_get_template_html( $template_name, $args = array(), $template_path = '', $default_path = '' ) {
	ob_start();
    wptfe_get_template( $template_name, $args, $template_path, $default_path );
	return ob_get_clean();
}

/**
 * Merge user defined arguments into defaults array.
 * Similar to wp_parse_args() just a bit extended to work with multidimensional arrays.
 *
 * @since 1.0.0
 *
 * @param array $args      (Required) Value to merge with $defaults.
 * @param array $defaults  Array that serves as the defaults. Default value: ''


 * @return void
 */
function wptfe_wp_parse_args( &$args, $defaults = '' ) {
	$args     = (array) $args;
	$defaults = (array) $defaults;
	$result   = $defaults;

	foreach ( $args as $key => &$value ) {
		if ( is_array( $value ) && isset( $result[ $key ] ) ) {
			$result[ $key ] = wptfe_wp_parse_args( $value, $result[ $key ] );
		} else {
			$result[ $key ] = $value;
		}
	}
	return $result;
}

/**
 * Generate array of any.
 *
 * @since 1.0.0
 *
 * @param any $arr    Multipe object to create.
 * @param int $count  Number of objects.
 * @return array      List of object passed.
 */
function wptfe_generate_arrays( $arr, $count ) {
	$result = array();

	for( $index = 0; $index < $count; $index++ ) {
		array_push( $result, $arr );
	}

	return $result;
}
