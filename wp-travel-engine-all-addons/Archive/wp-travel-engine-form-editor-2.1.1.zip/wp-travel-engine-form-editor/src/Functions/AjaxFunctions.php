<?php
/**
 * AJAX Functions.
 *
 * @package WTE_Form_Editor
 * @subpackage  WTE_Form_Editor
 */

namespace Wfe;

defined( 'ABSPATH' ) || exit;

/**
 * Global Settings.
 */
class AjaxFunctions {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->init();
	}

	/**
	 * Initialization.
	 *
	 * @since 1.0.0
	 * @access private
	 *
	 * @return void
	 */
	private function init() {
		// Initialize hooks.
		$this->init_hooks();

		// Allow 3rd party to remove hooks.
		do_action( 'wfe_ajaxfunctions_unhook', $this );
	}

	/**
	 * Initialize hooks.
	 *
	 * @since 1.0.0
	 * @access private
	 *
	 * @return void
	 */
	private function init_hooks() {
		add_action( 'wp_ajax_wte_form_editor_save_fields', array( $this, 'save_settings_all_fields' ) );
	}

	/**
	 * Save settings ajax callback
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function save_settings_all_fields() {

		if ( ! isset( $_POST['action'] ) || 'wte_form_editor_save_fields' !== $_POST['action'] ) {
			wp_send_json_error( array( 'message' => __( 'Save failed. Invalid action supplied.', 'wte-form-editor' ) ) );
		}

		if ( ! isset( $_POST['wte_form_editor_save_fields_nonce'] ) || ! wp_verify_nonce( $_POST['wte_form_editor_save_fields_nonce'], 'wte_form_editor_save_form_fields_action' ) ) {
			wp_send_json_error( array( 'message' => __( 'Save failed. Nonce verification failed.', 'wte-form-editor' ) ) );
		}

		if ( isset( $_POST['wpte_form_editor_form_fields'] ) && ! empty( $_POST['wpte_form_editor_form_fields'] ) ) {
			$wpte_form_editor_form_fields = stripslashes_deep( $_POST['wpte_form_editor_form_fields'] );
			update_option( 'wpte_form_editor_form_fields', $wpte_form_editor_form_fields );
			// Send JSON.
			wp_send_json_success( array( 'message' => __( 'Settings saved. All form fields updated.', 'wte-form-editor' ) ) );
		}

		die;

	}

}

new AjaxFunctions();
