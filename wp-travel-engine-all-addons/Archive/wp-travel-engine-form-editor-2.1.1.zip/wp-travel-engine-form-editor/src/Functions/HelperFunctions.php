<?php
/**
 * Helper functions for our plugin.
 * 
 * @package WTE_Form_Editor
 */

/**
 * Get text type fields for form generator.
 *
 * @return array $text_fields
 */
function wte_form_editor_get_text_fields( $text_fields = array() ) {

    $text_fields = array(

        'field_type' => array(
            'type'    => 'hidden',
            'default' => 'text',
            'name'    => 'wte_form_editor_fields[{{data.form_name}}][{{data.index}}][field_type]',
            'id'      => 'wte_form_editor_fields[{{data.form_name}}][{{data.index}}][field_type]',
        ),

        'field_label' => array(

            'type'          => 'text',
            'wrapper_class' => 'wpte-fe-field fe-text-field',
            'field_label'   => __( 'Field Label:', 'wte-form-editor' ),
            'name'          => 'wte_form_editor_fields[{{data.form_name}}][{{data.index}}][field_label]',
            'id'            => 'wte_form_editor_fields[{{data.form_name}}][{{data.index}}][field_label]',
            'attributes'    => array(
                'wte_bind' => 'field_label_{{data.index}}',
                'data-wte_update_field_name' => 'wte_form_editor_fields_{{data.form_name}}_{{data.index}}_field_name',
                'data-wte_update_field_id'   => 'wte_form_editor_fields_{{data.form_name}}_{{data.index}}_field_id',
            ),
            'validations'   => array(
                'required' => true
            ),
        ),

        'field_name' => array(
            'type'          => 'text',
            'wrapper_class' => 'wpte-fe-field fe-text-field',
            'field_label'   => __( 'Field Name:', 'wte-form-editor' ),
            'name'          => 'wte_form_editor_fields[{{data.form_name}}][{{data.index}}][field_name]',
            'id'            => 'wte_form_editor_fields_{{data.form_name}}_{{data.index}}_field_name',
            'validations'   => array(
                'required' => true
            ),
            'attributes'   => array(
                'data-requires-snakecase' => 'true',
            )
        ),

        'default_value' => array(

            'type'          => 'text',
            'wrapper_class' => 'wpte-fe-field fe-text-field',
            'field_label'   => __( 'Default Value:', 'wte-form-editor' ),
            'name'          => 'wte_form_editor_fields[{{data.form_name}}][{{data.index}}][default_value]',
            'id'            => 'wte_form_editor_fields[{{data.form_name}}][{{data.index}}][default_value]',
        ),

        'field_id' => array(
            'type'          => 'text',
            'wrapper_class' => 'wpte-fe-field fe-text-field',
            'field_label'   => __( 'Field ID:', 'wte-form-editor' ),
            'name'          => 'wte_form_editor_fields[{{data.form_name}}][{{data.index}}][field_id]',
            'id'            => 'wte_form_editor_fields_{{data.form_name}}_{{data.index}}_field_id',
            'validations'   => array(
                'required' => true
            ),
            'attributes' => array(
                'wte_update_field_id'     => 'field_id_{{data.index}}',
                'data-requires-kebabcase' => 'true',
            ),
        ),

        'validation' => array(
            'type'          => 'checkbox',
            'wrapper_class' => 'wpte-fe-field fe-checkbox',
            'field_label'   => __( 'Validation:', 'wte-form-editor' ),
            'id'            => 'fe-required',
            'option_attributes'    => array(
                'data-multiple' => 'true',
            ),
            'options' => array(
                'true' => __( 'Required', 'wte-form-editor' ),
            ),
            'name' => 'wte_form_editor_fields[{{data.form_name}}][{{data.index}}][validation]',
        ),

        'placeholder' => array(
            'type'          => 'text',
            'wrapper_class' => 'wpte-fe-field fe-text-field',
            'field_label'   => __( 'Placeholder:', 'wte-form-editor' ),
            'name'          => 'wte_form_editor_fields[{{data.form_name}}][{{data.index}}][placeholder]',
            'id'            => 'wte_form_editor_fields[{{data.form_name}}][{{data.index}}][placeholder]',
        )
    );

    return apply_filters( 'wte_form_editor_text_type_fields', $text_fields );

}
/**
 * Get textarea field type fields
 *
 * @return void
 */
function wte_form_editor_get_textarea_fields( $textarea_fields = array() ) {

    $textarea_fields = wte_form_editor_get_text_fields();

    $textarea_fields['field_type'] = array(

        'type'    => 'hidden',
        'default' => 'textarea',
        'name'    => 'wte_form_editor_fields[{{data.form_name}}][{{data.index}}][field_type]',
        'id'      => 'wte_form_editor_fields[{{data.form_name}}][{{data.index}}][field_type]',

    );

    $textarea_fields['rows'] = array(

        'type'    => 'number',
        'field_label' => __( 'Rows', 'wte-form-editor' ),
        'wrapper_class' => 'wpte-fe-field fe-checkbox',
        'name'    => 'wte_form_editor_fields[{{data.form_name}}][{{data.index}}][rows]',
        'id'      => 'wte_form_editor_fields[{{data.form_name}}][{{data.index}}][rows]',
        'validations' => array(
            'min' => '1',
        ),

    );

    $textarea_fields['cols'] = array(

        'type'    => 'number',
        'field_label' => __( 'Cols', 'wte-form-editor' ),
        'wrapper_class' => 'wpte-fe-field fe-checkbox',
        'name'    => 'wte_form_editor_fields[{{data.form_name}}][{{data.index}}][cols]',
        'id'      => 'wte_form_editor_fields[{{data.form_name}}][{{data.index}}][cols]',
        'validations' => array(
            'min' => '1',
        ),

    );

    return apply_filters( 'wte_form_editor_textarea_type_fields', $textarea_fields );

}

/**
 * Get select field type fields
 *
 * @return void
 */
function wte_form_editor_get_select_fields( $select_fields = array() ) {

    $select_fields = wte_form_editor_get_text_fields();

    $select_fields['field_type'] = array(

        'type'    => 'hidden',
        'default' => 'select',
        'name'    => 'wte_form_editor_fields[{{data.form_name}}][{{data.index}}][field_type]',
        'id'      => 'wte_form_editor_fields[{{data.form_name}}][{{data.index}}][field_type]',

    );

    return apply_filters( 'wte_form_editor_select_type_fields', $select_fields );

}

/**
 * Get Checkbox field type fields
 *
 * @return void
 */
function wte_form_editor_get_checkbox_fields( $checkbox_fields = array() ) {

    $checkbox_fields = wte_form_editor_get_text_fields();

    $checkbox_fields['field_type'] = array(

        'type'    => 'hidden',
        'default' => 'checkbox',
        'name'    => 'wte_form_editor_fields[{{data.form_name}}][{{data.index}}][field_type]',
        'id'      => 'wte_form_editor_fields[{{data.form_name}}][{{data.index}}][field_type]',

    );

    return apply_filters( 'wte_form_editor_checkbox_type_fields', $checkbox_fields );

}

/**
 * Heading tags.
 * @return array
 */
function wtefe_heading_tags() {
    $headings = array(
        'h1' => 'H1',
        'h2' => 'H2',
        'h3' => 'H3',
        'h4' => 'H4',
        'h5' => 'H5',
        'h6' => 'H6',
        'p' => 'P',
        'em' => 'EM',
        'div' => 'DIV',
    );
    return $headings;
}

/**
 * Field editor popup fields.
 *
 * @return array Fields.
 */
function wtefe_get_popup_fields() {
    
    $fields_array = array(
        'wte_form_editor_label' => array(
            'type'        => 'text',
            'field_label' => __( 'Label', 'wte-form-editor' ),
            'name'        => 'wte_form_editor_label',
            'id'          => 'wte_form_editor_label',
            'wrapper_class' => 'wtefe_popup_fld_contl wte_form_editor_label_wrap',
            'validations' => array(
                'required' => true,
            ),
            'attributes' => array(
                'placeholder' => __( 'Enter field label', 'wte-form-editor' ),
                'data-wte_update_field_name' => 'wte_form_editor_name',
                'data-wte_update_field_id'   => 'wte_form_editor_id',
            ),
            'priority' => 10,
            'show_in' => array(
                'all'
            ),
        ),
        'wte_form_editor_name' => array(
            'type'        => 'text',
            'field_label'       => __( 'Name', 'wte-form-editor' ),
            'name'        => 'wte_form_editor_name',
            'id'          => 'wte_form_editor_name',
            'wrapper_class' => 'wtefe_popup_fld_contl wte_form_editor_name_wrap',
            'validations' => array(
                'required' => true,
            ),
            'attributes' => array(
                'placeholder'            => __( 'Enter field name', 'wte-form-editor' ),
                'data-parsley-validname' => 'true',
                'data-requires-snakecase' => 'true',
            ),
            'priority' => 20,
            'show_in' => array(
                'all'
            ),
        ),
        'wte_form_editor_id' => array(
            'type'        => 'text',
            'field_label'       => __( 'ID', 'wte-form-editor' ),
            'name'        => 'wte_form_editor_id',
            'id'          => 'wte_form_editor_id',
            'wrapper_class' => 'wtefe_popup_fld_contl wte_form_editor_id_wrap',
            'validations' => array(
                'required' => true,
            ),
            'attributes' => array(
                'placeholder'          => __( 'Enter field ID', 'wte-form-editor' ),
                'data-parsley-validid' => 'true',
                'data-requires-kebabcase' => 'true',
            ),
            'priority' => 30,
            'show_in' => array(
                'all'
            ),
        ),
        'wte_form_editor_class' => array(
            'type'       => 'text',
            'field_label'      => __( 'Class', 'wte-form-editor' ),
            'name'       => 'wte_form_editor_class',
            'id'         => 'wte_form_editor_class',
            'wrapper_class' => 'wtefe_popup_fld_contl wte_form_editor_class_wrap',
            'attributes' => array(
                'placeholder' => __( 'Enter field class', 'wte-form-editor' ),
            ),
            'priority' => 40,
            'show_in' => array(
                'all'
            ),
        ),
        'wte_form_editor_placeholder' => array(
            'type'          => 'text',
            'field_label'         => __( 'Placeholder', 'wte-form-editor' ),
            'name'          => 'wte_form_editor_placeholder',
            'id'            => 'wte_form_editor_placeholder',
            'wrapper_class' => 'wtefe_popup_fld_contl wte_form_editor_placeholder_wrap',
            'attributes'    => array(
                'placeholder'   => __( 'Enter field placeholder', 'wte-form-editor' ),
                'data-ishidden' => 'false',
            ),
            'priority' => 60,
            'show_in' => array(
                'text',
                'textarea',
                'tel',
                'number',
                'datepicker',
                'email'
            ),
        ),
        'wte_form_editor_select_options' => array(
            'type'       => 'textarea',
            'field_label'      => __( 'Choices/Options', 'wte-form-editor' ),
            'name'       => 'wte_form_editor_select_options',
            'id'         => 'wte_form_editor_select_options',
            'attributes' => array(
                'placeholder'   => __( 'Enter field Choices/Options one in each new line', 'wte-form-editor' ),
                'data-ishidden' => 'true',
            ),
            'wrapper_class' => 'wtefe_popup_fld_contl wte_form_editor_select_options_wrap',
            'priority'      => 70,
            'show_in' => array(
                'select',
                'radio',
                'checkbox'
            ),
        ),
        'wte_form_editor_validation' => array(
            'type'          => 'checkbox',
            'field_label'         => __( 'Validation', 'wte-form-editor' ),
            'name'          => 'wte_form_editor_validation',
            'id'            => 'wte_form_editor_validation',
            'wrapper_class' => 'wtefe_popup_fld_contl wte_form_editor_validation_wrap',
            'options'       => array(
                'required' => __( 'Required', 'wte-form-editor' ),
            ),
            'priority' => 90,
            'show_in' => array(
                'all'
            ),
        ),
        'wte_form_editor_form_name' => array(
            'type' => 'hidden',
            'name' => 'wte_form_editor_form_name',
            'id'   => 'wte_form_editor_form_name',
            'show_in' => array(
                'all'
            ),
        ),
        'wte_form_editor_field_name' => array(
            'type' => 'hidden',
            'name' => 'wte_form_editor_field_name',
            'id'   => 'wte_form_editor_field_name',
            'show_in' => array(
                'all'
            ),
        ),
    );

    return $fields_array;
}

/**
 * Get allowed fields for type.
 *
 * @param [type] $type
 * @return void
 */
function wtefe_get_allowed_fields_for_type( $type ) {

    $fields = wtefe_get_popup_fields();

    if ( ! $type || empty( $type )  ) return array_column( $fields, 'name' );
    
    $allowed_fields = array_filter( $fields, function( $field ) use ( $type ) {
        return $field['show_in'][0] === 'all' || in_array( $type, $field['show_in'] );
    } );

    if ( ! empty( $allowed_fields ) ) {
        return array_column( $allowed_fields, 'name' ); 
    }
    return false;
}

// Active check.
add_filter( 'wpte_is_form_editor_addon_active', '__return_true' );