<?php
/**
 * Google recaptcha field.
 * 
 */
class WP_Travel_Engine_Form_Field_Recaptcha_V2 {
	protected $field;
	protected $field_type = 'grecaptcha_v2';
	function init( $field ) {
		$this->field = $field;
		return $this;
	}

    /**
     * Render output
     *
     * @param boolean $display
     * @return void
     */
	function render( $display = true ) {
		$validations = '';
		if ( isset( $this->field['validations'] ) ) {
			foreach ( $this->field['validations'] as $key => $attr ) {
				$validations .= sprintf( ' %s="%s" data-parsley-%s="%s"', $key, $attr, $key, $attr );
			}
		}
		$attributes = '';
		if ( isset( $this->field['attributes'] ) ) {
			foreach ( $this->field['attributes'] as $attribute => $attribute_val ) {
				$attributes .= sprintf( ' %s="%s" ', $attribute, $attribute_val );
			}
		}

		wp_enqueue_script( 'grecaptcha' );

		$before_field = '';
		if ( isset( $this->field['before_field'] ) ) {
			$before_field_class = isset( $this->field['before_field_class'] ) ? $this->field['before_field_class'] : '';
			$before_field = sprintf( '<span class="wp-travel-field-before %s">%s</span>', $before_field_class, $this->field['before_field'] );
		}
        $output = '';
        $wp_travel_engine_settings = get_option( 'wp_travel_engine_settings' );
        $gcaptcha_site_key = isset( $wp_travel_engine_settings['form_editor']['grecaptcha_site_key'] ) ? stripslashes_deep( $wp_travel_engine_settings['form_editor']['grecaptcha_site_key'] ) : '';

		if ( ! empty( $gcaptcha_site_key ) ) {
			$output = sprintf( '%s<div id="%s" %s class="%s" %s data-sitekey="%s" data-callback="wte_add_grecaptcha_token"></div>', $before_field, $this->field['id'], $validations, $this->field['class'] . 'g-recaptcha', $attributes, $gcaptcha_site_key );
		} else if ( current_user_can( 'manage_options' ) ){
            $output = __( 'Missing Google reCaptcha site key. Please add site key in WP Travel Engine Settings to use Google Recaptcha field', 'wte-form-editor' );
        }
		if ( ! $display ) {
			return $output;
		}

		echo $output;
	}
}
