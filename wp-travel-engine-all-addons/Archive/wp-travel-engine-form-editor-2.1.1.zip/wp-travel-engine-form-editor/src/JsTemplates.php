<?php
/**
 * Include JS Templates.
 *
 * @package AffiliateEngine
 * @subpackage AAffiliateEngine
 */

namespace Wfe;

defined( 'ABSPATH' ) || exit;

/**
 * Global Settings.
 */
class JsTemplates {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->init();
	}

	/**
	 * Initialization.
	 *
	 * @since 1.0.0
	 * @access private
	 *
	 * @return void
	 */
	private function init() {
		// Initialize hooks.
		$this->init_hooks();

		// Allow 3rd party to remove hooks.
		do_action( 'wfe_jstemplates_unhook', $this );
	}

	/**
	 * Initialize hooks.
	 *
	 * @since 1.0.0
	 * @access private
	 *
	 * @return void
	 */
	private function init_hooks() {

		// add_action( 'admin_footer', array( $this, 'include_templates' ) );
	}

	/**
	 * Include JS Templates.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function include_templates() {
		
		$screen = get_current_screen();

		if ( isset( $screen->id ) && 'trip_page_wtefe_edit_form_screen' === $screen->id ) :

			wtefe_get_template( 'admin/global/js-templates/field-text.php' );

			wtefe_get_template( 'admin/global/js-templates/field-textarea.php' );

			wtefe_get_template( 'admin/global/js-templates/field-select.php' );

			wtefe_get_template( 'admin/global/js-templates/field-checkbox.php' );

		endif;

	}

}
