<?php
/**
 * Settings page under Settings for global settings.
 *
 * @package AffiliateEngine
 * @subpackage AAffiliateEngine
 */

namespace Wfe;

defined( 'ABSPATH' ) || exit;

/**
 * Global Settings.
 */
class GlobalSettings {

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->init();
	}

	/**
	 * Initialization.
	 *
	 * @since 1.0.0
	 * @access private
	 *
	 * @return void
	 */
	private function init() {
		
		// Initialize hooks.
		$this->init_hooks();

		// Allow 3rd party to remove hooks.
		do_action( 'wtefe_options_unhook', $this );
	}

	/**
	 * Initialize hooks.
	 *
	 * @since 1.0.0
	 * @access private
	 *
	 * @return void
	 */
	private function init_hooks() {

		// Add menu in settins page.
		add_action( 'admin_menu', array( $this, 'add_submenu_page' ) );

		// Register global settings.
		add_action( 'admin_init', array( $this, 'register_global_settings' ) );

		// Add admin scripts.
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );

		// Add public scripts
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_public_scripts' ) );

		add_filter('script_loader_tag', array( $this, 'add_script_attribute' ), 10, 2);

		// Load tabs header.
		add_action( 'wpte_global_settings_tabs_header', array( $this, 'load_tabs_header' ) );

		// Load sidebar.
		add_action( 'wpte_global_settings_sidebar', array( $this, 'load_sidebar' ) );

		// Laod Enquiry form tab.
		add_action( 'wpte_global_settings_enquiry_form_tab', array( $this, 'load_enquiry_form_tab' ) );

		// Load checkout form tab.
		add_action( 'wpte_global_settings_checkout_form_tab', array( $this, 'load_checkout_form_tab' ) );

		// Load traveller information form tab.
		add_action( 'wpte_global_settings_traveller_information_form_tab', array( $this, 'load_travellers_information_form_tab' ) );

		// Load emergency contact form tab.
		add_action( 'wpte_global_settings_emergency_contact_form_tab', array( $this, 'load_emergency_contact_info_form_tab' ) );

		// Load submit button
		add_action( 'wpte_global_settings_save_submit_btn', array( $this, 'load_global_settings_save_submit_btn' ) );

		// Load all fields popup content.
		add_action( 'wpte_settings_after_settings_save_button', array( $this, 'load_all_fields_popup_form' ) );

		// Add global settings field
		add_action( 'wte_addons_global_settings', array( $this, 'add_global_settings' ) );

		// Add validation checks
		add_filter( 'wp_travel_engine_enquiry_validation_check', array( $this, 'validation_check' ) );

		add_action( 'wpte_get_global_extensions_tab', array( $this, 'form_editor_extension_settings' ) );
	}

	/**
	 * Add submenu page for form editor.
	 * 
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function add_submenu_page() {

		add_submenu_page( 
			'edit.php?post_type=booking', 
			__( 'WP Travel Engine Form Editor', 'wte-form-editor' ), 
			__( 'Form Editor', 'wte-form-editor' ), 
			'manage_options', 
			'wtefe_edit_form_screen', 
			array( $this, 'display_submenu_page' ),
			10
		);

	}

	/**
	 * Global settings array register.
	 *
	 * @return void
	 */
	function form_editor_extension_settings( $extension_settings ) {
		$extension_settings['wte_form_editor'] = array(
			'label'        => __( 'Form Editor', 'wte-form-editor' ),
			'content_path' => plugin_dir_path( WTE_FORM_EDITOR_PLUGIN_FILE ) . 'templates/admin/global/admin-settings.php',
			'current'      => false,
		);
		return $extension_settings;
	}

	/**
	 * Add Global Serttings.
	 *
	 * @return void
	 */
	public function add_global_settings() {
		
		$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings' );

		$wtefe_settings_defaults =
			array(
				'grecaptcha_site_key' => '',
				'recaptcha_v2_secret_key' => ''
			);

		$wtefe_settings = isset( $wp_travel_engine_settings['form_editor'] ) ? stripslashes_deep( $wp_travel_engine_settings['form_editor'] ) : $wtefe_settings_defaults;
		?>
			<div class="group-status-options"><h3 class="status-options"><?php _e('Form Editor Settings','wte-form-editor');?></h3>
			
				<div class="wp_travel_engine_settings">
					<label for="wp_travel_engine_settings[form_editor][grecaptcha_site_key]"><?php _e( 'Google reCaptcha site key','wte-form-editor' ); ?><span class="tooltip" title="<?php _e( 'Enter google recaptcha site key.', 'wte-form-editor' ); ?>"><i class="fas fa-question-circle"></i></span></label>

					<input value="<?php echo esc_attr( $wtefe_settings['grecaptcha_site_key'] ); ?>" type="text" name="wp_travel_engine_settings[form_editor][grecaptcha_site_key]" id="wp_travel_engine_settings[form_editor][grecaptcha_site_key]">
				</div>

				<div class="wp_travel_engine_settings">
					<label for="wp_travel_engine_settings[form_editor][recaptcha_v2_secret_key]"><?php _e( 'Google reCaptcha secret key','wte-form-editor' ); ?><span class="tooltip" title="<?php _e( 'Enter google recaptcha secret key.', 'wte-form-editor' ); ?>"><i class="fas fa-question-circle"></i></span></label>

					<input value="<?php echo esc_attr( $wtefe_settings['recaptcha_v2_secret_key'] ); ?>" type="text" name="wp_travel_engine_settings[form_editor][recaptcha_v2_secret_key]" id="wp_travel_engine_settings[form_editor][recaptcha_v2_secret_key]">
				</div>

			</div>
		<?php
	}

	/**
	 * Validation checks.
	 *
	 * @param [type] $data
	 * @return void
	 */
	public function validation_check( $data ) {
		if ( isset( $_POST['g-recaptcha-response'] ) ) {
		$captcha = isset( $_POST['g-recaptcha-response'] ) && ! empty( $_POST['g-recaptcha-response'] ) ? $_POST['g-recaptcha-response'] : false;
			if ( ! $captcha ) {
				$data['status'] = false;
				$data['message'] = __( 'Please make sure to check the recaptcha checkbox.', 'wte-form-editor' );
			}
			$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings' );
			$secret_key = isset( $wp_travel_engine_settings['form_editor']['recaptcha_v2_secret_key'] ) ? stripslashes_deep( $wp_travel_engine_settings['form_editor']['recaptcha_v2_secret_key'] ) : '';
			if ( empty( $secret_key ) ) {
				$data['status'] = true;
				return $data;
			}
			$ip        = $_SERVER['REMOTE_ADDR'];
			$url       = sprintf( 'https://www.google.com/recaptcha/api/siteverify?secret=%s&response=%s&remoteip=%s', $secret_key, $captcha, $ip );
			$response  = file_get_contents( $url );
			$responseKeys = json_decode( $response, true );
			if( intval( $responseKeys['success'] ) !== 1 ) {
				$data['status'] = false;
				$data['message'] = __( 'Please make sure to check the recaptcha checkbox.', 'wte-form-editor' );
			}
		}
		return $data;
	}

	/**
	 * Enqueue Admin Scripts for global settings.
	 * 
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function enqueue_admin_scripts() {

		$min = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		$screen = get_current_screen();

		if ( isset( $screen->id ) && 'booking_page_wtefe_edit_form_screen' === $screen->id ) :

			wp_enqueue_style( 'jquery-mCustomScrollbar', WTE_FORM_EDITOR_PLUGIN_URL . '/assets/css/jquery.mCustomScrollbar.css', array(), WTE_FORM_EDITOR_VERSION, 'all' );

			wp_enqueue_style( 'wpte-form-editor-admin', WTE_FORM_EDITOR_PLUGIN_URL . '/assets/css/wpte-form-editor-admin'. $min .'.css', array(), WTE_FORM_EDITOR_VERSION, 'all' );

			// Magnific popup css.
			wp_enqueue_style( 'magnific-popup',  WTE_FORM_EDITOR_PLUGIN_URL . '/assets/css/magnific-popup.min.css', array(), WTE_FORM_EDITOR_VERSION, 'all' );

			wp_enqueue_script( 'jquery-mCustomScrollbar', WTE_FORM_EDITOR_PLUGIN_URL . '/assets/js/jquery.mCustomScrollbar.js', array( 'jquery' ), WTE_FORM_EDITOR_VERSION, true );

			wp_enqueue_script( 'wpte-lodash-min', WTE_FORM_EDITOR_PLUGIN_URL . '/assets/js/lodash.min.js', array( 'jquery' ), WTE_FORM_EDITOR_VERSION, true );

			wp_enqueue_script( 'magnific-popup', WTE_FORM_EDITOR_PLUGIN_URL . '/assets/js/magnific-popup.min.js', array( 'jquery' ), '1.1.0', true );

			wp_enqueue_script( 'parsley', WTE_FORM_EDITOR_PLUGIN_URL . '/assets/js/parsley.min.js', array( 'jquery' ), '2.9.2', true );

			// Toaster Scripts.
			wp_enqueue_style( 'toastr', WTE_FORM_EDITOR_PLUGIN_URL . '/assets/css/toastr.min.css', WTE_FORM_EDITOR_VERSION );

			wp_enqueue_script( 'toastr', WTE_FORM_EDITOR_PLUGIN_URL . '/assets/js/toastr.min.js', array( 'jquery' ), WTE_FORM_EDITOR_VERSION, true );

			wp_enqueue_script( 'wpte-form-editor-admin', WTE_FORM_EDITOR_PLUGIN_URL . '/assets/js/wpte-form-editor-admin'. $min .'.js', array( 'jquery', 'jquery-ui-accordion', 'jquery-ui-sortable', 'wpte-lodash-min', 'magnific-popup', 'parsley', 'toastr' ), WTE_FORM_EDITOR_VERSION, true );

		endif;

	}

	/**
	 * Public scripts
	 *
	 * @return void
	 */
	public function enqueue_public_scripts() {

		wp_register_script( 'grecaptcha', 'https://www.google.com/recaptcha/api.js', array(), WTE_FORM_EDITOR_VERSION, false );

	}

	/**
	 * Defer add
	 *
	 * @return void
	 */
	public function add_script_attribute( $tag, $handle ) {
		if ( 'grecaptcha' !== $handle )
				return $tag;
		
		return str_replace( ' src', '  async defer src', $tag );
	}

	/**
	 * Display submenu page template
	 * 
	 * @since 1.0.0
	 * @access public
	 * 
	 * @return void
	 */
	public function display_submenu_page() {
		
		global $pagenow;

		if ( 'edit.php' === $pagenow && 'wtefe_edit_form_screen' === $_GET['page'] ) {
			wtefe_get_template( 'admin/global/settings.php' );
		}

	}

	/**
	 * Register global settings for form editor.
	 * 
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function register_global_settings() {

		register_setting( 'wtefe', 'wtefe_global_settings_general', array(
			'sanitize_callback' => array( $this, 'sanitize_general')
		) );

	}

	/**
	 * Global settings tab headers template.
	 * 
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function load_tabs_header() {
		wtefe_get_template( 'admin/global/tab-header.php' );
	}

	/**
	 * Global settings sidebar template.
	 * 
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function load_sidebar() {
		wtefe_get_template( 'admin/global/sidebar.php' );
	}

	/**
	 * Global settings Enquiry tab template.
	 * 
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function load_enquiry_form_tab() {
		wtefe_get_template( 'admin/global/tabs/tab-enquiry-form.php' );
	}

	/**
	 * Global settings Checkout form tab template.
	 * 
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function load_checkout_form_tab() {
		wtefe_get_template( 'admin/global/tabs/tab-checkout-form.php' );
	}

	/**
	 * Global settings Travellers Information tab template.
	 * 
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function load_travellers_information_form_tab() {
		wtefe_get_template( 'admin/global/tabs/tab-traveller-information-form.php' );
	}

	/**
	 * Global settings Emervency Contact tab template.
	 * 
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function load_emergency_contact_info_form_tab() {
		wtefe_get_template( 'admin/global/tabs/tab-emergency-contact-info-form.php' );
	}

	/**
	 * Global settings Travellers Information tab template.
	 * 
	 * @since 1.0.0
	 * @access public
	 *
	 * @return void
	 */
	public function load_global_settings_save_submit_btn() {
		wtefe_get_template( 'admin/global/save-submit-btn.php' );
	}

	/**
	* Global settings Travellers Information tab template.
	* 
	* @since 1.0.0
	* @access public
	*
	* @return void
	*/
	public function load_all_fields_popup_form() {
		wtefe_get_template( 'admin/global/fields-popup.php' );
	}
	
}
