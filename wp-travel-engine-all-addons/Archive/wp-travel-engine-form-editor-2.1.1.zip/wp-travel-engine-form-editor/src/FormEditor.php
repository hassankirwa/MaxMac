<?php
/**
 * Main formeditor class
 *
 * @package WTE_Form_Editor
 */

namespace Wfe;

defined( 'ABSPATH' ) || exit;

/**
 * Main FormEditor Cass.
 *
 * @class FormEditor
 */
final class FormEditor {
	/**
	 * FormEditor verison.
	 *
	 * @var string
	 */
	public $version = '2.1.1';

	/**
	 * The single instance of the class.
	 *
	 * @var FormEditor
	 * @since 1.0.0
	 */
	protected static $_instance = null;

	/**
	 * JS Templates.
	 *
	 * @since 1.0.0
	 * @access private
	 *
	 * @var Wfe\JsTemplates
	 */
	private $js_templates;

	/**
	 * Main FormEditor Instance.
	 *
	 * Ensures only one instance of FormEditor is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 * @static
	 * @see WTE_FE()
	 * @return FormEditor - Main instance.
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * FormEditor Constructor.
	 */
	public function __construct() {

		$this->define_constants();
		$this->init_hooks();
		$this->includes();

		// Load class instances.
		$this->global_settings = new GlobalSettings();
		$this->js_templates    = new JsTemplates();
	}

	/**
	 * When WP has loaded all plugins, trigger the 'wfe_loaded; hook.
	 *
	 * This ensures 'wfe_loaded' is called only after all the other plugins
	 * are loaded, to avoid issues caused by plugin directory naming changing
	 * the load order.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function on_plugins_loaded() {
		do_action( 'wfe_loaded' );
	}

	/**
	 * Hook into actions and filters.
	 *
	 * @since 1.0.0
	 * @access private
	 */
	private function init_hooks() {
		add_action( 'init', array( $this, 'init' ) );
		add_action( 'plugins_loaded', array( $this, 'wte_form_editor_updater_call' ) );
		add_filter( 'wp_travel_engine_enquiry_fields_display', array( $this, 'enquiry_form_fields' ), 11, 2 );
		add_filter( 'wp_travel_engine_booking_fields_display', array( $this, 'booking_form_fields' ) );
		add_filter( 'wp_travel_engine_traveller_info_fields_display', array( $this, 'traveller_information_form_fields' ) );
		add_filter( 'wp_travel_engine_emergency_contact_fields_display', array( $this, 'emergency_contact_form_fields' ) );
		add_filter( 'wp_travel_engine_form_field_types', array( $this, 'add_field_type' ) );

		add_action( 'admin_notices', array( $this, 'maybe_disable_plugin' ) );

		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

		add_action(
			'wp_head',
			function() {
				print( '<style>.single-trip #wte_enquiry_contact_form input[type=checkbox]+label { display: inline;}</style>' );
			},
			9
		);

		add_filter(
			'wte_booking_mail_tags',
			array( __CLASS__, 'mail_tag_content' ),
			12,
			2
		);
	}

	/**
	 *
	 * @since 2.1.0
	 */
	public static function mail_tag_content( $mail_tags, $payment_id ) {
		if ( isset( $mail_tags['{form_editor}'] ) ) {
			unset( $mail_tags['{form_editor}'] );
		} else {
			return $mail_tags;
		}
		$booking_id = get_post_meta( $payment_id, 'booking_id', ! 0 );
		$booking    = get_post( $booking_id );

		if ( is_null( $booking ) || 'booking' !== $booking->post_type ) {
			return $mail_tags;
		}

		$additional_fields = wte_array_get( get_post_meta( $booking->ID, 'additional_fields', ! 0 ), null, array() );

		foreach ( $additional_fields as $field_name => $field_value ) {
			$mail_tags[ '{' . $field_name . '}' ] = is_array( $field_value ) ? implode( ',', $field_value ) : $field_value;
		}

		return $mail_tags;
	}

	/**
	 * Define WTE_FORM_EDITOR Constants.
	 *
	 * @since 1.0.0
	 * @access private
	 */
	private function define_constants() {
		$this->define( 'WTE_FORM_EDITOR_PLUGIN_NAME', 'wte-form-editor' );
		$this->define( 'WTE_FORM_EDITOR_ABSPATH', dirname( WTE_FORM_EDITOR_PLUGIN_FILE ) . '/' );
		$this->define( 'WTE_FORM_EDITOR_PLUGIN_BASENAME', plugin_basename( WTE_FORM_EDITOR_PLUGIN_FILE ) );
		$this->define( 'WTE_FORM_EDITOR_VERSION', $this->version );
		$this->define( 'WTE_FORM_EDITOR_TEMPLATE_DEBUG_MODE', false );
		$this->define( 'WTE_FORM_EDITOR_PLUGIN_URL', $this->plugin_url() );
	}

	/**
	 * Define constant if not already set.
	 *
	 * @param string      $name       Constant name.
	 * @param string|bool $value      Constant value.
	 * @return void
	 */
	private function define( $name, $value ) {
		if ( ! defined( $name ) ) {
			define( $name, $value );
		}
	}

	/**
	 * Init FormEditor when WordPress initializes.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function init() {
		// Before init action.
		do_action( 'before_wte_form_editor_init' );

		// Set up localization.
		$this->load_plugin_textdomain();

	}

	/**
	 * Include required files.
	 *
	 * @return void
	 */
	public function includes() {
		if ( $this->meets_requirements() ) {
			include WTE_FORM_EDITOR_ABSPATH . 'src/includes/class-field-recaptcha-v2.php';
		}
	}

	/**
	 * Include Updater files.
	 *
	 * @return void
	 */
	public function wte_form_editor_updater_call() {
		if ( $this->meets_requirements() && is_admin() ) {
			include WTE_FORM_EDITOR_ABSPATH . 'src/updater/wte-form-editor-updater.php';
		}
	}

	/**
	 * Add Recaptcha field type
	 */
	public function add_field_type( $field_types ) {
		$field_types['grecaptcha_v2'] = array(
			'field_label' => __( 'Grecaptcha', 'wte-form-editor' ),
			'field_class' => 'WP_Travel_Engine_Form_Field_Recaptcha_V2',
		);

		return $field_types;
	}

	/**
	 * Enqueue Frontend scripts.
	 *
	 * @return void
	 */
	public function enqueue_scripts() {
		wp_enqueue_script( 'wte-form-editor-public', WTE_FORM_EDITOR_PLUGIN_URL . '/assets/js/wpte-form-editor-public.js', array( 'jquery' ), WTE_FORM_EDITOR_VERSION, true );
	}

	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 *
	 * Note: the first-loaded translation file overrides any following ones if the same translation is present.
	 *
	 * Locales found in:
	 *      - WP_LANG_DIR/wp-travel-engine/wp-travel-engine-LOCALE.mo
	 *      - WP_LANG_DIR/plugins/wp-travel-engine-LOCALE.mo
	 */
	public function load_plugin_textdomain() {
		if ( function_exists( 'determine_locale' ) ) {
			$locale = determine_locale();
		} else {
			// TODO Remove when start supporting WP 5.0 or later.
			$locale = is_admin() ? get_user_locale() : get_locale();
		}

		$locale = apply_filters( 'plugin_locale', $locale, 'wte-form-editor' );

		unload_textdomain( 'wte-form-editor' );
		load_textdomain( 'wte-form-editor', WP_LANG_DIR . '/wte-form-editor/wte-form-editor-' . $locale . '.mo' );
		load_plugin_textdomain(
			'wte-form-editor',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);
	}

	/**
	 * Get the plugin URL.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string
	 */
	public function plugin_url() {
		return untrailingslashit( plugins_url( '/', WTE_FORM_EDITOR_PLUGIN_FILE ) );
	}

	/**
	 * Get the plugin path.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string
	 */
	public function plugin_path() {
		return untrailingslashit( plugin_dir_path( WTE_FORM_EDITOR_PLUGIN_FILE ) );
	}

	/**
	 * Get Ajax URL.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string
	 */
	public function ajax_url() {
		return admin_url( 'admin-ajax.php', 'relative' );
	}

	/**
	 * Get the template path.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string
	 */
	public function template_path() {
		return apply_filters( 'wtefe_template_path', '/wte-form-editor' );
	}

	/**
	 * Output error message and disable plugin if requirements are not met.
	 *
	 * This fires on admin_notices.
	 *
	 * @since 1.0.0
	 */
	public function maybe_disable_plugin() {

		if ( ! $this->meets_requirements() ) {

			// Display our error
			echo '<div id="message" class="error">';
			echo '<p>' . sprintf( __( '<strong>WP Travel Engine Form Editor</strong> addon requires WP Travel Engine plugin <strong>v.4.0.0 or later</strong> and has been <a href="%s">deactivated</a>. Please install, activate, or update WP Travel Engine plugin and then reactivate this plugin.', 'wte-form-editor' ), admin_url( 'plugins.php' ) ) . '</p>';
			echo '</div>';

			// Deactivate our plugin
			deactivate_plugins( WTE_FORM_EDITOR_PLUGIN_BASENAME );
		}
	}

	/**
	 * Check if all plugin requirements are met.
	 *
	 * @since 1.0.0
	 *
	 * @return bool True if requirements are met, otherwise false.
	 */
	private function meets_requirements() {
		return ( class_exists( 'WP_Travel_Engine' ) && defined( 'WP_TRAVEL_ENGINE_VERSION' ) && version_compare( WP_TRAVEL_ENGINE_VERSION, '4.0.0', '>=' ) );
	}

	/**
	 * Enquiry form fields
	 *
	 * @return void
	 */
	public function enquiry_form_fields( $enquiry_fields, $post_id = null ) {
		$wpte_form_editor_form_fields = get_option( 'wpte_form_editor_form_fields' );

		if ( isset( $wpte_form_editor_form_fields['enquiry_form'] ) && ! empty( $wpte_form_editor_form_fields['enquiry_form'] ) ) {
			$form_field_keys = array_keys( $wpte_form_editor_form_fields['enquiry_form'] );
			if( is_callable( ['WP_Travel_Engine_Enquiry_Form_Shortcodes', 'get_package_detail_fields'] ) && !! $post_id ) {
				$package_fields = \WP_Travel_Engine_Enquiry_Form_Shortcodes::get_package_detail_fields( $post_id );
				$form_field_keys = array_merge( array_keys( $package_fields ), $form_field_keys  );
			}

			$enquiry_fields  = array_filter(
				$enquiry_fields,
				function( $key ) use ( $form_field_keys ) {
					return in_array( $key, $form_field_keys ) || ( isset( $enquiry_fields[ $key ]['default_field'] ) && $enquiry_fields[ $key ]['default_field'] );
				},
				ARRAY_FILTER_USE_KEY
			);

			$enquiry_mods = array_replace_recursive( $enquiry_fields, $wpte_form_editor_form_fields['enquiry_form'] );
			$enquiry_mods = array_map(
				function( $enquiry_mod ) {
					return wp_parse_args(
						$enquiry_mod,
						array(
							'wrapper_class' => 'row-repeater',
						)
					);
				},
				$enquiry_mods
			);
			$enquiry_mods = array_merge( array_flip( $form_field_keys ), $enquiry_mods );

			return $enquiry_mods;
		}

		return $enquiry_fields;
	}

	/**
	 * Booking form fields
	 *
	 * @return void
	 */
	public function booking_form_fields( $booking_fields ) {
		$wpte_form_editor_form_fields = get_option( 'wpte_form_editor_form_fields' );

		if ( isset( $wpte_form_editor_form_fields['checkout_form'] ) && ! empty( $wpte_form_editor_form_fields['checkout_form'] ) ) {
			$form_field_keys = array_keys( $wpte_form_editor_form_fields['checkout_form'] );
			$booking_fields  = array_filter(
				$booking_fields,
				function( $key ) use ( $form_field_keys ) {
					return in_array( $key, $form_field_keys ) || ( isset( $booking_fields[ $key ]['default_field'] ) && $booking_fields[ $key ]['default_field'] );
				},
				ARRAY_FILTER_USE_KEY
			);

			$booking_mods = array_replace_recursive( $booking_fields, $wpte_form_editor_form_fields['checkout_form'] );
			$booking_mods = array_map(
				function( $enquiry_mod ) {
					return wp_parse_args(
						$enquiry_mod,
						array(
							'wrapper_class' => 'row-repeater',
							'label_class'   => 'wpte-bf-label',
						)
					);
				},
				$booking_mods
			);

			$booking_mods = array_merge( array_flip( $form_field_keys ), $booking_mods );

			// return checkout form default names.
			$booking_mods = array_map(
				function( $field ) {
					if ( isset( $field['default_field'] ) && $field['default_field'] ) {
						  $field['name'] = $field['id'];
					}
					return $field;
				},
				$booking_mods
			);

			return $booking_mods;
		}

		return $booking_fields;
	}

	/**
	 * Booking form fields
	 *
	 * @return void
	 */
	public function traveller_information_form_fields( $travellers_info_fields ) {
		$wpte_form_editor_form_fields = get_option( 'wpte_form_editor_form_fields' );

		if ( isset( $wpte_form_editor_form_fields['travellers_info_form'] ) && ! empty( $wpte_form_editor_form_fields['travellers_info_form'] ) ) {
			$form_field_keys        = array_keys( $wpte_form_editor_form_fields['travellers_info_form'] );
			$travellers_info_fields = array_filter(
				$travellers_info_fields,
				function( $key ) use ( $form_field_keys ) {
					return in_array( $key, $form_field_keys ) || ( isset( $travellers_info_fields[ $key ]['default_field'] ) && $travellers_info_fields[ $key ]['default_field'] );
				},
				ARRAY_FILTER_USE_KEY
			);

			$traveller_info_mods = array_replace_recursive( $travellers_info_fields, $wpte_form_editor_form_fields['travellers_info_form'] );

			$traveller_info_mods = array_merge( array_flip( $form_field_keys ), $traveller_info_mods );

			// return checkout form default names.
			$traveller_info_mods = array_map(
				function( $field ) {
					if ( isset( $field['default_field'] ) && $field['default_field'] ) {
						  $field['name'] = $field['id'];
					}
					return $field;
				},
				$traveller_info_mods
			);

			return $traveller_info_mods;
		}

		return $travellers_info_fields;
	}

	/**
	 * Emergenct contact form fields
	 *
	 * @return void
	 */
	public function emergency_contact_form_fields( $emergency_contact_fields ) {
		$wpte_form_editor_form_fields = get_option( 'wpte_form_editor_form_fields' );

		if ( isset( $wpte_form_editor_form_fields['emergency_contact_info'] ) && ! empty( $wpte_form_editor_form_fields['emergency_contact_info'] ) ) {
			$form_field_keys          = array_keys( $wpte_form_editor_form_fields['emergency_contact_info'] );
			$emergency_contact_fields = array_filter(
				$emergency_contact_fields,
				function( $key ) use ( $form_field_keys ) {
					return in_array( $key, $form_field_keys ) || ( isset( $emergency_contact_fields[ $key ]['default_field'] ) && $emergency_contact_fields[ $key ]['default_field'] );
				},
				ARRAY_FILTER_USE_KEY
			);

			$emergency_contact_mods = array_replace_recursive( $emergency_contact_fields, $wpte_form_editor_form_fields['emergency_contact_info'] );

			$emergency_contact_mods = array_merge( array_flip( $form_field_keys ), $emergency_contact_mods );

			// return checkout form default names.
			$emergency_contact_mods = array_map(
				function( $field ) {
					if ( isset( $field['default_field'] ) && $field['default_field'] ) {
						  $field['name'] = $field['id'];
					}
					return $field;
				},
				$emergency_contact_mods
			);

			return $emergency_contact_mods;
		}

		return $emergency_contact_fields;
	}

}
