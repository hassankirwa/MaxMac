<?php
/**
 * Easy Digital Downloads Plugin Updater
 *
 * @package WTE_Form_Editor
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Includes the files needed for the plugin updater.
 *
 * @since 1.0.0
 */
if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {

	include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

/**
 * Download ID for the product in Easy Digital Downloads.
 *
 * @since 1.0.0
 */
define( 'WTE_FORM_EDITOR_ITEM_ID', 33247 ); 

/**
 * Setup the updater for the WTE User History Add-on.
 *
 * @since 1.0.0
 */
function wte_form_editor_updater() {

	// retrieve our license key from the DB
	$settings = get_option( 'wp_travel_engine_license' );
	$license_key = isset( $settings['wte_form_editor_license_key'] ) ? esc_attr( $settings['wte_form_editor_license_key'] ):'';

	// setup the updater
	$edd_updater = new EDD_SL_Plugin_Updater( WP_TRAVEL_ENGINE_STORE_URL, WTE_FORM_EDITOR_PLUGIN_FILE,
		array(
			'version' => WTE_FORM_EDITOR_VERSION,                    // current version number
			'license' => $license_key,             // license key (used get_option above to retrieve from DB)
			'item_id' => WTE_FORM_EDITOR_ITEM_ID,       // ID of the product
			'author'  => __( 'WP Travel Engine', 'wte-form-editor' ), // author of this plugin
			'beta'    => false,
		)
	);

}
add_action( 'admin_init', 'wte_form_editor_updater', 0 );

/**
 * Add-ons name for plugin license page.
 *
 * @since 1.0.0
 */
function wte_form_editor_name($array)
{
	$array['WP Travel Engine - Form Editor'] =  'wte_form_editor';
	return $array;
}
add_filter( 'wp_travel_engine_addons', 'wte_form_editor_name' );

/**
 * Add-ons Item ID for plugin license page.
 *
 * @since 1.0.0
 */
function wte_form_editor_id($array)
{
	$array['wte_form_editor'] = WTE_FORM_EDITOR_ITEM_ID;
	return $array;
}
add_filter( 'wp_travel_engine_addons_id', 'wte_form_editor_id' );
