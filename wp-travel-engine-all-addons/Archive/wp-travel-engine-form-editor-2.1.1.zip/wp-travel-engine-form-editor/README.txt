=== WP Travel Engine - Form Editor ===
Contributors: wptravelengine
Donate link: https://wptravelengine.com/
Tags: form-editor. wp-travel-engine
Requires at least: 4.4.0
Tested up to: 5.6
Stable tag: 2.1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

An addon to WP Travel Engine plugin that lets users to edit forms.

== Description ==
An addon to WP Travel Engine plugin that lets users to edit forms.

== Changelog ==

= 2.1.1 =
Released on: 3rd December, 2021
* Fix: Enquiry form redirection not working

= 2.1.0 =
Released on: 5th August, 2021
* Compatibility update for WTE 5.0+
* Minor bug fixes
