"use strict";

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

jQuery(document).ready(function ($) {
  //tab js
  $('.wpte-fe-tab-wrap .wpte-fe-tab').on('click', function () {
    var tabId = $(this).attr('id');

    if ('fe-tab3' === tabId || 'fe-tab4' === tabId) {
      $('.wpte-fe-sidebar-block input[data-field-type="file"]').parent('.wpte-fe-sidebar-repeater').hide();
    } else {
      $('.wpte-fe-sidebar-block input[data-field-type="file"]').parent('.wpte-fe-sidebar-repeater').show();
    }

    if ('fe-tab1' !== tabId) {
      $('.wpte-fe-sidebar-block input[data-field-type="grecaptcha_v2"]').parent('.wpte-fe-sidebar-repeater').hide();
    } else {
      $('.wpte-fe-sidebar-block input[data-field-type="grecaptcha_v2"]').parent('.wpte-fe-sidebar-repeater').show();
    }

    $('.wpte-fe-tab').removeClass('active');
    $('.wpte-fe-tab-content').removeClass('active');
    $(this).addClass('active');
    $('#' + tabId + '-content').addClass('active');
  }); //call custom scrollbar

  $('.wpte-fe-sidebar-inner').mCustomScrollbar(); //toggle sidebar

  $('.wpte-fe-sidebar .wpte-fe-button').click(function (e) {
    e.stopPropagation();
    $('.wpte-fe-outer').addClass('fe-open');
  });
  $('.wpte-fe-sidebar-wrap').click(function (e) {
    e.stopPropagation();
  });
  $('.wpte-fe-sidebar-wrap .wpte-fe-close, body, html, .wpte-fe-block-content .wpte-fe-sidebar-repeater label').click(function (e) {
    $('.wpte-fe-outer').removeClass('fe-open');
  });
  $(window).on("keyup", function (event) {
    if (event.key == "Escape") {
      $('.wpte-fe-outer').removeClass('fe-open');
    }
  });
  $('.wpte-fe-repeater-field').accordion({
    collapsible: true,
    active: false
  });
  $('.wpte-fe-repeater-fields').sortable({
    handle: '.wpte-fe-repeater-fields-handle'
  });
  $('.wte-form-editor-add-field').click(function (e) {
    var ShowFields = $(this).data('show-fields');
    var field_type = $(this).data('field-type');
    var form_name = $('.wpte-fe-tab.active').data('form');
    $.magnificPopup.open({
      items: {
        src: '#wte_form_editor_popup'
      },
      type: 'inline',
      callbacks: {
        open: function open() {
          var template = wp.template('wpte-fields-popup-form'),
              index = _.uniqueId();

          $('#wte_form_editor_popup').html(template({
            index: index,
            type: field_type
          }));
          $('input[name="wte_form_editor_field_type"]').val(field_type);
          $('input[name="wte_form_editor_form_name"]').val(form_name);
          $('input[name="wtefe-form-editor-add-field"]').attr('data-show-fields', JSON.stringify(ShowFields));
          $('.wtefe_popup_fld_contl').each(function () {
            var name = $(this).children('input,textarea').attr('id') || $(this).children().find('input').attr('id');
            var display = -1 == $.inArray(name, ShowFields) ? 'none' : 'block';

            if (-1 == $.inArray(name, ShowFields)) {
              $(this).remove();
            }
          });
          wtefe_handle_popup_add_field();
        },
        close: function close() {// $('textarea.field_property').removeClass('current-edited-field');
        }
      }
    }); // e.preventDefault();
    // var field_type = $(this).data( 'field-type' );
    // console.log(field_type);
    // var template = wp.template('wte-form-editor-field-'+field_type);
    // index     = _.uniqueId();
    // form_name = $( '.wpte-fe-tab.active' ).data( 'form' );
    // $( '.wpte-fe-tab-content.active > .wpte-fe-repeater-fields' ).append( template( { form_name: form_name, index: index } ) );
    // $( '.wpte-fe-repeater-field' ).accordion( {  collapsible: true } );
  });

  function wtefe_handle_popup_add_field() {
    $('#wte_form_editor_popup #wtefe-form-editor-add-field').click(function (e) {
      var _this = this;

      e.preventDefault();
      $('#wtefe-form-editor-form').parsley();

      if (!$('#wtefe-form-editor-form').parsley().isValid()) {
        $('#wtefe-form-editor-form').parsley().validate();
        return;
      }

      var FieldData = $('#wtefe-form-editor-form').serializeArray();
      var Appendata = [];
      var form_fields = [];

      var mapLoop = /*#__PURE__*/function () {
        var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(_) {
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  FieldData.map(function (elem) {
                    var field_name = elem.name || false;

                    if (field_name) {
                      switch (field_name) {
                        case 'wte_form_editor_form_name':
                          Appendata['form_name'] = elem.value;
                          break;

                        case 'wte_form_editor_name':
                          Appendata['field_name'] = elem.value;
                          form_fields['name'] = elem.value;
                          break;

                        case 'wte_form_editor_label':
                          Appendata['field_label'] = elem.value;
                          form_fields['label'] = elem.value;
                          break;

                        case 'wte_form_editor_field_type':
                          form_fields['type'] = elem.value;
                          break;

                        case 'wte_form_editor_id':
                          form_fields['id'] = elem.value;
                          break;

                        case 'wte_form_editor_class':
                          form_fields['class'] = elem.value;
                          break;

                        case 'wte_form_editor_placeholder':
                          form_fields['placeholder'] = elem.value;
                          break;

                        case 'wte_form_editor_validation[]':
                          form_fields['required'] = true;
                          break;

                        case 'wte_form_editor_select_options':
                          var textarea = elem.value;
                          var linebreak = textarea.split('\r\n');
                          var length = linebreak.length;
                          var data = {};

                          for (var i = 0; i < length; i++) {
                            var key = linebreak[i];
                            data[key] = key;
                          }

                          form_fields['options'] = JSON.stringify(data);
                          break;
                      }
                    }
                  });

                case 1:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee);
        }));

        return function mapLoop(_x) {
          return _ref.apply(this, arguments);
        };
      }();

      mapLoop().then(function () {
        Appendata['field_attrs'] = form_fields;
        Appendata['ShowFields'] = $(_this).attr('data-show-fields'); // debugger;

        var row_template = wp.template('wpte-add-singular-field-row'),
            index = _.uniqueId();

        $('.wpte-fe-tab-content.active .wpte-fe-repeater-fields').append(row_template({
          index: index,
          data: Appendata
        }));
        $.magnificPopup.close();
      });
    });
  }

  function wtefe_handle_popup_update_field() {
    $('#wte_form_editor_popup #wtefe-form-editor-add-field').click(function (e) {
      e.preventDefault();
      $('#wtefe-form-editor-form').parsley();

      if (!$('#wtefe-form-editor-form').parsley().isValid()) {
        $('#wtefe-form-editor-form').parsley().validate();
        return;
      }

      var FieldData = $('#wtefe-form-editor-form').serializeArray();
      var field_name = $('input[name="wte_form_editor_field_name"]').val();
      var form_name = $('input[name="wte_form_editor_form_name"]').val(); // debugger;
      // $.fn.formToArray = function () {

      $("form input[type=checkbox]").each(function () {
        FieldData.push({
          name: this.name,
          value: this.checked
        });
      }); // return FieldData;
      // };

      FieldData.map(function (data) {
        // debugger;
        switch (data.name) {
          case 'wte_form_editor_label':
            $('input[name="wpte_form_editor_form_fields[' + form_name + '][' + field_name + '][field_label]"]').val(data.value);
            $('td[data-fieldlabeldisp="' + form_name + '_' + field_name + '"]').html(data.value);
            break;

          case 'wte_form_editor_name':
            $('input[name="wpte_form_editor_form_fields[' + form_name + '][' + field_name + '][name]"]').val(data.value);
            var mail_tag = '{' + data.value + '}';
            $('td[data-fieldnamedisp="' + form_name + '_' + field_name + '"]').html(mail_tag);
            break;

          case 'wte_form_editor_id':
            $('input[name="wpte_form_editor_form_fields[' + form_name + '][' + field_name + '][id]"]').val(data.value);
            break;

          case 'wte_form_editor_class':
            $('input[name="wpte_form_editor_form_fields[' + form_name + '][' + field_name + '][class]"]').val(data.value);
            break;

          case 'wte_form_editor_placeholder':
            $('input[name="wpte_form_editor_form_fields[' + form_name + '][' + field_name + '][placeholder]"]').val(data.value);
            break;

          case 'wte_form_editor_validation[]':
            $('input[name="wpte_form_editor_form_fields[' + form_name + '][' + field_name + '][validations][required]"]').val(data.value);
            break;

          case 'wte_form_editor_select_options':
            var textarea = data.value;
            var linebreak = textarea.split('\r\n');
            var length = linebreak.length;
            var object = {};

            for (var i = 0; i < length; i++) {
              var key = linebreak[i];
              object[key] = key;
            }

            var dataToSave = JSON.stringify(object);
            $('input[name="wpte_form_editor_form_fields[' + form_name + '][' + field_name + '][options]"]').val(dataToSave);
            break;
        }
      });
      $.magnificPopup.close();
    });
  }

  $(document).on('click', '.wpte-fe-delete', function (e) {
    var confirmation = confirm("Are you sure to delete the field?");

    if (confirmation) {
      $(this).parents('.wpte-fe-repeater-field').remove();
    }
  });

  function setUrlParameter(url, key, value) {
    var key = encodeURIComponent(key),
        value = encodeURIComponent(value);
    var baseUrl = url.split('?')[0],
        newParam = key + '=' + value,
        params = '?' + newParam;

    if (url.split('?')[1] === undefined) {
      // if there are no query strings, make urlQueryString empty
      var urlQueryString = '';
    } else {
      var urlQueryString = '?' + url.split('?')[1];
    } // If the "search" string exists, then build params from it


    if (urlQueryString) {
      var updateRegex = new RegExp('([\?&])' + key + '=[^&]*');
      var removeRegex = new RegExp('([\?&])' + key + '=[^&;]+[&;]?');

      if (value === undefined || value === null || value === '') {
        // Remove param if value is empty
        params = urlQueryString.replace(removeRegex, "$1");
        params = params.replace(/[&;]$/, "");
      } else if (urlQueryString.match(updateRegex) !== null) {
        // If param exists already, update it
        params = urlQueryString.replace(updateRegex, "$1" + newParam);
      } else if (urlQueryString == '') {
        // If there are no query strings
        params = '?' + newParam;
      } else {
        // Otherwise, add it to end of query string
        params = urlQueryString + '&' + newParam;
      }
    } // no parameter was set so we don't need the question mark


    params = params === '?' ? '' : params;
    return baseUrl + params;
  }

  $(document).on('click', '#wte-formeditor-reset-defaults-fldsbtn', function (e) {
    var confirmation = confirm("Are you sure to reset all fields to default values ? It will also delete all newly added fields. This action cannot be reverted.");

    if (confirmation) {
      var url = window.location.href;
      var newurlPar = setUrlParameter(url, 'wtefe_reset_all_fields', 'true');
      var newurl = setUrlParameter(newurlPar, 'wpte_reset_all_nonce', $(this).data('nonce'));
      window.location.href = newurl;
    }
  });
  $(document).on('change keyup', "*[wte_bind]", function (e) {
    var to_bind = $(this).attr('wte_bind');
    var value = '' != $(this).val() ? $(this).val() : 'Untitled';
    $("*[wte_bind='" + to_bind + "']").html(value);
    $("*[wte_bind='" + to_bind + "']").val($(this).val());
  });
  $(document).on('change', "*[data-wte_update_field_name]", function (e) {
    var to_bind = $(this).data('wte_update_field_name');
    var value = '' != $(this).val() ? $(this).val() : '',
        next_field_val = $('#' + to_bind).val();

    if ('' === value || '' !== next_field_val) {
      return;
    }

    var value = _.snakeCase(value);

    $('#' + to_bind).val(value);
  });
  $(document).on('change', "*[data-wte_update_field_id]", function (e) {
    var to_bind = $(this).data('wte_update_field_id');
    var value = '' != $(this).val() ? $(this).val() : '',
        next_field_val = $('#' + to_bind).val();

    if ('' === value || '' !== next_field_val) {
      return;
    }

    var value = _.kebabCase(value);

    $('#' + to_bind).val(value);
  });
  $(document).on('change', '*[data-requires-snakecase]', function (e) {
    $(this).val(_.snakeCase($(this).val()));
  });
  $(document).on('change', '*[data-requires-kebabcase]', function (e) {
    $(this).val(_.kebabCase($(this).val()));
  });
  $(document).on('click', '#wte-formeditor-save-fldsbtn', function (e) {
    e.preventDefault();
    parent = '.wpte-fe-tab-content';
    var wte_form_fields = {};
    $(parent + ' input, ' + parent + ' select').each(function (index) {
      var filterby = $(this).attr('name');
      var filterby_val = $(this).val();

      if ($(this).data('multiple') == true) {
        if ('undefined' == typeof wte_form_fields[filterby]) {
          wte_form_fields[filterby] = [];
        }

        if ($(this).attr('type') == 'checkbox') {
          if ($(this).is(':checked')) {
            wte_form_fields[filterby].push(filterby_val);
          }
        }

        if ($(this).data('dependent') == true) {
          var pare = $(this).data('parent');

          if ($('#' + pare).is(':checked')) {
            wte_form_fields[filterby].push(filterby_val);
          }
        }
      } else {
        wte_form_fields[filterby] = filterby_val;
      }
    });
    wte_form_fields['action'] = 'wte_form_editor_save_fields';
    wte_form_fields['wte_form_editor_save_fields_nonce'] = $('input[name="wte_form_editor_save_form_fields_nonce"]').val();
    $.ajax({
      type: "POST",
      url: ajaxurl,
      data: wte_form_fields,
      beforeSend: function beforeSend() {
        $(this).prop('disabled', true);
      },
      success: function success(data) {
        if (data.success) {
          toastr.success(data.data.message);
        } else {
          toastr.error(data.data.message);
        }

        $(this).prop('disabled', false);
        ;
      }
    });
  });
  $(document).on('click', '.wpte-fe-field-settings-row .fa-trash-alt', function () {
    var field_name = $(this).data('field-name');
    var x = confirm("Are you sure you want to delete?");

    if (x) {
      $(this).parents().find('tr[data-field-name="' + field_name + '"]').remove();
    }
  });
  $(document).on('click', '.wpte-fe-field-settings-row .wte_fe_editrow', function () {
    var field_name = $(this).data('field-name');
    var form_name = $(this).data('form-name');
    var ShowFields = JSON.stringify($(this).data('showfields'));
    var field_type = $(this).data('field-type');
    $.magnificPopup.open({
      items: {
        src: '#wte_form_editor_popup'
      },
      type: 'inline',
      callbacks: {
        open: function open() {
          var template = wp.template('wpte-fields-popup-form');

          var index = _.uniqueId();

          $('#wte_form_editor_popup').html(template({
            index: index,
            type: field_type
          }));
          $('input[name="wte_form_editor_field_type"]').val(field_type);
          $('input[name="wte_form_editor_field_name"]').val(field_name);
          $('input[name="wte_form_editor_form_name"]').val(form_name);
          $('.wtefe_popup_fld_contl').each(function () {
            var name = $(this).children('input,textarea').attr('id') || $(this).children().find('input').attr('id');

            if (-1 == $.inArray(name, JSON.parse(ShowFields))) {
              $(this).remove();
            }

            switch (name) {
              case 'wte_form_editor_label':
                var Input_val = $('input[name="wpte_form_editor_form_fields[' + form_name + '][' + field_name + '][field_label]"]').val();
                $(this).children('input,textarea').val(Input_val);
                break;

              case 'wte_form_editor_name':
                var Input_val = $('input[name="wpte_form_editor_form_fields[' + form_name + '][' + field_name + '][name]"]').val();
                $(this).children('input,textarea').val(Input_val);

                if ('1' == $('input[name="wpte_form_editor_form_fields[' + form_name + '][' + field_name + '][default_field]"]').val()) {
                  $(this).remove();
                }

                break;

              case 'wte_form_editor_id':
                var Input_val = $('input[name="wpte_form_editor_form_fields[' + form_name + '][' + field_name + '][id]"]').val();
                $(this).children('input,textarea').val(Input_val);

                if ('1' == $('input[name="wpte_form_editor_form_fields[' + form_name + '][' + field_name + '][default_field]"]').val()) {
                  $(this).remove();
                }

                break;

              case 'wte_form_editor_class':
                var Input_val = $('input[name="wpte_form_editor_form_fields[' + form_name + '][' + field_name + '][class]"]').val();
                $(this).children('input,textarea').val(Input_val);
                break;

              case 'wte_form_editor_placeholder':
                var Input_val = $('input[name="wpte_form_editor_form_fields[' + form_name + '][' + field_name + '][placeholder]"]').val();
                $(this).children('input,textarea').val(Input_val);
                break;

              case 'wte_form_editor_validation':
                var Input_val = $('input[name="wpte_form_editor_form_fields[' + form_name + '][' + field_name + '][validations][required]"]').val();

                if ('true' == Input_val) {
                  $('#wtefe-form-editor-form input[name="wte_form_editor_validation[]"]').prop('checked', true);
                  $('#wtefe-form-editor-form input[name="wte_form_editor_validation[]"]').attr('checked', 'checked');
                }

                break;

              case 'wte_form_editor_select_options':
                var Input_val = $('input[name="wpte_form_editor_form_fields[' + form_name + '][' + field_name + '][options]"]').val(); // debugger;

                if (null != Input_val) {
                  var Input_val = JSON.parse(Input_val);
                  var keys = Object.keys(Input_val);
                  var KeysString = keys.join('\n');
                  $(this).children('input,textarea').val(KeysString);
                }

                break;
            }
          });
          wtefe_handle_popup_update_field();
        },
        close: function close() {// $('textarea.field_property').removeClass('current-edited-field');
        }
      }
    });
  });
  $(document).on('click', '.fe_close_popup', function (e) {
    e.preventDefault();
    $.magnificPopup.close();
  });
}); //document close
//# sourceMappingURL=wpte-form-editor-admin.js.map
