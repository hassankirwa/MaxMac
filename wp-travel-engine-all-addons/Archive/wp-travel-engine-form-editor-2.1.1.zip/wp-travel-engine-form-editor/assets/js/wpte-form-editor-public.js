/**
 * Grecaptcha callback.
 */
function wte_add_grecaptcha_token( response ) {
    
}