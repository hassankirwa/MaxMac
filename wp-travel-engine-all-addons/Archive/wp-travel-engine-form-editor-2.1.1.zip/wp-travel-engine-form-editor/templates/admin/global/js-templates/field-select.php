<?php
/**
 * JS Template for form editor text field.
 * 
 * @package WTE_Form_Editor
 */
?>
<script type="text/html" id="tmpl-wte-form-editor-field-select">

    <div data-index="{{data.index}}" class="wpte-fe-repeater-field">
        <div class="wpte-fe-repeater-title-wrap">
            <button class="wpte-fe-sortable">
                <svg xmlns="http://www.w3.org/2000/svg" width="21.606" height="20.94" viewBox="0 0 21.606 20.94"><g transform="translate(-6)"><g transform="translate(11.717 0)"><path d="M0,10.877,6.729,5.439,0,0" transform="translate(10.877 14.211) rotate(90)" fill="#1a84ee"></path><path d="M0,0,6.729,5.439,0,10.877" transform="translate(0 6.729) rotate(-90)" fill="#1a84ee"></path></g><path d="M21.606,0H0" transform="translate(6 10.282)" fill="none" stroke="#1a84ee" stroke-width="0.25" opacity="0.7"></path></g></svg>
            </button>
            <h4 wte_bind="field_label_{{data.index}}" class="wpte-fe-repeater-title"><?php esc_html_e( 'Select Field', 'wte-form-editor' ); ?></h4>
            <button class="wpte-fe-delete">
                <svg xmlns="http://www.w3.org/2000/svg" width="16.589" height="22.119" viewBox="0 0 16.589 22.119"><g transform="translate(-132.5 -10)" opacity="0.8"><path d="M149.089,12.839H144.48V11.688A1.687,1.687,0,0,0,142.792,10h-4a1.684,1.684,0,0,0-1.681,1.688v1.151H132.5v.846h1.214l1.359,16.745a1.687,1.687,0,0,0,1.688,1.688h8.121a1.687,1.687,0,0,0,1.688-1.688l1.343-16.745h1.176Zm-11.141-1.151a.846.846,0,0,1,.842-.846h4a.843.843,0,0,1,.842.846v1.151h-5.688Zm7.778,18.7v.045a.846.846,0,0,1-.842.846h-8.121a.843.843,0,0,1-.842-.846v-.045l-1.366-16.7h12.511Z" fill="#191919"></path><path d="M482.1,255h.806v13.883H482.1Z" transform="translate(-341.709 -239.47)" fill="#191919"></path><path d="M600.158,255h-.842l-.616,13.883h.842Z" transform="translate(-455.678 -239.47)" fill="#191919"></path><path d="M337.535,255H336.7l.616,13.883h.842Z" transform="translate(-199.591 -239.47)" fill="#191919"></path></g></svg>
            </button>
        </div>
        <div class="wpte-fe-repeater-content wpte-fe-inline-fields">
        
            
            <?php

            include_once WP_TRAVEL_ENGINE_ABSPATH . '/includes/lib/wte-form-framework/class-wte-form.php';

            $form_fields      = new WP_Travel_Engine_Form_Field();
            $text_fields      = wte_form_editor_get_select_fields();

                $form_fields->init( $text_fields )->render();

            ?>

        </div>
    </div>

</script>
<?php
