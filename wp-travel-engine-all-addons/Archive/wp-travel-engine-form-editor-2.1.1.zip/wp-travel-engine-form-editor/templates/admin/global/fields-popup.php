<?php
/**
 * Global settings save / submit button.
 * 
 * @package WTE_Form_Editor
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div id="wte_form_editor_popup" class="white-popup-block mfp-hide" style="text-align:center" ></div>
    <script type="text/html" id="tmpl-wpte-fields-popup-form">
        <a class="fe_close_popup" title='<?php _e( 'Close (Esc)', 'wte-form-editor' ); ?>' type='button' ><span></span></a>
        <?php
            include_once WP_TRAVEL_ENGINE_ABSPATH . '/includes/lib/wte-form-framework/class-wte-form.php';

        $form = new WP_Travel_Engine_Form();
            $fields_array = wtefe_get_popup_fields();
            $fields_array['field_type'] = array(
                'type' => 'hidden',
                'name' => 'wte_form_editor_field_type',
                'id'   => 'wte_form_editor_field_type',
                'show_in' => array(
                    ''
                ),
            );
            $form_options = array(
                'id'            => 'wtefe-form-editor-form',
                'wrapper_class' => 'wtefe-form-editor-form-wrapper',
                'submit_button' => array(
                    'name'  => 'wtefe-form-editor-add-field',
                    'id'    => 'wtefe-form-editor-add-field',
                    'value' => __( 'Save field', 'wte-form-editor' ),
                    'class' => 'button button-primary',
                ),
            );
            $form->init( $form_options )->form_fields( $fields_array )->template();
        ?>
    </script>
    <script type="text/html" id="tmpl-wpte-add-singular-field-row" >
    <# 
        fields_attr = data.data.field_attrs;
        var type        = fields_attr.type,
            label       = fields_attr.label,
            name        = fields_attr.name,
            id          = fields_attr.id,
            className   = fields_attr.class || '',
            placeholder = fields_attr.placeholder || '',
            required    = fields_attr.required || false,
            options     = fields_attr.options || false;

        var fieldname = '{'+data.data.field_name+'}';
    #>

        <?php
            $allowed_fields = wtefe_get_allowed_fields_for_type( '{{data.data.field_attrs.type}}' );
        ?>
    
        <tr data-field-name="{{data.data.field_name}}" class="wpte-fe-field-settings-row">
            <td><span class="wpte-fe-repeater-fields-handle"><i class="fas fa-arrows-alt"></i></span></td>
            <td data-fieldtypedisp='{{type}}' >{{type}}</td>
            <td data-fieldlabeldisp='{{data.data.form_name}}_{{data.data.field_name}}' >{{data.data.field_label}}</td>
            <td data-fieldnamedisp='{{data.data.form_name}}_{{data.data.field_name}}' ><span>{{fieldname}}</span></td>
            <td>
                <span class="wte_fe_editrow"
                    data-field-name = "{{data.data.field_name}}"
                    data-form-name  = "{{data.data.form_name}}"
                    data-showfields = "{{data.data.ShowFields}}"
                    data-field-type = "{{data.data.field_attrs.type}}"
                >
                    <i 
                        data-field-name = "{{data.data.field_name}}"
                        data-form-name  = "{{data.data.form_name}}"
                        data-showfields = "{{data.data.ShowFields}}"
                        data-field-type = "{{data.data.field_attrs.type}}"
                        class           = "fas fa-pencil-alt">
                    </i> 
                    <?php _e( 'Edit', 'wte-form-editor' ); ?>
                </span>
                <span>
                    <i 
                        data-field-name="{{data.data.field_name}}" 
                        class="far fa-trash-alt">
                    </i>
                </span>
            </td>
            <input 
                name  = "wpte_form_editor_form_fields[{{data.data.form_name}}][{{data.data.field_name}}][type]"
                type  = "hidden"
                value = "{{type}}"
            />
            <input 
                name  = "wpte_form_editor_form_fields[{{data.data.form_name}}][{{data.data.field_name}}][field_label]"
                type  = "hidden"
                value = "{{label}}"
            />
            <input 
                name  = "wpte_form_editor_form_fields[{{data.data.form_name}}][{{data.data.field_name}}][name]"
                type  = "hidden"
                value = "{{name}}"
            />
            <input 
                name  = "wpte_form_editor_form_fields[{{data.data.form_name}}][{{data.data.field_name}}][id]"
                type  = "hidden"
                value = "{{id}}"
            />
            <input 
                name  = "wpte_form_editor_form_fields[{{data.data.form_name}}][{{data.data.field_name}}][class]"
                type  = "hidden"
                value = "{{className}}"
            />
            <input 
                name  = "wpte_form_editor_form_fields[{{data.data.form_name}}][{{data.data.field_name}}][placeholder]"
                type  = "hidden"
                value = "{{placeholder}}"
            />
            <input 
                name  = "wpte_form_editor_form_fields[{{data.data.form_name}}][{{data.data.field_name}}][validations][required]"
                type  = "hidden"
                value = "{{required}}"
            />
            <# if ( options ) { #>
                <input 
                    name  = "wpte_form_editor_form_fields[{{data.data.form_name}}][{{data.data.field_name}}][options]"
                    type  = "hidden"
                    value = "{{options}}"
                />
            <# } #>
        </tr>
    </script>
<?php
