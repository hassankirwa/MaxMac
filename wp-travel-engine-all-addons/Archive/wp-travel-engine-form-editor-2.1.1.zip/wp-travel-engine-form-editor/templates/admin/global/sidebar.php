<?php
/**
 * Global settings screen sidebar
 * 
 * @package WTE_Form_Editor
 */
?>
<div class="wpte-fe-sidebar">
    <div class="wpte-fe-button-wrap">
        <button class="wpte-fe-button">
            <?php esc_html_e( 'Add Field', 'wte-form-editor' ); ?>
            <span class="fe-plus-sign"></span>
        </button>
    </div><!-- .wpte-fe-button-wrap -->

    <div class="wpte-fe-sidebar-wrap">
        <button class="wpte-fe-close"></button>
        <div class="wpte-fe-sidebar-inner">
            <div class="wpte-fe-sidebar-block">
                <h3 class="wpte-fe-sidebar-title"><?php esc_html_e( 'Basic Fields', 'wte-form-editor' ); ?></h3>
                <div class="wpte-fe-block-content">
                    <div class="wpte-fe-sidebar-repeater">
                        <input class="wte-form-editor-add-field" data-field-type="text" data-show-fields="<?php echo esc_attr( json_encode( wtefe_get_allowed_fields_for_type( 'text' ) ) ); ?>" type="radio" name="textfield" value="" id="fe-text-field">
                        <label for="fe-text-field">
                            <img src="<?php echo esc_url( WTE_FORM_EDITOR_PLUGIN_URL ); ?>/assets/images/text.jpg" alt="textfield">
                            <span class="wpte-fe-title"><?php esc_html_e( 'Text', 'wte-form-editor' ); ?></span>
                        </label>
                    </div>

                    <div class="wpte-fe-sidebar-repeater">
                        <input class="wte-form-editor-add-field" data-field-type="textarea" data-show-fields="<?php echo esc_attr( json_encode( wtefe_get_allowed_fields_for_type( 'textarea' ) ) ); ?>" type="radio" name="textareafield" value="" id="fe-textarea-field">
                        <label for="fe-textarea-field">
                            <img src="<?php echo esc_url( WTE_FORM_EDITOR_PLUGIN_URL ); ?>/assets/images/textarea.jpg" alt="textareafield">
                            <span class="wpte-fe-title"><?php esc_html_e( 'Text Area', 'wte-form-editor' ); ?></span>
                        </label>
                    </div>

                    <div class="wpte-fe-sidebar-repeater">
                        <input class="wte-form-editor-add-field" data-field-type="select" data-show-fields="<?php echo esc_attr( json_encode( wtefe_get_allowed_fields_for_type( 'select' ) ) ); ?>" type="radio" name="selectbox" value="" id="fe-selectbox">
                        <label for="fe-selectbox">
                            <img src="<?php echo esc_url( WTE_FORM_EDITOR_PLUGIN_URL ); ?>/assets/images/selsect-box.jpg" alt="selectbox">
                            <span class="wpte-fe-title"><?php esc_html_e( 'Select', 'wte-form-editor' ); ?></span>
                        </label>
                    </div>

                    <div class="wpte-fe-sidebar-repeater">
                        <input class="wte-form-editor-add-field" data-field-type="checkbox" data-show-fields="<?php echo esc_attr( json_encode( wtefe_get_allowed_fields_for_type( 'checkbox' ) ) ); ?>" type="radio" name="checkbox-field" value="" id="fe-checkbox">
                        <label for="fe-checkbox">
                            <img src="<?php echo esc_url( WTE_FORM_EDITOR_PLUGIN_URL ); ?>/assets/images/checkbox.jpg" alt="checkbox">
                            <span class="wpte-fe-title"><?php esc_html_e( 'Checkbox', 'wte-form-editor' ); ?></span>
                        </label>
                    </div>

                    <div class="wpte-fe-sidebar-repeater">
                        <input class="wte-form-editor-add-field" data-field-type="radio" data-show-fields="<?php echo esc_attr( json_encode( wtefe_get_allowed_fields_for_type( 'radio' ) ) ); ?>" type="radio" name="radiobutton" value="" id="fe-radiobutton">
                        <label for="fe-radiobutton">
                            <img src="<?php echo esc_url( WTE_FORM_EDITOR_PLUGIN_URL ); ?>/assets/images/radio-button.jpg" alt="radiobutton">
                            <span class="wpte-fe-title"><?php esc_html_e( 'Radio Buttons', 'wte-form-editor' ); ?></span>
                        </label>
                    </div>

                    <div class="wpte-fe-sidebar-repeater">
                        <input class="wte-form-editor-add-field" data-field-type="file" data-show-fields="<?php echo esc_attr( json_encode( wtefe_get_allowed_fields_for_type( 'file' ) ) ); ?>" type="radio" name="attachement-field" value="" id="fe-attachement">
                        <label for="fe-attachement">
                            <img src="<?php echo esc_url( WTE_FORM_EDITOR_PLUGIN_URL ); ?>/assets/images/attachment.jpg" alt="attachement">
                            <span class="wpte-fe-title"><?php esc_html_e( 'Attachement', 'wte-form-editor' ); ?></span>
                        </label>
                    </div>
                </div>
            </div>

            <div class="wpte-fe-sidebar-block">
                <h3 class="wpte-fe-sidebar-title"><?php esc_html_e( 'Advanced Fields', 'wte-form-editor' ); ?></h3>
                <div class="wpte-fe-block-content">
                    <div class="wpte-fe-sidebar-repeater">
                        <input class="wte-form-editor-add-field" data-field-type="country_dropdown" data-show-fields="<?php echo esc_attr( json_encode( wtefe_get_allowed_fields_for_type( 'country_dropdown' ) ) ); ?>" type="radio" name="country-field" value="" id="fe-country">
                        <label for="fe-country">
                            <img src="<?php echo esc_url( WTE_FORM_EDITOR_PLUGIN_URL ); ?>/assets/images/country.jpg" alt="country">
                            <span class="wpte-fe-title"><?php esc_html_e( 'Country Dropdown', 'wte-form-editor' ) ?></span>
                        </label>
                    </div>

                    <div class="wpte-fe-sidebar-repeater">
                        <input class="wte-form-editor-add-field" data-field-type="tel" data-show-fields="<?php echo esc_attr( json_encode( wtefe_get_allowed_fields_for_type( 'tel' ) ) ); ?>" type="radio" name="telephone-field" value="" id="fe-telephone">
                        <label for="fe-telephone">
                            <img src="<?php echo esc_url( WTE_FORM_EDITOR_PLUGIN_URL ); ?>/assets/images/telephone.jpg" alt="telephone">
                            <span class="wpte-fe-title"><?php esc_html_e( 'Telephone', 'wte-form-editor' ); ?></span>
                        </label>
                    </div>

                    <div class="wpte-fe-sidebar-repeater">
                        <input class="wte-form-editor-add-field" data-field-type="number" data-show-fields="<?php echo esc_attr( json_encode( wtefe_get_allowed_fields_for_type( 'number' ) ) ); ?>" type="radio" name="number-field" value="" id="fe-number">
                        <label for="fe-number">
                            <img src="<?php echo esc_url( WTE_FORM_EDITOR_PLUGIN_URL ); ?>/assets/images/number.jpg" alt="number">
                            <span class="wpte-fe-title"><?php esc_html_e( 'Number', 'wte-form-editor' ); ?></span>
                        </label>
                    </div>

                    <div class="wpte-fe-sidebar-repeater">
                        <input class="wte-form-editor-add-field" data-field-type="trips_list" data-show-fields="<?php echo esc_attr( json_encode( wtefe_get_allowed_fields_for_type( 'trips_list' ) ) ); ?>" type="radio" name="trip-field" value="" id="fe-trip">
                        <label for="fe-trip">
                            <img src="<?php echo esc_url( WTE_FORM_EDITOR_PLUGIN_URL ); ?>/assets/images/trip.jpg" alt="trip">
                            <span class="wpte-fe-title"><?php esc_html_e( 'Trips List', 'wte-form-editor' ); ?></span>
                        </label>
                    </div>

                    <div class="wpte-fe-sidebar-repeater">
                        <input class="wte-form-editor-add-field" data-field-type="grecaptcha_v2" data-show-fields="<?php echo esc_attr( json_encode( wtefe_get_allowed_fields_for_type( 'grecaptcha_v2' ) ) ); ?>" type="radio" name="captcha-field" value="" id="fe-captcha">
                        <label for="fe-captcha">
                            <img src="<?php echo esc_url( WTE_FORM_EDITOR_PLUGIN_URL ); ?>/assets/images/captcha.jpg" alt="captcha">
                            <span class="wpte-fe-title"><?php esc_html_e( 'Captcha', 'wte-form-editor' ); ?></span>
                        </label>
                    </div>

                    <div class="wpte-fe-sidebar-repeater">
                        <input class="wte-form-editor-add-field" data-field-type="datepicker" data-show-fields="<?php echo esc_attr( json_encode( wtefe_get_allowed_fields_for_type( 'datepicker' ) ) ); ?>" type="radio" name="date-field" value="" id="fe-date">
                        <label for="fe-date">
                            <img src="<?php echo esc_url( WTE_FORM_EDITOR_PLUGIN_URL ); ?>/assets/images/date.jpg" alt="date">
                            <span class="wpte-fe-title"><?php esc_html_e( 'Datepicker', 'wte-form-editor' ); ?></span>
                        </label>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- .wpte-fe-sidebar-wrap -->
</div>
<?php
