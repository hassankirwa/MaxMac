<?php
/**
 * Travellers information form tab contents.
 * 
 * @package WTE_Form_Editor
 */
$travellers_fields = WTE_Default_Form_Fields::traveller_information();
$wpte_form_editor_form_fields = get_option( 'wpte_form_editor_form_fields', true );

if( isset( $wpte_form_editor_form_fields['travellers_info_form'] ) && ! empty( $wpte_form_editor_form_fields['travellers_info_form'] ) ) {
    $travellers_fields = $wpte_form_editor_form_fields['travellers_info_form'];
}
?>
<div id="fe-tab3-content" class="wpte-fe-tab-content">
    <table class="wte-form-editor-editable-fields">
        <thead>
            <tr>
                <th><?php esc_html_e( 'Sort', 'wte-form-editor' ); ?></th>
                <th><?php esc_html_e( 'Field Type', 'wte-form-editor' ); ?></th>
                <th><?php esc_html_e( 'Field label', 'wte-form-editor' ); ?></th>
                <th><?php esc_html_e( 'Field Name', 'wte-form-editor' ); ?></th>
                <th><?php esc_html_e( 'Actions', 'wte-form-editor' ); ?></th>
            </tr>
        </thead>
        <tbody class="wpte-fe-repeater-fields">
            <?php
                foreach( $travellers_fields as $key => $field ) {
                    $args = array(
                        'form_name' => 'travellers_info_form',
                        'field'     => $field,
                        'key'       => $key,
                    );
                    wtefe_get_template( 'admin/partials/field-row.php', $args );
                }
            ?>
        </tbody>
    </table>
</div><!-- .wpte-fe-tab-content -->
<?php
