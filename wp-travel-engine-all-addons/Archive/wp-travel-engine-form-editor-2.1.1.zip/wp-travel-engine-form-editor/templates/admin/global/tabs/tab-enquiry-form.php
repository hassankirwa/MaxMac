<?php
/**
 * Enquiry form editor tab contents
 * 
 * @package WTE_Form_Editor
 */
$enquiry_fields               = WTE_Default_Form_Fields::enquiry();
$wpte_form_editor_form_fields = get_option( 'wpte_form_editor_form_fields', true );

if( isset( $wpte_form_editor_form_fields['enquiry_form'] ) && ! empty( $wpte_form_editor_form_fields['enquiry_form'] ) ) {
    $enquiry_fields = $wpte_form_editor_form_fields['enquiry_form'];
} 
?>
<div id="fe-tab1-content" class="wpte-fe-tab-content active">
    <table class="wte-form-editor-editable-fields">
        <thead>
            <tr>
                <th><?php esc_html_e( 'Sort', 'wte-form-editor' ); ?></th>
                <th><?php esc_html_e( 'Field Type', 'wte-form-editor' ); ?></th>
                <th><?php esc_html_e( 'Field label', 'wte-form-editor' ); ?></th>
                <th><?php esc_html_e( 'Field Name', 'wte-form-editor' ); ?></th>
                <th><?php esc_html_e( 'Actions', 'wte-form-editor' ); ?></th>
            </tr>
        </thead>
        <tbody class="wpte-fe-repeater-fields">
            <?php 
                foreach( $enquiry_fields as $key => $field ) {
                    $args = array(
                        'form_name' => 'enquiry_form',
                        'field'     => $field,
                        'key'       => $key,
                    );
                    wtefe_get_template( 'admin/partials/field-row.php', $args );
                }
            ?>
        </tbody>
    </table>
</div><!-- .wpte-fe-tab-content -->
<?php
