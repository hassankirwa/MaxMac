<?php
/**
 * Emaergency Contact form tab contents.
 * 
 * @package WTE_Form_Editor
 */
$emergency_contact = WTE_Default_Form_Fields::emergency_contact();
$wpte_form_editor_form_fields = get_option( 'wpte_form_editor_form_fields', true );

if( isset( $wpte_form_editor_form_fields['emergency_contact_info'] ) && ! empty( $wpte_form_editor_form_fields['emergency_contact_info'] ) ) {
    $emergency_contact = $wpte_form_editor_form_fields['emergency_contact_info'];
}
?>
<div id="fe-tab4-content" class="wpte-fe-tab-content">
    <table class="wte-form-editor-editable-fields">
        <thead>
            <tr>
                <th><?php esc_html_e( 'Sort', 'wte-form-editor' ); ?></th>
                <th><?php esc_html_e( 'Field Type', 'wte-form-editor' ); ?></th>
                <th><?php esc_html_e( 'Field label', 'wte-form-editor' ); ?></th>
                <th><?php esc_html_e( 'Field Name', 'wte-form-editor' ); ?></th>
                <th><?php esc_html_e( 'Actions', 'wte-form-editor' ); ?></th>
            </tr>
        </thead>
        <tbody class="wpte-fe-repeater-fields">
            <?php
                foreach( $emergency_contact as $key => $field ) {
                    $args = array(
                        'form_name' => 'emergency_contact_info',
                        'field'     => $field,
                        'key'       => $key,
                    );
                    wtefe_get_template( 'admin/partials/field-row.php', $args );
                }
            ?>
        </tbody>
    </table>
</div><!-- .wpte-fe-tab-content -->
<?php
