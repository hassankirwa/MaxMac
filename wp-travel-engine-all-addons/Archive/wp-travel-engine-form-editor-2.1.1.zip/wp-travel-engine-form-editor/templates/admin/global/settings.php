<?php
/**
 * Template for form editor settings.
 * 
 * @package WTE_Form_Editor
 */
?>
<div class="wpte-fe-outer">

	<div class="wpte-fe-inner">

		<?php
			/**
			 * Hook - load tabs header
			 * 
			 * @hooked - GlobalSettings()->load_tabs_header() - 10
			 */
			do_action( 'wpte_global_settings_tabs_header' );
		?>

		<div class="wpte-fe-tab-content-wrap">
			<?php
				if ( isset( $_GET['wtefe_reset_all_fields'] ) 
					&& 'true' == $_GET['wtefe_reset_all_fields'] 
					&& isset( $_GET['wpte_reset_all_nonce'] ) 
					&& wp_verify_nonce( $_GET['wpte_reset_all_nonce'], 'wpte_reset_all_nonce' ) ) {
						// Reset Fields action.
						delete_option( 'wpte_form_editor_form_fields' );
				?>
						<div id="wtefe-message" class="notice notice-success is-dismissible"><p><?php _e( 'All fields has been set to default values.', 'wte-form-editor' ); ?> <button type="button" class="notice-dismiss"><span class="screen-reader-text"><?php _e( 'Dismiss this notice.', 'wte-form-editor' ); ?></span></button></div>
						<script>
							history.replaceState({},null,"<?php echo admin_url( 'edit.php?post_type=trip&page=wtefe_edit_form_screen' ); ?>");
						</script>
			<?php
			}
				/**
				 * Hook - load global sidebar
				 * 
				 * @hooked - GlobalSettings()->load_sidebar() - 10
				 */
				do_action( 'wpte_global_settings_sidebar' );

				/**
				 * Hook - load Enquiry Form tab
				 * 
				 * @hooked - GlobalSettings()->load_enquiry_form_tab() - 10
				 */
				do_action( 'wpte_global_settings_enquiry_form_tab' );

				/**
				 * Hook - load Checkout Form tab
				 * 
				 * @hooked - GlobalSettings()->load_checkout_form_tab() - 10
				 */
				do_action( 'wpte_global_settings_checkout_form_tab' );

				/**
				 * Hook - load Traveller Information Form tab
				 * 
				 * @hooked - GlobalSettings()->load_travellers_information_form_tab() - 10
				 */
				do_action( 'wpte_global_settings_traveller_information_form_tab' );

				/**
				 * Hook - load Emergency Conatact Info Form tab
				 * 
				 * @hooked - GlobalSettings()->load_emergency_contact_info_form_tab() - 10
				 */
				do_action( 'wpte_global_settings_emergency_contact_form_tab' );

				/**
				 * Hook - Settings save / Submit button.
				 * 
				 * @hooked - GlobalSettings()->load_global_settings_save_submit_btn() - 10
				 */
				do_action( 'wpte_global_settings_save_submit_btn' );
				
				/**
				 * Hook - After save submit button || Popup form
				 * 
				 * @hooked - GlobalSettings()->load_all_fields_popup_form() - 10
				 */
				do_action( 'wpte_settings_after_settings_save_button' );

			?>

		</div><!-- .wpte-fe-tab-content-wrap -->

	</div><!-- .wpte-fe-inner -->

</div><!-- .wpte-fb-outer -->
<?php
