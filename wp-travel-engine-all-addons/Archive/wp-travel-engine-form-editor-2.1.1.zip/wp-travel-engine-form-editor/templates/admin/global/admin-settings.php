<?php
/**
 * Global Settings
 */
$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings' );

$wtefe_settings_defaults =
    array(
        'grecaptcha_site_key' => '',
        'recaptcha_v2_secret_key' => ''
    );

$wtefe_settings = isset( $wp_travel_engine_settings['form_editor'] ) ? stripslashes_deep( $wp_travel_engine_settings['form_editor'] ) : $wtefe_settings_defaults;
?>
    
        <div class="wpte-field wpte-floated">
            <label class="wpte-field-label" for="wp_travel_engine_settings[form_editor][grecaptcha_site_key]"><?php _e( 'Google reCaptcha site key','wte-form-editor' ); ?></label>

            <input value="<?php echo esc_attr( $wtefe_settings['grecaptcha_site_key'] ); ?>" type="text" name="wp_travel_engine_settings[form_editor][grecaptcha_site_key]" id="wp_travel_engine_settings[form_editor][grecaptcha_site_key]">
            <span class="wpte-tooltip"><?php esc_html_e( 'Enter google recaptcha site key.', 'wte-form-editor' ); ?></span>
        </div>

        <div class="wpte-field wpte-floated">
            <label class="wpte-field-label" for="wp_travel_engine_settings[form_editor][recaptcha_v2_secret_key]"><?php _e( 'Google reCaptcha secret key','wte-form-editor' ); ?></label>

            <input value="<?php echo esc_attr( $wtefe_settings['recaptcha_v2_secret_key'] ); ?>" type="text" name="wp_travel_engine_settings[form_editor][recaptcha_v2_secret_key]" id="wp_travel_engine_settings[form_editor][recaptcha_v2_secret_key]">
            <span class="wpte-tooltip"><?php esc_html_e( 'Enter google recaptcha secret key.', 'wte-form-editor' ); ?></span>
        </div>
