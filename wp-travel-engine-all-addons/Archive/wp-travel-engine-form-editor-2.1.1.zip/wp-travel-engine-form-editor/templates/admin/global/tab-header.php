<?php
/**
 * Tab header template for admin global settings.
 * 
 * @package WTE_Form_Editor
 */
?>
<div class="wpte-fe-tab-wrap">
    <div class="wpte-fe-tab-inner">
        <button id="fe-tab1" data-form="enquiry_form" class="wpte-fe-tab active"><?php esc_html_e( 'Enquiry Form', 'wte-form-editor' ); ?></button>
        <button id="fe-tab2" data-form="checkout_form" class="wpte-fe-tab"><?php esc_html_e( 'Checkout Form', 'wte-form-editor' ); ?></button>
        <button id="fe-tab3" data-form="travellers_info_form" class="wpte-fe-tab"><?php esc_html_e( 'Traveller Information', 'wte-form-editor' ); ?></button>
        <button id="fe-tab4" data-form="emergency_contact_info" class="wpte-fe-tab"><?php esc_html_e( 'Emergency Contact', 'wte-form-editor' ); ?></button>
    </div>
</div><!-- .wpte-fe-tab-wrap -->
<?php
