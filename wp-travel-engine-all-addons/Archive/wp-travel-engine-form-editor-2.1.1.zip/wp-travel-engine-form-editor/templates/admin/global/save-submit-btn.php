<?php
/**
 * Global settings save / submit button.
 * 
 * @package WTE_Form_Editor
 */
wp_nonce_field( 'wte_form_editor_save_form_fields_action', 'wte_form_editor_save_form_fields_nonce' );
$reset_nonce = wp_create_nonce( 'wpte_reset_all_nonce' );
?>
<div class="wtefe-save-reset-btns">
    <button data-nonce="<?php echo esc_attr( $reset_nonce ); ?>" id="wte-formeditor-reset-defaults-fldsbtn" class="button" name="wte_form_editor_reset_fields_btn"><?php esc_html_e( 'Reset to defaults', 'wte-form-editor' ); ?></button>
    <button id="wte-formeditor-save-fldsbtn" class="button" name="wte_form_editor_save_fields_btn"><?php esc_html_e( 'Save Fields', 'wte-form-editor' ); ?></button>
</div>

<?php
