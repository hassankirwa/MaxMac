<?php
/**
 * Field Row temeplate.
 */
$field_name = sanitize_title( $args['key'] );
?>
<tr data-field-name="<?php echo esc_attr( $field_name ) ?>" class="wpte-fe-field-settings-row">
    <td><span class="wpte-fe-repeater-fields-handle"><i class="fas fa-sort"></i></span></td>
    <td data-fieldtypedisp='<?php echo esc_attr( $args['field']['type'] ); ?>' ><?php echo esc_attr( $args['field']['type'] ); ?></td>
    <td data-fieldlabeldisp='<?php echo esc_attr( $args['form_name'] ); ?>_<?php echo esc_attr( $field_name ) ?>' ><?php echo esc_attr( $args['field']['field_label'] ) ?></td>
    <td data-fieldnamedisp='<?php echo esc_attr( $args['form_name'] ); ?>_<?php echo esc_attr( $field_name ) ?>' >
        <span>
            <?php if ( isset( $args['field']['default_field'] ) ) : ?>
                    <?php echo esc_attr( $field_name ) ?>
                <?php else : ?>
                    {<?php echo esc_attr( $field_name ) ?>}
            <?php endif; ?>
        </span>
    </td>
    <td>
        <span class="wte_fe_editrow"
                data-field-name = '<?php echo esc_attr( $field_name ) ?>'
                data-form-name  = '<?php echo esc_attr( $args['form_name'] ); ?>'
                data-showfields = '<?php echo json_encode( wtefe_get_allowed_fields_for_type( $args['field']['type'] ) ); ?>'
                data-field-type = '<?php echo esc_attr( $args['field']['type'] ); ?>'
        >
            <i 
                data-field-name = '<?php echo esc_attr( $field_name ) ?>'
                data-form-name  = '<?php echo esc_attr( $args['form_name'] ); ?>'
                data-showfields = '<?php echo json_encode( wtefe_get_allowed_fields_for_type( $args['field']['type'] ) ); ?>'
                data-field-type = '<?php echo esc_attr( $args['field']['type'] ); ?>'
                class           = 'fas fa-pencil-alt'>
            </i>
            <?php _e( 'Edit', 'wte-form-editor' ); ?>
        </span>
        <?php if ( ! isset( $args['field']['required_field'] ) || ! $args['field']['required_field']  ) { ?>
            <span>
                <i 
                    data-field-name='<?php echo esc_attr( $field_name ) ?>' 
                    class='far fa-trash-alt'>
                </i>
            </span>
        <?php } ?>
    </td>
    <input 
        name  = "wpte_form_editor_form_fields[<?php echo esc_attr( $args['form_name'] ); ?>][<?php echo esc_attr( $field_name ) ?>][type]"
        type  = "hidden"
        value = "<?php echo esc_attr( $args['field']['type'] ); ?>"
    />
    <input 
        name  = "wpte_form_editor_form_fields[<?php echo esc_attr( $args['form_name'] ); ?>][<?php echo esc_attr( $field_name ) ?>][field_label]"
        type  = "hidden"
        value = "<?php echo esc_attr( $args['field']['field_label'] ); ?>"
    />
    <input 
        name  = "wpte_form_editor_form_fields[<?php echo esc_attr( $args['form_name'] ); ?>][<?php echo esc_attr( $field_name ) ?>][name]"
        type  = "hidden"
        value = "<?php echo esc_attr( $field_name ); ?>"
    />
    <input 
        name  = "wpte_form_editor_form_fields[<?php echo esc_attr( $args['form_name'] ); ?>][<?php echo esc_attr( $field_name ) ?>][id]"
        type  = "hidden"
        value = "<?php echo esc_attr( $args['field']['id'] ); ?>"
    />
    <input 
        name  = "wpte_form_editor_form_fields[<?php echo esc_attr( $args['form_name'] ); ?>][<?php echo esc_attr( $field_name ) ?>][class]"
        type  = "hidden"
        value = "<?php echo isset( $args['field']['class'] ) ? esc_attr( $args['field']['class'] ) : ''; ?>"
    />
    <input 
        name  = "wpte_form_editor_form_fields[<?php echo esc_attr( $args['form_name'] ); ?>][<?php echo esc_attr( $field_name ) ?>][placeholder]"
        type  = "hidden"
        value = "<?php echo isset( $args['field']['placeholder'] ) ? esc_attr( $args['field']['placeholder'] ) : ''; ?>"
    />
    <input 
        name  = "wpte_form_editor_form_fields[<?php echo esc_attr( $args['form_name'] ); ?>][<?php echo esc_attr( $field_name ) ?>][validations][required]"
        type  = "hidden"
        value = "<?php echo isset( $args['field']['validations']['required'] ) && ( '1' == $args['field']['validations']['required'] || 'true' == $args['field']['validations']['required'] ) ? 'true'  : 'false' ; ?>"
    />
    <?php
        if ( isset( $args['field']['options'] ) ) { 
            $options = $args['field']['options'];
            if ( is_array( $args['field']['options'] ) ) {
                $options = json_encode( $args['field']['options'] );
            }
    ?>
            <input 
                name  = "wpte_form_editor_form_fields[<?php echo esc_attr( $args['form_name'] ); ?>][<?php echo esc_attr( $field_name ) ?>][options]"
                type  = "hidden"
                value = "<?php echo esc_attr( $options ); ?>"
            />
    <?php 
        }
    ?>
    <?php
        if ( isset( $args['field']['default_field'] ) ) { 
    ?>
            <input 
                name  = "wpte_form_editor_form_fields[<?php echo esc_attr( $args['form_name'] ); ?>][<?php echo esc_attr( $field_name ) ?>][default_field]"
                type  = "hidden"
                value = "<?php echo esc_attr( $args['field']['default_field'] ); ?>"
            />
    <?php 
        }
    ?>
    <?php
        if ( isset( $args['field']['required_field'] ) ) { 
    ?>
            <input 
                name  = "wpte_form_editor_form_fields[<?php echo esc_attr( $args['form_name'] ); ?>][<?php echo esc_attr( $field_name ) ?>][required_field]"
                type  = "hidden"
                value = "<?php echo esc_attr( $args['field']['required_field'] ); ?>"
            />
    <?php 
        }
    ?>
</tr>
<?php
