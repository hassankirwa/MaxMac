<?php
/**
 * Plugin Name:     WP Travel Engine - Form Editor
 * Plugin URI:      https://wptravelengine.com
 * Description:     An addon to WP Travel Engine plugin that lets users to edit forms.
 * Author:          WP Travel Engine
 * Author URI:      https://wptravelengine.com
 * Text Domain:     wte-form-editor
 * Domain Path:     /languages
 * Version:         2.1.1
 * WTE tested up to: 5.2
 * WTE reqires at least: 4.3.0
 * WTE: 33247:wte_form_editor_license_key
 *
 * @package         Wte_Form_Editor
 */

use Wfe\FormEditor;

defined( 'ABSPATH' ) || exit;

// Include the autoloader.
require_once __DIR__ . '/vendor/autoload.php';

if ( ! defined( 'WTE_FORM_EDITOR_PLUGIN_FILE' ) ) {
	define( 'WTE_FORM_EDITOR_PLUGIN_FILE', __FILE__ );
}

defined( 'WTE_FORM_EDITOR_REQUIRES_AT_LEAST' ) || define( 'WTE_FORM_EDITOR_REQUIRES_AT_LEAST', '4.3.0' );

/**
 * Return the main instance of FormEditor.
 *
 * @since 1.0.0
 * @return FormEditor
 */
function WTE_FE() { // phpcs:ignore WordPress.NamingConventions.ValidFunctionName.FunctionNameInvalid
	return FormEditor::instance();
}

add_action(
	'plugins_loaded',
	function() {
		if ( ! defined( 'WP_TRAVEL_ENGINE_VERSION' ) || version_compare( WP_TRAVEL_ENGINE_VERSION, WTE_FORM_EDITOR_REQUIRES_AT_LEAST, '<' ) ) {
			add_action(
				'admin_notices',
				function() {
					echo wp_kses_post(
						sprintf(
							'<div class="error"><p>'
							// translators: 1. WTE Extension Name 2. Link to WTE Plugin.
							. sprintf( __( '%1$s requires the %2$s plugin to work. Please install and activate the latest <strong>WP Travel Engine</strong> plugin first.', 'wp-travel-engine-group-discount' ), '<strong>WP Travel Engine - Form Editor</strong>', '<a href="https://wordpress.org/plugins/wp-travel-enigne" target="__blank">WP Travel Engine</a>' )
							. '</p></div>'
						)
					);
				}
			);
		} else {
			// Global for backwards compatibility.
			$GLOBALS['WTE_FE'] = WTE_FE();
		}
	}
);
