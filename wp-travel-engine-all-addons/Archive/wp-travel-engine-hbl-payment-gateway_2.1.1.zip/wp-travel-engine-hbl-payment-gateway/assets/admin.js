jQuery(function ($) {
    if ($('.hbl').is(':checked')) {
        $('.wte-hbl-form.settings').fadeIn('slow');
    }
    else {
        $('.wte-hbl-form.settings').fadeOut('slow');
    }
    $('body').on('click', '.hbl', function (e) {
        if ($('.hbl').is(':checked')) {
            $('.wte-hbl-form.settings').fadeIn('slow');
        }
        else {
            $('.wte-hbl-form.settings').fadeOut('slow');
        }
    });


    jQuery('body').on('click', '#wtehbl_generate_merchant_signing_key', function (e) {
        e.preventDefault()
        var template = wp.template('wte-hbl-merchant-signing-keys')
        $('#wte-hbl-merchant-signing-keys').html(template())
    })

    jQuery(document).on('change', '#wp_travel_engine_settings_merchant_signing_public_key, #wp_travel_engine_settings_merchant_encryption_public_key', function () {
        var $this = jQuery(this);

        var container = jQuery('#wp_travel_engine_settings_merchant_public_keys')

        if (container[0]) {
            var data = container[0] && container[0].value

            if (data.length > 0) {
                data = JSON.parse(data)
            } else {
                data = {}
            }

            var key = $this.data('key')
            data[key] = $this.val()

            container[0].value = JSON.stringify(data)
            console.log({ data })

        }
    })

    document.addEventListener('wteSettingsTabContentLoaded', function (_e) {

        if ('wpte-payment-content' === _e.detail.contentKey + '-content') {
            hljs && document.getElementById('wp_travel_engine_settings_merchant_public_keys') && hljs.highlightBlock(document.getElementById('wp_travel_engine_settings_merchant_public_keys'))
        }
    });

});
