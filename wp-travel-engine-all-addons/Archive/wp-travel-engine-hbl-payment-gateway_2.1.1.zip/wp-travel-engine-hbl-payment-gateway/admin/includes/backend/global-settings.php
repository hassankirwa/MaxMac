<?php
/**
 * Get Global Settings
 */
$office_id                       = 'DEMOOFFICE';
$api_key                         = '';
$merchant_signing_private_key    = '';
$merchant_decryption_private_key = '';
$paco_encryption_public_key      = '';
$paco_signing_public_key         = '';
$key_id                          = '';

$notification_url_base = home_url();
$query_arg             = array( '_gateway' => 'hbl_enable' );

$query_arg['_action'] = 'wtep_success';
$confirmation_url     = add_query_arg( $query_arg, $notification_url_base );
$query_arg['_action'] = 'wtep_fail';
$failed_url           = add_query_arg( $query_arg, $notification_url_base );
$query_arg['_action'] = 'wtep_cancel';
$cancel_url           = add_query_arg( $query_arg, $notification_url_base );
$query_arg['_action'] = 'wtep_ipn';
$backend_url          = add_query_arg( $query_arg, $notification_url_base );

$wte_settings = get_option( 'wp_travel_engine_settings', array() );
$hbl_settings = isset( $wte_settings['hbl_settings'] ) ? $wte_settings['hbl_settings'] : compact( 'office_id', 'confirmation_url', 'failed_url', 'cancel_url', 'backend_url' );
$enable_3ds = isset( $wte_settings['enable_3ds'] ) && 'yes' == $wte_settings['enable_3ds'];
extract( $hbl_settings );

?>
<div class="wpte-field wpte-text wpte-floated">
	<label for="wp_travel_engine_settings[hbl_office_id]" class="wpte-field-label"><?php _e( 'Office ID', 'wte-hbl' ); ?></label>
	<input type="text" id="wp_travel_engine_settings[hbl_office_id]" name="wp_travel_engine_settings[hbl_settings][office_id]" value="<?php echo esc_attr( $office_id ); ?>">
	<span class="wpte-tooltip"><?php esc_html_e( 'Get office ID from the Bank.', 'wte-hbl' ); ?></span>
</div>
<!-- API KEY -->
<div class="wpte-field wpte-text wpte-floated">
	<label for="wp_travel_engine_settings[api_key]" class="wpte-field-label"><?php _e( 'API Key', 'wte-hbl' ); ?></label>
	<input type="text" id="wp_travel_engine_settings[api_key]" name="wp_travel_engine_settings[hbl_settings][api_key]" value="<?php echo esc_attr( $api_key ); ?>">
	<span class="wpte-tooltip"><?php esc_html_e( 'Get office API Key from the bank.', 'wte-hbl' ); ?></span>
</div>
<!-- Encryption Key ID - kid -->
<div class="wpte-field wpte-text wpte-floated">
	<label for="wp_travel_engine_settings[key_id]" class="wpte-field-label"><?php _e( 'Encryption Key ID', 'wte-hbl' ); ?></label>
	<input type="text" id="wp_travel_engine_settings[key_id]" name="wp_travel_engine_settings[hbl_settings][key_id]" value="<?php echo esc_attr( $key_id ); ?>">
	<span class="wpte-tooltip"><?php esc_html_e( 'Get Encryption Key ID from the bank.', 'wte-hbl' ); ?></span>
</div>
<!-- Enable 3DS -->
<div class="wpte-field wpte-checkbox advance-checkbox">
	<label for="wp_travel_engine_settings[enable_3ds]" class="wpte-field-label"><?php _e( 'Enable 3DS', 'wte-hbl' ); ?></label>
	<div class="wpte-checkbox-wrap">
		<input type="hidden" name="wp_travel_engine_settings[enable_3ds]" value="no">
		<input type="checkbox" id="wp_travel_engine_settings[enable_3ds]" name="wp_travel_engine_settings[enable_3ds]" value="yes" <?php checked( $enable_3ds, true );?>>
		<label for="wp_travel_engine_settings[enable_3ds]"></label>
	</div>
</div>

<!-- Encrypt Decrypt Keys -->
<div class="wpte-field wpte-multi-checkbox">
	<div class="wpte-title-wrap">
		<h3 class="wpte-title"><?php esc_html_e( 'Encryption Keys', 'wte-hbl' ); ?></h3>
	</div>
	<?php
	$hbl_keys_data = WTE_HBL_Payments_Handler::get_hbl_keys_data();

	if ( $hbl_keys_data ) {
		?>
		<div id="wte-hbl-merchant-signing-keys">
			<div class="wpte-field wpte-text wpte-floated">
				<p><strong><?php echo esc_html( 'The keys are saved in a file.' ); ?></strong> <a href="#" id="wtehbl_generate_merchant_signing_key"><?php echo esc_html( 'Add New Signing/Encryption Keys' ); ?></a></p>
			</div>
			<?php
			if ( isset( $hbl_keys_data->merchant_encryption_public_key, $hbl_keys_data->merchant_signing_public_key ) ) :
				$merchant_public_keys = array(
					'merchant_encryption_public_key' => $hbl_keys_data->merchant_encryption_public_key,
					'merchant_signing_public_key'    => $hbl_keys_data->merchant_signing_public_key,
				);
				?>
				<div class="wpte-title-wrap">
					<p style="width:100%">
					<?php
					printf(
						wp_kses(
							'<strong>Note: </strong>Copy the keys from below and provide it to the bank. Make sure the keys are entered properly.',
							array(
								'strong' => array(),
								'a'      => array(
									'href'   => array(),
									'target' => array(),
									'id'     => array(),
								),
							)
						)
					);
					?>
					</p>
					<div class="wpte-field wpte-text wpte-floated" style="max-width:100%;box-sizing:border-box;">
						<pre style="width:100%"><code id="wp_travel_engine_settings_merchant_public_keys" readonly><?php echo json_encode( $merchant_public_keys, JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT  ); ?></code></pre>
						<span class="wpte-tooltip"><?php esc_html_e( 'The above keys must be provided to the bank to get API Keys.', 'wte-hbl' ); ?></span>
					</div>
				</div>
			<?php
			endif;
			?>
		</div>
		<?php
	} else {
		?>
		<div id="wte-hbl-merchant-signing-keys">
			<div class="wpte-field wpte-text wpte-floated">
				<p><?php _e( "Please read the <a target=\"_blank\" href=\"https://docs.wptravelengine.com/docs/himalayan-bank-payment-gateway/#3-toc-title\">documentation</a> before generating keys. ", 'wte-hbl' ); ?><a href="#" id="wtehbl_generate_merchant_signing_key"><?php echo esc_html( 'Add Signing/Encryption Keys' ); ?></a></p>
			</div>
		</div>
	<?php } ?>
</div>

<!-- Notification URLs -->
<div class="wpte-field wpte-multi-checkbox">
	<div class="wpte-title-wrap">
		<h3 class="wpte-title"><?php esc_html_e( 'Notification URLs', 'wte-hbl' ); ?></h3>
	</div>
	<!-- Success URL -->
	<div class="wpte-field wpte-text wpte-floated">
		<label for="wp_travel_engine_settings[hbl_success_url]" class="wpte-field-label"><?php _e( 'Confirmation URL', 'wte-hbl' ); ?></label>
		<input type="text" id="wp_travel_engine_settings[hbl_success_url]" name="wp_travel_engine_settings[hbl_settings][confirmation_url]" value="<?php echo esc_attr( $confirmation_url ); ?>">
		<span class="wpte-tooltip"><?php esc_html_e( 'URL to redirect customer back to Merchant website after success.', 'wte-hbl' ); ?></span>
	</div>
	<!-- Cancel URL -->
	<div class="wpte-field wpte-text wpte-floated">
		<label for="wp_travel_engine_settings[hbl_cancel_url]" class="wpte-field-label"><?php _e( 'Cancellation URL', 'wte-hbl' ); ?></label>
		<input type="text" id="wp_travel_engine_settings[hbl_cancel_url]" name="wp_travel_engine_settings[hbl_settings][cancel_url]" value="<?php echo esc_attr( $cancel_url ); ?>">
		<span class="wpte-tooltip"><?php esc_html_e( 'Redirect URL if customer cancel the transaction.', 'wte-hbl' ); ?></span>
	</div>
	<!-- Failed URL -->
	<div class="wpte-field wpte-text wpte-floated">
		<label for="wp_travel_engine_settings[hbl_failed_url]" class="wpte-field-label"><?php _e( 'Failed URL', 'wte-hbl' ); ?></label>
		<input type="text" id="wp_travel_engine_settings[hbl_failed_url]" name="wp_travel_engine_settings[hbl_settings][failed_url]" value="<?php echo esc_attr( $failed_url ); ?>">
		<span class="wpte-tooltip"><?php esc_html_e( 'Redirect URL if transaction is failed.', 'wte-hbl' ); ?></span>
	</div>
	<!-- Backend URL -->
	<div class="wpte-field wpte-text wpte-floated">
		<label for="wp_travel_engine_settings[hbl_backend_url]" class="wpte-field-label"><?php _e( 'Notification URL', 'wte-hbl' ); ?></label>
		<input type="text" id="wp_travel_engine_settings[hbl_backend_url]" name="wp_travel_engine_settings[hbl_settings][backend_url]" value="<?php echo esc_attr( $backend_url ); ?>">
		<span class="wpte-tooltip"><?php esc_html_e( 'Payment Gateway Notification URL.', 'wte-hbl' ); ?></span>
	</div>
</div>

<script type="text/html" id="tmpl-wte-hbl-merchant-signing-keys">
	<div class="wpte-title-wrap">
		<h4 class="wpte-title"><?php esc_html_e( 'Merchant Signing Keys', 'wte-hbl' ); ?></h4>
		<p style="width:100%">
		<?php
		printf(
			wp_kses(
				'<strong>Step 1: </strong>Generate a Signing key Pair from %shere%s and enter below.',
				array(
					'strong' => array(),
					'a'      => array(
						'href'   => array(),
						'target' => array(),
						'id'     => array(),
					),
				)
			),
			'<a href="https://www.devglan.com/online-tools/rsa-encryption-decryption" target="_blank" id="wtehbl_generate_merchant_signing_key">',
			'</a>'
		);
		?>
		</p>
	</div>
	<table>
		<thead>
			<tr>
				<th><?php echo esc_html( 'Public Key' ); ?></th>
				<th><?php echo esc_html( 'Private Key' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>
					<!-- Merchant Signing Public Key -->
					<div class="wpte-field wpte-text wpte-floated">
						<textarea id="wp_travel_engine_settings_merchant_signing_public_key]" name="wptravelengine_hbl_merchant_signing_public_key"></textarea>
						<span class="wpte-tooltip"><?php esc_html_e( 'Merchant Signing Public Key is used to cryptographically sign and create the request JWS.', 'wte-hbl' ); ?></span>
					</div>
				</td>
				<td>
					<!-- Merchant Signing Private Key -->
					<div class="wpte-field wpte-text wpte-floated">
						<textarea id="wp_travel_engine_settings[merchant_signing_private_key]" name="wptravelengine_hbl_merchant_signing_private_key"></textarea>
						<span class="wpte-tooltip"><?php esc_html_e( 'Merchant Signing Private Key is used to cryptographically sign and create the request JWS.', 'wte-hbl' ); ?></span>
					</div>
				</td>
			</tr>
		</tbody>
	</table>
	<div class="wpte-title-wrap">
		<h4 class="wpte-title"><?php esc_html_e( 'Merchant Encryption Keys', 'wte-hbl' ); ?></h4>
		<p style="width:100%">
		<?php
		printf(
			wp_kses(
				'<strong>Step 2: </strong>Generate another key Pair for encryption from %shere%s and enter below.',
				array(
					'strong' => array(),
					'a'      => array(
						'href'   => array(),
						'target' => array(),
						'id'     => array(),
					),
				)
			),
			'<a href="https://www.devglan.com/online-tools/rsa-encryption-decryption" target="_blank" id="wtehbl_generate_merchant_signing_key">',
			'</a>'
		);
		?>
		</p>
	</div>
	<table>
		<thead>
			<tr>
				<th><?php echo esc_html( 'Public Key' ); ?></th>
				<th><?php echo esc_html( 'Private Key' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>
					<!-- Merchant Encryption Public Key -->
					<div class="wpte-field wpte-text wpte-floated">
						<textarea id="wp_travel_engine_settings_merchant_encryption_public_key" name="wptravelengine_hbl_merchant_encryption_public_key"></textarea>
						<span class="wpte-tooltip"><?php esc_html_e( 'Merchant Encryption Public Key is used to cryptographically sign and create the request JWS.', 'wte-hbl' ); ?></span>
					</div>
				</td>
				<td>
					<!-- Merchant Signing Private Key -->
					<div class="wpte-field wpte-text wpte-floated">
						<textarea id="wp_travel_engine_settings[merchant_decryption_private_key]" name="wptravelengine_hbl_merchant_decryption_private_key"></textarea>
						<span class="wpte-tooltip"><?php esc_html_e( 'Merchant Encryption Private Key is used to cryptographically encrypt and create the request JWE.', 'wte-hbl' ); ?></span>
					</div>
				</td>
			</tr>
		</tbody>
	</table>
	<div class="wpte-title-wrap">
		<h4 class="wpte-title"><?php esc_html_e( 'PACO public Keys', 'wte-hbl' ); ?></h4>
		<p style="width:100%">
		<?php
		printf(
			wp_kses(
				'<strong>Step 3: </strong>Get PACO public keys from the bank and make sure the Signing public and Encryption public keys are correctly entered on respective fields below.',
				array(
					'strong' => array(),
					'a'      => array(
						'href'   => array(),
						'target' => array(),
						'id'     => array(),
					),
				)
			)
		);
		?>
		</p>
	</div>

	<!-- PACO Signing Public Key is used to cryptographically verify the response JWS signature. -->
	<div class="wpte-field wpte-text wpte-floated">
		<label for="wp_travel_engine_settings[paco_signing_public_key]" class="wpte-field-label"><?php _e( 'PACO Signing Public Key', 'wte-hbl' ); ?></label>
		<textarea id="wp_travel_engine_settings[paco_signing_public_key]" name="wptravelengine_hbl_paco_signing_public_key"></textarea>
		<span class="wpte-tooltip"><?php esc_html_e( 'PACO Encryption Public Key is used to cryptographically encrypt and create the request JWE.', 'wte-hbl' ); ?></span>
	</div>
	<!-- Paco Encryption public key -->
	<div class="wpte-field wpte-text wpte-floated">
		<label for="wp_travel_engine_settings[paco_encryption_public_key]" class="wpte-field-label"><?php _e( 'PACO Encryption Public Key', 'wte-hbl' ); ?></label>
		<textarea id="wp_travel_engine_settings[paco_encryption_public_key]" name="wptravelengine_hbl_paco_encryption_public_key"></textarea>
		<span class="wpte-tooltip"><?php esc_html_e( 'PACO Encryption Public Key is used to cryptographically encrypt and create the request JWE.', 'wte-hbl' ); ?></span>
	</div>
</script>
