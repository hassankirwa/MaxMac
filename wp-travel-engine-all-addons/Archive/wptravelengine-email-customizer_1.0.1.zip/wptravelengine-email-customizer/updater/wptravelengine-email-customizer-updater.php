<?php
/**
 * Easy Digital Downloads Plugin Updater
 *
 * @package Extra_Services_Wp_Travel_Engine
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Includes the files needed for the plugin updater.
 *
 * @since 1.0.0
 */
if ( ! class_exists( 'EDD_SL_Plugin_Updater' ) ) {

	include dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php';
}

/**
 * Download ID for the product in Easy Digital Downloads.
 *
 * @since 1.0.0
 */
define( 'WPTRAVELENGINE_EMAIL_CUSTOMIZER_ID', 128382 );

/**
 * Setup the updater for the Email Customizer Add-on.
 *
 * @since 1.0.0
 */
function wptravelengine_email_customizer_updater() {

	if ( version_compare( WP_TRAVEL_ENGINE_VERSION, '5.6', '>=' ) ) {
		return; // Automatically done by core plugin if WTE comment header is present.
	}

	// retrieve our license key from the DB
	$settings    = get_option( 'wp_travel_engine_license' );
	$license_key = isset( $settings['wptravelengine_email_customizer_license_key'] ) ? esc_attr( $settings['wptravelengine_email_customizer_license_key'] ) : '';

	// setup the updater
	$edd_updater = new EDD_SL_Plugin_Updater(
		WP_TRAVEL_ENGINE_STORE_URL,
		WP_TRAVEL_ENGINE_PER_TRIP_EMAILS_FILE_PATH,
		array(
			'version' => WPTRAVELENGINE_EMAIL_TEMPLATES_VERSION,      	// current version number
			'license' => $license_key,                                  // license key (used get_option above to retrieve from DB)
			'item_id' => WPTRAVELENGINE_EMAIL_CUSTOMIZER_ID,            // ID of the product
			'author'  => 'WP Travel Engine',                            // author of this plugin
			'beta'    => false,
		)
	);

}
add_action( 'admin_init', 'wptravelengine_email_customizer_updater', 0 );

/**
 * Add-ons name for plugin license page.
 *
 * @since 1.0.0
 */
function wptravelengine_email_customizer_name( $array ) {
	$array['WP Travel Engine - Email Customizer'] = 'wptravelengine_email_customizer';
	return $array;
}
add_filter( 'wp_travel_engine_addons', 'wptravelengine_email_customizer_name' );

/**
 * Add-ons Item ID for plugin license page.
 *
 * @since 1.0.0
 */
function wptravelengine_email_customizer_id( $array ) {
	$array['wptravelengine_email_customizer'] = WPTRAVELENGINE_EMAIL_CUSTOMIZER_ID;
	return $array;
}
add_filter( 'wp_travel_engine_addons_id', 'wptravelengine_email_customizer_id' );
