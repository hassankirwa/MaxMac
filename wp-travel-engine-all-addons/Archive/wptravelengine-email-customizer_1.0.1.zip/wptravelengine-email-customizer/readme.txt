=== WP Travel Engine - Email Customizer ===
Contributors:      The WordPress Contributors
Tags:              emails, templates, customizer, wp-travel-engine
Tested up to:      6.4
Stable tag:        1.0.1
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

WP Travel Engine - Email Customizer
This feature will enable you to customize the look and feel of your email templates.

== Description ==
This feature will enable you to customize the look and feel of your email templates.

== Changelog ==

= 1.0.1 =
* Compatible: Compatibility with WordPress v6.4.

= 1.0.0 =
* Initial Release.
