<?php
/**
 * Plugin Name:       WP Travel Engine - Email Customizer
 * Description:       Customize the email templates sent by WP Travel Engine.
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Version:           1.0.1
 * Author:            WP Travel Engine
 * Author URI:        https://wptravelengine.com/
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wptravelengine-email-customizer
 * Domain Path:       languages/
 * WTE tested up to:  5.7.9
 * WTE requires at least: 6.4
 * WTE: 128382:wptravelengine_email_customizer_license_key
 *
 * @package           wptravelengine-email-customizer
 */
defined( 'ABSPATH' ) || exit;

define( 'WPTRAVELENGINE_EMAIL_TEMPLATES_PLUGIN_FILE__', __FILE__ );
define( 'WPTRAVELENGINE_EMAIL_TEMPLATES_VERSION', '1.0.1' );

add_action( 'admin_notices', 'wptravelengine_email_customizer_maybe_disable_plugin' );

/**
 * Output error message and disable plugin if requirements are not met.
 *
 * This fires on admin_notices.
 *
 * @since 1.0.0
 * @return void
 */
function wptravelengine_email_customizer_maybe_disable_plugin() {
    if( ! wptravelengine_email_customizer_meets_requirements() ) {
        // Displays error.
        echo '<div id="message" class="error">';
		echo '<p>' . sprintf( __( '<strong>WP Travel Engine - Email Customizer</strong> requires WP Travel Engine v-5.7.6+, plugin is currently NOT RUNNING.', 'wptravelengine-email-customizer' ), admin_url( 'plugins.php' ) ) . '</p>';
		echo '</div>';
    }
}

/**
 * Check if all plugin requirements are met.
 *
 * @since 1.0.0
 *
 * @return bool True if the requirements are met, otherwise false.
 */
function wptravelengine_email_customizer_meets_requirements() {
    return ( defined( 'WP_TRAVEL_ENGINE_VERSION' ) && version_compare( WP_TRAVEL_ENGINE_VERSION, '5.7.6', '>=' ) );
}

/**
 * Email Customizer core load.
 *
 * @return void
 */
function wptravelengine_email_customizer_core() {
    if ( wptravelengine_email_customizer_meets_requirements() ) {
		require __DIR__ . '/includes/class-plugin.php';
    }
}
add_action( 'plugins_loaded', 'wptravelengine_email_customizer_core' );
