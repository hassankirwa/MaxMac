<?php
/**
 * Main Plugin File.
 *
 * @since 1.0.0
 * @package wptravelengine-email-templates
 */
namespace WPTravelEngineEmailTemplates;

use WPTravelEngineEmailTemplates\Helpers;

defined( 'ABSPATH' ) || exit;

/**
 * Main Plugin Class.
 *
 * @since 1.0.0
 */
class Plugin {

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->define_constants();
		$this->includes();
		$this->init_hooks();
	}

	/**
	 * Define Constants.
	 *
	 * @since 1.0.0
	 */
	private function define_constants() {
		define( 'WPTRAVELENGINE_EMAIL_TEMPLATES_PLUGIN_DIR__', plugin_dir_path( WPTRAVELENGINE_EMAIL_TEMPLATES_PLUGIN_FILE__ ) );
		define( 'WPTRAVELENGINE_EMAIL_TEMPLATES_URL', plugin_dir_url( WPTRAVELENGINE_EMAIL_TEMPLATES_PLUGIN_FILE__ ) );
	}

	/**
	 * Includes.
	 *
	 * @since 1.0.0
	 */
	private function includes() {
		require_once WPTRAVELENGINE_EMAIL_TEMPLATES_PLUGIN_DIR__ . 'includes/helpers/index.php';
		require_once WPTRAVELENGINE_EMAIL_TEMPLATES_PLUGIN_DIR__ . 'includes/class-isoeditor-gutenberg.php';
		require_once WPTRAVELENGINE_EMAIL_TEMPLATES_PLUGIN_DIR__ . 'includes/class-blocks.php';
		require_once WPTRAVELENGINE_EMAIL_TEMPLATES_PLUGIN_DIR__ . 'includes/helpers/class-template-parser.php';
		require_once WPTRAVELENGINE_EMAIL_TEMPLATES_PLUGIN_DIR__ . 'updater/wptravelengine-email-customizer-updater.php';
	}

	/**
	 * Init Hooks.
	 *
	 * @since 1.0.0
	 */
	private function init_hooks() {
		add_action( 'init', [ $this, 'init' ] );

		add_action( 'init', function () {
			if ( isset( $_GET['action'] ) && 'wte-email-template-preview' === $_GET['action'] ) {
				include_once WPTRAVELENGINE_EMAIL_TEMPLATES_PLUGIN_DIR__ . '/includes/templates/preview-template.php';
				die;
			}
		} );

		// Add admin menu page
		add_action( 'admin_menu', [ $this, 'add_admin_menu' ] );

		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_scripts' ] );

		add_action( 'wp_ajax_save_email_template', [ $this, 'save_email_template' ] );

		add_filter( 'wptravelengine_generate_email_template', array( $this, 'filter_email_template' ), 10, 2 );
	}

	/**
	 * Filter the email content.
	 *
	 * @since 1.0.0
	 */
	function filter_email_template( $content, \WTE_Booking_Emails $email_object ) {
		if ( 'customer' !== $email_object->sendto ) {
			return $content;
		}
		$email_settings = get_option( 'wte_email_template_settings', array() );
		$email_type = $email_object->email_template_type;
		$mappings = array(
			'order' => 'template-wte-email-notification',
			'order_confirmation' => 'template-wte-email-notification-payment',
		);
		if ( isset( $email_settings[ $mappings[ $email_type ] ] ) && 'yes' === $email_settings[ $mappings[ $email_type ] ] ) {
			ob_start();
			$template_type = $mappings[ $email_type ];
			include WPTRAVELENGINE_EMAIL_TEMPLATES_PLUGIN_DIR__ . '/includes/templates/template.php';
			$content = $email_object->replace_content_tags( ob_get_clean() );
		}
		return $content;
	}

	/**
	 * Save Email Template to the option.
	 *
	 * @return void
	 */
	function save_email_template() {

		if ( ! isset( $_POST['_nonce'] ) || ! wp_verify_nonce( $_POST['_nonce'], 'email_customizer_editor_form_nonce' ) ) {
			wp_send_json_error( __( 'Invalid nonce', '' ) );
		}

		if ( isset( $_POST['template_type'] ) && isset( $_POST['content'] ) ) {
			$option_key = wp_unslash( $_POST['template_type'] );
			$option_value = wp_unslash( $_POST['content'] );

			update_option( $option_key, $option_value );

			$template_parser = new TemplateParser( $option_value );
			$parsed_content = $template_parser->get_parsed_content();

			update_option( "{$option_key}_parsed", $parsed_content );

			if ( isset( $_POST['enabled'] ) ) {
				$wte_email_template_settings = get_option( 'wte_email_template_settings', array() );
				$wte_email_template_settings[ $option_key ] = wp_unslash( $_POST['enabled'] );
				update_option( 'wte_email_template_settings', $wte_email_template_settings );
			}
			wp_send_json_success( __( 'Email template saved successfully', 'wptravelengine-email-customizer' ) );
		}

	}

	/**
	 * Enqueue scripts.
	 *
	 * @since 1.0.0
	 */
	public function enqueue_scripts() {

		$plugin_asset = include WPTRAVELENGINE_EMAIL_TEMPLATES_PLUGIN_DIR__ . '/build/plugin.asset.php';
		wp_register_script( 'wpte-email-customizer', WPTRAVELENGINE_EMAIL_TEMPLATES_URL . 'build/plugin.js', $plugin_asset['dependencies'], $plugin_asset['version'], true );
		wp_register_style( 'wpte-email-customizer-plugin', WPTRAVELENGINE_EMAIL_TEMPLATES_URL . 'build/plugin.css', [], WPTRAVELENGINE_EMAIL_TEMPLATES_VERSION );
		wp_register_style( 'wpte-email-customizer', WPTRAVELENGINE_EMAIL_TEMPLATES_URL . 'build/style-plugin.css', [ 'wpte-email-customizer-plugin' ], WPTRAVELENGINE_EMAIL_TEMPLATES_VERSION );

		$screen = get_current_screen();

		$editor_settings = Helpers\get_editor_settings();

		wp_localize_script(
			'wpte-email-customizer',
			'wteEmailCustomizer',
			[
				'ajaxUrl'        => admin_url( 'admin-ajax.php' ),
				'homeUrl'        => home_url(),
				'nonce'          => wp_create_nonce( 'email_customizer_editor_form_nonce' ),
				'editorSettings' => $editor_settings,
				'customizerSettings' => get_option( 'wte_email_template_settings', array( 'template-wte-email-notification' => 'no', 'template-wte-email-notification-payment' => 'no' ) )
			]
		);

		if ( 'booking_page_wpte-email-customizer' === $screen->id ) {
			wp_enqueue_media();
		}
	}

	/**
	 * Init.
	 *
	 * @since 1.0.0
	 */
	public function init() {
		$blocks_instance = new Blocks();
		$blocks_instance->init();
	}

	/**
	 * Add admin menu.
	 *
	 * @since 1.0.0
	 */
	public function add_admin_menu() {

		add_submenu_page(
			'edit.php?post_type=booking',
			__( 'Email Customizer', 'wptravelengine-email-customizer' ),
			__( 'Email Customizer', 'wptravelengine-email-customizer' ),
			'manage_options',
			'wpte-email-customizer',
			function () {
				$gutenberg = new \IsoEditor_Gutenberg();
				$gutenberg->load();
				wp_enqueue_script( 'wpte-email-customizer' );
				wp_enqueue_style( 'wpte-email-customizer' );

				$order_email_template = get_option( 'template-wte-email-notification', false );
				if ( $order_email_template === false ) {
					$order_email_template = file_get_contents( WPTRAVELENGINE_EMAIL_TEMPLATES_PLUGIN_DIR__ . 'templates/notification.html' );
				}

				$payment_email_template = get_option( 'template-wte-email-notification-payment', false );
				if ( $payment_email_template === false ) {
					$payment_email_template = file_get_contents( WPTRAVELENGINE_EMAIL_TEMPLATES_PLUGIN_DIR__ . 'templates/notification-payment.html' );
				}
				?>
			<div id="wpte-email-customizer" class="flex w-full px-4 mt-4 justify-center">
				<div class="editor-wrapper w-full">
					<script type="text/html" id="template-wte-email-notification"><?php echo $order_email_template; ?></script>
					<script type="text/html" id="template-wte-email-notification-payment"><?php echo $payment_email_template; ?></script>
					<div id="wptravelengine__email-customizer"></div>
				</div>
			</div>
			<?php
			}
		);
	}
}

new Plugin();
