<?php
/**
 * Email Template Preview.
 *
 * @since 1.0.0
 */
defined( 'ABSPATH' ) || exit;

! is_user_logged_in() && wp_die( esc_html__( 'You are not allowed to access this page.', 'wptravelengine-email-customizer' ) );

use WPTravelEngineEmailTemplates\Helpers;

$template_settings = Helpers\get_editor_settings();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

    <head>
        <meta name="viewport" content="width=device-width" />
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title>
            <?php esc_html_e('WP Travel Engine Emails', 'wptravelengine-email-customizer'); ?>
        </title>
	</head>

	<body itemscope itemtype="http://schema.org/EmailMessage">
		<table class="body-wrap" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td>&nbsp;</td>
				<td class="container" style="width:640px;">
					<div class="content" style="padding:20px;">
						<?php
						$template_type = isset( $_GET['template_type'] )
							&& in_array( $_GET['template_type'], [ 'template-wte-email-notification', 'template-wte-email-notification-payment' ], true )
							? wp_unslash( $_GET['template_type'] )
							: 'template-wte-email-notification';
						Helpers\the_parsed_template_content( $template_type );
						?>
					</div>
				</td>
				<td>&nbsp;</td>
			</tr>
		</table>
	</body>
</html>
