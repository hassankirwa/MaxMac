<?php
/**
 * Loads blocks and metadata from the plugin's build directory.
 *
 * @since 1.0.0
 */
namespace WPTravelEngineEmailTemplates;

class Blocks {

    /**
     * Init.
     *
     * @since 1.0.0
     */
    public function init() {
        $this->register_blocks();
    }

    /**
     * Register Blocks.
     *
     * @since 1.0.0
     */
    public function register_blocks() {
        $blocks = glob( WPTRAVELENGINE_EMAIL_TEMPLATES_PLUGIN_DIR__ . 'build/*/block.json' );

        if ( ! empty( $blocks ) ) {
            foreach ( $blocks as $block ) {
                register_block_type( dirname( $block ) );
            }
        }
    }
}
