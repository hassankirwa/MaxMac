<?php
/**
 * class Template_Parser.
 *
 * @since 1.0.0
 */
namespace WPTravelEngineEmailTemplates;

class TemplateParser {

    /**
     * An array of parsed blocks.
     *
     * @var array
     */
    protected $parsed_blocks = array();

    /**
     * The parsed content.
     *
     * @var string
     */
    protected $parsed_content = '';

    /**
     * Constructor.
     *
     * @param string $content The content to parse.
     */
    public function __construct( $content = '' ) {
        $this->parse_blocks( $content );
    }

    /**
     * Parses the blocks from the given content.
     *
     * @param string $content The content to parse.
     */
    public function parse_blocks( string $content ) {
        $parsed_content = parse_blocks( $content );

        $this->parsed_blocks = $parsed_content;
    }

    /**
     * Loops through and formats the given blocks.
     *
     * @param array $blocks The blocks to format.
     */
    protected function loop_and_format_blocks( $blocks = array(), $inside_column = false ) {
        if ( empty( $blocks ) ) {
            return;
        }

        foreach ( $blocks as $block ) {
            $this->format_block( $block, $inside_column );
            // $block = new \WP_Block( $block );
        }
    }

    /**
     * Formats the given block.
     *
     * @param array $block The block to format.
     */
    public function format_block( array $block = array(), $inside_column = false ) {
        if ( empty( $block ) ) {
            return;
        }

        switch( $block['blockName'] ) {
            case 'core/columns':
                $this->format_core_columns( $block );
                break;
            case 'core/column':
                $this->format_core_column( $block );
                break;
            default:
				$block_content = render_block( $block );
				// extract dynamic alignment value from has-text-align-* class name.
				if ( preg_match( '/has-text-align-(\w+)/', $block_content, $matches ) ) {
					$block_content = str_replace( 'class=', 'align="' . $matches[1] . '" class=', $block_content );
				}

				// If content has class has-background, add padding.
				if ( preg_match( '/has-background/', $block_content ) ) {
					// Check if content has padding property or set padding property.
					if ( ! preg_match( '/padding/', $block_content ) ) {
						// if has style attribute, append padding property to the style value.
						if ( preg_match( '/style="(.*)"/', $block_content, $matches ) ) {
							$block_content = str_replace( $matches[1], $matches[1] . ';padding: 1.25em 2.375em;', $block_content );
						} else {
							$block_content = str_replace( 'class=', 'style="padding: 1.25em 2.375em;" class=', $block_content );
						}
					}
				}

				if ( $inside_column ) {
					$this->parsed_content .= '<tr><td>' . $block_content . '</td></tr>';
				} else {
					$this->parsed_content .= $block_content;
				}
                break;
        }

    }

    /**
     * Returns the parsed blocks.
     *
     * @return array The parsed blocks.
     */
    public function get_parsed_blocks() {
        return $this->parsed_blocks;
    }

    /**
     * Formats the core columns block.
     *
     * @param array $block The core columns block to format.
     */
    public function format_core_columns( $block ) {
        $attrs = array(
            'style' => [
                'spacing' => [
                    'margin' => [
                        'top' => 0,
                        'right' => 0,
                        'bottom' => 0,
                        'left' => 0,
                    ],
                    'padding' => [
                        'top' => '1.25em',
                        'right' => '2.375em',
                        'bottom' => '1.25em',
                        'left' => '2.375em',
                    ]
                ]
            ]
        );

        $block['attrs']['style']['spacing'] = wp_parse_args( $block['attrs']['style']['spacing'], $attrs['style']['spacing'] );

        $this->parsed_content .=  str_replace( '<div', '<table cellpadding="0" cellspacing="0" width="100%"><tr><td', $block['innerContent'][0] );
        $this->parsed_content .= '<table cellpadding="0" cellspacing="0" width="100%"><tr>';
        if ( $block['innerBlocks'] ) {
            $this->loop_and_format_blocks( $block['innerBlocks'] );
        }
        $this->parsed_content .= '</tr></table>';
        $this->parsed_content .= str_replace( '</div>', '</td></tr></table>', $block['innerContent'][ count( $block['innerContent'] ) - 1 ] );
    }

    /**
     * Formats the core column block.
     *
     * @param array $block The core column block to format.
     */
    public function format_core_column( $block ) {
        // $block_attributes = $this->parse_attributes( $block );
        $this->parsed_content .=  str_replace( '<div', '<td', $block['innerContent'][0] );
        if ( $block['innerBlocks'] ) {
			$this->parsed_content .= '<table cellpadding="0" cellspacing="0" width="100%">';
            $this->loop_and_format_blocks( $block['innerBlocks'], true );
			$this->parsed_content .= '</table>';
        }
        $this->parsed_content .= str_replace( '</div>', '</td>', $block['innerContent'][ count( $block['innerContent'] ) - 1 ] );
    }

    /**
     * Returns the parsed content.
     *
     * @return string The parsed content.
     */
    public function get_parsed_content() {
        $this->loop_and_format_blocks( $this->parsed_blocks );
        return $this->parsed_content;
    }

}
