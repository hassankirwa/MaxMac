<?php
/**
 * Block helper functions.
 *
 * @since 1.0.0
 */
namespace WPTravelEngineEmailTemplates\Helpers;

function get_wrapper() {
	$default_wrapper = '<table><tr><td style="%s">%s</td></tr></table>';
	return $default_wrapper;
}

/**
 * Parse block attributes.
 *
 * @param array $attributes Block attributes.
 * @since 1.0.0
 */
function parse_block_attributes( array $attributes = array() ) {
	$parsed_data = [
		'style' => '',
		'class' => '',
	];

	$style = [];
	$class = [];

	if ( isset( $attributes['style']['spacing'] ) ) {
		foreach ( $attributes['style']['spacing'] as $key => $value ) {
			if ( is_array( $value ) ) {
				foreach ( $value as $pos => $val ) {
					$style[] = $key . '-' . $pos . ':' . $val;
				}
			}
		}
	}

	if ( isset( $attributes['style']['color']['background'] ) ) {
		$style[] = 'background-color:' . $attributes['style']['color']['background'];
	}

	if ( isset( $attributes['style']['color']['text'] ) ) {
		$style[] = 'color:' . $attributes['style']['color']['text'];
	}

	if ( isset( $attributes['textAlign'] ) ) {
		$style[] = 'text-align:' . $attributes['textAlign'];
	}

	if ( isset( $attributes['align'] ) ) {
		$style[] = 'text-align:' . $attributes['align'];
	}

	if ( isset( $attributes['className'] ) ) {
		$class[] = $attributes['className'];
	}

	$parsed_data['style'] = implode( ';', $style );
	$parsed_data['class'] = implode( ' ', $class );

	return $parsed_data;
}

function loop_and_format_blocks( array $blocks = array() ) {

	$default_wrapper = get_wrapper();
	foreach ( $blocks as $block ) {
		$block = (object) $block;
		ob_start();

        // "core/columns",
        // "core/column",
        // "core/paragraph",
        // "core/heading",
        // "core/list",
		// "core/image",
        // "core/site-logo",
        // "core/code",
        // "core/list-item",
        // "core/table",
        // "core/cover",
		switch ( $block->blockName ) {
			case 'core/columns':
				$parsed_attributes = parse_block_attributes( $block->attrs );
				$style = $parsed_attributes['style'];
				echo sprintf( '<table style="%1$s" class="__tmpl-columns"><tr>', $style );
				call_user_func( __NAMESPACE__ . '\loop_and_format_blocks', $block->innerBlocks );
				echo '</tr></table>';
				break;
			case 'core/column':
				$parsed_attributes = parse_block_attributes( $block->attrs );
				$style = $parsed_attributes['style'];
				echo sprintf( '<td style="%1$s" class="__tmpl-column">', $style );
				if ( ! empty( $block->innerBlocks ) ) {
					call_user_func( __NAMESPACE__ . '\loop_and_format_blocks', $block->innerBlocks );
				}
				echo '</td>';
				break;
			case 'core/paragraph':
				$parsed_attributes = parse_block_attributes( $block->attrs );
				$style             = $parsed_attributes['style'];
				echo sprintf( $default_wrapper, '', str_replace( '<p', '<p style=\"' . $style . '\"', $block->innerHTML ) );
				break;
			case 'core/heading':
				$parsed_attributes = parse_block_attributes( $block->attrs );
				$level = isset( $block->attrs['level'] ) ? $block->attrs['level'] : '2';
				if ( ! empty( $level ) ) {
					$style             = $parsed_attributes['style'];
					echo sprintf( $default_wrapper, '', str_replace( "<h{$level}", '<h'. $level .' style=\"' . $style . '\"', $block->innerHTML ) );
				}
				break;
			case 'core/list':
				break;
			case 'core/image':
				break;
			case 'core/site-logo':
				$logo = get_theme_mod( 'custom_logo' );
				if ( $logo ) {
					$block_attributes  = $block->attrs;
					$parsed_attributes = parse_block_attributes( array_merge(
						$block->attrs,
						array(
							'textAlign' => isset( $block_attributes['align'] ) ? $block_attributes['align'] : '',
						)
					 ) );
					$logo_url          = wp_get_attachment_image_src( $logo, 'full' );
					echo sprintf(
						'<table><tr><td style="%s" class="%s">%s</td></tr></table>',
						$parsed_attributes['style'],
						$parsed_attributes['class'],
						sprintf(
							'<a href="%4$s" %6$s style="display:inline-block;" class="%5$s" rel="home" title="%2$s"><img src="%1$s" alt="%2$s" %3$s/></a>',
							esc_url( $logo_url[0] ),
							get_bloginfo( 'name' ),
							isset( $block_attributes['width'] ) ? 'width="' . $block_attributes['width'] . '"' : '',
							get_bloginfo( 'url' ),
							( isset( $block_attributes['className'] ) && strpos( $block_attributes['className'], 'is-style-rounded' ) >= 0) ? 'is-style-rounded' : '',
							isset( $block_attributes['linkTarget'] ) ? 'target="' . $block_attributes['linkTarget'] . '"' : ''
						)
					);
				}
				break;
			case 'core/code':
				break;
			case 'core/list-item':
				break;
			case 'core/table':
				break;
			case 'core/cover':

				break;
			default:
				if ( ! empty( $block->innerBlocks ) ) {
					call_user_func( __NAMESPACE__ . '\loop_and_format_blocks', $block->innerBlocks );
				} else {
					$parsed_attributes = parse_block_attributes( $block->attrs );
					$style             = $parsed_attributes['style'];
					echo sprintf( $default_wrapper, $style, $block->innerHTML );
				}
				break;
		}

		echo ob_get_clean();
	}

}
