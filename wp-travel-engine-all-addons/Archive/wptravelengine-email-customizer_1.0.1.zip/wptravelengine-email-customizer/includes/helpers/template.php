<?php
/**
 * Template Helper Functions.
 *
 * @since 1.0.0
 */
namespace WPTravelEngineEmailTemplates\Helpers;

/**
 * Gets editor settings from settings.json file.
 *
 * @since 1.0.0
 */
function get_editor_settings( $raw = false ) {
	// Read json file parse and return.
	$settings = file_get_contents( WPTRAVELENGINE_EMAIL_TEMPLATES_PLUGIN_DIR__ . 'includes/settings.json' );
	if ( $raw ) {
		return $settings;
	}
	return json_decode( $settings, true );
}

/**
 * Get parse the template content.
 *
 * @since 1.0.0
 */
function parse_the_template_content( $content ) {
	$parsed_content = parse_blocks( $content );
	ob_start();
	echo '<table><tr><td>';
	loop_and_format_blocks( is_array( $parsed_content ) ? $parsed_content : array() );
	echo '</td></tr></table>';
	return ob_get_clean();
}

/**
 * Get parsed template content.
 *
 * @since 1.0.0
 */
function get_the_parsed_template_content( $template_type = 'template-wte-email-notification' ) {
	return get_option("{$template_type}_parsed", '');
}

/**
 * Print Email Template.
 *
 * @since 1.0.0
 */
function the_parsed_template_content( $template_type = 'template-wte-email-notification' ) {
	echo wp_kses_post( get_the_parsed_template_content( $template_type ) );
}
