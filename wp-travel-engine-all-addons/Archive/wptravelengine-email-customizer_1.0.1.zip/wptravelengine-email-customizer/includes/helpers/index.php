<?php
/**
 * Collect all the helper functions.
 */

defined('ABSPATH') || exit;

require_once WPTRAVELENGINE_EMAIL_TEMPLATES_PLUGIN_DIR__ . '/includes/helpers/blocks.php';
require_once WPTRAVELENGINE_EMAIL_TEMPLATES_PLUGIN_DIR__ . '/includes/helpers/template.php';
