<?php
global $post;
// Get post ID.
if ( ! is_object( $post ) && defined( 'DOING_AJAX' ) && DOING_AJAX ) {
	$post_id  = $_POST['post_id'];
	$next_tab = $_POST['next_tab'];
} else {
	$post_id = $post->ID;
}
$wp_travel_engine_setting                = get_post_meta( $post_id, 'wp_travel_engine_setting', true );
$wp_travel_engine_setting_option_setting = get_option( 'wp_travel_engine_settings', true );

$enable_partial_payment = isset( $wp_travel_engine_setting['partial_payment_enable'] ) ? $wp_travel_engine_setting['partial_payment_enable'] : 'yes';
$enable_full_payment    =  isset( $wp_travel_engine_setting['trip_full_payment_enabled'] ) ? $wp_travel_engine_setting['trip_full_payment_enabled'] : 'yes';
$global_full_pay_enable = ! isset( $wp_travel_engine_setting_option_setting['full_payment_enable'] ) || ( isset( $wp_travel_engine_setting_option_setting['full_payment_enable'] ) && 'yes' === $wp_travel_engine_setting_option_setting['full_payment_enable'] );
if ( '1' === $enable_partial_payment ) {
	$enable_partial_payment = 'yes';
}
if ( ! isset( $wp_travel_engine_setting_option_setting['partial_payment_enable'] ) || 'no' === $wp_travel_engine_setting_option_setting['partial_payment_enable'] ) {
	?>
		<div class="wpte-form-block">
			<div class="wpte-title-wrap">
				<h2 class="wpte-title"><?php _e( 'Partial Payment', 'wte-partial-payment' ); ?></h2>
			</div> <!-- .wpte-title-wrap -->
			<div class="wpte-info-block">
				<p><?php _e( 'Partial Payment is disabled. Please enable Partial Payment via WP Travel Engine > Settings > Extensions > Partial Payment.', 'wte-partial-payment' ); ?></p>
			</div>
		</div>
	<?php
	return;
}
?>
<div id="wpte-partial-payment-settings" class="wpte-field wpte-multi-fields" >
	<div class="wpte-form-block-wrap">
		<div class="wpte-form-block">
			<div class="wpte-title-wrap">
				<h2 class="wpte-title"><?php esc_html_e( 'Partial Payment', 'wte-partial-payment' ); ?></h2>
				<span class="wpte-tooltip"><?php esc_html_e( 'Toggle the switch below to enable partial payment for this trip on checkout. You can manually enter payout amount/percentage in the field below.', 'wte-partial-payment' ); ?></span>
			</div>
			<div class="wpte-field wpte-onoff-block">
				<input type="hidden" name="wp_travel_engine_setting[partial_payment_enable]" value="no">
				<a href="Javascript:void(0);" class="wpte-onoff-toggle <?php echo 'yes' === $enable_partial_payment ? 'active' : ''; ?>">
					<label for="wp_travel_engine_setting[partial_payment_enable]" class="wpte-field-label"><?php esc_html_e( 'Enable Partial Payment', 'wte-partial-payment' ); ?><span class="wpte-onoff-btn"></span></label>
				</a>
				<input
					type    = "checkbox"
					class   = "wp-travel-engine-setting-enable-pp"
					id      = "wp_travel_engine_setting[partial_payment_enable]"
					name    = "wp_travel_engine_setting[partial_payment_enable]"
					value   = "yes"
					<?php checked( $enable_partial_payment, 'yes' ); ?>
				/>
				<div <?php echo 'yes' === $enable_partial_payment ? 'style="display:block;"' : ''; ?> class="wpte-onoff-popup">
					<div class="wpte-field wpte-number wpte-floated">
						<div class="wpte-floated">
						<?php
						if ( isset( $wp_travel_engine_setting_option_setting['partial_payment_option'] ) && $wp_travel_engine_setting_option_setting['partial_payment_option'] == 'percent' ) {
							?>
								<label class="wpte-field-label">
								<?php esc_html_e( 'Partial Payment Percentage', 'wte-partial-payment' ); ?></label>
								<input type="number" min="1" step="0.01" name="wp_travel_engine_setting[partial_payment_percent]"
								id="wp_travel_engine_setting[partial_payment_percent]"
								value="<?php echo isset( $wp_travel_engine_setting['partial_payment_percent'] ) ? esc_attr( $wp_travel_engine_setting['partial_payment_percent'] ) : ''; ?>"
								placeholder="<?php _e( 'Partial payout percent', 'wte-partial-payment' ); ?>" />
								<span class="wpte-sublabel"><?php esc_html_e( '%', 'wte-partial-payment' ); ?></span>
							<?php
						} elseif ( isset( $wp_travel_engine_setting_option_setting['partial_payment_option'] ) && $wp_travel_engine_setting_option_setting['partial_payment_option'] == 'amount' ) {
							?>
								<label class="wpte-field-label">
							<?php esc_html_e( 'Partial Payment Amount', 'wte-partial-payment' ); ?></label>
								<input type="number" min="1" step="0.01" name="wp_travel_engine_setting[partial_payment_amount]"
								id="wp_travel_engine_setting[partial_payment_amount]"
								value="<?php echo isset( $wp_travel_engine_setting['partial_payment_amount'] ) ? esc_attr( $wp_travel_engine_setting['partial_payment_amount'] ) : ''; ?>"
								placeholder="<?php _e( 'Partial payout amount', 'wte-partial-payment' ); ?>" />
								<span class="wpte-sublabel"><?php echo esc_html( wp_travel_engine_get_currency_code() ); ?></span>
							<?php
						}
						?>
						</div>
					</div>
				</div>
				<?php
				if ( $global_full_pay_enable ) :
					?>
				<div <?php echo 'yes' === $enable_partial_payment ? 'style="display:block;"' : ''; ?> class="wpte-onoff-popup">
					<div class="wpte-field wpte-number wpte-floated">
						<div class="wpte-floated">
							<a href="Javascript:void(0);" class="wpte-onoff-toggle <?php echo 'yes' === $enable_full_payment ? 'active' : ''; ?>">
								<label for="wp_travel_engine_setting[trip_full_payment_enabled]" class="wpte-field-label"><?php esc_html_e( 'Full Payment', 'wte-partial-payment' ); ?><span class="wpte-onoff-btn"></span></label>
							</a>
							<input type="hidden" name="wp_travel_engine_setting[trip_full_payment_enabled]" value="no">		
							<input
								type    = "checkbox"
								id      = "wp_travel_engine_setting[trip_full_payment_enabled]"
								name    = "wp_travel_engine_setting[trip_full_payment_enabled]"
								value   = "yes"
								<?php checked( $enable_full_payment, 'yes' ); ?>
							/>
						</div>
					</div>
				</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
