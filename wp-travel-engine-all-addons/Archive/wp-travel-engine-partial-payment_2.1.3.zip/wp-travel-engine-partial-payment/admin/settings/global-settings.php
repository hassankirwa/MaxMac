<?php
/**
 * Partial payments global settings
 */
$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', true );
$option                    = isset( $wp_travel_engine_settings['partial_payment_enable'] ) ? $wp_travel_engine_settings['partial_payment_enable'] : 'no';

$partial_pay_option   = isset( $wp_travel_engine_settings['partial_payment_option'] ) ? $wp_travel_engine_settings['partial_payment_option'] : '';
$full_payment_enable = ! isset( $wp_travel_engine_settings['full_payment_enable'] ) || ( isset( $wp_travel_engine_settings['full_payment_enable'] ) && 'yes' == $wp_travel_engine_settings['full_payment_enable'] );
if ( '1' === $option ) {
	$option = 'yes';
}
?>
<div class="wpte-field wpte-checkbox advance-checkbox">
	<label class="wpte-field-label" for="wp_travel_engine_settings[partial_payment_enable]"><?php _e( 'Partial Payment Enable', 'wte-partial-payment' ); ?></label>
	<div class="wpte-checkbox-wrap">
		<input type="hidden" name="wp_travel_engine_settings[partial_payment_enable]" value="no">
		<input type="checkbox" id="wp_travel_engine_settings[partial_payment_enable]" class="partial-payment" name="wp_travel_engine_settings[partial_payment_enable]" value="yes" <?php echo checked( $option, 'yes' ); ?>>
		<label for="wp_travel_engine_settings[partial_payment_enable]"></label>
	</div>
	<span class="wpte-tooltip"><?php esc_html_e( 'Check this if you want to enable partial payments for trip bookings.', 'wte-partial-payment' ); ?></span>
</div>
<div class="wpte-field wpte-multi-field">
	<div class="wpte-floated">
		<label class="wpte-field-label"><?php _e( 'Accept Partial Payment In', 'wte-partial-payment' ); ?></label>
		<div class="wpte-field wpte-radio wpte-alignleft">
			<label class="wpte-field-label" for="percent"><?php _e( 'Percentage', 'wte-partial-payment' ); ?></label>
			<div class="wpte-radio-wrap">
				<input type="radio" id="percent" value="percent" name="wp_travel_engine_settings[partial_payment_option]" <?php echo checked( isset( $wp_travel_engine_settings['partial_payment_option'] ) ? $wp_travel_engine_settings['partial_payment_option'] : '', 'percent' ); ?> class="partial-payment">
				<label for="percent"></label>
			</div>
		</div>
		<div class="wpte-field wpte-radio wpte-alignleft">
			<label class="wpte-field-label" for="amount"><?php _e( 'Amount', 'wte-partial-payment' ); ?></label>
			<div class="wpte-radio-wrap">
				<input type="radio" id="amount" value="amount" name="wp_travel_engine_settings[partial_payment_option]" <?php echo checked( isset( $wp_travel_engine_settings['partial_payment_option'] ) ? $wp_travel_engine_settings['partial_payment_option'] : '', 'amount' ); ?> class="partial-payment">
				<label for="amount"></label>
			</div>
		</div>
		<span class="wpte-tooltip"><?php esc_html_e( 'Accept Partial Payment in Amount or Percentage.', 'wte-partial-payment' ); ?></span>
	</div>
</div>
<div <?php echo 'amount' === $partial_pay_option ? 'style="display:none"' : ''; ?> id="partial-pay-percent" class="wpte-field wpte-text wpte-floated">
	<label for="wp_travel_engine_settings[partial_payment_percent]" class="wpte-field-label"><?php _e( 'Partial Payment in Percentage', 'wte-partial-payment' ); ?></label>
	<input min="1" max="100" step="0.01" type="number" id="wp_travel_engine_settings[partial_payment_percent]" name="wp_travel_engine_settings[partial_payment_percent]" value="<?php echo isset( $wp_travel_engine_settings['partial_payment_percent'] ) ? esc_attr( $wp_travel_engine_settings['partial_payment_percent'] ) : ''; ?>" />
	<span class="wpte-tooltip"><?php esc_html_e( 'Enter partial payment amount (in percentage of total trip cost) to be paid while booking the trip (without % sign).', 'wte-partial-payment' ); ?></span>
</div>
<div <?php echo 'percent' === $partial_pay_option ? 'style="display:none"' : ''; ?> id="partial-pay-amount" class="wpte-field wpte-text wpte-floated">
	<label for="wp_travel_engine_settings[partial_payment_amount]" class="wpte-field-label"><?php _e( 'Partial Payment in Amount', 'wte-partial-payment' ); ?></label>
	<input min="1" step="0.01" type="number" id="wp_travel_engine_settings[partial_payment_amount]" name="wp_travel_engine_settings[partial_payment_amount]" value="<?php echo isset( $wp_travel_engine_settings['partial_payment_amount'] ) ? esc_attr( $wp_travel_engine_settings['partial_payment_amount'] ) : ''; ?>" />
	<span class="wpte-tooltip"><?php esc_html_e( 'Enter partial payment amount (in figures) to be paid while booking the trip (without $ sign).', 'wte-partial-payment' ); ?></span>
</div>
<?php
/**
 * Added option to disable full payment in global settings.
 *
 * @since 2.1.3
 */
?>
<div class="wpte-field wpte-checkbox advance-checkbox">
	<label class="wpte-field-label" for="full_payment_enable"><?php esc_html_e( 'Full Payment', 'wte-partial-payment' ); ?></label>
	<div class="wpte-checkbox-wrap">
		<input type="hidden" name="wp_travel_engine_settings[full_payment_enable]" value="no">
		<input type="checkbox" name="wp_travel_engine_settings[full_payment_enable]" value="yes" id="full_payment_enable" <?php checked( $full_payment_enable, true ); ?> />
		<label for="full_payment_enable"></label>
	</div>
	<span class="wpte-tooltip"><?php esc_html_e( 'Enable this feature to display both full payment and partial payment options on the checkout page.', 'wte-partial-payment' ); ?></span>
</div>
<?php
