=== WP Travel Engine - Partial Payment ===
Contributors: wptravelengine
Donate link: https://wptravelengine.com/
Tags: payment, partial-payment
Requires at least: 4.4.0
Tested up to: 6.2
Requires PHP: 5.6
Stable tag: 2.1.3
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

An extension of WP Travel Engine plugin for partial payment of the total trip cost.

== Description ==
An extension of WP Travel Engine plugin for partial payment of the total trip cost.

== Changelog ==

= 2.1.3 =
Released on: 26th June, 2023
* Feature: Added option to show/hide full payment option.

= 2.1.2 =
Released on: 9th July, 2021
* Compatibility update for WP Travel Engine  5.0
* Minor bug fixes
