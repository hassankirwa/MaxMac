jQuery(document).ready(function($){
    if ($('.partial-payment').is( ':checked' )) {
        $('.wte-partial-payment-form.settings').fadeIn('slow');
    }
    else{
        $('.wte-partial-payment-form.settings').fadeOut('slow');
    }
    $('body').on('click', '.partial-payment', function (e){ 
        if ($('.partial-payment').is( ':checked' )) {
            $('.wte-partial-payment-form.settings').fadeIn('slow');
        }
        else{
            $('.wte-partial-payment-form.settings').fadeOut('slow');
        }
    });

    $( document ).on( 'change', 'input[name="wp_travel_engine_settings[partial_payment_option]"]', function(e) {
        e.preventDefault();

        if ( $('#percent').is(':checked') ) {
            $( '#partial-pay-percent' ).show();
            $( '#partial-pay-amount' ).hide();
        } else {
            $( '#partial-pay-percent' ).hide();
            $( '#partial-pay-amount' ).show();
        }
    } );

    if ($('.partial-payment1').is( ':checked' )) {
        $('.wte-partial-payment-form1.settings').fadeIn('slow');
    }
    else{
        $('.wte-partial-payment-form1.settings').fadeOut('slow');
    }
    $('body').on('click', '.partial-payment1', function (e){ 
        if ($('.partial-payment1').is( ':checked' )) {
            $('.wte-partial-payment-form1.settings').fadeIn('slow');
        }
        else{
            $('.wte-partial-payment-form1.settings').fadeOut('slow');
        }
    });
});