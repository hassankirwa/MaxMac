<?php
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://wptravelengine.com/
 * @since             1.0.0
 * @package           WP_Travel_Engine
 *
 * @wordpress-plugin
 * Plugin Name:       WP Travel Engine - Partial Payment
 * Plugin URI:        https://wptravelengine.com/
 * Description:       An extension of WP Travel Engine plugin for partial payment of the total trip cost.
 * Version:           2.1.3
 * Author:            WP Travel Engine
 * Author URI:        https://wptravelengine.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wte-partial-payment
 * Domain Path:       /languages
 * WTE Requires at least: 4.3.0
 * WTE Tested up to: 5.1.0
 * WTE: 1750:wte_partial_payment_license_key
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

define( 'WP_TRAVEL_ENGINE_PARTIAL_PAYMENT_FILE_PATH', __FILE__ );
define( 'WP_TRAVEL_ENGINE_PARTIAL_PAYMENT_BASE_PATH', dirname( __FILE__ ) );
define( 'WP_TRAVEL_ENGINE_PARTIAL_PAYMENT_VERSION', '2.1.3' );
define( 'WP_TRAVEL_ENGINE_PARTIAL_PAYMENT_REQUIRES_AT_LEAST', '4.3.0' ); // @since 2.1.0

/**
 * Plugin Initialization.
 */
add_action(
	'plugins_loaded',
	function() {
		if ( ! defined( 'WP_TRAVEL_ENGINE_VERSION' ) || version_compare( WP_TRAVEL_ENGINE_VERSION, WP_TRAVEL_ENGINE_PARTIAL_PAYMENT_REQUIRES_AT_LEAST, '<' ) ) {
			add_action(
				'admin_notices',
				function() {
					echo wp_kses_post(
						sprintf(
							'<div class="error"><p>'
							// translators: 1. WTE Extension Name 2. Link to WTE Plugin.
							. sprintf( __( '%1$s requires the %2$s plugin to work. Please install and activate the latest <strong>WP Travel Engine</strong> plugin first.', 'wte-partial-payment' ), '<strong>WP Travel Engine - Partial Payment</strong>', '<a href="https://wptravelengine.com" target="__blank">WP Travel Engine</a>' )
							. '</p></div>'
						)
					);
				}
			);
		} else {
			include WP_TRAVEL_ENGINE_PARTIAL_PAYMENT_BASE_PATH . '/includes/class-wp-travel-engine-partial-payment.php';
			include WP_TRAVEL_ENGINE_PARTIAL_PAYMENT_BASE_PATH . '/updater/wte-partial-payment-updater.php';
		}
	}
);
