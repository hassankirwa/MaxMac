<?php
// admin settings
class Wte_Partial_Payment_Admin {

	public function __construct() {
		$this->init_hooks();
	}

	public function init_hooks() {
		// plugins_loaded hook won't work here.
		add_action( 'admin_enqueue_scripts', array( $this, 'wte_enqueue_backend_assets' ) );

		add_action( 'wpte_partial_payment_add_meta_boxes', array( $this, 'wpte_partial_payment_add_meta_boxes' ) );
		add_action( 'init', array( $this, 'load_plugin_textdomain' ) );

		add_action( 'wpte_get_global_extensions_tab', array( $this, 'wte_partial_payment_extension_settings' ) );

		add_action( 'wte_after_pricing_options_section', array( $this, 'wpte_partial_payment_add_meta_boxes' ), 9 );

		add_filter(
			'trip_edit_tab_pricing_and_dates_tab_content',
			function( array $tab_contents ) {

				$tab_contents[20] = array(
					'content_id'       => 'partial-payment',
					'content_callback' => function() {
						require_once plugin_dir_path( WP_TRAVEL_ENGINE_PARTIAL_PAYMENT_FILE_PATH ) . 'admin/trip/edit/tab-pricing/tab-pricing__partial-payment.php';
					},
				);
				return $tab_contents;
			}
		);

		add_filter(
			'wtel10n',
			function( $l10n ) {
				if ( isset( $_GET['action'] ) && 'partial-payment' === $_GET['action'] && ! empty( $_GET['booking_id'] ) ) {
					$booking             = WPTravelEngine\Core\Booking::get_booking_info_by_id( $_GET['booking_id'] );
					$l10n['bookingInfo'] = array(
						'cartInfo'       => $booking->cart_info,
						'total'          => round( $booking->cart_info['total'], 2 ),
						'totalPartial'   => round( $booking->cart_info['cart_partial'], 2 ), // Partially to be paid.
						'totalRemaining' => round( ( $booking->cart_info['total'] - $booking->cart_info['cart_partial'] ), 2 ), // Partially to be paid.
						'totalPaid'      => round( $booking->paid_amount, 2 ),
						'totalDue'       => round( $booking->due_amount, 2 ),
					);
				}
				return $l10n;
			}
		);

		add_action(
			'wp_enqueue_scripts',
			function() {
				if ( ! isset( $_GET['action'] ) || 'partial-payment' !== $_GET['action'] || empty( $_GET['booking_id'] ) ) {
					return;
				}
				$booking = WPTravelEngine\Core\Booking::get_booking_info_by_id( $_GET['booking_id'] );

				$billing_info = $booking->billing_info;

				$data = "if ( window.wte && window.wte.payments ) { \n"
					. "window['wte'].payments.total = " . round( $booking->cart_info['total'], 2 ) . ";\n"
					. "window['wte'].payments.total_partial = " . round( $booking->cart_info['cart_partial'], 2 ) . ";\n"
					. "window['wte'].payments.total_remaining = " . round( ( $booking->cart_info['total'] - $booking->cart_info['cart_partial'] ), 2 ) . ";\n"
					. "window['wte'].payments.billing_info = " . wp_json_encode( $billing_info ) . ";\n"
					. "}\n";

				wp_add_inline_script( 'wp-travel-engine', $data );
			}
		);

		add_action(
			'wte_before_remaining_payment_form_close',
			function() {
				echo '<input type="radio" checked name="wp_travel_engine_payment_mode" value="remaining_payment" style="display:none"/>';
			}
		);
	}

	function load_plugin_textdomain() {
		load_plugin_textdomain(
			'wte-partial-payment',
			false,
			WP_TRAVEL_ENGINE_PARTIAL_PAYMENT_BASE_PATH . '/languages/'
		);
	}

	/**
	 * Payment Details.
	 *
	 * @since 1.0
	 */
	function wpte_partial_payment_add_meta_boxes() {
		require WP_TRAVEL_ENGINE_PARTIAL_PAYMENT_BASE_PATH . '/admin/includes/frontend/trip-meta/trip-meta-parts/partial-payment.php';
	}

	// Enqueue required assets for admin.
	function wte_enqueue_backend_assets() {
		$screen = get_current_screen();

		if ( $screen->post_type == 'trip' || isset( $_GET['page'] ) && $_GET['page'] == 'class-wp-travel-engine-admin.php' || $screen->id == 'trip_page_class-wp-travel-engine-admin' ) {
			wp_enqueue_script( 'Wte-Partial-Payment', plugin_dir_url( WP_TRAVEL_ENGINE_PARTIAL_PAYMENT_FILE_PATH ) . 'assets/admin.js', array( 'jquery' ), '', false );
			wp_enqueue_style( 'Wte-Partial-Payment', plugin_dir_url( WP_TRAVEL_ENGINE_PARTIAL_PAYMENT_FILE_PATH ) . 'assets/admin.css', array(), '', 'all' );
		}
	}

	/**
	 * Global settings array register.
	 *
	 * @return void
	 */
	function wte_partial_payment_extension_settings( $extension_settings ) {
		$extension_settings['wte_partial_payment'] = array(
			'label'        => __( 'Partial Payment', 'wte-partial-payment' ),
			'content_path' => WP_TRAVEL_ENGINE_PARTIAL_PAYMENT_BASE_PATH . '/admin/settings/global-settings.php',
			'current'      => false,
		);
		return $extension_settings;
	}
}

new Wte_Partial_Payment_Admin();
