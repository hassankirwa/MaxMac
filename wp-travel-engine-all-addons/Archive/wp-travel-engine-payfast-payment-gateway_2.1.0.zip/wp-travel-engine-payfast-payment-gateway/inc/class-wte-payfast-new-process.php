<?php
/**
 * PayFast Payment Gateway
 *
 * Provides a PayFast Payment Gateway.
 *
 * @class  wte_payfast
 * @package WP_Travel_Engine
 * @category Payment Gateways
 * @author WP_Travel_Engine
 */
class WTE_Gateway_Payfast {

	/**
	 * Version
	 *
	 * @var string
	 */
	public $version;

	/**
	 * @access protected
	 * @var array $data_to_send
	 */
	protected $data_to_send = array();

	/**
	 * Constructor
	 */
	public function __construct() {

		$this->version = WP_TRAVEL_ENGINE_PAYFAST_VERSION;
		$this->id      = 'payfast';

		$this->debug_email          = get_option( 'admin_email' );
		$this->available_countries  = array( 'ZA' );
		$this->available_currencies = (array) apply_filters( 'wte_gateway_payfast_available_currencies', array( 'ZAR' ) );

		$wte_settings = get_option( 'wp_travel_engine_settings' );

		if ( ! is_admin() ) {

			$this->setup_constants();

		}

		// Setup default merchant data.
		$this->merchant_id  = isset( $wte_settings['payfast_id'] ) ? $wte_settings['payfast_id'] : '';
		$this->merchant_key = isset( $wte_settings['payfast_merchant_key'] ) ? $wte_settings['payfast_merchant_key'] : '';
		$this->pass_phrase  = '';

		$this->url          = 'https://www.payfast.co.za/eng/process?aff=wte-free';
		$this->validate_url = 'https://www.payfast.co.za/eng/query/validate';

		$this->title        = __( 'Payfast Checkout', 'wte-payfast' );
		$this->response_url = add_query_arg( 'wte_payment', 'wte_gateway_payfast', home_url( '/' ) );

		// $this->response_url     = 'https://webhook.site/d0e38971-cd17-4c1c-9afb-4c670ea97334';

		$this->send_debug_email = defined( 'WP_TRAVEL_ENGINE_PAYMENT_DEBUG' ) && WP_TRAVEL_ENGINE_PAYMENT_DEBUG ? true : false;
		$this->description      = '';

		$this->enabled        = $this->is_valid_for_use() ? 'yes' : 'no'; // Check if the base currency supports this gateway.
		$this->enable_logging = defined( 'WP_TRAVEL_ENGINE_PAYMENT_DEBUG' ) && WP_TRAVEL_ENGINE_PAYMENT_DEBUG ? true : false;

		$this->testmode = defined( 'WP_TRAVEL_ENGINE_PAYMENT_DEBUG' ) && WP_TRAVEL_ENGINE_PAYMENT_DEBUG ? true : false;

		// Setup the test data, if in test mode.
		if ( defined( 'WP_TRAVEL_ENGINE_PAYMENT_DEBUG' ) && WP_TRAVEL_ENGINE_PAYMENT_DEBUG ) {

			$this->url          = 'https://sandbox.payfast.co.za/eng/process?aff=wte-free';
			$this->validate_url = 'https://sandbox.payfast.co.za/eng/query/validate';

		} else {

			$this->send_debug_email = false;

		}
		add_action( 'init', array( $this, 'remove_callback_hook_from_core' ), 8 );

		add_action( 'init', array( $this, 'response_catcher' ) );

		add_action( 'wp_travel_engine_after_booking_process_completed', array( $this, 'generate_payfast_form' ) );
		add_action( 'wp_travel_engine_after_remaining_payment_process_completed', array( $this, 'generate_remaining_payment_payfast_form' ) );

		add_action( 'wte_payment_gateway_payfast_enable', array( $this, 'save_booking_data' ), 9, 3 );
	}

	/**
	 *
	 * @since 2.1.0
	 */
	public function remove_callback_hook_from_core() {
		if ( ( isset( $_REQUEST['wte_gateway'] ) && 'payfast' === $_REQUEST['wte_gateway'] ) || ( isset( $_REQUEST['wte_payment'] ) && 'wte_gateway_payfast' === $_REQUEST['wte_payment'] ) ) {
			remove_action( 'init', array( 'WPTravelEngine\Core\Booking', 'payment_gateway_callback_backward_compatibility' ), 9 );
			remove_action( 'init', array( 'WTE_Booking', 'payment_gateway_callback_backward_compatibility' ), 9 );
		}
	}

	 /**
	  *
	  * @since 2.1.0
	  */
	public function save_booking_data( $payment_id, $payment_mode, $payment_method ) {
		remove_action( 'wp_travel_engine_after_booking_process_completed', array( $this, 'generate_payfast_form' ) );
		remove_action( 'wp_travel_engine_after_remaining_payment_process_completed', array( $this, 'generate_remaining_payment_payfast_form' ) );
		if ( ! $payment_id ) {
			return;
		}
		$booking_id = get_post_meta( $payment_id, 'booking_id', true );
		if ( empty( $booking_id ) ) {
			return;
		}
		$this->generate_payfast_form( $booking_id, $payment_mode == 'partial', $payment_id );
	}

	/**
	 *
	 * @since 2.1.0
	 */
	public function handle_notification_response( $payment_id ) {
		if ( ! $payment_id ) {
			return;
		}

		$payment    = get_post( $payment_id );
		$booking_id = get_post_meta( $payment->ID, 'booking_id', true );
		$booking    = get_post( $booking_id );

		update_post_meta( $payment->ID, 'gateway_response', $_REQUEST );
		update_post_meta( $payment->ID, 'payment_status', strtolower( $_REQUEST['payment_status'] ) );
		if ( 'complete' === strtolower( $_REQUEST['payment_status'] ) ) {
			$cart_info   = get_post_meta( $booking_id, 'cart_info', true );
			$amount      = $_REQUEST['amount_gross'];
			$due_amount  = get_post_meta( $booking->ID, 'due_amount', ! 0 );
			$paid_amount = get_post_meta( $booking->ID, 'paid_amount', ! 0 );
			update_post_meta( $booking->ID, 'wp_travel_engine_booking_status', 'booked' );
			if ( (float) $booking->due_amount < (float) $amount ) {
				update_post_meta( $booking->ID, 'due_amount', (float) $cart_info['subtotal'] - (float) $amount );
			} else {
				update_post_meta( $booking->ID, 'due_amount', (float) $booking->due_amount - (float) $amount );
			}
			update_post_meta( $booking->ID, 'paid_amount', (float) $paid_amount + (float) $amount );
			update_post_meta(
				$payment->ID,
				'payment_amount',
				array(
					'value'    => $amount,
					'currency' => 'ZAR',
				)
			);
			WTE_Booking::send_emails( $payment->ID, 'order_confirmation', 'all' );
		}
	}

	/**
	 * Catch notify URL Response.
	 *
	 * @return void
	 */
	public function response_catcher() {
		if ( isset( $_GET['wte_gateway'], $_GET['payment_id'], $_GET['booking_id'] ) && 'payfast' === $_GET['wte_gateway'] ) {
			if ( ! headers_sent() ) {
				if ( class_exists( 'WPTravelEngine\Core\Booking' ) ) {
					$thankyou_url = WPTravelEngine\Core\Booking::get_thankyou_url( $_GET['booking_id'], $_GET['payment_id'], 'payhere_payment' );
				} elseif ( class_exists( 'WTE_Booking' ) ) {
					$thankyou_url = WTE_Booking::get_thankyou_url( $_GET['booking_id'], $_GET['payment_id'], 'payhere_payment' );
				}
				wp_redirect( $thankyou_url );
				exit;
			}
		}

		// ITN
		if ( isset( $_GET['wte_payment'] ) && esc_attr( $_GET['wte_payment'] ) === 'wte_gateway_payfast' ) {
			if ( ! empty( $_GET['_payment_id'] ) ) {
				$this->handle_notification_response( (int) $_GET['_payment_id'] );
				// Notify PayFast that information has been received
				header( 'HTTP/1.0 200 OK' );
				flush();
				exit;
			}

			$this->check_itn_response();
		}

	}

	/**
	 * is_valid_for_use()
	 *
	 * Check if this gateway is enabled and available in the base currency being traded with.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	public function is_valid_for_use() {

		$is_available          = false;
		$is_available_currency = in_array( wp_travel_engine_get_currency_code(), $this->available_currencies );

		if ( $is_available_currency && $this->merchant_id && $this->merchant_key ) {

			$is_available = true;

		}

		return $is_available;
	}

	/**
	 *
	 * @since 2.1.0
	 */
	public function get_billing_info( $booking_id, $payment_mode = 'full_payment' ) {
		$billing_info = array();

		$billing_infos = get_post_meta( $booking_id, 'billing_info', true );
		if ( ! empty( $billing_infos ) && is_array( $billing_infos ) ) {
			foreach (
				array(
					'fname' => 'name_first',
					'lname' => 'name_last',
					'email' => 'email_address',
				) as $key => $args_key ) {
				if ( isset( $billing_infos[ $key ] ) ) {
					$billing_info[ $args_key ] = $billing_infos[ $key ];
				}
			}
		}

		return $billing_info;

	}

	/**
	 *
	 * @since 2.1.0
	 */
	public function prepare_payment_form( $payment_id, $payment_mode = 'full_payment' ) {
		$payment    = get_post( $payment_id );
		$booking_id = get_post_meta( $payment_id, 'booking_id', true );

		$booking = get_post( $booking_id );

		$cart_info = $booking->cart_info;
		$amounts   = array(
			'full_payment'      => round( $cart_info['subtotal'], 2 ),
			'partial'           => round( $cart_info['cart_partial'], 2 ),
			'remaining_payment' => round( $cart_info['subtotal'], 2 ) - round( $cart_info['cart_partial'], 2 ),
		);

		if ( ! isset( $amounts[ $payment_mode ] ) ) {
			$payment_mode = 'full_payment';
		}

		$return_url = add_query_arg(
			array(
				'booking_id'  => $booking_id,
				'booked'      => true,
				'wte_gateway' => 'payfast',
				'payment_id'  => $payment_id,
			),
			wp_travel_engine_get_booking_confirm_url()
		);

		$order_items = $booking->order_trips;

		$item_name = '';
		if ( is_array( $order_items ) ) {
			foreach ( $order_items as $item ) {
				$item_name = ! empty( $item['title'] ) ? $item['title'] : 'Trip';
				break;
			}
		}

		$form_data_array = array(
			// Merchant details
			'merchant_id'      => $this->merchant_id,
			'merchant_key'     => $this->merchant_key,
			'return_url'       => $return_url,
			'cancel_url'       => home_url( '/' ),
			'notify_url'       => add_query_arg(
				array(
					'wte_payment' => 'wte_gateway_payfast',
					'_payment_id' => $payment_id,
				),
				home_url( '/' )
			),

			// Item details
			'm_payment_id'     => ltrim( $booking_id, _x( '#', 'hash before order number', 'wte-payfast' ) ),
			'amount'           => $amounts[ $payment_mode ],
			'item_name'        => $item_name,
			/* translators: 1: blog info name */
			'item_description' => sprintf( __( 'New order from %s', 'wte-payfast' ), get_bloginfo( 'name' ) ),

			// Custom strings
			'custom_str1'      => $booking_id,
			'custom_str2'      => 'WPTravelEngine/' . WP_TRAVEL_ENGINE_PAYFAST_VERSION . '; ' . get_site_url(),
			'custom_str3'      => $booking_id,
			'source'           => 'WTE-PayFast-Gateway',
		);

		$form_data_array = wp_parse_args( $this->get_billing_info( $booking_id, $payment_mode ), $form_data_array );

		$inputs = '';
		foreach ( $form_data_array as $name => $value ) {
			$inputs .= '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" />';
		}
		echo '<p>' . esc_html_e( 'Redirecting to PayFast website...', 'wte-payfast' ) . '</p>
			<form action="' . $this->url . '" method="POST" name="payfast_payment_form" id="payfast_payment_form">
				' . $inputs . '
				<input type="submit" class="button" id="submit_payfast_payment_form" value="' . __( 'Pay via Payfast', 'wte-payfast' ) . '" />
				<script type="text/javascript">
                    document.getElementById("submit_payfast_payment_form").click();
				</script>
            </form>';
		exit;
	}

	/**
	 * Generate the PayFast button link.
	 *
	 * @since 1.0.0
	 */
	public function generate_payfast_form( $booking_id, $partial_payment = false, $payment_id = false ) {
		if ( ! ! $payment_id ) {
			$payment_mode = isset( $_POST['wp_travel_engine_payment_mode'] ) ? $_POST['wp_travel_engine_payment_mode'] : 'full_payment';
			$this->prepare_payment_form( $payment_id, $payment_mode );
			return;
		}

		if ( ! $booking_id ) {
			return;
		}

		// Is partial payment check.
		if ( ! $partial_payment ) {
			do_action( 'wte_payment_process', $booking_id );
		}

		// Check if paypal is selected.
		if ( ! isset( $_POST['wpte_checkout_paymnet_method'] ) || 'payfast_enable' !== $_POST['wpte_checkout_paymnet_method'] ) {
			return;
		}

		global $wte_cart;

		$cart_totals    = $wte_cart->get_total();
		$payment_mode   = isset( $_POST['wp_travel_engine_payment_mode'] ) ? $_POST['wp_travel_engine_payment_mode'] : '';
		$payment_amount = wp_travel_engine_get_formated_price( $cart_totals['total'] );

		if ( 'partial' === $payment_mode && wp_travel_engine_is_cart_partially_payable() ) :

			$payment_amount = wp_travel_engine_get_formated_price( $cart_totals['total_partial'] );

		endif;

		$return_url = wp_travel_engine_get_booking_confirm_url();

		$return_url = add_query_arg(
			array(
				'booking_id'  => $booking_id,
				'booked'      => true,
				'wte_gateway' => 'payfast',
			),
			$return_url
		);

		$booking_metas = get_post_meta( $booking_id, 'wp_travel_engine_booking_setting', true );

		$fail_cancel_url = isset( $booking_metas['place_order']['tid'] ) && ! empty( $booking_metas['place_order']['tid'] ) ? get_the_permalink( $booking_metas['place_order']['tid'] ) : home_url( '/' );

		// Construct variables for post
		$this->data_to_send = array(
			// Merchant details
			'merchant_id'      => $this->merchant_id,
			'merchant_key'     => $this->merchant_key,
			'return_url'       => $return_url,
			'cancel_url'       => $fail_cancel_url,
			'notify_url'       => $this->response_url,

			// Billing details
			'name_first'       => esc_attr( $_POST['wp_travel_engine_booking_setting']['place_order']['booking']['fname'] ),
			'name_last'        => esc_attr( $_POST['wp_travel_engine_booking_setting']['place_order']['booking']['lname'] ),
			'email_address'    => esc_attr( $_POST['wp_travel_engine_booking_setting']['place_order']['booking']['email'] ),

			// Item details
			'm_payment_id'     => ltrim( $booking_id, _x( '#', 'hash before order number', 'wte-payfast' ) ),
			'amount'           => $payment_amount,
			'item_name'        => get_the_title( $booking_metas['place_order']['tid'] ),
			/* translators: 1: blog info name */
			'item_description' => sprintf( __( 'New order from %s', 'wte-payfast' ), get_bloginfo( 'name' ) ),

			// Custom strings
			'custom_str1'      => $booking_id,
			'custom_str2'      => 'WPTravelEngine/' . WP_TRAVEL_ENGINE_PAYFAST_VERSION . '; ' . get_site_url(),
			'custom_str3'      => $booking_id,
			'source'           => 'WTE-PayFast-Gateway',
		);

		$payfast_args_array = array();
		foreach ( $this->data_to_send as $key => $value ) {
			$payfast_args_array[] = '<input type="hidden" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '" />';
		}

		// The form
		echo '<p>' . esc_html_e( 'Redirecting to PayFast website...', 'wte-payfast' ) . '</p>
			<form action="' . $this->url . '" method="POST" name="payfast_payment_form" id="payfast_payment_form">
				' . implode( '', $payfast_args_array ) . '
				<input type="submit" class="button" id="submit_payfast_payment_form" value="' . __( 'Pay via Payfast', 'wte-payfast' ) . '" />
				<script type="text/javascript">
                    document.getElementById("submit_payfast_payment_form").click();
				</script>
            </form>';

		exit;
	}

	public function generate_remaining_payment_payfast_form( $booking_id, $partial_payment = false ) {

		if ( ! $booking_id ) {
			return;
		}

		// Is partial payment check.
		if ( ! $partial_payment ) {
			do_action( 'wte_payment_process', $booking_id );
		}

		// Check if paypal is selected.
		if ( ! isset( $_POST['wpte_checkout_paymnet_method'] ) || 'payfast_enable' !== $_POST['wpte_checkout_paymnet_method'] ) {
			return;
		}

		$booking_metas = get_post_meta( $booking_id, 'wp_travel_engine_booking_setting', true );

		$fail_cancel_url = isset( $booking_metas['place_order']['tid'] ) && ! empty( $booking_metas['place_order']['tid'] ) ? get_the_permalink( $booking_metas['place_order']['tid'] ) : home_url( '/' );
		$firstname       = isset( $booking_metas['place_order']['booking']['fname'] ) && ! empty( $booking_metas['place_order']['booking']['fname'] ) ? $booking_metas['place_order']['booking']['fname'] : '';
		$lastname        = isset( $booking_metas['place_order']['booking']['lname'] ) && ! empty( $booking_metas['place_order']['booking']['lname'] ) ? $booking_metas['place_order']['booking']['lname'] : '';
		$email           = isset( $booking_metas['place_order']['booking']['email'] ) && ! empty( $booking_metas['place_order']['booking']['email'] ) ? $booking_metas['place_order']['booking']['email'] : '';
		$country         = isset( $booking_metas['place_order']['booking']['country'] ) && ! empty( $booking_metas['place_order']['booking']['country'] ) ? $booking_metas['place_order']['booking']['country'] : '';
		$address         = isset( $booking_metas['place_order']['booking']['address'] ) && ! empty( $booking_metas['place_order']['booking']['address'] ) ? $booking_metas['place_order']['booking']['address'] : '';
		$phone           = isset( $booking_metas['place_order']['booking']['phone'] ) && ! empty( $booking_metas['place_order']['booking']['phone'] ) ? $booking_metas['place_order']['booking']['phone'] : '';
		$city            = isset( $booking_metas['place_order']['booking']['city'] ) && ! empty( $booking_metas['place_order']['booking']['city'] ) ? $booking_metas['place_order']['booking']['city'] : '';
		$trip_id         = isset( $booking_metas['place_order']['tid'] ) ? $booking_metas['place_order']['tid'] : '';
		$payment_mode    = isset( $_POST['wp_travel_engine_payment_mode'] ) ? $_POST['wp_travel_engine_payment_mode'] : '';
		$payment_amount  = isset( $booking_metas['place_order']['partial_due'] ) ? $booking_metas['place_order']['partial_due'] : 0;

		$return_url = wp_travel_engine_get_booking_confirm_url();

		$return_url = add_query_arg(
			array(
				'booking_id'    => $booking_id,
				'booked'        => true,
				'wte_gateway'   => 'payfast',
				'redirect_type' => 'partial-payment',
			),
			$return_url
		);

		$fail_cancel_url = isset( $booking_metas['place_order']['tid'] ) && ! empty( $booking_metas['place_order']['tid'] ) ? get_the_permalink( $booking_metas['place_order']['tid'] ) : home_url( '/' );

		// Construct variables for post
		$this->data_to_send = array(
			// Merchant details
			'merchant_id'      => $this->merchant_id,
			'merchant_key'     => $this->merchant_key,
			'return_url'       => $return_url,
			'cancel_url'       => $fail_cancel_url,
			'notify_url'       => $this->response_url,

			// Billing details
			'name_first'       => $firstname,
			'name_last'        => $lastname,
			'email_address'    => $email,

			// Item details
			'm_payment_id'     => ltrim( $booking_id, _x( '#', 'hash before order number', 'wte-payfast' ) ),
			'amount'           => $payment_amount,
			'item_name'        => get_the_title( $booking_metas['place_order']['tid'] ),
			/* translators: 1: blog info name */
			'item_description' => sprintf( __( 'New order from %s', 'wte-payfast' ), get_bloginfo( 'name' ) ),

			// Custom strings
			'custom_str1'      => $booking_id,
			'custom_str2'      => 'WPTravelEngine/' . WP_TRAVEL_ENGINE_PAYFAST_VERSION . '; ' . get_site_url(),
			'custom_str3'      => $booking_id,
			'source'           => 'WTE-PayFast-Gateway',
		);

		$payfast_args_array = array();
		foreach ( $this->data_to_send as $key => $value ) {
			$payfast_args_array[] = '<input type="hidden" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '" />';
		}

		// The form
		echo '<p>' . esc_html_e( 'Redirecting to PayFast website...', 'wte-payfast' ) . '</p>
			<form action="' . $this->url . '" method="POST" name="payfast_payment_form" id="payfast_payment_form">
				' . implode( '', $payfast_args_array ) . '
				<input type="submit" class="button" id="submit_payfast_payment_form" value="' . __( 'Pay via Payfast', 'wte-payfast' ) . '" />
				<script type="text/javascript">
                    document.getElementById("submit_payfast_payment_form").click();
				</script>
            </form>';

		exit;
	}

	/**
	 * Check PayFast ITN response.
	 *
	 * @since 1.0.0
	 */
	public function check_itn_response() {

		$this->handle_itn_request( stripslashes_deep( $_POST ) );

		// Notify PayFast that information has been received
		header( 'HTTP/1.0 200 OK' );
		flush();
	}

	/**
	 * Check PayFast ITN validity.
	 *
	 * @param array $data
	 * @since 1.0.0
	 */
	public function handle_itn_request( $data ) {

		$payfast_error = false;
		$payfast_done  = false;

		$debug_email = get_option( 'admin_email' );
		$session_id  = $data['custom_str1'];

		$vendor_name = get_bloginfo( 'name', 'display' );
		$vendor_url  = home_url( '/' );

		$booking_id = absint( $data['custom_str3'] );
		$order_key  = $session_id;

		$booking          = get_post( $booking_id );
		$original_booking = $booking;

		$order_metas = get_post_meta( $booking_id, 'wp_travel_engine_booking_setting', true );

		$customer = get_page_by_title( $order_metas['place_order']['booking']['email'], OBJECT, 'customer' );

		$customer_id = $customer->ID;

		$order_total = isset( $order_metas['place_order']['cost'] ) && ! empty( $order_metas['place_order']['cost'] ) ? $order_metas['place_order']['cost'] : 0;

		if ( false === $data ) {
			// error_log( 'WTE-PAYFAST: Data False' );
			$payfast_error         = true;
			$payfast_error_message = WTE_PF_ERR_BAD_ACCESS;
		}

		// Verify security signature
		if ( ! $payfast_error && ! $payfast_done ) {

			$signature = md5( $this->_generate_parameter_string( $data, false, false ) ); // false not to sort data
			// If signature different, log for debugging
			if ( ! $this->validate_signature( $data, $signature ) ) {
				// error_log( 'WTE-PAYFAST: Signature validate failed' );
				$payfast_error         = true;
				$payfast_error_message = WTE_PF_ERR_INVALID_SIGNATURE;
			}
		}

		// Verify source IP (If not in debug mode)
		if ( ! $payfast_error && ! $payfast_done
			&& $this->testmode ) {

			if ( ! $this->is_valid_ip( $_SERVER['REMOTE_ADDR'] ) ) {

				// error_log( 'WTE-PAYFAST: Invaild IP' );

				$payfast_error         = true;
				$payfast_error_message = WTE_PF_ERR_BAD_SOURCE_IP;

			}
		}

		// Verify data received
		if ( ! $payfast_error ) {

			// error_log( 'WTE-PAYFAST: Error after IP' );

			$validation_data = $data;

			unset( $validation_data['signature'] );

			// error_log( 'WTE-PAYFAST: error before validate_response_data' );

			$has_valid_response_data = $this->validate_response_data( $validation_data );

			// error_log( 'WTE-PAYFAST: validate_response_data_'. $has_valid_response_data );

			if ( ! $has_valid_response_data ) {

				// error_log( 'WTE-PAYFAST: validate_response_data fail' );

				$payfast_error         = true;
				$payfast_error_message = WTE_PF_ERR_BAD_ACCESS;

			}
		}

		// Check data against internal order
		if ( ! $payfast_error && ! $payfast_done ) {

			// error_log( 'WTE-PAYFAST: amounts_equal before' );

			// error_log( $this->amounts_equal( $data['amount_gross'], $order_total ) );

			error_log( 'strasecmp test:' . strcasecmp( $data['custom_str1'], $booking_id ) != 0 );

			// Check order amount
			if ( ! $this->amounts_equal( $data['amount_gross'], $order_total ) ) {

				// error_log( 'WTE-PAYFAST: amounts_equal fail' );

				$payfast_error         = true;
				$payfast_error_message = WTE_PF_ERR_AMOUNT_MISMATCH;

			} elseif ( $data['custom_str1'] != $booking_id ) {

				// error_log( 'WTE-PAYFAST: booking ID fail' );

				// Check session ID
				$payfast_error         = true;
				$payfast_error_message = WTE_PF_ERR_SESSIONID_MISMATCH;

			}
		}

		// error_log( 'WTE-PAYFAST: After booking ID_error_' . var_dump( $payfast_error ) );

		// alter order object to be the renewal order if
		// the ITN request comes as a result of a renewal submission request
		$description = json_decode( $data['item_description'] );

		// Get internal order and verify it hasn't already been processed
		if ( ! $payfast_error && ! $payfast_done ) {

			// Check if order has already been processed
			if ( get_post_meta( $booking_id, 'wte_payfast_completed_processing', true ) ) {
				// Order already processed
				$payfast_done = true;
			}
		}

		// error_log( 'WTE-PAYFAST: PAYFAST_DONE ?_' . $payfast_done );

		// If an error occurred
		if ( $payfast_error ) {

			// error_log( 'WTE-PAYFAST: Before send email_' . $this->send_debug_email );

			if ( $this->send_debug_email ) {

				 // Send an email
				$subject = 'PayFast ITN error: ' . $payfast_error_message;
				$body    =
					"Hi,\n\n" .
					"An invalid PayFast transaction on your website requires attention\n" .
					"------------------------------------------------------------\n" .
					'Site: ' . esc_html( $vendor_name ) . ' (' . esc_url( $vendor_url ) . ")\n" .
					'Remote IP Address: ' . $_SERVER['REMOTE_ADDR'] . "\n" .
					'Remote host name: ' . gethostbyaddr( $_SERVER['REMOTE_ADDR'] ) . "\n" .
					'Purchase ID: ' . $booking_id . "\n" .
					'User ID: ' . $customer_id . "\n";
				if ( isset( $data['pf_payment_id'] ) ) {
					$body .= 'PayFast Transaction ID: ' . esc_html( $data['pf_payment_id'] ) . "\n";
				}
				if ( isset( $data['payment_status'] ) ) {
					$body .= 'PayFast Payment Status: ' . esc_html( $data['payment_status'] ) . "\n";
				}

				$body .= "\nError: " . $payfast_error_message . "\n";

				switch ( $payfast_error_message ) {
					case WTE_PF_ERR_AMOUNT_MISMATCH:
						$body .=
							'Value received : ' . esc_html( $data['amount_gross'] ) . "\n"
							. 'Value should be: ' . $order_total;
						break;

					case WTE_PF_ERR_ORDER_ID_MISMATCH:
						$body .=
							'Value received : ' . esc_html( $data['custom_str3'] ) . "\n"
							. 'Value should be: ' . $booking_id;
						break;

					case WTE_PF_ERR_SESSIONID_MISMATCH:
						$body .=
							'Value received : ' . esc_html( $data['custom_str1'] ) . "\n"
							. 'Value should be: ' . $booking_id;
						break;

					// For all other errors there is no need to add additional information
					default:
						break;
				}

				// error_log( 'WTE-PAYFAST: Before wp_mail_' . $debug_email );

				wp_mail( $debug_email, $subject, $body );
			} // End if().
		} elseif ( ! $payfast_done ) {

			if ( $booking_id != $order_key ) {
				exit;
			}

			$status = strtolower( $data['payment_status'] );

			if ( 'complete' === $status ) {
				update_post_meta( $booking_id, 'wte_payfast_completed_processing', true );
			}

			$order_metas['place_order']['payment']['merchant_id']    = $_POST['merchant_id'];
			$order_metas['place_order']['payment']['pf_payment_id']  = $_POST['pf_payment_id'];
			$order_metas['place_order']['payment']['signature']      = $_POST['signature'];
			$order_metas['place_order']['payment']['payment_status'] = $_POST['payment_status'];
			$order_metas['place_order']['payment']['amount_gross']   = $_POST['amount_gross'];
			$order_metas['place_order']['payment']['amount_net']     = $_POST['amount_net'];
			$order_metas['place_order']['payment']['amount_fee']     = $_POST['amount_fee'];

			update_post_meta( $booking_id, 'wp_travel_engine_booking_setting', $order_metas );

		} // End if().

	}

	/**
	 * @since 1.4.0 introduced.
	 * @param      $api_data
	 * @param bool     $sort_data_before_merge? default true.
	 * @param bool     $skip_empty_values Should key value pairs be ignored when generating signature?  Default true.
	 *
	 * @return string
	 */
	protected function _generate_parameter_string( $api_data, $sort_data_before_merge = true, $skip_empty_values = true ) {

		// if sorting is required the passphrase should be added in before sort.
		if ( ! empty( $this->pass_phrase ) && $sort_data_before_merge ) {
			$api_data['passphrase'] = $this->pass_phrase;
		}

		if ( $sort_data_before_merge ) {
			ksort( $api_data );
		}

		// concatenate the array key value pairs.
		$parameter_string = '';
		foreach ( $api_data as $key => $val ) {

			if ( $skip_empty_values && empty( $val ) ) {
				continue;
			}

			if ( 'signature' !== $key ) {
				$val               = urlencode( $val );
				$parameter_string .= "$key=$val&";
			}
		}
		// when not sorting passphrase should be added to the end before md5
		if ( $sort_data_before_merge ) {
			$parameter_string = rtrim( $parameter_string, '&' );
		} elseif ( ! empty( $this->pass_phrase ) ) {
			$parameter_string .= 'passphrase=' . urlencode( $this->pass_phrase );
		} else {
			$parameter_string = rtrim( $parameter_string, '&' );
		}

		return $parameter_string;
	}

	/**
	 * Setup constants.
	 *
	 * Setup common values and messages used by the PayFast gateway.
	 *
	 * @since 1.0.0
	 */
	public function setup_constants() {
		// Create user agent string.
		define( 'WTE_PF_SOFTWARE_NAME', 'WooCommerce' );
		define( 'WTE_PF_SOFTWARE_VER', WP_TRAVEL_ENGINE_VERSION );
		define( 'WTE_PF_MODULE_NAME', 'WooCommerce-PayFast-Free' );
		define( 'WTE_PF_MODULE_VER', $this->version );

		// Features
		// - PHP
		$pf_features = 'PHP ' . phpversion() . ';';

		// - cURL
		if ( in_array( 'curl', get_loaded_extensions() ) ) {
			define( 'WTE_PF_CURL', '' );
			$pf_version   = curl_version();
			$pf_features .= ' curl ' . $pf_version['version'] . ';';
		} else {
			$pf_features .= ' nocurl;';
		}

		// Create user agrent
		define( 'WTE_PF_USER_AGENT', WTE_PF_SOFTWARE_NAME . '/' . WTE_PF_SOFTWARE_VER . ' (' . trim( $pf_features ) . ') ' . WTE_PF_MODULE_NAME . '/' . WTE_PF_MODULE_VER );

		// General Defines
		define( 'WTE_PF_TIMEOUT', 15 );
		define( 'WTE_PF_EPSILON', 0.01 );

		// Messages
		// Error
		define( 'WTE_PF_ERR_AMOUNT_MISMATCH', __( 'Amount mismatch', 'wte-payfast' ) );
		define( 'WTE_PF_ERR_BAD_ACCESS', __( 'Bad access of page', 'wte-payfast' ) );
		define( 'WTE_PF_ERR_BAD_SOURCE_IP', __( 'Bad source IP address', 'wte-payfast' ) );
		define( 'WTE_PF_ERR_CONNECT_FAILED', __( 'Failed to connect to PayFast', 'wte-payfast' ) );
		define( 'WTE_PF_ERR_INVALID_SIGNATURE', __( 'Security signature mismatch', 'wte-payfast' ) );
		define( 'WTE_PF_ERR_MERCHANT_ID_MISMATCH', __( 'Merchant ID mismatch', 'wte-payfast' ) );
		define( 'WTE_PF_ERR_NO_SESSION', __( 'No saved session found for ITN transaction', 'wte-payfast' ) );
		define( 'WTE_PF_ERR_ORDER_ID_MISSING_URL', __( 'Order ID not present in URL', 'wte-payfast' ) );
		define( 'WTE_PF_ERR_ORDER_ID_MISMATCH', __( 'Order ID mismatch', 'wte-payfast' ) );
		define( 'WTE_PF_ERR_ORDER_INVALID', __( 'This order ID is invalid', 'wte-payfast' ) );
		define( 'WTE_PF_ERR_ORDER_NUMBER_MISMATCH', __( 'Order Number mismatch', 'wte-payfast' ) );
		define( 'WTE_PF_ERR_ORDER_PROCESSED', __( 'This order has already been processed', 'wte-payfast' ) );
		define( 'WTE_PF_ERR_PDT_FAIL', __( 'PDT query failed', 'wte-payfast' ) );
		define( 'WTE_PF_ERR_PDT_TOKEN_MISSING', __( 'PDT token not present in URL', 'wte-payfast' ) );
		define( 'WTE_PF_ERR_SESSIONID_MISMATCH', __( 'Session ID mismatch', 'wte-payfast' ) );
		define( 'WTE_PF_ERR_UNKNOWN', __( 'Unkown error occurred', 'wte-payfast' ) );

		// General
		define( 'WTE_PF_MSG_OK', __( 'Payment was successful', 'wte-payfast' ) );
		define( 'WTE_PF_MSG_FAILED', __( 'Payment has failed', 'wte-payfast' ) );
		define( 'WTE_PF_MSG_PENDING', __( 'The payment is pending. Please note, you will receive another Instant Transaction Notification when the payment status changes to "Completed", or "Failed"', 'wte-payfast' ) );

		do_action( 'wte_gateway_payfast_setup_constants' );
	}

	/**
	 * validate_signature()
	 *
	 * Validate the signature against the returned data.
	 *
	 * @param array  $data
	 * @param string $signature
	 * @since 1.0.0
	 * @return string
	 */
	public function validate_signature( $data, $signature ) {
		$result = $data['signature'] === $signature;
		return $result;
	}

	/**
	 * Validate the IP address to make sure it's coming from PayFast.
	 *
	 * @param array $source_ip
	 * @since 1.0.0
	 * @return bool
	 */
	public function is_valid_ip( $source_ip ) {
		// Variable initialization
		$valid_hosts = array(
			'www.payfast.co.za',
			'sandbox.payfast.co.za',
			'w1w.payfast.co.za',
			'w2w.payfast.co.za',
		);

		$valid_ips = array();

		foreach ( $valid_hosts as $pf_hostname ) {
			$ips = gethostbynamel( $pf_hostname );

			if ( false !== $ips ) {
				$valid_ips = array_merge( $valid_ips, $ips );
			}
		}

		// Remove duplicates
		$valid_ips = array_unique( $valid_ips );

		// Adds support for X_Forwarded_For
		if ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$source_ip = (string) rest_is_ip_address( trim( current( preg_split( '/[,:]/', sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) ) ) ) ) ?: $source_ip;
		}

		$is_valid_ip = in_array( $source_ip, $valid_ips );
		return apply_filters( 'woocommerce_gateway_payfast_is_valid_ip', $is_valid_ip, $source_ip );
	}

	/**
	 * validate_response_data()
	 *
	 * @param array  $post_data
	 * @param string $proxy Address of proxy to use or NULL if no proxy.
	 * @since 1.0.0
	 * @return bool
	 */
	public function validate_response_data( $post_data, $proxy = null ) {

		if ( ! is_array( $post_data ) ) {
			return false;
		}

		$response = wp_remote_post(
			$this->validate_url,
			array(
				'body'       => $post_data,
				'timeout'    => 70,
				'user-agent' => WTE_PF_USER_AGENT,
			)
		);

		if ( is_wp_error( $response ) || empty( $response['body'] ) ) {

			return false;
		}

		parse_str( $response['body'], $parsed_response );

		$response = $parsed_response;

		// Interpret Response
		if ( is_array( $response ) && in_array( 'VALID', array_keys( $response ) ) ) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * amounts_equal()
	 *
	 * Checks to see whether the given amounts are equal using a proper floating
	 * point comparison with an Epsilon which ensures that insignificant decimal
	 * places are ignored in the comparison.
	 *
	 * eg. 100.00 is equal to 100.0001
	 *
	 * @author Jonathan Smit
	 * @param $amount1 Float 1st amount for comparison
	 * @param $amount2 Float 2nd amount for comparison
	 * @since 1.0.0
	 * @return bool
	 */
	public function amounts_equal( $amount1, $amount2 ) {
		return ! ( abs( floatval( $amount1 ) - floatval( $amount2 ) ) > WTE_PF_EPSILON );
	}
}

new WTE_Gateway_Payfast();
