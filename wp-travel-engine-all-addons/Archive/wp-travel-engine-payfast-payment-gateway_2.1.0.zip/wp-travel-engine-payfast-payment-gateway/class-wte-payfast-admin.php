<?php
// admin settings
class Wte_PayFast_Admin {

	function __construct() {
		// add_action( 'wte_payfast_settings',array( $this, 'wte_payfast_settings' ) );

		// filter - Global settings | New backend UI
		add_filter( 'wpte_settings_get_global_tabs', array( $this, 'wte_payfast_settings' ) );

		add_action( 'wte_payfast_enable', array( $this, 'wte_payfast_enable' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'Wte_enqueue_backend_assets' ) );
		$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', true );
		if ( isset( $wp_travel_engine_settings['payfast_enable'] ) ) {
			add_action( 'wp_enqueue_scripts', array( $this, 'Wte_enqueue_frontend_assets' ) );
			add_filter( 'wte_payment_gateways_dropdown_options', array( $this, 'wte_enable_payfast_dropdown' ) );
			add_action( 'wp_ajax_payfast_form', array( $this, 'payfast_form' ) );
			add_action( 'wp_ajax_nopriv_payfast_form', array( $this, 'payfast_form' ) );
		}

		add_action( 'wp_ajax_payfast_payment_process', array( $this, 'payfast_payment_process' ) );
		add_action( 'wp_ajax_nopriv_payfast_payment_process', array( $this, 'payfast_payment_process' ) );

		add_action( 'add_meta_boxes', array( $this, 'wpte_payfast_add_meta_boxes' ) );
		add_action( 'save_post', array( $this, 'wp_travel_engine_payfast_meta_box_data' ) );
		add_action( 'init', array( $this, 'load_plugin_textdomain' ) );
		add_shortcode( 'WP_TRAVEL_ENGINE_NOTIFY_PAYFAST', array( $this, 'wpte_payfast_sc' ) );

		add_filter( 'wp_travel_engine_available_payment_gateways', array( $this, 'payfast_gateway_list' ) );

	}

	function wpte_payfast_sc() {
		// Notify PayFast that information has been received
		session_start();
		header( 'HTTP/1.0 200 OK' );
		flush();

		// Variable initialization
		$pfError       = false;
		$pfErrMsg      = '';
		$filename      = 'notify.txt'; // DEBUG
		$output        = ''; // DEBUG
		$pfParamString = '';
		$pfHost        = 'www.payfast.co.za';

		// Dump the submitted variables and calculate security signature
		if ( ! $pfError ) {
			$output = "Posted Variables:\n\n"; // DEBUG

			// Strip any slashes in data
			foreach ( $_POST as $key => $val ) {
				$pfData[ $key ] = stripslashes( $val );
			}

			// Dump the submitted variables and calculate security signature
			foreach ( $pfData as $key => $val ) {
				if ( $key != 'signature' ) {
					$pfParamString .= $key . '=' . urlencode( $val ) . '&';
				}
			}

			// Remove the last '&' from the parameter string
			$pfParamString     = substr( $pfParamString, 0, -1 );
			$pfTempParamString = $pfParamString;

			// If a passphrase has been set in the PayFast Settings, include it in the signature string.
			$passPhrase = 'XXXXX'; // You need to get this from a constant or stored in you website
			if ( ! empty( $passPhrase ) ) {
				$pfTempParamString .= '&passphrase=' . urlencode( $passPhrase );
			}
			$signature = md5( $pfTempParamString );

			$result = ( $_POST['signature'] == $signature );

			$output .= "Security Signature:\n\n"; // DEBUG
			$output .= '- posted     = ' . $_POST['signature'] . "\n"; // DEBUG
			$output .= '- calculated = ' . $signature . "\n"; // DEBUG
			$output .= '- result     = ' . ( $result ? 'SUCCESS' : 'FAILURE' ) . "\n"; // DEBUG
		}

		// Verify source IP
		if ( ! $pfError ) {
			$validHosts = array(
				'www.payfast.co.za',
				'sandbox.payfast.co.za',
				'w1w.payfast.co.za',
				'w2w.payfast.co.za',
			);

			$validIps = array();

			foreach ( $validHosts as $pfHostname ) {
				$ips = gethostbynamel( $pfHostname );

				if ( $ips !== false ) {
					$validIps = array_merge( $validIps, $ips );
				}
			}

			// Remove duplicates
			$validIps = array_unique( $validIps );

			if ( ! in_array( $_SERVER['REMOTE_ADDR'], $validIps ) ) {
				$pfError  = true;
				$pfErrMsg = PF_ERR_BAD_SOURCE_IP;
			}
		}

		// Connect to server to validate data received
		if ( ! $pfError ) {
			// Use cURL (If it's available)
			if ( function_exists( 'curl_init' ) ) {
				$output .= "\n\nUsing cURL\n\n"; // DEBUG

				// Create default cURL object
				$ch = curl_init();

				// Base settings
				$curlOpts = array(
					// Base options
					CURLOPT_USERAGENT      => USER_AGENT, // Set user agent
					CURLOPT_RETURNTRANSFER => true,  // Return output as string rather than outputting it
					CURLOPT_HEADER         => false,         // Don't include header in output
					CURLOPT_SSL_VERIFYHOST => 2,
					CURLOPT_SSL_VERIFYPEER => 1,

					// Standard settings
					CURLOPT_URL            => 'https://' . $pfHost . '/eng/query/validate',
					CURLOPT_POST           => true,
					CURLOPT_POSTFIELDS     => $pfParamString,
				);
				curl_setopt_array( $ch, $curlOpts );

				// Execute CURL
				$res = curl_exec( $ch );
				curl_close( $ch );

				if ( $res === false ) {
					$pfError  = true;
					$pfErrMsg = PF_ERR_CURL_ERROR;
				}
			}
			// Use fsockopen
			else {
				$output .= "\n\nUsing fsockopen\n\n"; // DEBUG

				// Construct Header
				$header  = "POST /eng/query/validate HTTP/1.0\r\n";
				$header .= 'Host: ' . $pfHost . "\r\n";
				$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
				$header .= 'Content-Length: ' . strlen( $pfParamString ) . "\r\n\r\n";

				// Connect to server
				$socket = fsockopen( 'ssl://' . $pfHost, 443, $errno, $errstr, 10 );

				// Send command to server
				fputs( $socket, $header . $pfParamString );

				// Read the response from the server
				$res        = '';
				$headerDone = false;

				while ( ! feof( $socket ) ) {
					$line = fgets( $socket, 1024 );

					// Check if we are finished reading the header yet
					if ( strcmp( $line, "\r\n" ) == 0 ) {
						// read the header
						$headerDone = true;
					}
					// If header has been processed
					elseif ( $headerDone ) {
						// Read the main response
						$res .= $line;
					}
				}
			}
		}

		// Get data from server
		if ( ! $pfError ) {
			// Parse the returned data
			$lines = explode( "\n", $res );

			$output .= "\n\nValidate response from server:\n\n"; // DEBUG

			foreach ( $lines as $line ) { // DEBUG
				$output .= $line . "\n"; // DEBUG
			}
		}

		// Interpret the response from server
		if ( ! $pfError ) {
			// Get the response from PayFast (VALID or INVALID)
			$result = trim( $lines[0] );

			$output .= "\nResult = " . $result; // DEBUG

			// If the transaction was valid
			if ( strcmp( $result, 'VALID' ) == 0 ) {
				$new_post  = array(
					'post_status' => 'publish',
					'post_type'   => 'booking',
					'post_title'  => 'booking',
				);
				$post_id   = wp_insert_post( $new_post );
				$book_post = array(
					'ID'         => $post_id,
					'post_title' => 'booking ' . $post_id,
				);
				// Update the post into the database
				$updated     = wp_update_post( $book_post );
				$post        = get_post( $_SESSION['trip-id'] );
				$slug        = $post->post_title;
				$order_metas =
				array(
					'place_order' => array(
						'traveler' => esc_attr( $_POST['custom_int1'] ),
						'cost'     => esc_attr( $_POST['amount_gross'] ),
						'due'      => esc_attr( $_SESSION['due'] ),
						'tid'      => esc_attr( $_POST['item_description'] ),
						'tname'    => esc_attr( $_POST['item_name'] ),
						'datetime' => esc_attr( $_POST['custom_str1'] ),
						'booking'  => array(
							'fname'    => $_POST['name_first'],
							'lname'    => $_POST['name_last'],
							'email'    => $_POST['email_address'],
							'address'  => $_POST['address_street'],
							'city'     => $_POST['address_city'],
							'country'  => $_POST['address_country_code'],
							'postcode' => $_POST['address_zip'],
						),
						'payment'  => array(
							'merchant_id'    => $_POST['merchant_id'],
							'pf_payment_id'  => $_POST['pf_payment_id'],
							'signature'      => $_POST['signature'],
							'payment_status' => $_POST['payment_status'],
							'amount_gross'   => $_POST['amount_gross'],
							'amount_net'     => $_POST['amount_net'],
							'amount_fee'     => $_POST['amount_fee'],
						),
					),
				);
				$bid[]       = $post_id;
				$order_metas = array_merge_recursive( $order_metas, $bid );
				update_post_meta( $post_id, 'wp_travel_engine_booking_setting', $order_metas );
				update_post_meta( $_POST['item_description'], $_POST['custom_str1'] . '_bid', $post_id );

				global $wpdb;
				if ( ! is_admin() ) {
					require_once ABSPATH . 'wp-admin/includes/post.php';
				}

				if ( post_exists( $order_metas['place_order']['booking']['email'], '', '' ) == 0 ) {
					$new_post = array(
						'post_status' => 'publish',
						'post_type'   => 'customer',
						'post_title'  => 'customer',
					);
					$post_id  = wp_insert_post( $new_post );

					foreach ( $order_metas['place_order'] as $key => $value ) {
						$arr[ $key ][1] = $value;
					}
					unset( $arr['booking'] );

					$booked_id[] = $order_metas[0];

					if ( ! isset( $booked_id ) && ! is_array( $booked_id ) ) {
						$booked_id = array();
					}

					update_post_meta( $post_id, 'wp_travel_engine_bookings', $booked_id );
					update_post_meta( $post_id, 'wp_travel_engine_booking_setting', $order_metas );
					update_post_meta( $post_id, 'wp_travel_engine_booked_trip_setting', $arr );

					$customer_post = array(
						'ID'         => $post_id,
						'post_title' => esc_attr( $order_metas['place_order']['booking']['email'] ),
					);
					// Update the post into the database
					$updated = wp_update_post( $customer_post );

					if ( false === $updated ) {
						_e( 'There was an error on update.', 'wte-payfast' );
					}
					require_once WP_TRAVEL_ENGINE_BASE_PATH . '/includes/class-wp-travel-engine-mail.php';
					$obj = new Wp_Travel_Engine_Mail_Template();
					$obj->mail_editor( $order_metas, $post_id );
				} else {
					$pid      = get_page_by_title( $order_metas['place_order']['booking']['email'], OBJECT, 'customer' );
					$my_array = get_post_meta( $pid->ID, 'wp_travel_engine_booked_trip_setting', true );

					if ( isset( $my_array ) && $my_array != '' ) {
						$size = sizeof( $my_array['traveler'] );
					} else {
						$my_array[] = '';
						$size       = 0;
					}
					$size++;
					foreach ( $order_metas['place_order'] as $key => $value ) {
						$arr[ $key ][ $size ] = $value;
					}
					unset( $arr['booking'] );
					$a           = array_merge_recursive( $my_array, $arr );
					$my_bookings = get_post_meta( $pid->ID, 'wp_travel_engine_bookings', true );
					$booked_id[] = $order_metas[0];
					if ( ! isset( $booked_id ) && ! is_array( $booked_id ) ) {
						$booked_id = array();
					}
					if ( isset( $my_bookings ) && $my_bookings != '' ) {
						$my_bookings = array_merge_recursive( $my_bookings, $booked_id );
					} else {
						$my_bookings[] = '';
					}
					update_post_meta( $pid->ID, 'wp_travel_engine_booked_trip_setting', $a );
					update_post_meta( $pid->ID, 'wp_travel_engine_bookings', $my_bookings );
				}
				if ( false === $updated ) {
					_e( 'There was an error on update.', 'wte-payfast' );
				}
				require_once WP_TRAVEL_ENGINE_BASE_PATH . '/includes/class-wp-travel-engine-mail.php';
				$obj = new Wp_Travel_Engine_Mail_Template();
				$obj->mail_editor( $order_metas, $post_id );
			}
			// If the transaction was NOT valid
			else {
				// Log for investigation
				$pfError  = true;
				$pfErrMsg = PF_ERR_INVALID_DATA;
			}
		}

		// If an error occurred
		if ( $pfError ) {
			$output .= "\n\nAn error occurred!";
			$output .= "\nError = " . $pfErrMsg;
		}

		// Write output to file // DEBUG
		file_put_contents( $filename, $output ); // DEBUG
	}

	function load_plugin_textdomain() {

		load_plugin_textdomain(
			'wte-payfast',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}
	/**
	 * Payment Details.
	 *
	 * @since 1.0
	 */
	function wpte_payfast_add_meta_boxes() {
		$screens = array( 'booking' );
		foreach ( $screens as $screen ) {
			add_meta_box(
				'payfast_id',
				__( 'PayFast Payment Details', 'wte-payfast' ),
				array( $this, 'wte_payfast_metabox_callback' ),
				$screen,
				'side',
				'high'
			);
		}
	}

	// Tab for notice listing and settings
	public function wte_payfast_metabox_callback() {
		include WP_TRAVEL_ENGINE_PAYFAST_BASE_PATH . '/admin/includes/backend/payfast.php';
	}

	/**
	 * When the post is saved, saves our custom data.
	 *
	 * @param int $post_id The ID of the post being saved.
	 */
	function wp_travel_engine_payfast_meta_box_data( $post_id ) {

		/*
		 * We need to verify this came from our screen and with proper authorization,
		 * because the save_post action can be triggered at other times.
		 */
		// Sanitize user input.
		if ( isset( $_POST['wp_travel_engine_booking_setting'] ) ) {
			$settings = $_POST['wp_travel_engine_booking_setting'];
			update_post_meta( $post_id, 'wp_travel_engine_booking_setting', $settings );
		}
	}


	// enable payfast on dropdown
	function wte_enable_payfast_dropdown( $options ) {
		$options[] = 'PayFast';
		return $options;
	}
	// Enqueue required assets for admin
	function Wte_enqueue_backend_assets() {
		wp_enqueue_script( 'Wte-PayFast', plugin_dir_url( __FILE__ ) . 'assets/admin.js', array( 'jquery' ), '', false );
		wp_enqueue_style( 'Wte-PayFast', plugin_dir_url( __FILE__ ) . 'assets/admin.css', array(), '', 'all' );
	}

	// Enqueue required assets for admin
	function Wte_enqueue_frontend_assets() {
		wp_register_script( 'Wte-PayFast', plugin_dir_url( __FILE__ ) . 'assets/public.js', array( 'jquery' ), '', true );
		$payfast_base_url  = defined( 'WP_TRAVEL_ENGINE_PAYMENT_DEBUG' ) && WP_TRAVEL_ENGINE_PAYMENT_DEBUG ? 'https://sandbox.payfast.co.za/eng/process' : 'https://www.payfast.co.za/eng/process';
		$translation_array = array(
			'success'     => __( 'Redirecting to PayFast...', 'wte-payfast' ),
			'payfast_url' => $payfast_base_url,
		);
		wp_localize_script( 'Wte-PayFast', 'payfast', $translation_array );
		wp_enqueue_script( 'Wte-PayFast' );
	}

	public function wte_payfast_settings( $global_tabs ) {
		if ( isset( $global_tabs['wpte-payment'] ) ) {
			$global_tabs['wpte-payment']['sub_tabs']['wte-payfast'] = array(
				'label'        => __( 'PayFast Payment', 'wte-payfast' ),
				'content_path' => WP_TRAVEL_ENGINE_PAYFAST_BASE_PATH . '/admin/includes/backend/payfast-global-extension-setting.php',
				'current'      => false,
			);
		}
		return $global_tabs;
	}

	// admin enable settings
	function wte_payfast_enable() {
		$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', true );
		?>
	<div class="wte-payfast-form">
	  <label for="wp_travel_engine_settings[payfast_enable]"><?php _e( 'PayFast : ', 'wte-payfast' ); ?></label>
	  <input type="checkbox" id="wp_travel_engine_settings[payfast_enable]" class="payfast" name="wp_travel_engine_settings[payfast_enable]" value="1"
		<?php
		if ( isset( $wp_travel_engine_settings['payfast_enable'] ) && $wp_travel_engine_settings['payfast_enable'] != '' ) {
			echo 'checked';}
		?>
			>
	  <div class="settings-note"><?php _e( 'Please check this to enable PayFast booking system for trip booking and fill the account info below.', 'wte-payfast' ); ?></div>
	</div>
		<?php
	}

	function payfast_payment_process() {
		ob_start();
		$obj                       = new Wp_Travel_Engine_Functions();
		$billing_options           = $obj->order_form_billing_options();
		$personal_options          = $obj->order_form_personal_options();
		$relation_options          = $obj->order_form_relation_options();
		$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', true );
		$merchant_id               = isset( $wp_travel_engine_settings['payfast_id'] ) ? esc_attr( $wp_travel_engine_settings['payfast_id'] ) : '';
		$merchant_key              = isset( $wp_travel_engine_settings['payfast_merchant_key'] ) ? esc_attr( $wp_travel_engine_settings['payfast_merchant_key'] ) : '';
		$action                    = '';

		$payfast_base_url = defined( 'WP_TRAVEL_ENGINE_PAYMENT_DEBUG' ) && WP_TRAVEL_ENGINE_PAYMENT_DEBUG ? 'https://sandbox.payfast.co.za/eng/process' : 'https://www.payfast.co.za/eng/process';

		define( 'PAYFAST_BASE_URL', $payfast_base_url );    // Testing url

		$phone = $_POST['phone'];

		$firstName = $_POST['firstname'];

		$lastName = $_POST['lastname'];

		$country = $_POST['country'];

		$city = $_POST['city'];

		$address = $_POST['address'];

		$amount = $_SESSION['trip-cost'];

		$amount = str_replace( ',', '', $amount );

		$hash = '';

		$email = $_POST['email'];

		$wp_travel_engine_confirm            = isset( $wp_travel_engine_settings['pages']['wp_travel_engine_confirmation_page'] ) ? esc_attr( $wp_travel_engine_settings['pages']['wp_travel_engine_confirmation_page'] ) : '';
		$wp_travel_engine_payfast_notify_url = isset( $wp_travel_engine_settings['pages']['wp_travel_engine_payfast_notify_url'] ) ? esc_attr( $options['pages']['wp_travel_engine_payfast_notify_url'] ) : '';
		$wp_travel_engine_confirm            = get_permalink( $wp_travel_engine_confirm );
		$wp_travel_engine_payfast            = get_permalink( $wp_travel_engine_settings['pages']['wp_travel_engine_payfast_notify_url'] );
		$data                                = array(
			// Merchant details
			'merchant_id'      => $merchant_id,
			'merchant_key'     => $merchant_key,
			'return_url'       => $wp_travel_engine_confirm,
			'cancel_url'       => $wp_travel_engine_payfast_notify_url,
			'notify_url'       => $wp_travel_engine_payfast,
			// Buyer details
			'name_first'       => $firstName,
			'name_last'        => $lastName,
			'email_address'    => $email,
			// Transaction details
			'm_payment_id'     => rand( 5, 50 ), // Unique payment ID to pass through to notify_url
		// If multicurrency system its conversion has to be done before building this array
			'amount'           => number_format( sprintf( '%.2f', $amount ), 2, '.', '' ),
			'item_name'        => get_the_title( $_SESSION['trip-id'] ),
			'item_description' => $_SESSION['trip-id'],
			'custom_int1'      => $_SESSION['travelers'], // custom integer to be passed through
			'custom_str1'      => $_SESSION['trip-date'],
		);

		$pfOutput = '';

		foreach ( $data as $key => $val ) {
			if ( ! empty( $val ) ) {
				$pfOutput .= $key . '=' . urlencode( trim( $val ) ) . '&';
			}
		}
		// Remove last ampersand
		$getString = substr( $pfOutput, 0, -1 );
		if ( isset( $passPhrase ) ) {
			$getString .= '&passphrase=' . urlencode( trim( $passPhrase ) );
		}
		$data['signature'] = md5( $getString );

		foreach ( $data as $name => $value ) {
			$htmlForm .= '<input name="' . $name . '" type="hidden" value="' . $value . '" />'; }
		echo $htmlForm;
		wp_reset_postdata();
		$data = ob_get_clean();
		wp_send_json_success( $data );
		die();
	}

	/**
	 * Add PayU to payment gateways list.
	 *
	 * @param [type] $gateway_list
	 * @return void
	 */
	public function payfast_gateway_list( $gateway_list ) {

		if ( ! $this->is_currency_rand() ) {
			return $gateway_list;
		}

		$gateway_list['payfast_enable'] = array(
			'label'       => __( 'Payfast', 'wte-payfast' ),
			'input_class' => 'payfast',
			'info_text'   => __( 'Please check this to enable Payfast booking system for trip booking and fill the account info below.', 'wte-payfast' ),
		);

		return $gateway_list;

	}

	/**
	 * Is ZAR selected.
	 *
	 * @return boolean
	 */
	public function is_currency_rand() {
		$currency_code = wp_travel_engine_get_currency_code();

		return 'ZAR' === $currency_code;
	}



}
new Wte_PayFast_Admin();
