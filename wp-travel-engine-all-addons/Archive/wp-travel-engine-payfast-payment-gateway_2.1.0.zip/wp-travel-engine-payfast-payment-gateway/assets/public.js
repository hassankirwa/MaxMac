jQuery(document).ready(function($){
  $("#wte_payment_options").on('change', function(e){
    var val = $('#wte_payment_options :selected').val();
    e.preventDefault();
    if( val == '' && val != 'PayFast' )
    {
      return;
    }
    jQuery.ajax({
      type: 'post',
      url: WTEAjaxData.ajaxurl,
      data : {action: 'payfast_form', val : val},
      success: function (response) {
        if(val == 'PayFast')
        {
          $('#wp-travel-engine-order-form').attr('action',Url.normalurl);
          $( '.wp-travel-engine-billing-details-wrapper' ).html( response.data );
          $( '.stripe-button:visible' ).remove();  
          $( '.stripe-button-el' ).remove();
          $('.wp-travel-engine-submit').show();
          $('.wte-authorize-net-wrap').remove();
        }
      }
    });
  });
});

jQuery( function($) {
  $(".wp-travel-engine-submit").on('click', function(e){
    var val = $('#wte_payment_options :selected').val();
    if( val != 'PayFast' ){
      return;
    }
    e.preventDefault();
    var email = $('#email').val();
    var phone = $('#phone').val();
    var firstname = $('#fname').val();
    var lastname = $('#lname').val();
    var country = $('#country').val();
    var city = $('#city').val();
    var address = $('#address').val();

    jQuery.ajax({
      type: 'post',
      url: WTEAjaxData.ajaxurl,
      data : {action: 'payfast_payment_process',email:email,phone:phone,firstname:firstname,lastname:lastname,city:city,country:country,address:address},
      beforeSend: function(){
        $("#submit-loader").fadeIn(500);
      },
      success: function (response) {
        $('#wp-travel-engine-order-form').attr('action',payfast.payfast_url);
        $( '.stripe-button:visible' ).remove();  
        $( '.stripe-button-el' ).remove();
        $( '.wp-travel-engine-submit' ).show();
        $( '.wp-travel-engine-billing-details-wrapper' ).html( response.data );         
      },
      complete: function(){
        $("#submit-loader").fadeOut(500);
        $("#wp-travel-engine-order-form .successful").text(payfast.success);
        $("#wp-travel-engine-order-form .successful").fadeIn();
        $("#wp-travel-engine-order-form").submit();             
      }
    });
  });
});