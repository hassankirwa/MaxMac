jQuery(document).ready(function($){
    if ($('.payfast').is( ':checked' )) {
        $('.wte-payfast-form.settings').fadeIn('slow');
    }
    else{
        $('.wte-payfast-form.settings').fadeOut('slow');
    }
    $('body').on('click', '.payfast', function (e){ 
        if ($('.payfast').is( ':checked' )) {
            $('.wte-payfast-form.settings').fadeIn('slow');
        }
        else{
            $('.wte-payfast-form.settings').fadeOut('slow');
        }
    });
});