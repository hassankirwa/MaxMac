<?php
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://wptravelengine.com/
 * @since             1.0.0
 * @package           WP_Travel_Engine
 *
 * @wordpress-plugin
 * Plugin Name:       WP Travel Engine - PayFast Payment Gateway
 * Plugin URI:        https://wptravelengine.com/
 * Description:       An extension of WP Travel Engine plugin to accept credit cards directly on your website through your PayFast account.
 * Version:           2.1.0
 * Author:            WP Travel Engine
 * Author URI:        https://wptravelengine.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wte-payfast
 * Domain Path:       /languages
 * WTE requires at least: 4.3.0
 * WTE tested up to: 5.2
 * WTE: 1744:wte_payfast_license_key
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

defined( 'WP_TRAVEL_ENGINE_PAYFAST_REQUIRES_AT_LEAST' ) || define( 'WP_TRAVEL_ENGINE_PAYFAST_REQUIRES_AT_LEAST', '4.3.0' );

/**
 * Main plugin instantiation class.
 *
 * @since 1.0.0
 */
class WTE_PAYFAST_PAYMENT {

	/**
	 * Track instance of the WTE_PAYFAST_PAYMENT class.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	private static $instance = null;

	/**
	 * Tracks current plugin version throughout codebase.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	var $version = '2.1.0';

	/**
	 * Main WTE_PAYFAST_PAYMENT Instance
	 *
	 * Ensures only one instance of WTE_PAYFAST_PAYMENT is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 *
	 * @return WTE_PAYFAST_PAYMENT - Main instance
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof WTE_PAYFAST_PAYMENT ) ) {
			self::$instance = new WTE_PAYFAST_PAYMENT();
			self::$instance->i18n();
			self::$instance->includes();
		}

		return self::$instance;
	}

	/**
	 * Fire up the engines.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		// Define plugin constants
		$this->plugin_file    = __FILE__;
		$this->basename       = plugin_basename( $this->plugin_file );
		$this->directory_path = plugin_dir_path( $this->plugin_file );
		$this->directory_url  = plugin_dir_url( $this->plugin_file );

		define( 'WP_TRAVEL_ENGINE_PAYFAST_VERSION', $this->version );
		define( 'WP_TRAVEL_ENGINE_PAYFAST_FILE_PATH', __FILE__ );
		define( 'WP_TRAVEL_ENGINE_PAYFAST_BASE_PATH', dirname( __FILE__ ) );

		// Handle plugin activation and deactivation
		register_activation_hook( $this->plugin_file, array( $this, 'activation' ) );
		register_deactivation_hook( $this->plugin_file, array( $this, 'deactivation' ) );

	}

	/**
	 * Plugin activation hook.
	 *
	 * @since  1.0.0
	 */
	public function activation() {

		$this->includes();

		$arr           = array();
		$new_page      = array(
			'post_title'   => 'Payfast Notify',
			'post_content' => '[WP_TRAVEL_ENGINE_NOTIFY_PAYFAST]',
			'post_status'  => 'publish',
			'post_type'    => 'page',
		);
		$existing_page = get_page_by_title( $new_page['post_title'] );
		$options       = get_option( 'wp_travel_engine_settings', array() );

		if ( ! isset( $options['pages']['wp_travel_engine_payfast_notify_url'] ) ) {
			$post_id = wp_insert_post( $new_page );
			$arr['pages']['wp_travel_engine_payfast_notify_url'] = $post_id;
			$enquiry_page                                        = array_merge_recursive( $options, $arr );
			update_option( 'wp_travel_engine_settings', $enquiry_page );
		}
	}

	/**
	 * Plugin deactivation hook.
	 *
	 * @since  1.0.0
	 */
	public function deactivation() {
		// $this->includes();
	}

	/**
	 * Load localization.
	 *
	 * @since 1.0.0
	 */
	public function i18n() {
		load_plugin_textdomain( 'wte-payfast', false, $this->directory_path . '/languages/' );
	}

	/**
	 * Include file dependencies.
	 *
	 * @since 1.0.0
	 */
	public function includes() {

		require WP_TRAVEL_ENGINE_PAYFAST_BASE_PATH . '/class-wte-payfast-admin.php';
		require WP_TRAVEL_ENGINE_PAYFAST_BASE_PATH . '/inc/class-wte-payfast-new-process.php';
		require WP_TRAVEL_ENGINE_PAYFAST_BASE_PATH . '/updater/wte-payfast-updater.php';

	}

	/**
	 * Output error message and disable plugin if requirements are not met.
	 *
	 * This fires on admin_notices.
	 *
	 * @since 1.0.0
	 */
	public function maybe_disable_plugin() {

		if ( ! $this->meets_requirements() ) {

			// Display our error
			echo '<div id="message" class="error">';
			echo '<p>' . sprintf( __( '<strong>WP Travel Engine - PayFast Payment Gateway</strong> addon requires WP Travel Engine plugin <strong>v.4.0.0 or later</strong> and has been <a href="%s">deactivated</a>. Please install, activate, or update WP Travel Engine plugin and then reactivate this plugin.', 'wte-payfast' ), admin_url( 'plugins.php' ) ) . '</p>';
			echo '</div>';

			// Deactivate our plugin
			deactivate_plugins( $this->basename );
		}
	}

	/**
	 * Check if all plugin requirements are met.
	 *
	 * @since 1.0.0
	 *
	 * @return bool True if requirements are met, otherwise false.
	 */
	private function meets_requirements() {
		return ( class_exists( 'WP_Travel_Engine' ) && defined( 'WP_TRAVEL_ENGINE_VERSION' ) && version_compare( WP_TRAVEL_ENGINE_VERSION, '4.0.0', '>=' ) );
	}


}

/**
 * Returns the main instance of WTE_PAYFAST_PAYMENT.
 *
 * @since  1.0.0
 * @return WTE_PAYFAST_PAYMENT
 */
function wte_gateway_payfast() {

	if ( ! class_exists( 'WP_Travel_Engine' ) ) {
		return null;
	}

	return WTE_PAYFAST_PAYMENT::instance();
}

add_action( 'plugins_loaded', 'wtepayfast_load', 10 );
/**
 *
 * @since 2.1.0
 */
function wtepayfast_load() {
	if ( ! defined( 'WP_TRAVEL_ENGINE_VERSION' ) || version_compare( WP_TRAVEL_ENGINE_VERSION, WP_TRAVEL_ENGINE_PAYFAST_REQUIRES_AT_LEAST, '<' ) ) {
		add_action(
			'admin_notices',
			function() {
				echo wp_kses_post(
					sprintf(
						'<div class="error"><p>'
						// translators: 1. WTE Extension Name 2. Link to WTE Plugin.
						. sprintf( __( '%1$s requires the %2$s plugin to work. Please install and activate the latest <strong>%2$s</strong> plugin first.', 'wte-payfast' ), '<strong>WP Travel Engine - Trip Fixed Starting Dates Countdown</strong>', '<a href="https://wordpress.org/plugins/wp-travel-engine/" target="__blank">WP Travel Engine</a>' )
						. '</p></div>'
					)
				);
			}
		);
	} else {
		wte_gateway_payfast();
	}
}
