=== WP Travel Engine - PayFast Payment Gateway ===
Contributors: wptravelengine
Plugin link: https://wptravelengine.com/
Tags: tour-booking, tour-operator, travel, travel-booking, travel-agency, travel-engine
Requires at least: 4.4.0
Tested up to: 5.4
Requires PHP: 5.6
Stable tag: 2.1.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

PayFast Payment Gateway is an extension for WP Travel Engine that allows you to accept trip and tour payments via one of South Africa’s popular merchant service, PayFast.

== Description ==

Tour operators and travel agencies can enable the PayFast booking system for trip booking by setting up PayFast Account with key details – Merchant Key and Merchant ID.

PayFast Payment Gateway addon requires WP Travel Engine plugin v. 3.0.0 or later installed and activated in the site.

== Changelog ==

= 2.1.0 =
Released on: 5th August, 2021
* Compatible update for WP Travel Engine 5.0+
* Minor bug fixes

= 2.0.1 =

Released on: 24th September, 2020

Enhancements:
* Partial Payment payable support added from user dashboard.
* Assets optimization, and conditional loading.

Fixes:

* Minor bug fixes.

= 2.0.0 =

Released on: 11th June, 2020

Enhancements:

* Revamped backend UI.
* Assets minification, optimization, and conditional loading.

Fixes:

* Minor bug fixes.

== 1.0.4 ==

Released on: 21st January, 2020

Enhancements:

* Compatibility testing with WP Travel Engine 3.0.
* Shiny update added for future versions.
* Payments API updated.

Fixes:

* Minor Bug Fixes

== 1.0.3 ==

* Minor Issues fixing

== 1.0.0 ==

* Initial Release
