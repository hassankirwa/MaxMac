<?php
global $post;
$wp_travel_engine_postmeta_settings = get_post_meta( $post->ID, 'wp_travel_engine_booking_setting', true );
?>
<div class="trip-info-meta">
    <div>
    <label for="wp_travel_engine_booking_setting[place_order][payment][merchant_id]"><?php _e('Payment ID: ','wte-payfast');?></label>   
    <input type="text" id="wp_travel_engine_booking_setting[place_order][payment][merchant_id]" name="wp_travel_engine_booking_setting[place_order][payment][merchant_id]" value="<?php echo isset($wp_travel_engine_postmeta_settings['place_order']['payment']['merchant_id']) ? esc_attr($wp_travel_engine_postmeta_settings['place_order']['payment']['merchant_id']):''?>">
    </div>
	<div>
	<label for="wp_travel_engine_booking_setting[place_order][payment][pf_payment_id]"><?php _e('Payment ID: ','wte-payfast');?></label>	
	<input type="text" id="wp_travel_engine_booking_setting[place_order][payment][pf_payment_id]" name="wp_travel_engine_booking_setting[place_order][payment][pf_payment_id]" value="<?php echo isset($wp_travel_engine_postmeta_settings['place_order']['payment']['pf_payment_id']) ? esc_attr($wp_travel_engine_postmeta_settings['place_order']['payment']['pf_payment_id']):''?>">
	</div>
	<div>
	<label for="wp_travel_engine_booking_setting[place_order][payment][signature]"><?php _e('Signature: ','wte-payfast');?></label>	
	<input type="text" id="wp_travel_engine_booking_setting[place_order][payment][signature]" name="wp_travel_engine_booking_setting[place_order][payment][signature]" value="<?php echo isset($wp_travel_engine_postmeta_settings['place_order']['payment']['signature']) ? esc_attr($wp_travel_engine_postmeta_settings['place_order']['payment']['signature']):'';?>">
	</div>
	<div>
	<label for="wp_travel_engine_booking_setting[place_order][payment][payment_status]"><?php _e('Status: ','wte-payfast');?></label>	
	<input type="text" id="wp_travel_engine_booking_setting[place_order][payment][payment_status]" name="wp_travel_engine_booking_setting[place_order][payment][payment_status]" value="<?php echo isset($wp_travel_engine_postmeta_settings['place_order']['payment']['payment_status']) ? esc_attr($wp_travel_engine_postmeta_settings['place_order']['payment']['payment_status']):'';?>">
	</div>
	<div>
	<label for="wp_travel_engine_booking_setting[place_order][payment][amount_gross]"><?php _e('Amount Gross: ','wte-payfast');?><?php
    $code = 'USD';
    if( isset( $wp_travel_engine_settings['currency_code'] ) && $wp_travel_engine_settings['currency_code']!= '' )
    {
        $code = $wp_travel_engine_settings['currency_code'];
    } 
    $obj = new Wp_Travel_Engine_Functions();
    $currency = $obj->wp_travel_engine_currencies_symbol( $code );
    echo esc_attr($currency);
    ?></label>	
	<input type="text" id="wp_travel_engine_booking_setting[place_order][payment][amount_gross]" name="wp_travel_engine_booking_setting[place_order][payment][amount_gross]" value="<?php echo isset($wp_travel_engine_postmeta_settings['place_order']['payment']['amount_gross']) ? esc_attr($wp_travel_engine_postmeta_settings['place_order']['payment']['amount_gross']):'';?>">
	</div>

	<div>
	<label for="wp_travel_engine_booking_setting[place_order][payment][amount_net]"><?php _e('Amount Net: ','wte-payfast');?><?php
    $code = 'USD';
    if( isset( $wp_travel_engine_settings['currency_code'] ) && $wp_travel_engine_settings['currency_code']!= '' )
    {
        $code = $wp_travel_engine_settings['currency_code'];
    } 
    $obj = new Wp_Travel_Engine_Functions();
    $currency = $obj->wp_travel_engine_currencies_symbol( $code );
    echo esc_attr($currency);
    ?></label>	
	<input type="text" id="wp_travel_engine_booking_setting[place_order][payment][amount_net]" name="wp_travel_engine_booking_setting[place_order][payment][amount_net]" value="<?php echo isset($wp_travel_engine_postmeta_settings['place_order']['payment']['amount_net']) ? esc_attr($wp_travel_engine_postmeta_settings['place_order']['payment']['amount_net']):'';?>">
	</div>

	<div>
	<label for="wp_travel_engine_booking_setting[place_order][payment][amount_fee]"><?php _e('Amount Fee: ','wte-payfast');?><?php
    $code = 'USD';
    if( isset( $wp_travel_engine_settings['currency_code'] ) && $wp_travel_engine_settings['currency_code']!= '' )
    {
        $code = $wp_travel_engine_settings['currency_code'];
    } 
    $obj = new Wp_Travel_Engine_Functions();
    $currency = $obj->wp_travel_engine_currencies_symbol( $code );
    echo esc_attr($currency);
    ?></label>	
	<input type="text" id="wp_travel_engine_booking_setting[place_order][payment][amount_fee]" name="wp_travel_engine_booking_setting[place_order][payment][amount_fee]" value="<?php echo isset($wp_travel_engine_postmeta_settings['place_order']['payment']['amount_fee']) ? esc_attr($wp_travel_engine_postmeta_settings['place_order']['payment']['amount_fee']):'';?>">
	</div>
	
</div>