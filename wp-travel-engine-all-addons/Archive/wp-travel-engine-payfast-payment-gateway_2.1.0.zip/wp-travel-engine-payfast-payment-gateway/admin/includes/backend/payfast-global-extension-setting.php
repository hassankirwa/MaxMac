<?php 
$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', true );
$currency_code = wp_travel_engine_get_currency_code();
?>

<div class="wte-payfast-form settings">
	<?php if ( 'ZAR' !== $currency_code ) : ?>
		<div style="margin-bottom: 40px;" class="wpte-info-block">
			<b><?php _e("Note:","wte-payfast");?></b>
			<p><?php _e("Please choose South African rand (R) in Settings Tab ( Miscellaneous > Currency Settings > Payment Currency ) for this gateway.","wte-payfast");?></p>
		</div>
	<?php endif; ?>
	<div class="wpte-field wpte-text wpte-floated">
		<label class="wpte-field-label" for="wp_travel_engine_settings[payfast_merchant_key]"><?php _e('Merchant Key','wte-payfast');?></label>
		<input type="text" id="wp_travel_engine_settings[payfast_merchant_key]" name="wp_travel_engine_settings[payfast_merchant_key]" value="<?php echo isset($wp_travel_engine_settings['payfast_merchant_key']) ? esc_attr( $wp_travel_engine_settings['payfast_merchant_key'] ): '';?>">
		<span class="wpte-tooltip"><?php _e('Enter a valid Merchant key from PayFast account. All payments will go to this account.','wte-payfast');?></span>
	</div>

   	<div class="wpte-field wpte-text wpte-floated">
		<label class="wpte-field-label" for="wp_travel_engine_settings[payfast_id]"><?php _e('Merchant ID','wte-payfast');?></label>
		<input type="text" id="wp_travel_engine_settings[payfast_id]" name="wp_travel_engine_settings[payfast_id]" value="<?php echo isset($wp_travel_engine_settings['payfast_id']) ? esc_attr( $wp_travel_engine_settings['payfast_id'] ): '';?>">
		<span class="wpte-tooltip"><?php _e('Enter a valid Merchant ID from PayFast account.','wte-payfast');?></span>
	</div>
</div>