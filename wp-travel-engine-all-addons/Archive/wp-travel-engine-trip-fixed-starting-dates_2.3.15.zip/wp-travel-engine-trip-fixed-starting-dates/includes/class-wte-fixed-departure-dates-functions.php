<?php
/**
 * Basic functions for the plugin.
 *
 * Maintain a list of functions that are used in the plugin for basic purposes
 *
 * @package    WTE_Fixed_Starting_Dates
 * @subpackage WTE_Fixed_Starting_Dates/includes
 * @author
 */
/**
 * Recurring options.
 */
use RRule\RRule;
use RRule\RSet;

class WTE_Fixed_Starting_Dates_Functions {

	/**
	 * Checks if cutoff is enabled.
	 *
	 * @since 2.3.14
	 * @return array
	 */
	public static function get_cutoff_duration( $trip_id ) {
		$trip_settings     = get_post_meta( $trip_id, 'wp_travel_engine_setting', true );
		$cutoff_enabled    = ! empty( $trip_settings['trip_cutoff_enable'] ) && 'true' === $trip_settings['trip_cutoff_enable'];
		$trip_cut_off_time = isset( $trip_settings['trip_cut_off_time'] ) ? $trip_settings['trip_cut_off_time'] : 0;
		if ( ! $cutoff_enabled ) {
			$trip_cut_off_time = 0;
		}

		$trip_cut_off_time = is_numeric( $trip_cut_off_time ) ? $trip_cut_off_time : 0;

		return array( $trip_cut_off_time, isset( $trip_settings['trip_cut_off_unit'] ) && in_array( $trip_settings['trip_cut_off_unit'], array( 'days', 'hours' ), true ) ? $trip_settings['trip_cut_off_unit'] : 'days' );
	}

	/**
	 * Gets Trip Duration.
	 *
	 * @since 2.3.14
	 * @return array
	 */
	public static function get_trip_duration( $trip_id ) {
		$trip_settings = get_post_meta( $trip_id, 'wp_travel_engine_setting', true );
		$duration      = isset( $trip_settings['trip_duration'] ) && is_numeric( $trip_settings['trip_duration'] ) ? absint( $trip_settings['trip_duration'] - 1 ) : 0;
		$duration_unit = isset( $trip_settings['trip_duration_unit'] ) && in_array( $trip_settings['trip_duration_unit'], array( 'days', 'hours' ), true ) ? $trip_settings['trip_duration_unit'] : 'days';

		return array( $duration, $duration_unit );
	}

	/**
	 * Returns next trip date after calculating offset.
	 *
	 * @since 2.3.14
	 * @param integer $trip_id
	 * @return string Formated Date (Y-m-d).
	 */
	public static function get_trip_offset_date( $trip_id ) {

		list( $cutoff_duration, $cutoff_duration_unit ) = self::get_cutoff_duration( $trip_id );

		$global_settings = get_option( 'wp_travel_engine_settings', array() );

		if ( $cutoff_duration <= 0 ) {
			$cutoff_duration_unit = 'days';
			if ( isset( $global_settings['hide_trips_without_dates_beyond'] ) && 'yes' === $global_settings['hide_trips_without_dates_beyond'] ) {
				$number_of_days = isset( $global_settings['number_of_days_to_hide_trips'] ) ? $global_settings['number_of_days_to_hide_trips'] : '';
				if ( is_numeric( $number_of_days ) ) {
					$cutoff_duration = $number_of_days;
				}
			}
		}

		return apply_filters( 'get_trip_offset_date', date( 'Y-m-d', strtotime( "now + {$cutoff_duration} {$cutoff_duration_unit}" ) ) );
	}

	/**
	 * Undocumented function
	 *
	 * @since 2.3.13
	 * @return \RRule\RSet
	 */
	public static function get_package_dates_rules( $trip_id ) {
		$rrule_args = self::get_package_dates_rrules_args( $trip_id );

		$rset = new RSet();
		if ( is_string( $rrule_args ) ) {
			$rset->addDate( $rrule_args );
			return $rset;
		}

		foreach ( $rrule_args as $rrule_arg ) {
			foreach ( $rrule_arg as $rrule ) {
				try {
					if ( is_string( $rrule['rrule'] ) ) {
						$rset->addDate( $rrule['rrule'] );
						continue;
					}
					$rset->addRRule( $rrule['rrule'] );
				} catch (\Exception $e) {

				}
			}
		}

		return $rset;

	}

	/**
	 * Get packages dates.
	 *
	 * @since 2.3.14
	 * @param int|object $trip
	 * @return object
	 */
	public static function get_package_dates_rrules_args( $trip ) {
		$trip_id = 0;

		if ( is_numeric( $trip ) ) {
			$trip_id = $trip;
		} else if ( is_object( $trip ) ) {
			$trip_id = $trip->ID;
		}

		global $wpdb;

		$package_ids = get_post_meta( $trip_id, 'packages_ids', true );

		if ( ! is_array( $package_ids ) || empty( $package_ids ) ) {
			return array();
		}

		$results = $wpdb->get_results( "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE post_id IN (" . implode( ',', $package_ids ) . ") AND  meta_key = 'package-dates' AND meta_value != 'a:0:{}' " );

		if ( ! isset( $results[0] ) ) {
			return self::get_trip_offset_date( $trip_id );
		}

		$_rrule_args = array();
		foreach ( $results as $result ) {
			$package_dates = maybe_unserialize( $result->meta_value );

			// update_post_meta( $result->post_id, 'trip_ID', $trip->ID );

			if ( ! is_array( $package_dates ) ) {
				continue;
			}
			foreach ( $package_dates as $date_key => $date_args ) {
				$date_args = (object) $date_args;
				if ( isset( $date_args->dtstart ) && empty( trim( $date_args->dtstart ) ) ) {
					continue;
				}

				try {
					$date_start = new DateTime( $date_args->dtstart );
					if ( isset( $date_args->is_recurring ) && 1 === (int) $date_args->is_recurring ) {
						$freq    = isset( $date_args->rrule['r_frequency'] ) ? $date_args->rrule['r_frequency'] : 'DAILY';
						$count   = isset( $date_args->rrule['r_count'] ) ? (int) $date_args->rrule['r_count'] : 10;
						$dtstart = $date_args->dtstart;

						$rrule_args = array(
							'FREQ'    => $freq,
							'DTSTART' => $dtstart,
							'COUNT'   => $count,
						);

						if ( ! empty( $date_args->rrule['r_until'] ) ) {
							unset( $rrule_args['COUNT'] );
							$rrule_args['UNTIL'] = $date_args->rrule['r_until'];
						}

						if ( 'MONTHLY' === $freq && ! empty( $date_args->rrule['r_months'] ) ) {
							$rrule_args['BYMONTH'] = array_map(
								function ($month) {
									return (int) $month;
								},
								$date_args->rrule['r_months']
							);
						}

						if ( 'WEEKLY' === $freq && ! empty( $date_args->rrule['r_weekdays'] ) ) {
							$rrule_args['BYDAY'] = array_values( $date_args->rrule['r_weekdays'] );
						}

						$_rrule_args[ $result->post_id ][] = array(
							'rrule' => $rrule_args,
							'args'  => $date_args
						);
						// $_rrule_args[ $result->post_id ]['args']  = $date_args;
						// $rset->addRRule( $rrule_args );
					} else {
						$_rrule_args[ $result->post_id ][] = array(
							'rrule' => $date_args->dtstart,
							'args'  => $date_args,
						);
					}
				} catch (\Exception $e) {
					continue;
				}
			}
		}

		return $_rrule_args;

	}

	/**
	 * Set min and max trip date.
	 */
	private static function set_trip_minmax_dates( $trip ) {

		$rset = self::get_package_dates_rules( $trip );

		$today            = new \DateTime();
		$available_months = array();
		foreach ( $rset as $occurrence ) {
			if ( $occurrence < $today ) {
				continue;
			}
			$key                      = $occurrence->format( 'ym' );
			$available_months[ $key ] = $key;
		}
		update_post_meta( $trip->ID, 'trip_available_months', implode( ',', $available_months ) );
	}

	public static function set_min_and_max_date() {
		$already_set = get_option( '_wte_trips_available_months_set', false );
		$is_migrated = get_option( 'wte_migrated_to_multiple_pricing', false ) === 'done';

		if ( ! $is_migrated || $already_set ) {
			return;
		}

		global $wpdb;

		$where = $wpdb->prepare( "{$wpdb->posts}.post_type = %s", WP_TRAVEL_ENGINE_POST_TYPE );
		$where .= " AND {$wpdb->posts}.post_status IN ( 'publish','draft' )";

		$trip_ids = $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE {$where}" );

		if ( $trip_ids ) {
			global $wp_query;
			$wp_query->in_the_lopp = true;
			while ( $next_trips = array_splice( $trip_ids, 0, 20 ) ) { // phpcs:ignore WordPress.CodeAnalysis.AssignmentInCondition.FoundInWhileCondition
				$where = 'WHERE ID IN (' . join( ',', $next_trips ) . ')';
				$trips = $wpdb->get_results( "SELECT * FROM {$wpdb->posts} $where" ); // phpcs:ignore
				foreach ( $trips as $trip ) {
					self::set_trip_minmax_dates( $trip );
				}
			}
		}
		update_option( '_wte_trips_available_months_set', 'done' );
	}

	public static function generator( $year_months ) {
		for ( $i = 0; $i < count( array_keys( $year_months ) ); $i++ ) {
			if ( empty( $year_months[ $i ] ) ) {
				continue;
			}
			$yearmonth = '20' . $year_months[ $i ];
			$year      = substr( $yearmonth, 0, 4 );
			$month     = substr( $yearmonth, 4 );
			$now       = new \DateTime();
			try {
				$now->setDate( (int) $year, (int) $month, date( 't', mktime( 0, 0, 0, (int) $month, 1, (int) $year ) ) );
				yield $i => $now;
			} catch (\Exception $e) {
				yield $i => $now;
			}
		}
	}

	/**
	 * Cache Indexed By trip dates.
	 *
	 * @since @since 2.3.13
	 * @return void
	 */
	public static function cache_indexed_trip_by_dates() {
		$_trip_ids = self::get_trips_by_next_date();
		update_option( 'wptravelengine_indexed_trips_by_dates', wp_json_encode( $_trip_ids ) );
	}

	/**
	 * Get Indexed Trips By dates.
	 *
	 * @since 2.3.14
	 * @return boolean|array
	 */
	public static function get_indexed_trip_by_dates() {
		$trips_by_dates = get_option( 'wptravelengine_indexed_trips_by_dates', false );
		// $trips_by_dates = false; //get_option( 'wptravelengine_indexed_trips_by_dates', false );

		$post__in = array();
		if ( false === $trips_by_dates ) {
			self::cache_indexed_trip_by_dates();
		}
		$trips_by_dates = get_option( 'wptravelengine_indexed_trips_by_dates', '[]' );
		$post__in       = json_decode( $trips_by_dates, true );
		return $post__in;
	}

	public static function get_trips_available_year_months() {
		global $wpdb;

		$results     = $wpdb->get_results( "SELECT GROUP_CONCAT( meta_value ) as 'year_months' FROM {$wpdb->postmeta} WHERE meta_key = 'trip_available_months' ORDER BY meta_value ASC" );
		$year_months = array();
		if ( isset( $results[0]->year_months ) ) {
			$year_months = explode( ',', $results[0]->year_months );
			$year_months = array_flip( $year_months );
			ksort( $year_months, SORT_NUMERIC );
			$year_months = array_keys( $year_months );
		}
		return self::generator( $year_months );
	}

	public static function to_utc( string $date ) {
		$utc = new \DateTime( $date, new \DateTimeZone( 'UTC' ) );
		$utc->setTime( 0, 0, 0 );
		return $utc;
	}

	public static function generate_fsds( $pid, $rrule_filter = array() ) {

		// For single trip.
		$trip_settings    = get_post_meta( $pid, 'wp_travel_engine_setting', true );
		$fsd_booked_seats = WPTravelEngine\Packages\get_booked_seats_number_by_date( $pid );
		$duration         = isset( $trip_settings['trip_duration'] ) && ! empty( $trip_settings['trip_duration'] ) ? absint( $trip_settings['trip_duration'] - 1 ) : false;
		$duration_unit    = isset( $trip_settings['trip_duration_unit'] ) ? $trip_settings['trip_duration_unit'] : 'days';

		$dur_days = isset( $duration ) && 'days' === $duration_unit ? $duration : false;
		$fsds     = array();
		$fsds     = get_post_meta( $pid, 'WTE_Fixed_Starting_Dates_setting', true );

		$dates_by_package = self::get_package_dates_rrules_args( $pid );

		$fsd_dates = array();
		if ( is_string( $dates_by_package ) ) {
			return $fsd_dates;
		}

		list( $duration, $duration_unit )               = self::get_trip_duration( $pid );
		list( $cutoff_duration, $cutoff_duration_unit ) = self::get_cutoff_duration( $pid );

		foreach ( $dates_by_package as $package_id => $rrules ) {
			$package_lowest_cost = WPTravelEngine\Packages\get_trip_lowest_price_by_package_id( $package_id );

			foreach ( $rrules as $rrule_arg ) {
				$rset = new RSet();

				if ( ! isset( $rrule_arg['args'], $rrule_arg['rrule'] ) ) {
					continue;
				}

				$date_settings = (object) $rrule_arg['args'];
				$rrule         = $rrule_arg['rrule'];

				if ( is_string( $rrule ) ) {
					$rset->addDate( $rrule );
				} else {
					$rset->addRRule( $rrule );
				}

				if ( ! empty( $rrule_filter['year'] ) && ! empty( $rrule_filter['month'] ) ) {
					$occurrence_from = date( 'Y-m-d', strtotime( $rrule_filter['year'] . '-' . $rrule_filter['month'] . '-01' ) );
					$occurence_to    = date( 'Y-m-d', strtotime( 'last day of ' . $rrule_filter['year'] . '-' . $rrule_filter['month'] . '-01' ) );
				} else if ( ! empty( $rrule_filter['year'] ) ) {
					$occurrence_from = date( 'Y-m-d', strtotime( $rrule_filter['year'] . '-01-01' ) );
					$occurence_to    = date( 'Y-m-d', strtotime( $rrule_filter['year'] . '-12-31' ) );
				} else if ( ! empty( $rrule_filter['month'] ) ) {
					$occurrence_from = date( 'Y-m-d', strtotime( date( 'Y' ) . '-' . $rrule_filter['month'] . '-01' ) );
					$occurence_to    = date( 'Y-m-d', strtotime( 'last day of ' . date( 'Y' ) . '-' . $rrule_filter['month'] . '-01' ) );
				} else {
					$occurrence_from = date( 'Y-m-d', strtotime( "now + {$cutoff_duration} {$cutoff_duration_unit}" ) );
					$occurence_to    = date( 'Y-m-d', strtotime( 'now + 2 years' ) );
				}

				$least_trip_starting_date = date( 'Y-m-d', strtotime( "now + {$cutoff_duration} {$cutoff_duration_unit}" ) );
				if ( strtotime( $occurrence_from ) < strtotime( $least_trip_starting_date ) ) {
					$occurrence_from = $least_trip_starting_date;
				}
				$occurrences = $rset->getOccurrencesBetween( $occurrence_from, $occurence_to );

				if ( ! isset( $occurrences[0] ) ) {
					continue;
				}

				$availability = isset( $date_settings->availability_label ) ? $date_settings->availability_label : '';
				$seats_left   = isset( $date_settings->seats ) && '' !== $date_settings->seats ? absint( $date_settings->seats ) : '';

				foreach ( $occurrences as $occurrence ) {
					$booked                                  = isset( $fsd_booked_seats[ $occurrence->getTimeStamp()]['booked'] ) ? $fsd_booked_seats[ $occurrence->getTimeStamp()]['booked'] : 0;
					$fsd_dates[ $occurrence->getTimestamp()] = array(
						'trip_id'      => $pid,
						'package_id'   => $package_id,
						'content_id'   => $occurrence->getTimestamp(),
						'start_date'   => $occurrence->format( 'Y-m-d' ),
						'end_date'     => date( 'Y-m-d', strtotime( $occurrence->format( 'Y-m-d' ) . " + {$duration} {$duration_unit}" ) ),
						'availability' => $availability,
						'seats_left'   => '' === $seats_left ? $seats_left : absint( $seats_left ) - absint( $booked ),
						// 'fsd_cost'     => ! empty( $fsds['departure_dates']['cost'][ $key ] ) && ! $enable_multi_pricing ? apply_filters( 'wte_fsd_price', $fsds['departure_dates']['cost'][ $key ], $pid ) : wp_travel_engine_get_actual_trip_price( $pid ),
						'fsd_cost'     => $package_lowest_cost,
					);
				}
			}
		}

		ksort( $fsd_dates );
		return $fsd_dates;

	}

	public static function get_fsds_by_trip_id( $trip_id ) {
		return self::generate_fsds( $trip_id );
	}

	/**
	 * Should hide trips without dates.
	 *
	 * @since 2.3.14
	 * @return boolean Should Hide?
	 */
	public static function hide_trip_without_dates() {
		$global_settings = get_option( 'wp_travel_engine_settings', array() );
		return isset( $global_settings['hide_trips_without_dates'] ) && 'yes' === $global_settings['hide_trips_without_dates'];
	}

	/**
	 * Gets Sorted Trips by next date.
	 *
	 * @since 2.3.14
	 * @return array Array of Trip IDs sorted by date.
	 */
	public static function get_trips_by_next_date() {

		remove_action( 'pre_get_posts', array( 'WTE_Fixed_Starting_Dates', 'archive_pre_get_posts' ), 15 );

		$query = new \WP_Query( array(
			'post_type'      => WP_TRAVEL_ENGINE_POST_TYPE,
			'posts_per_page' => -1,
			'post_status'    => 'publish',
			'fields'         => 'ids'
		) );

		$now       = new \DateTime();
		$_trip_ids = array();

		if ( $query->have_posts() ) {

			while ( $query->have_posts() ) {
				$query->the_post();
				$trip_id   = get_the_ID();
				$date_rule = self::get_package_dates_rules( $trip_id );

				if ( is_string( self::get_package_dates_rrules_args( $trip_id ) ) ) {
					$_trip_ids[ $trip_id ] = 'no_dates';
					continue;
				}

				$occurrences = $date_rule->getOccurrencesAfter( self::get_trip_offset_date( $trip_id ), true, 1 );

				if ( isset( $occurrences[0] ) ) {
					$_trip_ids[ $trip_id ] = $occurrences[0]->getTimestamp();
				} else {
					$_trip_ids[ $trip_id ] = 'expired';
				}
			}
			wp_reset_postdata();
		}

		add_action( 'pre_get_posts', array( 'WTE_Fixed_Starting_Dates', 'archive_pre_get_posts' ), 15 );

		return $_trip_ids;
	}

	public static function availability() {
		$options = array(
			'guaranteed' => __( 'Guaranteed', 'wte-fixed-departure-dates' ),
			'available'  => __( 'Available', 'wte-fixed-departure-dates' ),
			'limited'    => __( 'Limited', 'wte-fixed-departure-dates' ),
		);

		$options = apply_filters( 'wte_availability_options', $options );

		return $options;
	}

	/**
	 * Get difficulty Label
	 */
	public static function get_availability_label( $availability ) {
		$options = self::availability();

		$availability = ( $availability ) ? $options[ $availability ] : $availability;

		return $availability;
	}

	/**
	 * Get settings.
	 *
	 * @since 1.2.4
	 * @static
	 * @access public
	 *
	 * @param int $post_ID Trip ID.
	 * @return array Settings.
	 */
	public static function get_settings( $post_ID ) {
		$WTE_Fixed_Starting_Dates_setting = get_post_meta( $post_ID, 'WTE_Fixed_Starting_Dates_setting', true );

		if ( isset( $WTE_Fixed_Starting_Dates_setting['departure_dates']['cost'] ) ) {
			$costs                                                       = $WTE_Fixed_Starting_Dates_setting['departure_dates']['cost'];
			$costs                                                       = apply_filters( 'wte_fsd_price', $costs, $post_ID );
			$WTE_Fixed_Starting_Dates_setting['departure_dates']['cost'] = $costs;
		}

		return $WTE_Fixed_Starting_Dates_setting;
	}

	/**
	 * Gets Recurring Date by Args.
	 *
	 * @return array Recurring Dates.
	 */
	public function get_recurring_dates_by_rrule( array $args, $set = false ) {
		if ( $set ) {
			$rset = new RSet();
			foreach ( $args as $arg ) {
				$rset->addRRule( $arg );
			}
			return $rset;
		}
		return new RRule( $args );
	}

	/**
	 * Get formated FSD dates with recurring support
	 *
	 * @param [type] $post_id
	 * @return void
	 */
	public function get_formated_fsd_dates( $post_id = null, $filters = array() ) {
		$fsd_formated_array = array();
		if ( ! $post_id || 'trip' !== get_post( $post_id )->post_type ) {
			return $fsd_formated_array;
		}

		$trip_settings = get_post_meta( $post_id, 'wp_travel_engine_setting', true );

		$duration      = isset( $trip_settings['trip_duration'] ) && ! empty( $trip_settings['trip_duration'] ) ? absint( $trip_settings['trip_duration'] - 1 ) : false;
		$duration_unit = isset( $trip_settings['trip_duration_unit'] ) ? $trip_settings['trip_duration_unit'] : 'days';

		$dur_days = isset( $duration ) && 'days' == $duration_unit ? $duration : false;

		$WTE_Fixed_Starting_Dates_setting = get_post_meta( $post_id, 'WTE_Fixed_Starting_Dates_setting', true );

		$sortable_settings = get_post_meta( $post_id, 'list_serialized', true );
		if ( ! is_array( $sortable_settings ) ) {
			$sortable_settings = json_decode( $sortable_settings );
		}

		if ( isset( $WTE_Fixed_Starting_Dates_setting ) && $WTE_Fixed_Starting_Dates_setting != '' && isset( $sortable_settings ) && sizeof( $sortable_settings ) > 0 ) {

			$today    = strtotime( date( 'Y-m-d' ) ) * 1000;
			$fsd_indx = 0;

			// Cutoff Vars.
			$cutoff_enabled    = ! empty( $trip_settings['trip_cutoff_enable'] ) && 'true' === $trip_settings['trip_cutoff_enable'];
			$trip_cut_off_time = isset( $trip_settings['trip_cut_off_time'] ) && ! empty( $trip_settings['trip_cut_off_time'] ) ? $trip_settings['trip_cut_off_time'] : 0;
			$cut_off_unit      = isset( $trip_settings['trip_cut_off_unit'] ) ? $trip_settings['trip_cut_off_unit'] : 'days';

			foreach ( $sortable_settings as $content ) {
				if ( isset( $WTE_Fixed_Starting_Dates_setting['departure_dates']['edate'][ $content->id ] ) && $WTE_Fixed_Starting_Dates_setting['departure_dates']['edate'][ $content->id ] != '' ) {

					$recurring_enable = isset( $WTE_Fixed_Starting_Dates_setting['departure_dates'][ $content->id ]['recurring']['enable'] ) ? true : false;

					if ( $today <= strtotime( $WTE_Fixed_Starting_Dates_setting['departure_dates']['edate'][ $content->id ] ) * 1000 || $recurring_enable ) {

						if ( isset( $WTE_Fixed_Starting_Dates_setting['departure_dates']['cost'][ $content->id ] ) && $WTE_Fixed_Starting_Dates_setting['departure_dates']['cost'][ $content->id ] != '' ) {
							$fsd_cost = $WTE_Fixed_Starting_Dates_setting['departure_dates']['cost'][ $content->id ];
						} else {
							$fsd_cost = wp_travel_engine_get_actual_trip_price( $post_id );
						}

						// $fsd_cost = apply_filters( 'wte_fsd_price', $fsd_cost, $post_id );

						$start_date = isset( $WTE_Fixed_Starting_Dates_setting['departure_dates']['sdate'][ $content->id ] ) ? $WTE_Fixed_Starting_Dates_setting['departure_dates']['sdate'][ $content->id ] : '';

						$end_date = isset( $WTE_Fixed_Starting_Dates_setting['departure_dates']['edate'][ $content->id ] ) ? $WTE_Fixed_Starting_Dates_setting['departure_dates']['edate'][ $content->id ] : '';

						$availability = isset( $WTE_Fixed_Starting_Dates_setting['departure_dates']['availability_type'][ $content->id ] ) ? $WTE_Fixed_Starting_Dates_setting['departure_dates']['availability_type'][ $content->id ] : 'guaranteed';

						$seats_left = isset( $WTE_Fixed_Starting_Dates_setting['departure_dates']['seats_available'][ $content->id ] ) ? $WTE_Fixed_Starting_Dates_setting['departure_dates']['seats_available'][ $content->id ] : '';

						$trip_booked_seats = get_post_meta( $post_id, 'wte_fsd_booked_seats', true );

						if ( $recurring_enable ) {
							$recursion_type  = isset( $WTE_Fixed_Starting_Dates_setting['departure_dates'][ $content->id ]['recurring']['type'] ) ? $WTE_Fixed_Starting_Dates_setting['departure_dates'][ $content->id ]['recurring']['type'] : 'DAILY';
							$recurring_limit = isset( $WTE_Fixed_Starting_Dates_setting['departure_dates'][ $content->id ]['recurring']['limit'] ) ? $WTE_Fixed_Starting_Dates_setting['departure_dates'][ $content->id ]['recurring']['limit'] : 10;
							$months_recur    = isset( $WTE_Fixed_Starting_Dates_setting['departure_dates'][ $content->id ]['recurring']['months'] ) && ! empty( $WTE_Fixed_Starting_Dates_setting['departure_dates'][ $content->id ]['recurring']['months'] ) ? $WTE_Fixed_Starting_Dates_setting['departure_dates'][ $content->id ]['recurring']['months'] : array( '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12' );

							$weekdays_recur = isset( $WTE_Fixed_Starting_Dates_setting['departure_dates'][ $content->id ]['recurring']['week_days'] ) && ! empty( $WTE_Fixed_Starting_Dates_setting['departure_dates'][ $content->id ]['recurring']['week_days'] ) ? $WTE_Fixed_Starting_Dates_setting['departure_dates'][ $content->id ]['recurring']['week_days'] : array( 'MO', 'TU', 'WE', 'TH', 'FR', 'SA', 'SU' );

							$recurr_args = array(
								'FREQ'     => $recursion_type,
								'INTERVAL' => 1,
								'DTSTART'  => $start_date,
								'COUNT'    => $recurring_limit,
							);

							if ( 'MONTHLY' === $recursion_type ) {
								$recurr_args['BYMONTH'] = array_values( $months_recur );
							}

							if ( 'WEEKLY' === $recursion_type ) {
								$recurr_args['BYDAY'] = array_values( $weekdays_recur );
							}

							$rrule = $this->get_recurring_dates_by_rrule( $recurr_args );

							foreach ( $rrule as $occurrence ) {
								$start_recur = $occurrence->format( 'Y-m-d' );
								if ( isset( $filters['year'] ) && $filters['year'] !== $occurrence->format( 'Y' ) ) {
									continue;
								}
								if ( isset( $filters['month'] ) && $filters['month'] !== $occurrence->format( 'm' ) ) {
									continue;
								}
								if ( $dur_days ) {
									$date = new DateTime( $start_recur );
									$date->add( new DateInterval( 'P' . $dur_days . 'D' ) );
									$end_recur = $date->format( 'Y-m-d' );
								} else {
									$end_recur = date_i18n( 'Y-m-d', strtotime( $start_recur ) );
								}

								if ( $today >= strtotime( $start_recur ) * 1000 ) {
									continue;
								}

								if ( $cutoff_enabled ) {
									$departure_date = strtotime( $start_recur );
									$departure_date = ! $departure_date ? $today : $departure_date + 24 * 60 * 60;

									$cut_off_time = $trip_cut_off_time * 60 * 60;
									$cut_off_time = 'days' === $cut_off_unit ? $cut_off_time * 24 : $cut_off_time;

									$valid_departure_date = strtotime( 'now' ) + $cut_off_time;

									if ( $valid_departure_date > $departure_date ) {
										continue;
									}
								}

								$date_key = strtotime( $start_recur );

								$booked = isset( $trip_booked_seats[ $date_key ]['booked'] ) ? $trip_booked_seats[ $date_key ]['booked'] : 0;

								$fsd_formated_array[] = array(
									'trip_id'      => $post_id,
									'content_id'   => strtotime( $start_recur ),
									'start_date'   => $start_recur,
									'end_date'     => $end_recur,
									'availability' => $availability,
									'seats_left'   => '' === trim( $seats_left ) ? $seats_left : absint( $seats_left ) - absint( $booked ),
									'fsd_cost'     => $fsd_cost,
								);

							}
						} else { // Non recurring.
							$date_key = strtotime( $start_date );
							// Filter Date.
							/**
							 * @since 2.1.0
							 */
							if ( $cutoff_enabled ) {

								$departure_date = $date_key;
								$departure_date = ! $departure_date ? $today : $departure_date + 24 * 60 * 60;

								$cut_off_time = $trip_cut_off_time * 60 * 60;
								$cut_off_time = 'days' === $cut_off_unit ? $cut_off_time * 24 : $cut_off_time;

								$valid_departure_date = strtotime( 'now' ) + $cut_off_time;

								if ( $valid_departure_date > $departure_date ) {
									continue;
								}
							}
							// Filter Date Ends.

							$booked               = isset( $trip_booked_seats[ $date_key ]['booked'] ) ? $trip_booked_seats[ $date_key ]['booked'] : 0;
							$fsd_formated_array[] = array(
								'trip_id'      => $post_id,
								'content_id'   => strtotime( $start_date ),
								'start_date'   => $start_date,
								'end_date'     => $end_date,
								'availability' => $availability,
								'seats_left'   => '' === trim( $seats_left ) ? $seats_left : absint( $seats_left ) - absint( $booked ),
								'fsd_cost'     => $fsd_cost,
							);
						}
					}
				}
				$fsd_indx++;
			}
		}

		array_multisort( array_map( 'strtotime', array_column( $fsd_formated_array, 'start_date' ) ), SORT_ASC, $fsd_formated_array );

		return $fsd_formated_array;

	}
}
new WTE_Fixed_Starting_Dates_Functions();
