<?php
/**
 * Global Settings
 */
$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', array() );

$dates_layout      = isset( $wp_travel_engine_settings['fsd_dates_layout'] ) && '' != $wp_travel_engine_settings['fsd_dates_layout'] ? $wp_travel_engine_settings['fsd_dates_layout'] : 'dates_list';
$hide_dates_layout = isset( $wp_travel_engine_settings['departure']['hide_availability_section'] ) && 'yes' === $wp_travel_engine_settings['departure']['hide_availability_section'];
/**
 * @since 2.3.12
 */
$hide_availability_column = isset( $wp_travel_engine_settings['departure']['hide_availability_column'] ) && 'yes' === $wp_travel_engine_settings['departure']['hide_availability_column'];
$hide_price_column        = isset( $wp_travel_engine_settings['departure']['hide_price_column'] ) && 'yes' === $wp_travel_engine_settings['departure']['hide_price_column'];
$hide_space_left_column   = isset( $wp_travel_engine_settings['departure']['hide_space_left_column'] ) && 'yes' === $wp_travel_engine_settings['departure']['hide_space_left_column'];
?>
<?php $page_shortcode = '[WTE_TRIPS_FIXED_STARTING_DATES]'; ?>
<div class="wpte-info-block" style="margin-bottom: 40px;">
    <p>
        <?php
		echo sprintf( __( 'Need to list all the Fixed Starting Dates? You can use this shortcode <b>%1$s</b> on a page/post/tab to display Fixed Starting Dates from all of your trips sorted by Months.', 'wte-fixed-departure-dates' ), $page_shortcode );
		?>
    </p>
</div>

<div class="wpte-field wpte-checkbox advance-checkbox">
    <label class="wpte-field-label" for="wp_travel_engine_settings[departure][section]"><?php _e( 'Show Fixed Trip Starts Dates section', 'wte-fixed-departure-dates' ); ?></label>
    <div class="wpte-checkbox-wrap">
        <input type="checkbox" id="wp_travel_engine_settings[departure][section]" name="wp_travel_engine_settings[departure][section]" value="1"
            <?php
		if ( isset( $wp_travel_engine_settings['departure']['section'] ) && $wp_travel_engine_settings['departure']['section'] != '' ) {
			echo 'checked';}
		?>>
        <label for="wp_travel_engine_settings[departure][section]"></label>
    </div>
    <span class="wpte-tooltip"><?php esc_html_e( 'Check this if you want to enable fixed trip starting dates section between featured image/slider and trip content sections.', 'wte-fixed-departure-dates' ); ?></span>
</div>

<div class="wpte-field wpte-text wpte-floated">
    <label for="wp_travel_engine_settings[departure][section_title]" class="wpte-field-label"><?php _e( 'Fixed Starting Dates Section Title', 'wte-fixed-departure-dates' ); ?></label>
    <input type="text" id="wp_travel_engine_settings[departure][section_title]" name="wp_travel_engine_settings[departure][section_title]" value="<?php echo isset( $wp_travel_engine_settings['departure']['section_title'] ) ? esc_attr( $wp_travel_engine_settings['departure']['section_title'] ) : ''; ?>">
    <span class="wpte-tooltip"><?php esc_html_e( 'Title for Fixed Starting Dates of the trip.', 'wte-fixed-departure-dates' ); ?></span>
</div>

<div class="wpte-field wpte-checkbox advance-checkbox">
    <label class="wpte-field-label" for="wp_travel_engine_settings_hide_availability_section_show"><?php _e( 'Hide dates layout from trip cards', 'wte-fixed-departure-dates' ); ?></label>
    <div class="wpte-checkbox-wrap">
        <input type="checkbox" id="wp_travel_engine_settings_hide_availability_section_hide" name="wp_travel_engine_settings[departure][hide_availability_section]" value="" checked />
        <input type="checkbox" id="wp_travel_engine_settings_hide_availability_section_show" name="wp_travel_engine_settings[departure][hide_availability_section]" value="yes" <?php checked( true, $hide_dates_layout ); ?> />
        <label for="wp_travel_engine_settings_hide_availability_section_show"></label>
    </div>
    <span class="wpte-tooltip"><?php esc_html_e( 'Check this if you want to hide the availability section from the trip cards in homepage and archive pages.', 'wte-fixed-departure-dates' ); ?></span>
</div>

<?php
/**
 * Edit section for Fixed Starting Dates column.
 *
 * @since 2.3.12
 */
?>
<div class="wpte-field">
    <div class="wpte-field wpte-checkbox advance-checkbox">
        <label for="wp_travel_engine_settings_hide_availability_column_show" class="wpte-field-label"><?php esc_html_e( 'Hide FSD Column: Availability', 'wte-fixed-departure-dates' ); ?></label>
        <div class="wpte-checkbox-wrap">
            <input type="checkbox" name="wp_travel_engine_settings[departure][hide_availability_column]" id="wp_travel_engine_settings_hide_availability_column_hide" value="" checked />
            <input type="checkbox" name="wp_travel_engine_settings[departure][hide_availability_column]" id="wp_travel_engine_settings_hide_availability_column_show" value="yes" <?php checked( true, $hide_availability_column ); ?> />
            <label for="wp_travel_engine_settings_hide_availability_column_show"></label>
        </div>
        <span class="wpte-tooltip"><?php esc_html_e( 'Check this if you want to hide the availability column from the Fixed Starting Dates.', 'wte-fixed-departure-dates' ); ?></span>
    </div>
</div>
<div class="wpte-field">
    <div class="wpte-field wpte-checkbox advance-checkbox">
        <label for="wp_travel_engine_settings_hide_price_column_show" class="wpte-field-label"><?php esc_html_e( 'Hide FSD Column: Price', 'wte-fixed-departure-dates' ); ?></label>
        <div class="wpte-checkbox-wrap">
            <input type="checkbox" name="wp_travel_engine_settings[departure][hide_price_column]" id="wp_travel_engine_settings_hide_price_column_hide" value="" checked />
            <input type="checkbox" name="wp_travel_engine_settings[departure][hide_price_column]" id="wp_travel_engine_settings_hide_price_column_show" value="yes" <?php checked( true, $hide_price_column ); ?> />
            <label for="wp_travel_engine_settings_hide_price_column_show"></label>
        </div>
        <span class="wpte-tooltip"><?php esc_html_e( 'Check this if you want to hide the price column from the Fixed Starting Dates.', 'wte-fixed-departure-dates' ); ?></span>
    </div>
</div>
<div class="wpte-field">
    <div class="wpte-field wpte-checkbox advance-checkbox">
        <label for="wp_travel_engine_settings_hide_space_left_column_show" class="wpte-field-label"><?php esc_html_e( 'Hide FSD Column: Space left', 'wte-fixed-departure-dates' ); ?></label>
        <div class="wpte-checkbox-wrap">
            <input type="checkbox" name="wp_travel_engine_settings[departure][hide_space_left_column]" id="wp_travel_engine_settings_hide_space_left_column_hide" value="" checked />
            <input type="checkbox" name="wp_travel_engine_settings[departure][hide_space_left_column]" id="wp_travel_engine_settings_hide_space_left_column_show" value="yes" <?php checked( true, $hide_space_left_column ); ?> />
            <label for="wp_travel_engine_settings_hide_space_left_column_show"></label>
        </div>
        <span class="wpte-tooltip"><?php esc_html_e( 'Check this if you want to hide the Space Left column from the Fixed Starting Dates.', 'wte-fixed-departure-dates' ); ?></span>
    </div>
</div>

<div class="wpte-field">
    <label class="wpte-field-label" for="wp_travel_engine_settings[fsd_dates_layout]">
        <?php _e( 'Select the dates layout', 'wte-fixed-departure-dates' ); ?>
    </label>

    <div class="wte-dates-layout-holder wpte-floated">
        <div class="wte-dates-layout">
            <h4><?php esc_html_e( '1. Show dates list', 'wte-fixed-departure-dates' ); ?></h4>
            <label for="wte_fsd_dates_list_layout">
                <figure>
                    <input value="dates_list" id="wte_fsd_dates_list_layout" name="wp_travel_engine_settings[fsd_dates_layout]" type="radio" hidden="hidden" <?php checked( 'dates_list', $dates_layout, true ); ?>>
                    <img src="<?php echo WTE_FIXED_DEPARTURE_FILE_URL . '/admin/css/images/dates-list.png'; ?>" alt="dates list layout">
                </figure>
            </label>
        </div>
        <div class="wte-dates-layout">
            <h4><?php esc_html_e( '2. Show months list', 'wte-fixed-departure-dates' ); ?></h4>
            <label for="wte_fsd_months_list_layout">
                <figure>
                    <input id="wte_fsd_months_list_layout" value="months_list" name="wp_travel_engine_settings[fsd_dates_layout]" type="radio" hidden="hidden" <?php checked( 'months_list', $dates_layout, true ); ?>>
                    <img src="<?php echo WTE_FIXED_DEPARTURE_FILE_URL . '/admin/css/images/months-list.png'; ?>" alt="months list layout">
                </figure>
            </label>
        </div>
    </div>
    <span class="wpte-tooltip"><?php esc_html_e( 'Choose a dates list or months layout to display in taxonomy pages.', 'wte-fixed-departure-dates' ); ?></span>
</div>

<div class="wpte-field wpte-number wpte-floated">
    <label class="wpte-field-label" for="wp_travel_engine_settings[trip_dates][number]"><?php _e( 'Number of Trip Dates', 'wte-fixed-departure-dates' ); ?></label>
    <input type="number" id="wp_travel_engine_settings[trip_dates][number]" name="wp_travel_engine_settings[trip_dates][number]" min="0" value="<?php echo isset( $wp_travel_engine_settings['trip_dates']['number'] ) && ! empty( $wp_travel_engine_settings['trip_dates']['number'] ) ? $wp_travel_engine_settings['trip_dates']['number'] : 3; ?>">
    <span class="wpte-tooltip"><?php esc_html_e( 'Use this option to set number of trip fixed starting dates to show in the homepage sections.', 'wte-fixed-departure-dates' ); ?></span>
</div>

<div class="wpte-field wpte-number wpte-floated">
    <label class="wpte-field-label" for="wp_travel_engine_settings[trip_dates][pagination_number]"><?php _e( 'Pagination Number', 'wte-fixed-departure-dates' ); ?></label>
    <input type="number" id="wp_travel_engine_settings[trip_dates][pagination_number]" name="wp_travel_engine_settings[trip_dates][pagination_number]" min="1" step="1" max="99" value="<?php echo isset( $wp_travel_engine_settings['trip_dates']['pagination_number'] ) && ! empty( $wp_travel_engine_settings['trip_dates']['pagination_number'] ) ? $wp_travel_engine_settings['trip_dates']['pagination_number'] : 10; ?>">
    <span class="wpte-tooltip"><?php esc_html_e( 'Use this option to set number of trip fixed starting dates to show per page in the date listings through shortcode and tabs.', 'wte-fixed-departure-dates' ); ?></span>
</div>

<?php
$hide_trips_options = array(
	'default'      => array(
		'label' => __( 'Default', 'wte-fixed-departure-dates' ),
		'info' => __( 'Do not hides any trips.', 'wte-fixed-departure-dates' ),
	),
	'hide_no_dates_only' => array(
		'label' => __( 'Trips with no dates', 'wte-fixed-departure-dates' ),
		'info' => __( 'Hides trips with no dates set.', 'wte-fixed-departure-dates' ),
	),
	'hide_available_today_only' => array(
		'label' => __( 'Trips with no dates available after today', 'wte-fixed-departure-dates' ),
		'info' => __( 'Hides trips that have no dates available after today.', 'wte-fixed-departure-dates' ),
	),
	'hide_available_tomorrow_only' => array(
		'label' => __( 'Trips with no dates available after tomorrow', 'wte-fixed-departure-dates' ),
		'info' => __( 'Hides trips that have no dates available after tomorrow.', 'wte-fixed-departure-dates' ),
	),
	'hide_available_custom' => array(
		'label' => __( 'Trips with no dates after following days', 'wte-fixed-departure-dates' ),
		'info' => __( 'Hides trips that have no dates available after the number of days provided below. The number of days counts from today.', 'wte-fixed-departure-dates' ),
	),
);
$selected_hide_option = wte_array_get( $wp_travel_engine_settings, 'hide_trips_with_no_dates', 'default' );
$number_of_following_days = wte_array_get( $wp_travel_engine_settings, 'number_of_following_days_to_hide', '' );
?>
<div class="wpte-field wpte-number wpte-floated" style="flex-direction:column;">
    <label class="wpte-field-label" for="wptravelengine_settings_hide_trips_with_no_dates" style="width:100%;">
        <?php _e( 'Trip Visibility Settings', 'wte-fixed-departure-dates' ); ?>
    </label>
	<span class="wpte-tooltip"><?php _e( "Display trips on the archive page according to specific conditions.", 'wte-fixed-departure-dates' ); ?></span>
</div>
<div class="wpte-field-subfields">
    <div class="wpte-field wpte-checkbox advance-checkbox">
        <label class="wpte-field-label" for="wp_travel_engine_settings[show_trip_facts_sidebar]">
            <?php echo esc_html__( "Hide trips without fixed starting dates", 'wte-fixed-departure-dates' ) ?>
        </label>
        <?php
        $hide_trips_without_dates = isset( $wp_travel_engine_settings['hide_trips_without_dates'] ) && 'yes' === $wp_travel_engine_settings['hide_trips_without_dates'];
        ?>
        <div class="wpte-checkbox-wrap">
            <input type="hidden" name="wp_travel_engine_settings[hide_trips_without_dates]" value="no">
            <input type="checkbox" <?php checked( true, $hide_trips_without_dates ); ?> id="wp_travel_engine_settings[hide_trips_without_dates]" name="wp_travel_engine_settings[hide_trips_without_dates]" value="yes">
            <label for="wp_travel_engine_settings[hide_trips_without_dates]" class="checkbox-label"></label>
        </div>
        <span class="wpte-tooltip"><?php _e( "Enable this feature to hide any trips that do not have fixed starting dates.", 'wte-fixed-departure-dates' ); ?></span>
    </div>
    <div class="wpte-field wpte-checkbox advance-checkbox">
        <label class="wpte-field-label" for="wp_travel_engine_settings[hide_trips_without_dates_beyond]"><?php _e( 'Hide trips without available dates beyond a specific number of days', 'wte-fixed-departure-dates' ); ?></label>
        <?php
        $hide_trips_without_dates_beyond = isset( $wp_travel_engine_settings['hide_trips_without_dates_beyond'] ) && 'yes' === $wp_travel_engine_settings['hide_trips_without_dates_beyond'];
        ?>
        <div class="wpte-checkbox-wrap">
            <input type="hidden" name="wp_travel_engine_settings[hide_trips_without_dates_beyond]" value="no">
            <input type="checkbox" data-target="[data-target-htwdd]" <?php checked( true, $hide_trips_without_dates_beyond ); ?> id="wp_travel_engine_settings[hide_trips_without_dates_beyond]" name="wp_travel_engine_settings[hide_trips_without_dates_beyond]" value="yes">
            <label for="wp_travel_engine_settings[hide_trips_without_dates_beyond]" class="checkbox-label"></label>
        </div>
        <span class="wpte-tooltip"><?php _e( 'Enable this feature to hide any trips without available dates extending beyond a specified number of days.', 'wte-fixed-departure-dates' ); ?></span>
    </div>
    <div class="wpte-field wpte-number wpte-floated <?php echo ($hide_trips_without_dates_beyond) ? '' : 'hidden'; ?>" data-target-htwdd>
        <label class="wpte-field-label" for="wp_travel_engine_settings[number_of_days_to_hide_trips]"><?php _e( 'Number of days', 'wte-fixed-departure-dates' ); ?></label>
        <input type="number" id="wp_travel_engine_settings[number_of_days_to_hide_trips]" name="wp_travel_engine_settings[number_of_days_to_hide_trips]" min="0" value="3">
        <span class="wpte-tooltip"><?php _e( '1 = Today, 2 = Tomorrow, and so on.', 'wte-fixed-departure-dates' ); ?></span>
    </div>
    <script type="text/javascript">
    ;(function() {
        const fields = document.querySelectorAll('[name="wp_travel_engine_settings[hide_trips_without_dates_beyond]"]')
        if (fields) {
            fields.forEach(function(field) {
                field.addEventListener('change', function() {
                    var _self = this
                    var target = document.querySelector(_self.dataset.target)
                    if (target) {
                        target.classList.toggle('hidden', !_self.checked)
                    }
                })
            });
        }
    })();
    </script>
</div>
