<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://wptravelengine.com
 * @since             1.0.0
 * @package           Wte_Midtrans
 *
 * @wordpress-plugin
 * Plugin Name:       WP Travel Engine - Midtrans Payment Gateway
 * Plugin URI:        https://wptravelengine.com
 * Description:       Midtrans payment gateway for WP Travel Engine.
 * Version:           2.0.1
 * Author:            WP Travel Engine
 * Author URI:        https://wptravelengine.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wte-midtrans
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'WTE_MIDTRANS_VERSION', '2.0.1' );

/**
 * Download ID for the product in Easy Digital Downloads.
 *
 * @since 1.0.0
 */
define( 'WTE_MIDTRANS_ID', 31412 );

/**
 * Absolute path.
 * 
 * @since 1.0.0
 */
define( 'WTE_MIDTRANS_ABSPATH', __FILE__ );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wte-midtrans-activator.php
 */
function activate_wte_midtrans() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wte-midtrans-activator.php';
	Wte_Midtrans_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-wte-midtrans-deactivator.php
 */
function deactivate_wte_midtrans() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wte-midtrans-deactivator.php';
	Wte_Midtrans_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_wte_midtrans' );
register_deactivation_hook( __FILE__, 'deactivate_wte_midtrans' );


/**
 * Include the Midtrans PHP SDK.
*/
require_once plugin_dir_path( __FILE__ ) . '/lib/midtrans/Midtrans.php';

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-wte-midtrans.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_wte_midtrans() {

	$plugin = new Wte_Midtrans();
	$plugin->run();

}
run_wte_midtrans();
