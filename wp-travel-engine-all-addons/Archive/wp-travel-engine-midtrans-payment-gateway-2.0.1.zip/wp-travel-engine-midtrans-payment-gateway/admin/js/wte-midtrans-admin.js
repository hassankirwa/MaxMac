'use strict';

jQuery(document).ready( function() {
	displaySettings();

	jQuery('body').on('click', '.midtrans', function(event) {
		displaySettings();
	});

	function displaySettings() {
		if (jQuery('.midtrans').is(':checked')) {
			jQuery('.wte-midtrans-form.settings').fadeIn('slow');
		} else {
			jQuery('.wte-midtrans-form.settings').fadeOut('slow');
		}
	}

	/**
	 * Copy the midtrans payment urls.
	 */
	jQuery('.wte-midtrans-payment-urls').on('click', 'button', function(event){
		event.preventDefault();
		var url = jQuery(this).parent().find('.wte-midtrans-payment-url').val();
		var textArea = document.createElement('textarea');
		textArea.value = url;
		document.body.appendChild(textArea);
		textArea.select();
		document.execCommand('copy');
		document.body.removeChild(textArea);
	});

	/**
	 * Set checkbox enable disabled.
	 */
	jQuery('.wte-midtrans-form').on('change', 'input[type="checkbox"]', function(event){
		event.preventDefault();

		if ( jQuery(this).attr('checked') ) {
			jQuery(this).val('1');
		} else {
			jQuery(this).val('0');
		}
	});
});
