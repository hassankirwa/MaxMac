<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Midtrans
 * @subpackage Wte_Midtrans/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wte_Midtrans
 * @subpackage Wte_Midtrans/admin
 * @author     WP Travel Engine <support@wptravelengine.com>
 */
class Wte_Midtrans_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wte_Midtrans_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wte_Midtrans_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		if ( defined( 'SCRIPT_DEBUG') && true === SCRIPT_DEBUG ) {
			wp_enqueue_style(
				$this->plugin_name,
				plugin_dir_url( __FILE__ ) . 'css/wte-midtrans-admin.css',
				array(),
				$this->version,
				'all'
			);
		} else {
			wp_enqueue_style(
				$this->plugin_name,
				plugin_dir_url( __FILE__ ) . 'dist/css/wte-midtrans-admin-' . WTE_MIDTRANS_VERSION . '.min.css',
				array(),
				$this->version,
				'all'
			);
		}

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wte_Midtrans_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wte_Midtrans_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		if ( defined( 'SCRIPT_DEBUG') && true === SCRIPT_DEBUG ) {
			wp_enqueue_script(
				$this->plugin_name,
				plugin_dir_url( __FILE__ ) . 'js/wte-midtrans-admin.js',
				array( 'jquery' ),
				$this->version,
				false 
			);
		} else {
			wp_enqueue_script(
				$this->plugin_name,
				plugin_dir_url( __FILE__ ) . 'dist/js/wte-midtrans-admin-' . WTE_MIDTRANS_VERSION . '.min.js',
				array( 'jquery' ),
				$this->version,
				false 
			);
		}

	}

	/**
	 * Add midtrans to payment gateway list.
	 *
	 * @param mixed $list Payment gateway list.
	 * @return mixed Modified payment gateway list.
	 */
	public function add_to_gateway_list( $list ) {
		$list['midtrans_enable'] = array(
			'label' => __( 'Midtrans', 'wte-midtrans' ),
			'input_class' => 'midtrans',
			'info_text' => __( 'Please check this to enable Midtrans booking system for trip booking and fill the acount info below.', 'wte-midtrans' )
		);

		return $list;
	}

	/**
	 * Display settings.
	 *
	 * @return void
	 */
	public function display_settings() {
		$helper = Wte_Midtrans_Helper::get_instance();

		$wte_settings = get_option( 'wp_travel_engine_settings' );
		$finish_redirect_url = get_permalink( intval( $wte_settings['pages']['wp_travel_engine_confirmation_page'] ) );
		$notification_url = home_url();
		$unfinish_redirect_url = home_url();
		$error_redirect_url = home_url();

		$midtrans = $helper->get_settings();
		
		require_once plugin_dir_path( __FILE__ ) . 'partials/wte-midtrans-admin-display.php';
	}

	/**
	 * Add global settings - backend UI
	 *
	 * @return void
	 */
	public function add_global_settings( $global_tabs ) {
		if ( isset( $global_tabs['wpte-payment'] ) ) {
			$global_tabs['wpte-payment']['sub_tabs']['wte-midtrans'] = array(
				'label'        => __( 'Midtrans Payment', 'wte-midtrans' ),
				'content_path' => plugin_dir_path( __FILE__ ) . 'partials/midtrans-global.php',
				'current'      => false,
			);
		}

		return $global_tabs;
	}

	/**
	 * This will uninstall this plugin if parent WP Travel plugin not found.
	 * 
	 * @since 1.0.0
	 */
	public function check_dependency() {

		if ( ! class_exists( 'Wp_Travel_Engine' ) || ! $this->meets_requirements() ) {
			echo '<div class="error">';
			echo wp_kses_post( '
				<p>
					<strong>
						WP Travel Engine - Midtrans Payment Gateway
					</strong> 
					requires the <a href="https://wptravelengine.com" target="__blank">WP Travel Engine</a>
					<b>version - 4.0.0 or later</b> to work. 
					Please install and activate the latest WP Travel Engine plugin first. 
					<b>WP Travel Engine - Midtrans Payment Gateway will now be deactivated now.</b>
				</p>' );
			echo '</div>';

			// Deactivate Plugins.
			deactivate_plugins( plugin_basename( WTE_MIDTRANS_ABSPATH ) );
		}
	}

	/**
	 * Check if all plugin requirements are met.
	 *
	 * @since 1.0.0
	 *
	 * @return bool True if requirements are met, otherwise false.
	 */
	private function meets_requirements() {
		return ( class_exists( 'WP_Travel_Engine' ) && defined( 'WP_TRAVEL_ENGINE_VERSION' ) && version_compare( WP_TRAVEL_ENGINE_VERSION, '4.0.0', '>=' ) );
	}

	/**
	 * Check midtrans keys.
	 * 
	 * @since 1.0.0
	 * @access public
	 * 
	 * @return void
	 */
	public function check_midtrans_keys() {
		$helper = Wte_Midtrans_Helper::get_instance();

		try {
			$snap_token = $helper->get_snap_token( array() );
		} catch( Exception $e ) {
			if ( 401 === $e->getCode() ) {
				$error_message = $helper->get_error_message( $e->getCode() );
				$this->display_error_message( $error_message );
			}			
		} 
	}

	/**
	 * Display error message.
	 *
	 * @since 1.0.0
	 * @access private
	 * 
	 * @param string $error_message Error messsage.
	 * @return void
	 */
	private function  display_error_message( $error_message ) { ?>
		<div class="notice notice-error is-dismissible"> 
			<p>
				<strong> <?php esc_html_e( 'Midtrans:', 'wte-midtrans' ); ?></strong>
				<?php echo esc_html( $error_message ); ?>
			</p>
			<button type="button" class="notice-dismiss">
				<span class="screen-reader-text">
					<?php esc_html_e( 'Dismiss', 'wte-midtrans' ); ?>
				</span>
			</button>
		</div>
	<?php }
}
