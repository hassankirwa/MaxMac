<?php
/**
 * Global Settings
 * 
 * @package WTE_Midtrans
 */
$helper = Wte_Midtrans_Helper::get_instance();

$wte_settings                   = get_option( 'wp_travel_engine_settings' );
$finish_redirect_url            = wp_travel_engine_get_booking_confirm_url(); // get_permalink( intval( $wte_settings['pages']['wp_travel_engine_confirmation_page'] ) );
$notification_url               = home_url();
$recurring_notification_url     = home_url();
$unfinish_redirect_url          = home_url();
$error_redirect_url             = home_url();

$midtrans = $helper->get_settings();

?>
<h4><?php esc_html_e( 'Midtrans Redirection URLs', 'wte-midtrans' ); ?></h4>
<div class="wpte-field wpte-text wte-midtrans-payment-urls wpte-floated">
    <label class="wpte-field-label"><?php _e('Payment Notification URL','wte-midtrans');?></label>
    <input id="wte-midtrans-pay-notf" type="text" readonly
            class="wte-midtrans-payment-url"
            value="<?php echo esc_url( $notification_url ); ?>" />
        <button data-copyid="wte-midtrans-pay-notf" class="wte__copy-button wpte-copy-btn"><i class="far fa-copy"></i></button>
</div>

<div class="wpte-field wpte-text wte-midtrans-payment-urls wpte-floated">
    <label class="wpte-field-label"><?php _e('Recurring Notification URL','wte-midtrans');?></label>
    <input id="wte-midtrans-pay-recurr-notf" type="text" readonly
            class="wte-midtrans-payment-url"
            value="<?php echo esc_url( $recurring_notification_url ); ?>" />
        <button data-copyid="wte-midtrans-pay-recurr-notf" class="wte__copy-button wpte-copy-btn"><i class="far fa-copy"></i></button>
</div>

<div class="wpte-field wpte-text wte-midtrans-payment-urls wpte-floated">
    <label class="wpte-field-label"><?php _e('Finish Redirect URL','wte-midtrans');?></label>
    <input id="wte-midtrans-pay-red" type="text" readonly
            class="wte-midtrans-payment-url"
            value="<?php echo esc_url( $finish_redirect_url ); ?>" />
        <button data-copyid="wte-midtrans-pay-red" class="wte__copy-button wpte-copy-btn"><i class="far fa-copy"></i></button>
</div>

<div class="wpte-field wpte-text wte-midtrans-payment-urls wpte-floated">
    <label class="wpte-field-label"><?php _e('Unfinish Redirect URL','wte-midtrans');?></label>
    <input id="wte-midtrans-pay-unfinnof" type="text" readonly
            class="wte-midtrans-payment-url"
            value="<?php echo esc_url( $unfinish_redirect_url ); ?>" />
        <button data-copyid="wte-midtrans-pay-unfinnof" class="wte__copy-button wpte-copy-btn"><i class="far fa-copy"></i></button>
</div>

<div class="wpte-field wpte-text wte-midtrans-payment-urls wpte-floated">
    <label class="wpte-field-label"><?php _e('Error Redirect URL','wte-midtrans');?></label>
    <input id="wte-midtrans-pay-err-nrfd" type="text" readonly
            class="wte-midtrans-payment-url"
            value="<?php echo esc_url( $error_redirect_url ); ?>" />
        <button data-copyid="wte-midtrans-pay-err-nrfd" class="wte__copy-button wpte-copy-btn"><i class="far fa-copy"></i></button>
</div>

<h4><?php esc_html_e( 'Midtrans Settings', 'wte-midtrans' ); ?></h4>
<div class="wpte-field wpte-checkbox advance-checkbox">
    <input type="hidden" name="wp_travel_engine_settings[midtrans][3ds_enabled]" value="0">
    <label class="wpte-field-label" for="wp_travel_engine_settings[midtrans][3ds_enabled]"><?php esc_html_e( 'Enable 3DS Secure', 'wte-midtrans'); ?></label>
    <div class="wpte-checkbox-wrap">
        <input type="checkbox" id="wp_travel_engine_settings[midtrans][3ds_enabled]" name="wp_travel_engine_settings[midtrans][3ds_enabled]" value="<?php echo esc_attr( $midtrans['3ds_enabled'] ); ?>"
            <?php echo esc_attr( '1' === $midtrans['3ds_enabled'] ? 'checked' : '' ); ?>>
        <label for="wp_travel_engine_settings[midtrans][3ds_enabled]" class="checkbox-label"></label>
    </div>
    <span class="wpte-tooltip"><?php esc_html_e( 'Check this option to enable 3DS Secure', 'wte-midtrans' ); ?></span>
</div>

<div class="wpte-field wpte-checkbox advance-checkbox">
<input type="hidden" name="wp_travel_engine_settings[midtrans][save_card_enabled]" value="0">
    <label class="wpte-field-label" for="wp_travel_engine_settings[midtrans][save_card_enabled]"><?php esc_html_e( 'Enable Save Card', 'wte-midtrans'); ?></label>
    <div class="wpte-checkbox-wrap">
        <input type="checkbox" id="wp_travel_engine_settings[midtrans][save_card_enabled]" name="wp_travel_engine_settings[midtrans][save_card_enabled]" value="<?php echo esc_attr( $midtrans['save_card_enabled'] ); ?>"
            <?php echo esc_attr( '1' === $midtrans['save_card_enabled'] ? 'checked' : '' ); ?>>
        <label for="wp_travel_engine_settings[midtrans][save_card_enabled]" class="checkbox-label"></label>
    </div>
    <span class="wpte-tooltip"><?php esc_html_e( 'Check this option to enable Save Card', 'wte-midtrans' ); ?></span>
</div>

<div class="wpte-field wpte-text wte-midtrans-payment-urls wpte-floated">
    <label for="wp_travel_engine_settings[midtrans][merchant_id]" class="wpte-field-label"><?php esc_html_e( 'Merchant ID', 'wte-midtrans'); ?></label>
    <input type="text" id="wp_travel_engine_settings[midtrans][merchant_id]" name="wp_travel_engine_settings[midtrans][merchant_id]" value="<?php echo esc_attr( $midtrans['merchant_id'] );?>">
    <span class="wpte-tooltip"><?php esc_html_e( "Enter a valid Merchant key from Midtrans account. All payments will go to this account", 'wte-midtrans' ); ?></span>
</div>

<div class="wpte-field wpte-text wte-midtrans-payment-urls wpte-floated">
    <label for="wp_travel_engine_settings[midtrans][client_key]" class="wpte-field-label"><?php esc_html_e( 'Client Key', 'wte-midtrans'); ?></label>
    <input type="text" id="wp_travel_engine_settings[midtrans][client_key]" name="wp_travel_engine_settings[midtrans][client_key]" value="<?php echo esc_attr( $midtrans['client_key'] );?>">
    <span class="wpte-tooltip"><?php esc_html_e( "Enter a valid Client Key from Midtrans account.", 'wte-midtrans' ); ?></span>
</div>

<div class="wpte-field wpte-text wte-midtrans-payment-urls wpte-floated">
    <label for="wp_travel_engine_settings[midtrans][server_key]" class="wpte-field-label"><?php esc_html_e( 'Server Key', 'wte-midtrans'); ?></label>
    <input type="text" id="wp_travel_engine_settings[midtrans][server_key]" name="wp_travel_engine_settings[midtrans][server_key]" value="<?php echo esc_attr( $midtrans['server_key'] );?>">
    <span class="wpte-tooltip"><?php esc_html_e( "Enter a valid Server Key from Midtrans account.", 'wte-midtrans' ); ?></span>
</div>
<?php
