<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Midtrans
 * @subpackage Wte_Midtrans/admin/partials
 */
?>

<div class="wte-midtrans-form settings wp-travel-engine-settings">
    <h4><?php esc_html_e( 'Midtrans Redirection URL', 'wte-midtrans' ); ?></h4>
    <span>
        <?php esc_html_e( 'Save the following urls in the midtrans dashboard under the configuration and snap preferences.', 'wte-midtrans' ); ?>
    </span>
    <div class="wte-midtrans-payment-urls">
        <label><?php esc_html_e( 'Payment Notification URL: ', 'wte-midtrans'); ?></label>
        <input type="text" readonly
            class="wte-midtrans-payment-url"
            value="<?php echo esc_url( $notification_url ); ?>" />
        <button class="wte__copy-button"><i class="far fa-copy"></i></button>
    </div>

    <div class="wte-midtrans-payment-urls">
        <label><?php esc_html_e( 'Finish Redirect URL: ', 'wte-midtrans' ); ?></label>
        <input type="text" readonly
            class="wte-midtrans-payment-url"
            value="<?php echo esc_url( $finish_redirect_url ); ?>" />
        <button class="wte__copy-button"><i class="far fa-copy"></i></button>
    </div>
    <div class="wte-midtrans-payment-urls">
        <label><?php esc_html_e( 'Unfinish Redirect URL: ', 'wte-midtrans'); ?></label>
        <input type="text" readonly
            class="wte-midtrans-payment-url"
            value="<?php echo esc_url( $unfinish_redirect_url ); ?>" />
        <button class="wte__copy-button"><i class="far fa-copy"></i></button>
    </div>
    <div class="wte-midtrans-payment-urls">
        <label><?php esc_html_e( 'Error Redirect URL: ', 'wte-midtrans' ); ?></label>
        <input type="text" readonly
            class="wte-midtrans-payment-url"
            value="<?php echo esc_url( $error_redirect_url ); ?>" />
        <button class="wte__copy-button"><i class="far fa-copy"></i></button>
    </div>
    <hr />
    <h4><?php esc_html_e( 'Midtrans Settings', 'wte-midtrans' ); ?></h4>
    <!-- Enable 3DS -->
    <div class="wp-travel-engine-settings">
        <label for="wp_travel_engine_settings[midtrans][3ds_enabled]">
            <?php esc_html_e( 'Enable 3DS Secure', 'wte-midtrans'); ?>
            <span class="tooltip" 
                title="<?php esc_attr_e( 'Check this option to enable 3DS Secure', 'wte-midtrans' ); ?>">
                <i class="fas fa-question-circle"></i>
            </span>
        </label>
        <input type="checkbox"
            value="<?php echo esc_attr( $midtrans['3ds_enabled'] ); ?>"
            <?php echo esc_attr( '1' === $midtrans['3ds_enabled'] ? 'checked' : '' ); ?>
            id="wp_travel_engine_settings[midtrans][3ds_enabled]"
            name="wp_travel_engine_settings[midtrans][3ds_enabled]">
        <label for="wp_travel_engine_settings[midtrans][3ds_enabled]" 
            class="checkbox-label"></label>
    </div>
    <!-- ./ Enable 3DS -->

    <!-- Enable Save Card -->
    <div class="wp-travel-engine-settings">
        <label for="wp_travel_engine_settings[midtrans][save_card_enabled]">
            <?php esc_html_e( 'Enable Save Card', 'wte-midtrans' ); ?>
            <span class="tooltip"
                title=<?php esc_attr_e( 'Check this option to enable Save Card', 'wte-midtrans'); ?>>
                <i class="fas fa-question-circle"></i>
            </span>
        </label>
        <input type="checkbox" 
            value="<?php echo esc_attr( $midtrans['save_card_enabled'] ); ?>"
            <?php echo esc_attr( '1' === $midtrans['save_card_enabled'] ? 'checked' : '' ); ?>
            id="wp_travel_engine_settings[midtrans][save_card_enabled]"
            name="wp_travel_engine_settings[midtrans][save_card_enabled]">
        <label for="wp_travel_engine_settings[midtrans][save_card_enabled]" class="checkbox-label"></label>
    </div>
    <!-- ./ Enable Save Card -->

    <!-- Merchant Key -->
    <label for="wp_travel_engine_settings[midtrans][merchant_id]">
        <?php esc_html_e( 'Merchant ID: ', 'wte-midtrans'); ?>
        <span class="tooltip"
            title="<?php esc_attr_e( 'Enter a valid Merchant key from Midtrans account. All payments will go to this account.', 'wte-midtrans'); ?>">
            <i class="fas fa-question-circle"></i>
        </span>
    </label>
    <input type="text"
        id="wp_travel_engine_settings[midtrans][merchant_id]"
        name="wp_travel_engine_settings[midtrans][merchant_id]"
        value="<?php echo esc_attr( $midtrans['merchant_id'] );?>" /> 
    <!-- ./ Merchant Key -->

    <!-- Client Key -->
    <label for="wp_travel_engine_settings[midtrans][client_key]">
        <?php esc_html_e('Client Key : ','wte-midtrans');?> 
        <span class="tooltip"
        title="<?php esc_attr_e( 'Enter a valid Client Key from Midtrans account.', 'wte-midtrans' ); ?>">
            <i class="fas fa-question-circle"></i>
        </span>
    </label>
    <input type="text"
        id="wp_travel_engine_settings[midtrans][client_key]"
        name="wp_travel_engine_settings[midtrans][client_key]"
        value="<?php echo esc_attr( $midtrans['client_key'] ); ?>" />
    <!-- ./ Client Key -->
    
    <!-- Server Key -->
    <label for="wp_travel_engine_settings[midtrans][server_key]">
        <?php esc_html_e('Server Key : ','wte-midtrans');?> 
        <span class="tooltip"
        title="<?php esc_attr_e( 'Enter a valid Server Key from Midtrans account.', 'wte-midtrans' ); ?>">
            <i class="fas fa-question-circle"></i>
        </span>
    </label>
    <input type="text"
        id="wp_travel_engine_settings[midtrans][server_key]"
        name="wp_travel_engine_settings[midtrans][server_key]"
        value="<?php echo esc_attr( $midtrans['server_key'] ); ?>" />
    <!-- ./ Server Key -->

</div>
<?php
