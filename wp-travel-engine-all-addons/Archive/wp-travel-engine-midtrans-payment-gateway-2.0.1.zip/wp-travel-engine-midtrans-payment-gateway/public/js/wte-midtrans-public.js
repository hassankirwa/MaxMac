; (function () {
    var checkoutForm = document.getElementById('wp-travel-engine-new-checkout-form')
    var paymentGatewayInput = document.querySelector('input[name=wpte_checkout_paymnet_method]')
    var paymentModeInput = document.querySelector('input[name=wp_travel_engine_payment_mode]')


    var handlePaymentModeChange = function (event) {

    }

    var is_midtrans = function () {
        var activeGateway = document.querySelector('input[name=wpte_checkout_paymnet_method]:checked')
        return activeGateway && activeGateway.value == 'midtrans_enable'
    }

    var handlePaymentGatewayChange = function (event) {
        if (is_midtrans()) {

        }
    }

    var get_snap_token = function () {

    }

    if (paymentModeInput) {
        paymentModeInput.addEventListener('change', handlePaymentModeChange)
    }

    if (paymentGatewayInput) {
        paymentGatewayInput.addEventListener('change', handlePaymentGatewayChange)
    }

    var handleFormSubmitBtnClick = function (event) {
        var _self = this
        if (is_midtrans()) {
            event.preventDefault()
            this.removeEventListener('click', handleFormSubmitBtnClick)
            var formData = new FormData()
            var _paymentGatewayInput = document.querySelector('input[name=wp_travel_engine_payment_mode]:checked')
            if (_paymentGatewayInput) {
                formData.append('payment_type', _paymentGatewayInput.value)
            }
            var _bookingIDInput = document.querySelector('input[name=booking_id]')
            if (_bookingIDInput) {
                formData.append('booking_id', _bookingIDInput.value)
            }
            var first_name = document.querySelector('input[name="wp_travel_engine_booking_setting[place_order][booking][fname]"]');
            var last_name = document.querySelector('input[name="wp_travel_engine_booking_setting[place_order][booking][lname]"]');
            var contact_no = document.querySelector('input[name="wp_travel_engine_booking_setting[place_order][booking][phone]"]');
            var email_address = document.querySelector('input[name="wp_travel_engine_booking_setting[place_order][booking][email]"]');
            var billing_address = document.querySelector('input[name="wp_travel_engine_booking_setting[place_order][booking][address]"]');

            var fname = first_name && first_name.value;
            var lname = last_name && last_name.value;
            var phone = contact_no && contact_no.value;
            var email = email_address && email_address.value;
            var address = billing_address && billing_address.value;

            fname && formData.append('first_name', fname)
            lname && formData.append('last_name', lname)
            email && formData.append('email', email)
            address && formData.append('address', address)
            phone && formData.append('phone', phone)

            this.disabled = true
            fetch(WTEAjaxData.ajaxurl + '?action=wte_midtrans_snap_token', {
                method: 'POST',
                body: formData
            })
                .then(function (res) { return res.json() })
                .then(function (data) {
                    if (data.success && window['snap']) {
                        window.snap.pay(data.data.snap_token, {
                            onSuccess: function (result) {
                                console.debug({ result })
                                var _input = document.createElement('input')
                                _input.type = 'hidden'
                                _input.name = 'midtrans_success_details'
                                _input.value = JSON.stringify(result)
                                checkoutForm.append(_input)
                                _self.disabled = false
                                _self.click()
                            },
                            onPending: function (result) {
                                alert("wating your payment!"); console.log(result);
                            },
                            onError: function (result) {
                                /* You may add your own implementation here */
                                alert("payment failed!"); console.log({ result });
                            },
                            onClose: function () {
                                alert('You closed the popup without finishing the payment.');
                                _self.addEventListener('click', handleFormSubmitBtnClick)
                                _self.disabled = false
                            }
                        })
                    }
                })
        }
    }

    if (checkoutForm) {
        var submitBtn = checkoutForm.querySelector('input[type=submit]')
        if (submitBtn) {
            submitBtn.addEventListener('click', handleFormSubmitBtnClick)
        }
    }

})();
