<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Midtrans
 * @subpackage Wte_Midtrans/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Wte_Midtrans
 * @subpackage Wte_Midtrans/public
 * @author     WP Travel Engine <support@wptravelengine.com>
 */
class Wte_Midtrans_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string $plugin_name       The name of the plugin.
	 * @param      string $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;

		$this->init_hooks();
	}

	/**
	 *
	 * @since 2.1.0
	 */
	private function init_hooks() {
		add_action(
			'wte_payment_gateway_midtrans_enable',
			function( $payment_id, $payment_mode, $payment_method ) {
				remove_action( 'wp_travel_engine_after_booking_process_completed', array( $this, 'start_snap_process' ) );
				$booking_id = get_post_meta( $payment_id, 'booking_id', true );
				$booking    = get_post( $booking_id );
				if ( isset( $_REQUEST['midtrans_success_details'] ) ) {
					$payment_details = json_decode( wp_unslash( $_REQUEST['midtrans_success_details'] ) );

					if ( $payment_details ) {
						update_post_meta( $payment_id, 'gateway_response', $payment_details );

						if ( $payment_details->status_code == 200 ) {
							$status = $payment_details->transaction_status;
							update_post_meta( $payment_id, 'payment_status', $status );

							if ( 'capture' === $status ) {
								update_post_meta(
									$payment_id,
									'payment_amount',
									array(
										'value'    => $payment_details->gross_amount,
										'currency' => 'INR',
									)
								);
								$meta_input = array(
									'wp_travel_engine_booking_status' => 'booked',
									'paid_amount' => (float) $booking->paid_amount + (float) $payment_details->gross_amount,
									'due_amount'  => 0,
								);
								if ( (float) $booking->due_amount > (float) $payment_details->gross_amount ) {
									$meta_input['due_amount'] = (float) $booking->due_amount - (float) $payment_details->gross_amount;
								}
								\WTE_Booking::update_booking(
									$booking->ID,
									array(
										'meta_input' => $meta_input,
									)
								);
								\WTE_Booking::send_emails( $payment_id, 'order_confirmation', 'all' );
							}
							// wp_redirect( self::get_thankyou_url( $booking->ID, $payment_id, 'payu_enable' ) );
							// exit;
						}
					}
				}
			},
			10,
			3
		);

		add_action( 'wp_ajax_wte_midtrans_snap_token', array( $this, 'generate_snap_token' ) );
		add_action( 'wp_ajax_nopriv_wte_midtrans_snap_token', array( $this, 'generate_snap_token' ) );
	}

	public function generate_snap_token() {

		if ( isset( $_REQUEST['booking_id'] ) ) {
			$booking_id = $_REQUEST['booking_id'];
			$cart_info  = get_post_meta( $booking_id, 'cart_info' );
			$amount     = $cart_info['total'];
			if ( isset( $_REQUEST['payment_type'] ) && 'remaining_payment' === $_REQUEST['payment_type'] ) {
				$amount = (float) $cart_info['total'] - (float) $cart_info['cart_partial'];
			}
		} else {
			global $wte_cart;

			$totals = $wte_cart->get_total();

			$amounts = array(
				'full_payment' => $totals['cart_total'],
				'partial'      => $totals['total_partial'],
			);
		}
		if ( isset( $_REQUEST['payment_type'] ) && isset( $amounts[ $_REQUEST['payment_type'] ] ) ) {
			$amount = $amounts[ $_REQUEST['payment_type'] ];
		} else {
			$amount = $amounts['full_payment'];
		}
		$fname   = isset( $_REQUEST['first_name'] ) ? $_REQUEST['first_name'] : '';
		$lname   = isset( $_REQUEST['last_name'] ) ? $_REQUEST['last_name'] : '';
		$address = isset( $_REQUEST['address'] ) ? $_REQUEST['address'] : '';
		$email   = isset( $_REQUEST['email'] ) ? $_REQUEST['email'] : '';
		$phone   = isset( $_REQUEST['phone'] ) ? $_REQUEST['phone'] : '';

		$transaction                     = array(
			'transaction_details' => array(
				'order_id'     => rand(),
				'gross_amount' => intval( $amount ),
			),
			'custom_field1'       => 'midtrans',
		);
		$customer_details                = array(
			'first_name'      => $fname,
			'last_name'       => $lname,
			'email'           => $email,
			'billing_address' => array(
				'address' => $address,
			),
			'phone'           => $phone,
		);
		$transaction['customer_details'] = $customer_details;

		$helper                                  = Wte_Midtrans_Helper::get_instance();
		$transaction['credit_card']['save_card'] = $helper->is_save_card_enabled();

		try {
			$snap_token = $helper->get_snap_token( $transaction );

			wp_send_json_success(
				array(
					'snap_token' => $snap_token,
				)
			);
		} catch ( Exception $e ) {
			if ( wp_doing_ajax() ) {
				wp_send_json_error(
					$transaction,
					$e->getMessage()
				);
				exit;
			} else {
				error_log( $e->getMessage() );
			}
		}
		exit;
	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wte_Midtrans_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wte_Midtrans_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		if ( defined( 'SCRIPT_DEBUG' ) && true === SCRIPT_DEBUG ) {
			wp_enqueue_style(
				$this->plugin_name,
				plugin_dir_url( __FILE__ ) . 'css/wte-midtrans-public.css',
				array(),
				$this->version,
				'all'
			);
		} else {
			wp_enqueue_style(
				$this->plugin_name,
				plugin_dir_url( __FILE__ ) . 'dist/css/wte-midtrans-public-' . WTE_MIDTRANS_VERSION . '.min.css',
				array(),
				$this->version,
				'all'
			);
		}

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wte_Midtrans_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wte_Midtrans_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		$helper = Wte_Midtrans_Helper::get_instance();

		// Bail early if not enabled.
		if ( ! $helper->is_enabled() ) {
			return;
		}

		if ( $helper->is_debug_enabled() ) {
			wp_enqueue_script( 'midtrans-snap', 'https://app.sandbox.midtrans.com/snap/snap.js', null, null, true );
		} else {
			wp_enqueue_script( 'midtrans-snap', 'https://app.midtrans.com/snap/snap.js', null, null, true );
		}

		if ( defined( 'SCRIPT_DEBUG' ) && true === SCRIPT_DEBUG ) {
			wp_enqueue_script(
				$this->plugin_name,
				plugin_dir_url( __FILE__ ) . 'js/wte-midtrans-public.js',
				array( 'jquery', 'midtrans-snap' ),
				$this->version,
				true
			);
		} else {
			wp_enqueue_script(
				$this->plugin_name,
				plugin_dir_url( __FILE__ ) . 'dist/js/wte-midtrans-public-' . WTE_MIDTRANS_VERSION . '.min.js',
				array( 'jquery', 'midtrans-snap' ),
				$this->version,
				true
			);
		}

		wp_localize_script(
			$this->plugin_name,
			'wteMidtrans',
			array(
				'ajaxurl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'midtrans_nonce' ),
			)
		);
	}

	/**
	 * Modify the script tag.
	 *
	 * @param string $tag The <script> tag for the enqueued script.
	 * @param string $handle The script's registered handle.
	 * @param string $src The script's source URL.
	 * @return void
	 */
	public function modify_script_tag( $tag, $handle, $src ) {
		$helper = Wte_Midtrans_Helper::get_instance();

		if ( 'midtrans-snap' === $handle ) {
			$escaped_src = esc_url( $src );
			$client_key  = $helper->get_client_key();
			$tag         = "<script type='text/javascript' src='{$escaped_src}' data-client-key='{$client_key}'></script>";
		}

		return $tag;
	}

	/**
	 * Get the snap token.
	 *
	 * @param int $booking_id Booking id.
	 * @return void
	 */
	public function start_snap_process( $booking_id, $payment_id = null ) {
		$error_message = '';

		$helper = Wte_Midtrans_Helper::get_instance();

		$booking = get_post( $booking_id );

		// Bail early if the request is not coming form billing form.
		if ( ! isset( $_REQUEST['wp_travel_engine_nw_bkg_submit'] ) ) {
			return;
		}

		// Bail early if the payment method is not set.
		if ( ! isset( $_REQUEST['wpte_checkout_paymnet_method'] ) ) {
			return;
		}

		// Bail early if the payment method is not midtrans.
		if ( 'midtrans_enable' !== $_REQUEST['wpte_checkout_paymnet_method'] ) {
			return;
		}

		// Bail early if the booking is null.
		if ( null === $booking ) {
			return;
		}

		$meta = get_post_meta( $booking_id, 'wp_travel_engine_booking_setting', true );

		$transaction_details = array(
			'order_id'     => $booking_id,
			'gross_amount' => intval( $meta['place_order']['cost'] ),
		);

		$item_details = array(
			array(
				'id'       => $meta['place_order']['tid'],
				'price'    => intval( $meta['place_order']['cost'] ),
				'name'     => $meta['place_order']['tname'],
				'quantity' => 1,
			),
		);

		$billing_address = array(
			'first_name' => $meta['place_order']['booking']['fname'],
			'last_name'  => $meta['place_order']['booking']['lname'],
			'city'       => $meta['place_order']['booking']['city'],
			'address'    => $meta['place_order']['booking']['address'],
			'email'      => $meta['place_order']['booking']['email'],
		);

		$customer_details = array(
			'first_name'      => $meta['place_order']['booking']['fname'],
			'last_name'       => $meta['place_order']['booking']['lname'],
			'email'           => $meta['place_order']['booking']['email'],
			'billing_address' => $billing_address,
		);

		$transaction = array(
			'transaction_details' => $transaction_details,
			'customer_details'    => $customer_details,
			'item_details'        => $item_details,
			'custom_field1'       => 'midtrans',
		);

		$transaction['credit_card']['save_card'] = $helper->is_save_card_enabled();

		try {
			$snap_token = $helper->get_snap_token( $transaction );
		} catch ( Exception $e ) {
			if ( wp_doing_ajax() ) {
				wp_send_json_error(
					new \WP_Error(
						'WTE_ERROR',
						$e->getMessage(),
						$transaction
					)
				);
				exit;
			} else {
				error_log( $e->getMessage() );
			}
		}

		if ( wp_doing_ajax() ) {
			wp_send_json_success(
				array()
			);
		}

		$url = add_query_arg(
			array(
				'booking_id' => $booking_id,
				'snap_token' => $snap_token,
			),
			home_url( $_SERVER['REQUEST_URI'] )
		);

		wp_safe_redirect( $url );
		exit;
	}

	/**
	 * Display snap page.
	 *
	 * @param string $template Template.
	 * @return void
	 */
	public function display_snap_page( $template ) {
		$wte_settings = get_option( 'wp_travel_engine_settings' );
		if ( isset( $_GET['snap_token'] ) ) {
			$booking_id      = $_GET['booking_id'];
			$booking_details = get_post_meta( $booking_id, 'wp_travel_engine_booking_setting', true );
			include plugin_dir_path( __FILE__ ) . 'partials/wte-midtrans-public-display.php';
			die;
		}
	}

	/**
	 * Handle payment notification.
	 *
	 * @return void
	 */
	public function handle_payment_notificaton() {
		if ( is_admin() ) {
			return;
		}

		// Bail early if the $_POST doesn't contain status_code.
		if ( ! isset( $_POST['custom_field1'] ) ) {
			return;
		}

		if ( 'midtrans' === isset( $_POST['custom_field1'] ) ) {
			return;
		}

		$helper                         = Wte_Midtrans_Helper::get_instance();
		\Midtrans\Config::$isProduction = ! $helper->is_debug_enabled();
		\Midtrans\Config::$serverKey    = $helper->get_server_key();

		try {
			$notif = new \Midtrans\Notification();

			$transaction_status = $notif->transaction_status;
			$transaction_id     = $notif->transaction_id;
			$type               = $notif->payment_type;
			$order_id           = $notif->order_id;
			$fraud_status       = $notif->fraud_status;

			if ( 'capture' === $transaction_status && 'credit_card' === $type ) {
				if ( 'challenge' === $fraud_status ) {
					$payment_status = __( 'Challenge', 'wte-midtrans' );
				} else {
					$payment_status = __( 'Success', 'wte-midtrans' );
				}
			} elseif ( 'settlement' === $transaction_status ) {
				$payment_status = __( 'Settlement', 'wte-midtrans' );
			} elseif ( 'pending' === $transaction_status ) {
				$payment_status = __( 'Pending', 'wte-midtrans' );
			} elseif ( 'deny' === $transaction_status ) {
				$payment_status = __( 'Deny', 'wte-midtrans' );
			} elseif ( 'expire' === $transaction_status ) {
				$payment_status = __( 'Expire', 'wte-midtrans' );
			} elseif ( 'cancel' === $transaction_status ) {
				$payment_status = __( 'Cancel', 'wte-midtrans' );
			}

			$payment_details = array(
				array(
					'label' => __( 'Transaction ID', 'wte-midtrans' ),
					'value' => $transaction_id,
				),
				array(
					'label' => __( 'Payment Type', 'wte-midtrans' ),
					'value' => $type,
				),
			);

			update_post_meta(
				$order_id,
				'wp_travel_engine_booking_payment_status',
				$payment_status
			);
			update_post_meta(
				$order_id,
				'wp_travel_engine_booking_payment_gateway',
				__( 'Midtrans', 'wte-midtrans' )
			);
			update_post_meta(
				$order_id,
				'wp_travel_engine_booking_payment_details',
				$payment_details
			);
		} catch ( Exception $e ) {

		}
	}
}
