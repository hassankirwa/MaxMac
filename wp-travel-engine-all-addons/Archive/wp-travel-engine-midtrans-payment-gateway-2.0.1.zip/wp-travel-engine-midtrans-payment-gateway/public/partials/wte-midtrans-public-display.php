<?php
/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Midtrans
 * @subpackage Wte_Midtrans/public/partials26
 */
?>

<?php
get_header();
?>

<div class="snap-page">
    <table>
        <caption>
            <h2><?php echo esc_html( $booking_details["place_order"]["tname"] ); ?></h2>
        </caption>
        <tbody>
            <tr>
                <th>Booking Id</th>
                <td><?php echo esc_html( $_GET['booking_id'] ); ?></td>
            </tr>
            <tr>
                <th>Traveller</th>
                <td><?php echo esc_html( $booking_details["place_order"]["traveler"] ); ?></td>
            </tr>
            <tr>
                <th>Booked Date</th>
                <td><?php echo esc_html( $booking_details["place_order"]["datetime"] ); ?></td>
            </tr>
            <tr>
                <th>Cost</th>
                <td><?php echo esc_html( $booking_details["place_order"]["cost"] ); ?></td>
            </tr>
        </tbody>
    </table>
    <button type="button" id="wte-midtrans-snap-pay">Continue to payment</button>
</div>

<script>
    jQuery(document).ready(function(){
        snap.pay('<?php echo $_GET['snap_token']; ?>' )

        jQuery('#wte-midtrans-snap-pay').click(function(event){
            event.preventDefault();
            snap.pay('<?php echo $_GET['snap_token']; ?>' );
        });
    });
</script>

<?php
get_sidebar();
get_footer();
