<?php

/**
 * Helper functions.
 *
 * @link       https://wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Midtrans
 * @subpackage Wte_Midtrans/includes
 */

/**
 * Helper Functions
 *
 * @package    Wte_Midtrans
 * @subpackage Wte_Midtrans/includes
 * @author     WP Travel Engine <support@wptravelengine.com>
 */
final class Wte_Midtrans_Helper {
	/**
	 * Instance variable.
	 *
	 * @since 1.0.0
	 * @static
	 * @access private
	 *
	 * @var Wte_Midtrans_Helper
	 */
	private static $_instance = null;

	/**
	 * Get the instance.
	 *
	 * @since 1.0.0
	 * @static
	 * @access public
	 *
	 * @return Wte_Midtrans_Helper
	 */
	public static function get_instance() {
		if ( null === self::$_instance ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 * @access private
	 */
	private function __construct() {}

	/**
	 * Get settings.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Settings.
	 */
	public function get_settings() {
		$wte_settings = get_option( 'wp_travel_engine_settings' );

		if ( ! isset( $wte_settings['midtrans']['merchant_id'] ) ) {
			$wte_settings['midtrans']['merchant_id'] = '';
		}

		if ( ! isset( $wte_settings['midtrans']['server_key'] ) ) {
			$wte_settings['midtrans']['server_key'] = '';
		}

		if ( ! isset( $wte_settings['midtrans']['client_key'] ) ) {
			$wte_settings['midtrans']['client_key'] = '';
		}

		if ( ! isset( $wte_settings['midtrans']['3ds_enabled'] ) ) {
			$wte_settings['midtrans']['3ds_enabled'] = '0';
		}

		if ( ! isset( $wte_settings['midtrans']['save_card_enabled'] ) ) {
			$wte_settings['midtrans']['save_card_enabled'] = '0';
		}

		$midtrans = array(
			'merchant_id'       => trim( $wte_settings['midtrans']['merchant_id'] ),
			'server_key'        => trim( $wte_settings['midtrans']['server_key'] ),
			'client_key'        => trim( $wte_settings['midtrans']['client_key'] ),
			'3ds_enabled'       => trim( $wte_settings['midtrans']['3ds_enabled'] ),
			'save_card_enabled' => trim( $wte_settings['midtrans']['save_card_enabled'] ),
		);

		return $midtrans;
	}

	/**
	 * Check whether the debug is enabled or not.
	 *
	 * @access public
	 * @since 1.0.0
	 *
	 * @return boolean
	 */
	public function is_debug_enabled() {
		$wte_settings = get_option( 'wp_travel_engine_settings', array() );

		return isset( $wte_settings['payment_debug'] ) && 'yes' === $wte_settings['payment_debug'];
	}

	/**
	 * Check whether the midtrans is enabled or not.
	 *
	 * @access public
	 * @since 1.0.0
	 *
	 * @return boolean
	 */
	public function is_enabled() {
		$wte_settings = get_option( 'wp_travel_engine_settings' );

		if ( ! isset( $wte_settings['midtrans_enable'] ) ) {
			return false;
		}

		if ( '1' !== $wte_settings['midtrans_enable'] ) {
			return false;
		}

		return true;
	}

	/**
	 * Get merchant id.
	 *
	 * @access public
	 * @since 1.0.0
	 *
	 * @return string Merchant ID.
	 */
	public function get_merchant_id() {
		$settings = $this->get_settings();

		return trim( $settings['merchant_id'] );
	}

	/**
	 * Get server key.
	 *
	 * @access public
	 * @since 1.0.0
	 *
	 * @return string Server Key.
	 */
	public function get_server_key() {
		$settings = $this->get_settings();

		return trim( $settings['server_key'] );
	}

	/**
	 * Get client key.
	 *
	 * @access public
	 * @since 1.0.0
	 *
	 * @return string Client Key.
	 */
	public function get_client_key() {
		$settings = $this->get_settings();

		return trim( $settings['client_key'] );
	}

	/**
	 * Get snap token.
	 *
	 * @access public
	 * @since 1.0.0
	 *
	 * @return string Snap token.
	 */
	public function get_snap_token( $transaction ) {
		\Midtrans\Config::$serverKey    = $this->get_server_key();
		\Midtrans\Config::$isProduction = ! $this->is_debug_enabled();
		\Midtrans\Config::$isSanitized  = true;
		\Midtrans\Config::$is3ds        = $this->is_3ds_enabled();

		$snap_token = \Midtrans\Snap::getSnapToken( $transaction );
		return $snap_token;
	}

	/**
	 * Check whether the 3ds is enabled or not.
	 *
	 * @access public
	 * @since 1.0.0
	 * @return boolean
	 */
	public function is_3ds_enabled() {
		$settings = $this->get_settings();

		if ( '1' === $settings['3ds_enabled'] ) {
			return true;
		}
		return false;
	}

	/**
	 * Check whether the save card is enabled or not.
	 *
	 * @access public
	 * @since 1.0.0
	 * @return boolean
	 */
	public function is_save_card_enabled() {
		$settings = $this->get_settings();

		if ( '1' === $settings['save_card_enabled'] ) {
			return true;
		}
		return false;
	}

	/**
	 * Get error messages from error code.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param int $status_code Status code.
	 * @return string Error message
	 */
	public function get_error_message( $status_code ) {
		$error = array(
			'400' => __( 'Validation Error, merchant sent bad request data example; validation error, invalid transaction type, invalid credit card format, etc.', 'wte-midtrans' ),
			'401' => __( 'Access denied due to unauthorized transaction, please check client key, server key or payment debug is enabled or not.', 'wte-midtrans' ),
			'402' => __( 'Merchant doesn\'t have access for this payment type', 'wte-midtrans' ),
			'403' => __( 'The requested resource is only capable of generating content not acceptable according to the accepting headers that sent in the request', 'wte-midtrans' ),
			'404' => __( 'The requested resource/transaction is not found (eg. order_id is not exist)', 'wte-midtrans' ),
			'405' => __( 'Http method is not allowed', 'wte-midtrans' ),
			'406' => __( 'Duplicate order ID. Order ID has already been utilized previously', 'wte-midtrans' ),
			'407' => __( 'Expired transaction', 'wte-midtrans' ),
			'408' => __( 'Merchant sent the wrong data type', 'wte-midtrans' ),
			'409' => __( 'Merchant has sent too many transactions for the same card number', 'wte-midtrans' ),
			'410' => __( 'Merchant account is deactivated. Please contact Midtrans support', 'wte-midtrans' ),
			'411' => __( 'Token id is missing, invalid, or timed out', 'wte-midtrans' ),
			'412' => __( 'Merchant cannot modify status of the transaction', 'wte-midtrans' ),
			'413' => __( 'The request cannot be processed due to malformed syntax in the request body', 'wte-midtrans' ),
			'414' => __( 'Refund request is rejected due to invalid amount', 'wte-midtrans' ),
		);

		return $error[ $status_code ];
	}
}
