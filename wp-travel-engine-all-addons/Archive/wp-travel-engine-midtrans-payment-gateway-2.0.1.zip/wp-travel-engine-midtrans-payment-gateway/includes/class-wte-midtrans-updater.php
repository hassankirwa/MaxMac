<?php

/**
 * Handle initializaiton of EDD updater.
 *
 * @link       https://wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Midtrans
 * @subpackage Wte_Midtrans/includes
 */

/**
 * Register all actions and filters for the plugin.
 *
 * @package    Wte_Midtrans
 * @subpackage Wte_Midtrans/includes
 * @author     WP Travel Engine <support@wptravelengine.com>
 */
class Wte_Midtrans_Updater {

    /**
     * Instance variable.
     *
     * @since 1.0.0
     * @access private
     * 
     * @var Wte_Midtrans_Updater Single instance of the class.
     */
    private static $_instance = null;

    /**
     * Constructor.
     * 
     * @since 1.0.0
     * @access public
     * 
     * @return void
     */
    private function __construct() {
        $this->init();
    }

    /**
     * Get the instance of the class
     *
     * @since 1.0.0
     * @static
     * @access public
     * 
     * @return void
     */
    public static function get_instance() {
        if ( null === self::$_instance ) {
            self::$_instance = new self();
        }

        return self::$_instance;
    }

    /**
     * Initialization
     *
     * @since 1.0.0
     * @access private
     * @return void
     */
    private function init() {
        /**
         * Includes the files needed for the plugin updater.
         *
         * @since 1.0.0
         */
        if ( ! class_exists( 'EDD_SL_Plugin_Updater' ) ) {
            require_once plugin_dir_path( WTE_MIDTRANS_ABSPATH ) . 'lib/edd/EDD_SL_Plugin_Updater.php';
        }        
    }

    /**
     * Setup the updater for the WTE Extra Services Add-on.
     *
     * @since 1.0.0
     * @access public
     * @return void
     */
    public function wte_extra_services_updater() {
        if ( ! defined( 'WP_TRAVEL_ENGINE_STORE_URL' ) ) {
            return;
        }

        // Retrieve our license key from the DB
        $settings = get_option( 'wp_travel_engine_license' );

        $license_key = '';
        if ( isset ( $settings['wte_midtrans_license_key' ] ) ) {
            $license_key = $settings['wte_midtrans_license_key' ];
        }


        // Setup the updater
        $edd_updater = new EDD_SL_Plugin_Updater(
            WP_TRAVEL_ENGINE_STORE_URL, 
            WTE_MIDTRANS_ABSPATH,
            array(
                'version' => WTE_MIDTRANS_VERSION, 
                'license' => $license_key,             
                'item_id' => WTE_MIDTRANS_ID,
                'author'  => 'WP Travel Engine',
                'beta'    => false,
            )
        );
    }

    /**
     * Add-on name for plugin license page.
     * 
     * @since 1.0.0
     * @access public
     *
     * @param array $array Addons list.
     * 
     * @return array Modified addons list.
     */
    public function add_to_license_page( $addons ) {
        $addons['WP Travel Engine - Midtrans Payment Gateway'] = 'wte_midtrans';
        return $addons;
    }

    /**
     * Add-ons Item ID for plugin license page.
     * 
     * @since 1.0.0
     * @access public
     * 
     * @param array $array List of addons ids.
     * @return array Modified list of addons ids.
     */
    public function add_item_id( $array ) {
        $array['wte_midtrans'] = WTE_MIDTRANS_ID;
        return $array;
    }
}
