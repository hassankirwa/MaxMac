<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Midtrans
 * @subpackage Wte_Midtrans/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Wte_Midtrans
 * @subpackage Wte_Midtrans/includes
 * @author     WP Travel Engine <support@wptravelengine.com>
 */
class Wte_Midtrans {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Wte_Midtrans_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {
		if ( defined( 'WTE_MIDTRANS_VERSION' ) ) {
			$this->version = WTE_MIDTRANS_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->plugin_name = 'wte-midtrans';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();
	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Wte_Midtrans_Loader. Orchestrates the hooks of the plugin.
	 * - Wte_Midtrans_i18n. Defines internationalization functionality.
	 * - Wte_Midtrans_Admin. Defines all hooks for the admin area.
	 * - Wte_Midtrans_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies() {

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wte-midtrans-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wte-midtrans-i18n.php';

		/**
		 * The class responsible for ajax requests.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wte-midtrans-ajax.php';

		/**
		 * The class containing helper functions.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wte-midtrans-helper.php';

		/**
		 * EDD updater.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wte-midtrans-updater.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-wte-midtrans-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-wte-midtrans-public.php';

		$this->loader = new Wte_Midtrans_Loader();

	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Wte_Midtrans_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Wte_Midtrans_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {

		$plugin_admin = new Wte_Midtrans_Admin( $this->get_plugin_name(), $this->get_version() );
		$ajax         = Wte_Midtrans_Ajax::get_instance();
		$updater      = Wte_Midtrans_Updater::get_instance();

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );

		$this->loader->add_action( 'admin_notices', $plugin_admin, 'check_dependency' );

		// Get midtrans snap token.
		$this->loader->add_action( 'wp_ajax_wte_midtrans_get_snap_token', $ajax, 'get_snap_token' );
		$this->loader->add_action( 'wp_ajax_nopriv_wte_midtrans_get_snap_token', $ajax, 'get_snap_token' );

		// Add to payment gateway list.
		$this->loader->add_filter( 'wp_travel_engine_available_payment_gateways', $plugin_admin, 'add_to_gateway_list' );
		// Display payment gateway settings.
		$this->loader->add_action( 'wp_travel_engine_payment_gateways_settins', $plugin_admin, 'display_settings' );

		// Initialize EDD Updater.
		$this->loader->add_action( 'admin_init', $updater, 'wte_extra_services_updater', 0 );
		// Add addon name in the wp travel engine plugin license page.
		$this->loader->add_filter( 'wp_travel_engine_addons', $updater, 'add_to_license_page' );
		// Add addon item id for plugin license page.
		$this->loader->add_filter( 'wp_travel_engine_addons_id', $updater, 'add_item_id' );

		// Check midtrans keys
		$this->loader->add_action( 'admin_notices', $plugin_admin, 'check_midtrans_keys' );

		// add to global new backend UI
		$this->loader->add_filter( 'wpte_settings_get_global_tabs', $plugin_admin, 'add_global_settings' );
	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {

		$plugin_public = new Wte_Midtrans_Public( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );

		$this->loader->add_filter( 'script_loader_tag', $plugin_public, 'modify_script_tag', 10, 3 );

		// Get the snap token.
		$this->loader->add_action( 'wp_travel_engine_after_booking_process_completed', $plugin_public, 'start_snap_process' );
		// Display page for the snap process.
		$this->loader->add_action( 'init', $plugin_public, 'display_snap_page' );
		// Handle payment notification.
		$this->loader->add_action( 'init', $plugin_public, 'handle_payment_notificaton' );

	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Wte_Midtrans_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}
}
