<?php

/**
 * Handle ajax requests.
 *
 * @link       https://wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Midtrans
 * @subpackage Wte_Midtrans/includes
 */

/**
 * Handle ajax requests.
 * @package    Wte_Midtrans
 * @subpackage Wte_Midtrans/includes
 * @author     WP Travel Engine <support@wptravelengine.com>
 */
final class Wte_Midtrans_Ajax {
    /**
     * Instance variable.
     *
     * @since 1.0.0
     * @static
     * @access private
     * 
     * @var Wte_Midtrans_Ajax
     */
    private static $_instance = null;

    /**
     * Get the instance.
     *
     * @since 1.0.0
     * @static
     * @access public
     * 
     * @return Wte_Midtrans_Helper
     */
    public static function get_instance() {
        if ( null === self::$_instance ) {
            self::$_instance = new self;
        }

        return self::$_instance;
    }

    /**
     * Constructor.
     * 
     * @since 1.0.0
     * @access private
     */
    private function __construct() {}

    /**
     * Get snap token.
     *
     * @param int $order_id Order Id.
     * @return string Snap Token.
     */
    public function get_snap_token( $order_id = null ) {
        $helper = Wte_Midtrans_Helper::get_instance();
        
        if ( isset( $_REQUEST['order_id'] ) ) {
            $order_id = intval( $_REQUEST['order_id'] );
        }

        if ( null === $order_id ) {
            $order_id = rand();
        }

		$settings = $helper->get_settings();

		\Midtrans\Config::$serverKey = $settings['midtrans_server_key'];
		\Midtrans\Config::$isProduction = ! $helper->is_debug_enabled();
		\Midtrans\Config::$isSanitized = true;
		\Midtrans\Config::$is3ds = true;

		$transaction = array(
			'transaction_details' => array(
				'order_id'     => $order_id,
				'gross_amount' => 999
			),
		);

        try {
            $snapToken = \Midtrans\Snap::getSnapToken($transaction);
        } catch( Exception $e) {
            wp_send_json_error( 'Unable to get snap token', 401);
            exit;
        }
        
        wp_send_json_success( array(
            'snapToken' => $snapToken
        ));
        exit;
    }
}
