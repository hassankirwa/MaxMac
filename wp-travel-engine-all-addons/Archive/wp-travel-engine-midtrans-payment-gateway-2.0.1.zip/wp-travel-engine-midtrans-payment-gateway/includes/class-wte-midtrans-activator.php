<?php

/**
 * Fired during plugin activation
 *
 * @link       https://wptravelengine.com
 * @since      1.0.0
 *
 * @package    Wte_Midtrans
 * @subpackage Wte_Midtrans/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wte_Midtrans
 * @subpackage Wte_Midtrans/includes
 * @author     WP Travel Engine <support@wptravelengine.com>
 */
class Wte_Midtrans_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		$version = get_option( 'wte_midtrans_version' );

		if ( false === $version ) {
			update_option( 'wte_midtrans_version', WTE_MIDTRANS_VERSION );
		}
	}
}
