=== WP Travel Engine - Midtrans Payment Gateway ===
Contributors: wptravelengine
Plugin link: https://wptravelengine.com/
Tags: tour-booking, tour-operator, travel, travel-booking, travel-agency, travel-engine
Requires at least: 4.4.0
Tested up to: 6.2.2
Requires PHP: 5.6
Stable tag: 2.0.1
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Midtrans payment gateway for WP Travel Engine.

== Description ==

Midtrans payment gateway for WP Travel Engine.

Midtrans payment gateway requires WP Travel Engine plugin v. 4.0.0 or later installed and activated in the site.

== Changelog ==

= 2.0.1 =

Released on: 10th July, 2023

Enhancements:

* Sends customer details to midtrans dashboard.
* Payment Issue.

Fixes:

* Minor typo fixes.

= 2.0.0 =

Released on: 11th June, 2020

Enhancements:

* Revamped backend UI.
* Assets minification, optimization, and conditional loading.

Fixes:

* Minor bug fixes.

= 1.0.0 =

* Initial Release