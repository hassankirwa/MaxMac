=== WP Travel Engine - User History ===
Contributors: wptravelengine
Plugin link: https://wptravelengine.com/
Tags: tour-booking, tour-operator, travel, travel-booking, travel-agency
Requires at least: 4.4.0
Tested up to: 5.4
Requires PHP: 5.6
Stable tag: 2.1.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

WP Travel Engine User History plugin tracks and displays the user browsing history before the user actually books or sends an enquiry to trip. After successful booking or enquiry, user browsing history for each of the pages visited prior to the booking and enquiry is saved with timestamps and displayed in Admin Dashboard.

== Description ==

WP Travel Engine User History plugin tracks and displays the user browsing history before the user actually books or sends an enquiry to trip. After successful booking or enquiry, user browsing history for each of the pages visited prior to the booking and enquiry is saved with timestamps and displayed in Admin Dashboard.

WP Travel Engine User History addon requires WP Travel Engine plugin v. 4.0.0 or later installed and activated in the site.

== Changelog ==

= 2.1.0 =
Released on: 24th March, 2022
* Fix: Layout radio click
* Compatibility updates for WTE 5.0+
* Minor bug fixes

= 2.0.0 =

Released on: 11th June, 2020

Enhancements:

* Revamped backend UI.
* Assets minification, optimization, and conditional loading.

Fixes:

* Minor bug fixes.

= 1.0.2 =

Released on: 7th April, 2020

Enhancements:

* Compatibility check for WordPress 5.4.
* Requirements check for WP Travel Engine.

Fixes:

* Minor bug fixes.

= 1.0.1 =

Released on: 12th November, 2019

Fixes:

* Minor bug fixes.
