<?php

$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings' );
$option                    = isset( $wp_travel_engine_settings['user_history']['disable'] ) ? esc_attr( $wp_travel_engine_settings['user_history']['disable'] ) : '';

$cookie_settings_defaults = array(
	'position'            => 'bottom-left',
	'layout'              => 'block',
	'banner_bg'           => '#000000',
	'button_bg'           => '#f1d600',
	'content_text_col'    => '#ffffff',
	'button_text_col'     => '#000000',
	'learn_more_link'     => false,
	'policy_link_text'    => __( 'Learn more', 'wte-user-history' ),
	'consent_message'     => __( 'This website uses cookies to ensure you get the best experience on our website.', 'wte-user-history' ),
	'dismiss_button_text' => __( 'Got it!', 'wte-user-history' ),
);

$cookie_settings = isset( $wp_travel_engine_settings['user_history']['cookie_consent'] ) ? stripslashes_deep( $wp_travel_engine_settings['user_history']['cookie_consent'] ) : $cookie_settings_defaults;

// Cookie Consent data
$enable_cookie_consent = isset( $wp_travel_engine_settings['user_history']['cookie_consent']['enable'] ) ? esc_attr( $wp_travel_engine_settings['user_history']['cookie_consent']['enable'] ) : '';
?>
	<div class="group-status-options">

		<div class="wpte-field wpte-checkbox advance-checkbox">
			<label class="wpte-field-label" for="wp_travel_engine_settings[user_history][disable]"><?php _e( 'Disable user history tracking', 'wte-user-history' ); ?></label>
			<div class="wpte-checkbox-wrap">
					<input type="checkbox" name="wp_travel_engine_settings[user_history][disable]" class="disable_notif" id="wp_travel_engine_settings[user_history][disable]" value="1" <?php echo checked( '1', $option ); ?>/>
			<label for="wp_travel_engine_settings[user_history][disable]" class="checkbox-label"></label>
			</div>
			<span class="wpte-tooltip"><?php _e( 'Check this if you want to track user browsing history and data to display on bookings and enquiries.', 'wte-user-history' ); ?></span>
		</div>
		<div class="wpte-field wpte-checkbox advance-checkbox">
			<label class="wpte-field-label" for="wp_travel_engine_settings[user_history][cookie_consent][enable]"><?php _e( 'Enable cookie consent message', 'wte-user-history' ); ?></label>
			<div class="wpte-checkbox-wrap">
				<input type="checkbox" name="wp_travel_engine_settings[user_history][cookie_consent][enable]" class="disable_notif" id="wp_travel_engine_settings[user_history][cookie_consent][enable]" value="1" <?php echo checked( '1', $enable_cookie_consent ); ?>/>
			<label for="wp_travel_engine_settings[user_history][cookie_consent][enable]" class="checkbox-label"></label>
			</div>
			<span class="wpte-tooltip"><?php _e( 'Check this if you want to show cookie collection information on the website frontend.', 'wte-user-history' ); ?></span>
		</div>
		<div id="cookie-consent-options"  class="group-dates-options">
			<div class="wpte-field wpte-select wpte-floated">
				<label class="wpte-field-label" for="wp_travel_engine_settings[user_history][cookie_consent][position]"><?php _e( 'Cookie consent message position', 'wte-user-history' ); ?></label>
					<select name="wp_travel_engine_settings[user_history][cookie_consent][position]" id="wp_travel_engine_settings[user_history][cookie_consent][position]">
						<option <?php selected( 'top', $cookie_settings['position'] ); ?> value="top"><?php echo esc_attr( __( 'Top', 'wte-user-history' ) ); ?></option>
						<option <?php selected( 'bottom', $cookie_settings['position'] ); ?> value="bottom"><?php echo esc_attr( __( 'Bottom', 'wte-user-history' ) ); ?></option>
						<option <?php selected( 'bottom-right', $cookie_settings['position'] ); ?> value="bottom-right"><?php echo esc_attr( __( 'Bottom-Right', 'wte-user-history' ) ); ?></option>
						<option <?php selected( 'bottom-left', $cookie_settings['position'] ); ?> value="bottom-left"><?php echo esc_attr( __( 'Bottom-Left', 'wte-user-history' ) ); ?></option>
					</select>
				<span class="wpte-tooltip"><?php _e( 'This lets you choose the position of the cookie consent popup-up message.', 'wte-user-history' ); ?></span>
			</div>

			<div class="wp_travel_engine_settings wpte-field wpte-block-selector">
				<label class="wpte-field-label"><?php _e( 'Cookie consent message layout', 'wte-user-history' ); ?></label>
				<span class="wpte-tooltip"><?php _e( 'This lets you choose the layout of the cookie consent popup-up message.', 'wte-user-history' ); ?></span>
				<div class="wteuh-hiddenradio wpte-block-select-wrap">
					<div class="wpte-select-block">
						<label>
							<input <?php checked( 'block', $cookie_settings['layout'] ); ?> type="radio" name="wp_travel_engine_settings[user_history][cookie_consent][layout]" value="block">
							<img width="190" src="<?php echo WTE_USER_HISTORY_URL . '/assets/admin/images/cc-layout-block.jpg'; ?>">
						</label>
					</div>
					<div class="wpte-select-block">
						<label>
							<input <?php checked( 'edgeless', $cookie_settings['layout'] ); ?> type="radio" name="wp_travel_engine_settings[user_history][cookie_consent][layout]" value="edgeless">
							<img width="190" src="<?php echo WTE_USER_HISTORY_URL . '/assets/admin/images/cc-layout-edgeless.jpg'; ?>">
						</label>
					</div>
					<div class="wpte-select-block">
						<label>
							<input <?php checked( 'classic', $cookie_settings['layout'] ); ?> type="radio" name="wp_travel_engine_settings[user_history][cookie_consent][layout]" value="classic">
							<img width="190" src="<?php echo WTE_USER_HISTORY_URL . '/assets/admin/images/cc-layout-classic.jpg'; ?>">
						</label>
					</div>
					<div class="wpte-select-block">
						<label>
							<input <?php checked( 'wire', $cookie_settings['layout'] ); ?> type="radio" name="wp_travel_engine_settings[user_history][cookie_consent][layout]" value="wire">
							<img width="190" src="<?php echo WTE_USER_HISTORY_URL . '/assets/admin/images/cc-layout-wire.jpg'; ?>">
						</label>
					</div>
				</div>

			</div>

			<div class="wpte-field wpte-color-plate wpte-floated wte-uh-colwrap">
				<label class="wpte-field-label" for="wp_travel_engine_settings[user_history][cookie_consent][banner_bg]"><?php _e( 'Cookie consent banner background color', 'wte-user-history' ); ?></label>
				<input value="<?php echo esc_attr( $cookie_settings['banner_bg'] ); ?>" style="display:block;" class="wte-uh-colpckr" type="text" name="wp_travel_engine_settings[user_history][cookie_consent][banner_bg]" id="wp_travel_engine_settings[user_history][cookie_consent][banner_bg]">
				<span class="wpte-tooltip"><?php _e( 'Banner background color.', 'wte-user-history' ); ?></span>
			</div>

			<div class="wpte-field wpte-color-plate wpte-floated wte-uh-colwrap">
				<label class="wpte-field-label" for="wp_travel_engine_settings[user_history][cookie_consent][button_bg]"><?php _e( 'Cookie consent banner button color', 'wte-user-history' ); ?></label>
				<input value="<?php echo esc_attr( $cookie_settings['button_bg'] ); ?>" style="display:block;" class="wte-uh-colpckr" type="text" name="wp_travel_engine_settings[user_history][cookie_consent][button_bg]" id="wp_travel_engine_settings[user_history][cookie_consent][button_bg]">

			</div>

			<div class="wpte-field wpte-color-plate wpte-floated wte-uh-colwrap">
				<label class="wpte-field-label"  for="wp_travel_engine_settings[user_history][cookie_consent][content_text_col]"><?php _e( 'Cookie consent banner content text color', 'wte-user-history' ); ?></label>
				<input value="<?php echo esc_attr( $cookie_settings['content_text_col'] ); ?>" style="display:block;" class="wte-uh-colpckr" type="text" name="wp_travel_engine_settings[user_history][cookie_consent][content_text_col]" id="wp_travel_engine_settings[user_history][cookie_consent][content_text_col]">
				<span class="wpte-tooltip"><?php _e( 'Cookie consent banner content text color.', 'wte-user-history' ); ?></span>
			</div>

			<div class="wpte-field wpte-color-plate wpte-floated wte-uh-colwrap">
				<label class="wpte-field-label"  for="wp_travel_engine_settings[user_history][cookie_consent][button_text_col]"><?php _e( 'Cookie consent banner button text color', 'wte-user-history' ); ?></label>
				<input value="<?php echo esc_attr( $cookie_settings['button_text_col'] ); ?>" style="display:block;" class="wte-uh-colpckr" type="text" name="wp_travel_engine_settings[user_history][cookie_consent][button_text_col]" id="wp_travel_engine_settings[user_history][cookie_consent][button_text_col]">
				<span class="wpte-tooltip"><?php _e( 'Banner button text color.', 'wte-user-history' ); ?></span>
			</div>

			<div class="wpte-field wpte-url wpte-floated">
				<label class="wpte-field-label" for="wp_travel_engine_settings[user_history][cookie_consent][learn_more_link]"><?php _e( 'Cookie consent learn more link URL', 'wte-user-history' ); ?></label>
				<input value="<?php echo esc_attr( $cookie_settings['learn_more_link'] ); ?>" type="text" name="wp_travel_engine_settings[user_history][cookie_consent][learn_more_link]" id="wp_travel_engine_settings[user_history][cookie_consent][learn_more_link]">
				<span class="wpte-tooltip"><?php _e( 'learn more link URL.', 'wte-user-history' ); ?></span>
			</div>

			<div class="wpte-field wpte-url wpte-floated">
				<label class="wpte-field-label" for="wp_travel_engine_settings[user_history][cookie_consent][consent_message]"><?php _e( 'Cookie consent custom message', 'wte-user-history' ); ?></label>
				<textarea rows="8" cols="100" style="display:block;" name="wp_travel_engine_settings[user_history][cookie_consent][consent_message]" id="wp_travel_engine_settings[user_history][cookie_consent][consent_message]"><?php echo wp_strip_all_tags( $cookie_settings['consent_message'] ); ?></textarea>
				<span class="wpte-tooltip"><?php _e( 'custom message', 'wte-user-history' ); ?></span>
			</div>

			<div class="wpte-field wpte-url wpte-floated">
				<label class="wpte-field-label" for="wp_travel_engine_settings[user_history][cookie_consent][dismiss_button_text]"><?php _e( 'Dismiss button text', 'wte-user-history' ); ?></label>
				<input value="<?php echo esc_attr( $cookie_settings['dismiss_button_text'] ); ?>" type="text" name="wp_travel_engine_settings[user_history][cookie_consent][dismiss_button_text]" id="wp_travel_engine_settings[user_history][cookie_consent][dismiss_button_text]">
				<span class="wpte-tooltip"><?php _e( 'Dismiss button text', 'wte-user-history' ); ?></span>
			</div>

			<div class="wpte-field wpte-url wpte-floated">
				<label class="wpte-field-label" for="wp_travel_engine_settings[user_history][cookie_consent][policy_link_text]"><?php _e( 'Policy link text', 'wte-user-history' ); ?></label>
				<input value="<?php echo esc_attr( $cookie_settings['policy_link_text'] ); ?>" type="text" name="wp_travel_engine_settings[user_history][cookie_consent][policy_link_text]" id="wp_travel_engine_settings[user_history][cookie_consent][policy_link_text]">
				<span class="wpte-tooltip"><?php _e( 'Policy link text', 'wte-user-history' ); ?></span>
			</div>

			<?php
			if ( class_exists( 'GFFormsModel' ) ) {

				$selected_forms = isset( $wp_travel_engine_settings['user_history']['capture_gravity_forms'] ) ? stripslashes_deep( $wp_travel_engine_settings['user_history']['capture_gravity_forms'] ) : array();
				?>

				<div class="wp_travel_engine_settings_pages wpte-field wpte-select wpte-floated">
					<label class="wpte-field-label" for="wp_travel_engine_settings[user_history][capture_gravity_forms][]"><?php _e( 'Gravity form(s) to capture user history:', 'wte-user-history' ); ?></label>
					<select multiple="multiple" name="wp_travel_engine_settings[user_history][capture_gravity_forms][]" id="wp_travel_engine_settings[user_history][capture_gravity_forms][]">
						<?php
						foreach ( \GFFormsModel::get_forms() as $form ) :
							?>
							<option <?php echo in_array( $form->id, $selected_forms ) ? 'selected' : ''; ?> value="<?php echo esc_attr( $form->id ); ?>"><?php echo esc_html( $form->title ); ?></option>

						<?php endforeach; ?>
					</select>
					<span class="wpte-tooltip"><?php _e( 'Choose the gravity forms that will save user browsing history upon submission.', 'wte-user-history' ); ?></span>
				</div>
			<?php } ?>
		</div>
	</div>
