<?php
/**
 * Updates page - add code if update required functionality.
 * 
 * @package WTE_User_History
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
