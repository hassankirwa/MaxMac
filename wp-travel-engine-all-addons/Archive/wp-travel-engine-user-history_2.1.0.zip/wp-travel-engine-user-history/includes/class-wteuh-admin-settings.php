<?php
/**
 * WP Tarvel Engine user history admin global settings.
 *
 * @package WTE User History
 * @author  WP Travel Engine
 */

class WTEUH_admin_settings {

	/**
	 * Fire up the engines.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
        
        //add_action( 'wte_addons_global_settings', array( $this, 'user_history_global_settings' ) );
         add_filter( 'wpte_get_global_extensions_tab', array($this,'user_history_global_settings' ), 10, 3 );
        
	}

	/**
	 * Settings block for global settings.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 * Older parameter :  $booking
	 * New Parater: 
	 */
	public function user_history_global_settings($sub_tabs) {
        $sub_tabs['wte_user_history'] = array(
            'label'        => __( 'User History', 'wte-user-history' ),
            'content_path' => WTE_USER_HISTORY_DIR.'includes/admin/partials/wte-user-history-global-setting.php',
            'current' => false
         );
        return $sub_tabs;
	}

}
$WTEUH_admin_settings = new WTEUH_admin_settings();