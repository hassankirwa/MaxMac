<?php
/**
 * Functionality for viewing customer history.
 *
 * @package WTE User History
 * @author  WP Travel Engine
 */

class WTEUH_Show_History {

	/**
	 * Fire up the engines.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {

		add_filter( 'wte_booking_reciept_email_content', array( $this, 'render_email_tag_output' ), 10, 2 );

		// add_action( 'add_meta_boxes', array( $this, 'wpte_booking_user_history_add_meta_boxes' ) );
		add_action( 'add_meta_boxes', array( $this, 'wpte_enquiry_user_history_add_meta_boxes' ) );

		add_action( 'wte_additional_booking_email_tags', array( $this, 'register_email_tags' ) );

		// Gravity forms support add metabox
		add_filter( 'gform_entry_detail_meta_boxes', array( $this, 'gravity_forms_register_meta_box' ), 10, 3 );

		add_action( 'wp_travel_engine_booking_screen_after_personal_details', array( $this, 'render_browsing_history' ) );

		add_filter( 'wte_booking_mail_tags', array( $this, 'add_mail_tag' ), 11, 2 );
	}

	/**
	 *
	 * @since 2.1.0
	 */
	public function add_mail_tag( $mail_tags, $payment_id ) {
		$booking_id                  = get_post_meta( $payment_id, 'booking_id', true );
		$mail_tags['{user_history}'] = self::mail_tag_content( $booking_id );
		return $mail_tags;
	}

	/**
	 * Add custom metabox to display the user browser history on the booking page.
	 *
	 * @return void
	 */
	public function wpte_booking_user_history_add_meta_boxes() {

		$screens = array( 'booking' );
		foreach ( $screens as $screen ) {
			add_meta_box(
				'booking_user_history',
				__( 'Customer Browsing History', 'wte-user-history' ),
				array( $this, 'render_browsing_history' ),
				$screen,
				'normal',
				'high'
			);
		}

	}

	/**
	 * Undocumented function
	 *
	 * @param [type] $meta_boxes
	 * @param [type] $entry
	 * @param [type] $form
	 * @return void
	 */
	public function gravity_forms_register_meta_box( $meta_boxes, $entry, $form ) {

		$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings' );

		$selected_forms = isset( $wp_travel_engine_settings['user_history']['capture_gravity_forms'] ) ? stripslashes_deep( $wp_travel_engine_settings['user_history']['capture_gravity_forms'] ) : array();

		if ( in_array( $form['id'], $selected_forms ) ) :

			$meta_boxes['customer_browsing_history'] = array(
				'title'    => __( 'Customer Browsing History', 'wte-user-history' ),
				'callback' => array( $this, 'render_browsing_history_gravity_forms' ),
				'context'  => 'normal',
			);

		endif;

		return $meta_boxes;

	}

	/**
	 * Add custom metabox to display the user browser history on the enquiry page.
	 *
	 * @return void
	 */
	public function wpte_enquiry_user_history_add_meta_boxes() {

		$screens = array( 'enquiry' );
		foreach ( $screens as $screen ) {
			add_meta_box(
				'enquiry_user_history',
				__( 'Customer Browsing History', 'wte-user-history' ),
				array( $this, 'render_browsing_history' ),
				$screen,
				'normal',
				'high'
			);
		}

	}

	/**
	 * Mail tag content.
	 *
	 * @since 2.1.0
	 */
	public static function mail_tag_content( $booking_id ) {
		$browsing_history = get_post_meta( $booking_id, 'user_history', true );

		$user_history_table = __( 'No user history data found', 'wte-user-history' );

		if ( ! empty( $browsing_history ) ) :

				$user_history_table = '';

				// Strip off the referring URL
				$referrer = array_shift( $browsing_history );

				// Output the referrer
				$user_history_table .= '<p>';
				$user_history_table .= sprintf( __( '<strong>Referrer:</strong> %s', 'wte-user-history' ), preg_replace( '/(Referrer:\s)?(http.+)?/', '<a href="$2" target="_blank">$2</a>', $referrer['url'] ) );
				$user_history_table .= '</p>';

				// If referrer was a search engine, output the query string the user used
				$search_history = wte_uh_get_users_search_query( $referrer['url'] );
			if ( $search_history ) {
				$user_history_table .= '<p>' . sprintf( __( 'Original search query: %s', 'wte-user-history' ), '<strong><mark>' . $search_history . '</mark></strong>' ) . '</p>';
			}

				$user_history_table .= '
				<table>
					<tr>
						<th>URL</th>
						<th>Timestamp</th>
						<th>Time Elasped</th>
						<th>Total</th>
					</tr>';
			foreach ( $browsing_history as $key => $history ) {
				// Don't output the very last item.
				// This is always the internal 'Order Complete' item.
				if ( end( $browsing_history ) == $history ) {
					continue;
				}
				$user_history_table .= '<tr>';
				$user_history_table .= '<td><a href="' . esc_url( $history['url'] ) . '" target="_blank">' . esc_url( $history['url'] ) . '</a></td>';

				if ( $history['time'] ) {
					$user_history_table .= '<td>' . date( 'Y/m/d \&\n\d\a\s\h\; h:i:sa', ( $history['time'] + get_option( 'gmt_offset' ) * 3600 ) ) . '</td>';
				} else {
					$user_history_table .= '<td>' . __( 'N/A', 'wte-user-history' ) . '</td>';
				}
					$next                = isset( $browsing_history[ $key + 1 ] ) ? $browsing_history[ $key + 1 ] : end( $browsing_history );
					$user_history_table .= '<td>' . wte_uh_calculate_elapsed_time( $history['time'], $next['time'] ) . '</td>';
					$user_history_table .= '<td>' . wte_uh_calculate_elapsed_time( $referrer['time'], $next['time'] ) . '</td>';
					$user_history_table .= '</tr>';
			}

				$user_history_table .= '</table>';

		endif;

		return $user_history_table;
	}

	/**
	 * Render ueser hostory.
	 *
	 * @param [type] $book_reciept
	 * @param [type] $booking_id
	 * @return void
	 */
	public function render_email_tag_output( $book_reciept, $booking_id ) {

		if ( ! $booking_id ) {
			return $book_reciept;
		}

		$book_reciept = str_replace( '{user_history}', self::mail_tag_content( $booking_id ), $book_reciept );

		return $book_reciept;

	}

	/**
	 * Output browsing history for gravity forms metabox.
	 *
	 * @since 1.0.0
	 *
	 * @param int $booking Booking post object.
	 *
	 * @return mixed string|bool Browsing history output or false if no POST is supplied.
	 */
	public function render_browsing_history_for_gf( $booking, $is_gf_entry = false ) {
		if ( isset( $booking->ID ) && ! absint( $booking->ID ) && ! $is_gf_entry ) {
			return false;
		}

		$booking_id = $is_gf_entry ? $booking : $booking->ID;

		$browsing_history = get_post_meta( $booking_id, 'user_history', true );

		$browsing_history = ! empty( $browsing_history ) ? wte_uh_normalize_history_array( $browsing_history ) : array();

		$screen = is_admin() ? get_current_screen() : '';

		$screen_name = isset( $screen->id ) ? $screen->id : __( 'request', 'wte-user-history' );

		if ( 'forms_page_gf_entries' === $screen_name ) {
			$screen_name = __( 'Gravity forms submission', 'wte-user-history' );
		}

		$output  = '';
		$output .= sprintf( '<p>%s</p>', __( 'List of all of the pages the customer visited, in page visit order, prior to completing this ' . esc_html( $screen_name ) . '.', 'wte-user-history' ) );

		if ( is_array( $browsing_history ) && ! empty( $browsing_history ) ) {
			// Strip off the referring URL
			$referrer = array_shift( $browsing_history );

			// Output the referrer
			$output .= '<p>';
			$output .= sprintf( __( '<strong>Referrer Page:</strong> %s', 'wte-user-history' ), preg_replace( '/(Referrer:\s)?(http.+)?/', '<a href="$2" target="_blank">$2</a>', $referrer['url'] ) );
			$output .= '</p>';

			// If referrer was a search engine, output the query string the user used
			$search_history = wte_uh_get_users_search_query( $referrer['url'] );
			if ( $search_history ) {
				$output .= '<p>' . sprintf( __( 'Original search query: %s', 'wte-user-history' ), '<strong><mark>' . $search_history . '</mark></strong>' ) . '</p>';
			}

			$output .= '<table style="width:100%; border:1px solid ' . $this->get_admin_color_scheme()[1] . ';" cellpadding="0" cellspacing="0" border="0">';
			$output .= '<tr>';
			$output .= '<th style="background:' . $this->get_admin_color_scheme()[1] . '; color:#fff; text-align:left; padding:10px; width:55%;">' . __( 'URL Visited', 'wte-user-history' ) . '</th>';
			$output .= '<th style="background:' . $this->get_admin_color_scheme()[1] . '; color:#fff; text-align:left; padding:10px; width:15%;">' . __( 'Timestamp', 'wte-user-history' ) . '</th>';
			$output .= '<th style="background:' . $this->get_admin_color_scheme()[1] . '; color:#fff; text-align:right; padding:10px; width:15%;">' . __( 'Time elapsed', 'wte-user-history' ) . '</th>';
			$output .= '<th style="background:' . $this->get_admin_color_scheme()[1] . '; color:#fff; text-align:right; padding:10px; width:15%;">' . __( 'Total Time', 'wte-user-history' ) . '</th>';
			$output .= '</tr>';

			foreach ( $browsing_history as $key => $history ) {
				// Don't output the very last item.
				// This is always the internal 'Order Complete' item.
				if ( end( $browsing_history ) == $history ) {
					continue;
				}

				// $alt    = $key % 2 ? ' style="background: #f7f7f7;"' : '';
				$alt     = '';
				$output .= '<tr' . $alt . '>';
				$output .= '<td style="text-align:left; padding:10px;">' . ( $key + 1 ) . '. <a href="' . esc_url( $history['url'] ) . '" target="_blank">' . esc_url( $history['url'] ) . '</a></td>';
				if ( $history['time'] ) {
					$output .= '<td style="text-align:left; padding:10px;">' . date( 'Y/m/d \&\n\d\a\s\h\; h:i:sa', ( $history['time'] + get_option( 'gmt_offset' ) * 3600 ) ) . '</td>';
				} else {
					$output .= '<td style="text-align:left; padding:10px;">' . __( 'N/A', 'wte-user-history' ) . '</td>';
				}
				$next    = isset( $browsing_history[ $key + 1 ] ) ? $browsing_history[ $key + 1 ] : end( $browsing_history );
				$output .= '<td style="text-align:right; padding:10px;">' . wte_uh_calculate_elapsed_time( $history['time'], $next['time'] ) . '</td>';
				$output .= '<td style="text-align:right; padding:10px;">' . wte_uh_calculate_elapsed_time( $referrer['time'], $next['time'] ) . '</td>';
				$output .= '</tr>';
			}
			$output .= '</table>';

			// Output total elapsed time
			$final_entry = end( $browsing_history );
			$output     .= '<p style="text-align:right;">';
			$output     .= sprintf( __( '<strong>Total time spent on site:</strong> %s', 'wte-user-history' ), wte_uh_calculate_elapsed_time( $referrer['time'], $final_entry['time'] ) );
			$output     .= '</p>';

		} else {
			$output .= '<p><em>' . __( 'No page history collected.', 'wte-user-history' ) . '</em></p>';
		}

		echo $output;
	}

	/**
	 * Output browsing history for metabox and email.
	 *
	 * @since 1.0.0
	 *
	 * @param int $booking Booking post object.
	 *
	 * @return mixed string|bool Browsing history output or false if no POST is supplied.
	 */
	public function render_browsing_history( $booking_id ) {

		if ( is_object( $booking_id ) ) {
			$booking_id = $booking_id->ID;
		}

		if ( ! absint( $booking_id ) ) {
			return false;
		}

		$browsing_history = get_post_meta( $booking_id, 'user_history', true );

		$browsing_history = ! empty( $browsing_history ) ? wte_uh_normalize_history_array( $browsing_history ) : array();

		$screen = is_admin() ? get_current_screen() : '';

		$screen_name = isset( $screen->id ) ? $screen->id : __( 'request', 'wte-user-history' );

		if ( 'forms_page_gf_entries' === $screen_name ) {
			$screen_name = __( 'Gravity forms submission', 'wte-user-history' );
		}

		$output  = '';
		$output .= sprintf( '<p>%s</p>', __( 'List of all of the pages the customer visited, in page visit order, prior to completing this ' . esc_html( $screen_name ) . '.', 'wte-user-history' ) );

		if ( is_array( $browsing_history ) && ! empty( $browsing_history ) ) {
			// Strip off the referring URL
			$referrer = array_shift( $browsing_history );

			// Output the referrer
			$output .= '<p>';
			$output .= sprintf( __( '<strong>Referrer Page:</strong> %s', 'wte-user-history' ), preg_replace( '/(Referrer:\s)?(http.+)?/', '<a href="$2" target="_blank">$2</a>', $referrer['url'] ) );
			$output .= '</p>';

			// If referrer was a search engine, output the query string the user used
			$search_history = wte_uh_get_users_search_query( $referrer['url'] );
			if ( $search_history ) {
				$output .= '<p>' . sprintf( __( 'Original search query: %s', 'wte-user-history' ), '<strong><mark>' . $search_history . '</mark></strong>' ) . '</p>';
			}

			$output .= '<table class="wpte-table">';
			$output .= '<thead>
							<tr>
								<th class="wpte-leftalign">' . __( 'URL Visited', 'wte-user-history' ) . '</th>
								<th class="wpte-centeralign">' . __( 'Timestamp', 'wte-user-history' ) . '</th>
								<th class="wpte-centeralign">' . __( 'Time elapsed', 'wte-user-history' ) . '</th>
								<th class="wpte-centeralign">' . __( 'Total Time', 'wte-user-history' ) . '</th>
							</tr>
						</thead><tbody>';

			foreach ( $browsing_history as $key => $history ) {
				// Don't output the very last item.
				// This is always the internal 'Order Complete' item.
				if ( end( $browsing_history ) == $history ) {
					continue;
				}

				// $alt    = $key % 2 ? ' style="background: #f7f7f7;"' : '';
				$alt     = '';
				$output .= '<tr' . $alt . '>';
				$output .= '<td class="wpte-leftalign">' . ( $key + 1 ) . '. <a href="' . esc_url( $history['url'] ) . '" target="_blank">' . esc_url( $history['url'] ) . '</a></td>';
				if ( $history['time'] ) {
					$output .= '<td class="wpte-centeralign" >' . date( 'Y/m/d \&\n\d\a\s\h\; h:i:sa', ( $history['time'] + get_option( 'gmt_offset' ) * 3600 ) ) . '</td>';
				} else {
					$output .= '<td class="wpte-centeralign" >' . __( 'N/A', 'wte-user-history' ) . '</td>';
				}
				$next    = isset( $browsing_history[ $key + 1 ] ) ? $browsing_history[ $key + 1 ] : end( $browsing_history );
				$output .= '<td class="wpte-centeralign">' . wte_uh_calculate_elapsed_time( $history['time'], $next['time'] ) . '</td>';
				$output .= '<td class="wpte-centeralign">' . wte_uh_calculate_elapsed_time( $referrer['time'], $next['time'] ) . '</td>';
				$output .= '</tr>';
			}
			// Output total elapsed time
			$final_entry = end( $browsing_history );
			$output     .= '</tbody>
			<tfoot>
				<tr>
					<td class="wpte-rightalign" colspan="4">
						' . sprintf( __( '<strong>Total time spent on site:</strong> %s', 'wte-user-history' ), wte_uh_calculate_elapsed_time( $referrer['time'], $final_entry['time'] ) ) . '
					</td>
				</tr>
			</tfoot></table>';

		} else {
			$output .= '<p><em>' . __( 'No page history collected.', 'wte-user-history' ) . '</em></p>';
		}
		echo '<div class="wpte-block-wrap wte-user-history">
				<div class="wpte-block">
					<div class="wpte-title-wrap">
						<h4 class="wpte-title">' . __( 'Customer Browsing History', 'wte-user-history' ) . '</h4>
					</div>
					<div class="wpte-block-content">';
						echo $output;
				echo '</div>
				</div>
			</div>';
	}

	/**
	 * Render browsing history for gravity forms entry.
	 *
	 * @param [type] $args
	 * @return void
	 */
	public function render_browsing_history_gravity_forms( $args ) {

		$booking_id = $args['entry']['id'];

		$this->render_browsing_history_for_gf( $args['entry']['id'], true );

	}

	/**
	 * Get current user's admin color scheme.
	 *
	 * @since  1.6.0
	 *
	 * @return array Hexadecimal colors.
	 */
	public function get_admin_color_scheme() {
		global $_wp_admin_css_colors;

		$color_scheme = sanitize_html_class( get_user_option( 'admin_color' ), 'fresh' );

		// It's possible to have a color scheme set that is no longer registered.
		if ( empty( $_wp_admin_css_colors[ $color_scheme ] ) ) {
			$color_scheme = 'fresh';
		}

		return $_wp_admin_css_colors[ $color_scheme ]->colors;
	}

	/**
	 * Register custom email tags.
	 *
	 * @since 1.0.0
	 */
	public function register_email_tags() {
		?>

		<h3><?php _e( 'User History Addon E-mail tags', 'wte-user-history' ); ?></h3>

		<ul>
			<li><li><?php _e( '{user_history} - Show buyer\'s browsing history before making the booking', 'wte-user-history' ); ?></li><br/></li>
		</ul>

		<?php
	}

	/**
	 * Output browsing history via email tag.
	 *
	 * @since  1.0.0
	 *
	 * @param  integer $payment_id Payment post ID.
	 *
	 * @return string              HTML markup.
	 */
	public function email_tag_browsing_history( $payment_id = 0 ) {
		$output  = '<h2>' . __( 'Customer Browsing History', 'wte-user-history' ) . '</h2>';
		$output .= $this->render_browsing_history( $payment_id );

		return $output;
	}

}
