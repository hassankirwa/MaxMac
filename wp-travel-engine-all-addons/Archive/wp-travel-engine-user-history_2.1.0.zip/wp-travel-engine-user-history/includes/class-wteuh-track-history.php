<?php
/**
 * Functionality for tracking and saving customer history.
 *
 * @package WTE User History
 * @author  WP Travel Engine
 * @license GPL2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WTEUH_Track_History {

	/**
	 * Fire up the engines.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action( 'wteuh_visited_url', array( $this, 'update_customer_history' ), 10, 3 );
		
		// Save user history on booking and enquiries.
		add_action( 'wte_after_booking_created', array( $this, 'save_customer_history' ) );
		add_action( 'wte_after_enquiry_created', array( $this, 'save_customer_history' ) );

		// Support for gravity forms to save user history
		add_action( 'gform_after_submission', array( $this, 'gf_save_user_browsing_history' ), 10, 2 );

		// Uncomment the following action to enable devmode
		add_action( 'get_header', array( $this, 'devmode' ) );
	}

	/**
	 * Get customer's tracked browsing history.
	 *
	 * @since    1.0.0
	 *
	 * @referrer string The Referrer for ths user
	 */
	private function get_customer_history( $referrer = '' ) {
		$user_hash        = WTEUH_Cookie_Helper::get_cookie();
		$customer_history = wteuh_get_page_history( $user_hash );

		// If user has an established history, return that
		if ( ! empty( $customer_history ) ) {
			return (array) $customer_history;

			// Otherwise, return an array with the original referrer
		} else {
			$referrer = esc_url( $referrer ) ? $referrer : __( 'Direct Traffic', 'wte-user-history' );

			return array( array( 'url' => $referrer, 'time' => time() ) );
		}
	}

	/**
	 * Update customer's tracked browsing history.
	 *
	 * @since 1.0.0
	 */
	public function update_customer_history( $page_url = '', $timestamp = 0, $referrer = '' ) {
		// Grab browsing history from the current session
		$history   = $this->get_customer_history( $referrer );
		$history[] = array( 'url' => esc_url( $page_url ), 'time' => absint( $timestamp ) );

		// Push the updated history to the current session
		$user_hash = WTEUH_Cookie_Helper::get_cookie();
		wteuh_set_page_history( $user_hash, $history );
	}

	/**
	 * Save custom browsing history to entry meta
	 *
	 * @param [type] $entry
	 * @param [type] $form
	 * @return void
	 */
	public function gf_save_user_browsing_history( $entry, $form ) {

		$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings' );
		
		$selected_forms = isset( $wp_travel_engine_settings['user_history']['capture_gravity_forms'] ) ? stripslashes_deep( $wp_travel_engine_settings['user_history']['capture_gravity_forms'] ) : array();

		if ( in_array( $form['id'], $selected_forms ) ) :

			//save customer history to entry id.
			$this->save_customer_history( $entry['id'] );
		
		endif;

	}

	/**
	 * Save user history as payment meta.
	 *
	 * @since 1.0.0
	 *
	 * @param  string $booking_id WP Travel Engine booking id
	 *
	 * @return array $booking_id
	 */
	public function save_customer_history( $booking_id = '' ) {
		// Bail early if not on the purchase screen
		if ( empty( $booking_id ) ) {
			return false;
		}

		// Grab browsing history from the current session
		$customer_history = $this->get_customer_history();

		// If browsing history was captured, sanitize and store the URLs
		if ( is_array( $customer_history ) && ! empty( $customer_history ) ) {

			// Setup a clean, safe array for the database
			$sanitized_history = array();

			// Sanitize the referrer a bit differently
			// than the rest because it may not be a URL.
			$referrer = array_shift( $customer_history );
			if ( is_object( $referrer ) ) {
				$sanitized_history[] = array(
					'url'  => sanitize_text_field( $referrer->url ),
					'time' => absint( $referrer->time ),
				);
			}

			// Sanitize each additional URL
			foreach ( $customer_history as $history ) {
				$sanitized_history[] = array(
					'url'  => esc_url_raw( $history->url ),
					'time' => absint( $history->time ),
				);
			}

			// Add one final timestamp for order complete
			$sanitized_history[] = array(
				'url'  => __( 'Order Complete', 'wte-user-history' ),
				'time' => time(),
			);

			// Update user history to booking data.
			update_post_meta( $booking_id, 'user_history', $sanitized_history );

			WTEUH_Cookie_Helper::delete_cookie();

		}

		return $booking_id;
	}

	/**
	 * Handle developer debug data.
	 *
	 * Usage: Hook to get_header, append "?devmode=true" to any front-end URL.
	 * To view tracked history, add "&output=history".
	 * To view session object, add "&output=session".
	 * To reset tracked history, add "&reset=history".
	 *
	 * @since 1.0.0
	 */
	public function devmode() {
        // Only proceed if URL querystring cotnains "devmode=true"
        //TODO Define WTW_DEBUG 
		if ( defined( 'WTE_DEBUG' ) && WTE_DEBUG && isset( $_GET['devmode'] ) && 'true' == $_GET['devmode'] ) {

			// Output user history if URL querystring contains 'output=history'
			if ( isset( $_GET['output'] ) && 'history' == $_GET['output'] ) {
				var_dump( WTEUH_Cookie_Helper::get_cookie() );
				echo '<pre>' . print_r( $this->get_customer_history(), 1 ) . '</pre>';
			}

			// Output user history cookie if URL querystring contains 'output=cookie'
			if ( isset( $_GET['output'] ) && 'cookie' == $_GET['output'] ) {
				echo '<pre>' . print_r( $_COOKIE, 1 ) . '</pre>';
			}

			// Clear customer history and dump us back at the homepage if URL querystring contains 'history=reset'
			if ( isset( $_GET['history'] ) && 'reset' == $_GET['history'] ) {
				WTEUH_Cookie_Helper::delete_history_data();
				wp_redirect( site_url() );
				exit;
			}

		}
	}
}
