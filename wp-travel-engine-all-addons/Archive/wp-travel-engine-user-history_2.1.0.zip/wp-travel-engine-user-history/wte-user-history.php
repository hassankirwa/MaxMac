<?php
/**
 * Plugin Name: WP Travel Engine - User History
 * Plugin URI: https://wptravelengine.com
 * Description: WP Travel Engine addon to track and store customer browsing history on trip bookings and enquiries.
 * Version: 2.1.0
 * Author: WP Travel Engine
 * Author URI: https://wptravelengine.com
 * License: GPL2
 * Text Domain: wte-user-history
 * Domain Path: languages
 * WTE requires at least: 4.3.0
 * WTE tested up to: 5.1
 * WTE: 20468:wte_user_history_license_key
 */

/*
Copyright 2019 WP Travel Engine,

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2, as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'WTE_USER_HISTORY_REQUIRES_AT_LEAST', '4.0.0' );

/**
 * Main plugin instantiation class.
 *
 * @since 1.0.0
 */
class WTE_User_History {

	/**
	 * Track instance of the WTE_User_History class.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	private static $instance = null;

	/**
	 * Tracks current plugin version throughout codebase.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	var $version = '2.1.0';

	/**
	 * Main WTE_User_History Instance
	 *
	 * Ensures only one instance of WTE_User_History is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 *
	 * @return WTE_User_History - Main instance
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof WTE_User_History ) ) {
			self::$instance = new WTE_User_History();
			self::$instance->i18n();
			self::$instance->includes();
			self::$instance->maybe_update_plugin();

			// Schedule garbage collection cron job to remove cookie data.
			wteuh_schedule_garbage_collection();

			new WTEUH_Show_History();
			new WTEUH_Track_History();
		}

		return self::$instance;
	}

	/**
	 * Fire up the engines.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		// Define plugin constants
		$this->plugin_file    = __FILE__;
		$this->basename       = plugin_basename( $this->plugin_file );
		$this->directory_path = plugin_dir_path( $this->plugin_file );
		$this->directory_url  = plugin_dir_url( $this->plugin_file );

		define( 'WTE_USER_HISTORY_URL', rtrim( plugin_dir_url( __FILE__ ), '/' ) );
		define( 'WTE_USER_HISTORY_VERSION', $this->version );
		define( 'WTE_USER_HISTORY_FILE_PATH', __FILE__ );
		if ( ! defined( 'WTE_USER_HISTORY_DIR' ) ) {
			define( 'WTE_USER_HISTORY_DIR', dirname( __FILE__ ) . '/' );
		}

		// Handle plugin activation and deactivation
		register_activation_hook( $this->plugin_file, array( $this, 'activation' ) );
		register_deactivation_hook( $this->plugin_file, array( $this, 'deactivation' ) );

		// Basic setup
		add_action( 'wp_enqueue_scripts', array( $this, 'load_scripts' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'load_admin_scripts' ) );
		add_action( 'admin_notices', array( $this, 'maybe_disable_plugin' ) );

		$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings' );
		// Cookie Consent data
		$enable_cookie_consent = isset( $wp_travel_engine_settings['user_history']['cookie_consent']['enable'] ) ? esc_attr( $wp_travel_engine_settings['user_history']['cookie_consent']['enable'] ) : '';

		if ( '1' === $enable_cookie_consent ) :

			add_action( 'wp_footer', array( $this, 'add_cookie_consent_code' ) );

		endif;

	}

	/**
	 * Plugin activation hook.
	 *
	 * @since  1.0.0
	 */
	public function activation() {
		$this->includes();
		wteuh_schedule_garbage_collection();
	}

	/**
	 * Plugin deactivation hook.
	 *
	 * @since  1.0.0
	 */
	public function deactivation() {
		$this->includes();
		wteuh_unschedule_garbage_collection();
	}

	/**
	 * Load localization.
	 *
	 * @since 1.0.0
	 */
	public function i18n() {
		load_plugin_textdomain( 'wte-user-history', false, $this->directory_path . '/languages/' );
	}

	/**
	 * Include file dependencies.
	 *
	 * @since 1.0.0
	 */
	public function includes() {
		if ( $this->meets_requirements() ) {
			require_once $this->directory_path . 'includes/wte-user-history-helpers.php';
			require_once $this->directory_path . 'includes/wte-user-history-database-functions.php';
			require_once $this->directory_path . 'includes/wte-user-history-ajax.php';
			require_once $this->directory_path . 'includes/class-wteuh-cookie-helper.php';
			require_once $this->directory_path . 'includes/class-wteuh-track-history.php';
			require_once $this->directory_path . 'includes/class-wteuh-show-history.php';

			if ( is_admin() ) :
				require_once $this->directory_path . 'includes/class-wteuh-admin-settings.php';
				require_once $this->directory_path . 'updater/wte-user-history-updater.php';
			endif;
		}
	}

	/**
	 * Register frontend CSS and JS files.
	 *
	 * @since 1.0.0
	 */
	public function load_scripts() {

		$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings' );
		$disable_user_tracking     = isset( $wp_travel_engine_settings['user_history']['disable'] ) ? esc_attr( $wp_travel_engine_settings['user_history']['disable'] ) : '';

		$asset_script_path = '/min/';
		$version_prefix    = '-' . WTE_USER_HISTORY_VERSION;

		if ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) {
			$asset_script_path = '/';
			$version_prefix    = '';
		}

		if ( '1' !== $disable_user_tracking ) :

			wp_enqueue_script( 'wteuh-tracking', $this->directory_url . 'assets/public/js' . $asset_script_path . 'wte-user-history-trkuhcd' . $version_prefix . '.js', array( 'jquery' ), WTE_USER_HISTORY_VERSION, true );
			wp_localize_script(
				'wteuh-tracking',
				'wteuh',
				array(
					'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
					'currentUrl' => home_url( add_query_arg( null, null ) ),
				)
			);

		endif;

		// Cookie Consent data
		$enable_cookie_consent = isset( $wp_travel_engine_settings['user_history']['cookie_consent']['enable'] ) ? esc_attr( $wp_travel_engine_settings['user_history']['cookie_consent']['enable'] ) : '';

		if ( '1' === $enable_cookie_consent ) :

			// coocie consent CSS Styles
			wp_enqueue_style( 'cookie-consent-style', $this->directory_url . 'assets/public/css/cookieconsent.min.css', array(), WTE_USER_HISTORY_VERSION );

		endif;

	}

	/**
	 * Register backend CSS and JS files.
	 *
	 * @since 1.0.0
	 */
	public function load_admin_scripts() {

		$screen = get_current_screen();
		if ( $screen->post_type == 'trip' || $screen->post_type == 'booking' || $screen->id == 'trip_page_class-wp-travel-engine-admin' ) {
			wp_enqueue_style( 'wp-color-picker' );

			wp_enqueue_style( 'wte-user-history-admin-css', $this->directory_url . 'assets/admin/css/wte-uh-admin-css.css', array(), WTE_USER_HISTORY_VERSION );

			wp_enqueue_script( 'wteuh-admin-scripts-js', $this->directory_url . 'assets/admin/js/wteuh-admin-scripts.js', array( 'jquery', 'wp-color-picker' ), WTE_USER_HISTORY_VERSION, true );

		}
	}

	/**
	 * Output error message and disable plugin if requirements are not met.
	 *
	 * This fires on admin_notices.
	 *
	 * @since 1.0.0
	 */
	public function maybe_disable_plugin() {

		if ( ! $this->meets_requirements() ) {

			// Display our error
			echo '<div id="message" class="error">';
			echo '<p>' . sprintf( __( '<strong>WP Travel Engine User History</strong> addon requires WP Travel Engine plugin <strong>Version 4.0.0 or later</strong> and has been <a href="%s">deactivated</a>. Please install, activate, or update WP Travel Engine plugin and then reactivate this plugin.', 'wte-user-history' ), admin_url( 'plugins.php' ) ) . '</p>';
			echo '</div>';

			// Deactivate our plugin
			deactivate_plugins( plugin_basename( __FILE__ ) );
		}
	}

	/**
	 * Check if all plugin requirements are met.
	 *
	 * @since 1.0.0
	 *
	 * @return bool True if requirements are met, otherwise false.
	 */
	private function meets_requirements() {
		return ( class_exists( 'WP_Travel_Engine' ) && defined( 'WP_TRAVEL_ENGINE_VERSION' ) && version_compare( WP_TRAVEL_ENGINE_VERSION, '4.0.0', '>=' ) );
	}

	/**
	 * Run an update routine for the plugin.
	 *
	 * @since 1.0.0
	 */
	function maybe_update_plugin() {
		// Bail early if not on an admin page
		if ( ! is_admin() ) {
			return;
		}

		// Get the stored and current plugin database versions
		$stored_db_version = get_option( 'wteuh_plugin_db_version', '0.0.0' );

		// Only trigger updates when stored version is lower than current version
		if ( version_compare( $stored_db_version, $this->version, '<' ) ) {
			require_once $this->directory_path . '/includes/updates.php';
			do_action( 'wteuh_plugin_update', $stored_db_version, $this->version );
			update_option( 'wteuh_plugin_db_version', $this->version );
		}
	}

	/**
	 * Add cookie consent code script to the frontend.
	 *
	 * @return void
	 */
	public function add_cookie_consent_code() {

		$cookie_settings_defaults = array(
			'position'            => 'bottom-left',
			'layout'              => 'block',
			'banner_bg'           => '#000000',
			'button_bg'           => '#f1d600',
			'content_text_col'    => '#ffffff',
			'button_text_col'     => '#000000',
			'learn_more_link'     => false,
			'policy_link_text'    => __( 'Learn more', 'wte-user-history' ),
			'consent_message'     => __( 'This website uses cookies to ensure you get the best experience on our website.', 'wte-user-history' ),
			'dismiss_button_text' => __( 'Got it!', 'wte-user-history' ),
		);

		$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings' );
		$cookie_settings           = isset( $wp_travel_engine_settings['user_history']['cookie_consent'] ) ? stripslashes_deep( $wp_travel_engine_settings['user_history']['cookie_consent'] ) : $cookie_settings_defaults;

		?>
		<script src="<?php echo esc_url( $this->directory_url ) . 'assets/public/js/cookieconsent.min.js'; ?>" data-cfasync="false"></script>
		<script>
			window.cookieconsent.initialise({
			"palette": {
				"popup": {
				"background": "<?php echo esc_attr( $cookie_settings['banner_bg'] ); ?>",
				"text": "<?php echo esc_attr( $cookie_settings['content_text_col'] ); ?>"
				},
				"button": {
				<?php if ( 'wire' === $cookie_settings['layout'] ) : ?>
					"background": "transparent",
					"border": "<?php echo esc_attr( $cookie_settings['button_bg'] ); ?>",
				<?php else : ?>
					"background": "<?php echo esc_attr( $cookie_settings['button_bg'] ); ?>",
				<?php endif; ?>
				"text": "<?php echo esc_attr( $cookie_settings['button_text_col'] ); ?>"
				}
			},
			<?php if ( ! $cookie_settings['learn_more_link'] ) : ?>
				"showLink": false,
			<?php endif; ?>
			"theme": "<?php echo esc_attr( $cookie_settings['layout'] ); ?>",
			"position": "<?php echo esc_attr( $cookie_settings['position'] ); ?>",
			"content": {
					"message": "<?php echo wp_strip_all_tags( $cookie_settings['consent_message'] ); ?>",
					"dismiss": "<?php echo esc_html( $cookie_settings['dismiss_button_text'] ); ?>",
					"link": "<?php echo esc_html( $cookie_settings['policy_link_text'] ); ?>",
					<?php if ( $cookie_settings['learn_more_link'] ) : ?>
						"href": "<?php echo esc_url( $cookie_settings['learn_more_link'] ); ?>"
					<?php endif; ?>
				}
			});
		</script>
		<?php
	}

}

/**
 * Returns the main instance of WTE_User_History.
 *
 * @since  1.0.0
 * @return WTE_User_History
 */
function wte_user_history() {
	if ( ! defined( 'WP_TRAVEL_ENGINE_VERSION' ) || version_compare( WP_TRAVEL_ENGINE_VERSION, WTE_USER_HISTORY_REQUIRES_AT_LEAST, '<' ) ) {
		add_action(
			'admin_notices',
			function() {
				echo wp_kses_post(
					sprintf(
						'<div class="error"><p>'
						// translators: 1. WTE Extension Name 2. Link to WTE Plugin.
						. sprintf( __( '%1$s requires the %2$s plugin to work. Please install and activate the latest <strong>WP Travel Engine</strong> plugin first.', 'wte-user-history' ), '<strong>WP Travel Engine - User History</strong>', '<a href="https://wordpress.org/plugins/wp-travel-engine/" target="__blank">WP Travel Engine</a>' )
						. '</p></div>'
					)
				);
			}
		);
	} else {
		return WTE_User_History::instance();
	}
}
add_action( 'plugins_loaded', 'wte_user_history', 10 );
