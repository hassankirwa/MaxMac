
function backend_ui_new_callback( content_key ) {
    if ( ! 'content_key' === 'wpte-extensions' ) {
        return;
    }
    jQuery('.wte-uh-colpckr').wpColorPicker();
}
wpte_add_action( 'wpte_after_global_settings_tab_shown', 'backend_ui_new_callback' );