<?php
/**
 * Easy Digital Downloads Plugin Updater
 *
 * @package WTE_Group_Discount
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Includes the files needed for the plugin updater.
 *
 * @since 1.0.0
 */
if ( ! class_exists( 'EDD_SL_Plugin_Updater' ) ) {

	include dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php';
}

/**
 * Download ID for the product in Easy Digital Downloads.
 *
 * @since 1.0.0
 */
define( 'WP_TRAVEL_ENGINE_GROUP_DISCOUNT_ITEM_ID', 146 );

/**
 * Setup the updater for the WTE Group Discount Add-on.
 *
 * @since 1.0.0
 */
function wte_group_discount_updater() {
	// Bail early if the store url is not found.
	if ( version_compare( WP_TRAVEL_ENGINE_VERSION, '4.3.8', '>=' ) || ! defined( 'WP_TRAVEL_ENGINE_STORE_URL' ) ) {
		return; // Done by core when WTE header present in Plugin Block Comment.
	}

	// retrieve our license key from the DB
	$settings    = get_option( 'wp_travel_engine_license' );
	$license_key = isset( $settings['wte_group_discount_license_key'] ) ? esc_attr( $settings['wte_group_discount_license_key'] ) : '';

	// setup the updater
	$edd_updater = new EDD_SL_Plugin_Updater(
		WP_TRAVEL_ENGINE_STORE_URL,
		WP_TRAVEL_ENGINE_GROUP_DISCOUNT_FILE_PATH,
		array(
			'version' => WP_TRAVEL_ENGINE_GROUP_DISCOUNT_VERSION,                    // current version number
			'license' => $license_key,             // license key (used get_option above to retrieve from DB)
			'item_id' => WP_TRAVEL_ENGINE_GROUP_DISCOUNT_ITEM_ID,       // ID of the product
			'author'  => 'WP Travel Engine', // author of this plugin
			'beta'    => false,
		)
	);

}
add_action( 'admin_init', 'wte_group_discount_updater', 0 );

/**
 * Add-ons name for plugin license page.
 *
 * @since 1.0.0
 */
function wte_group_discount_name( $array ) {
	$array['WP Travel Engine - Group Discount'] = 'wte_group_discount';
	return $array;
}
add_filter( 'wp_travel_engine_addons', 'wte_group_discount_name' );

/**
 * Add-ons Item ID for plugin license page.
 *
 * @since 1.0.0
 */
function wte_group_discount_id( $array ) {
	$array['wte_group_discount'] = WP_TRAVEL_ENGINE_GROUP_DISCOUNT_ITEM_ID;
	return $array;
}
add_filter( 'wp_travel_engine_addons_id', 'wte_group_discount_id' );

/**
 * Add-ons License details for showing updates in plugin license page.
 *
 * @since 1.0.0
 */
function wte_group_discount_license( $array ) {
	$settings    = get_option( 'wp_travel_engine_license' );
	$license_key = isset( $settings['wte_group_discount_license_key'] ) ? esc_attr( $settings['wte_group_discount_license_key'] ) : '';

	$array[] =
		array(
			'version' => WP_TRAVEL_ENGINE_GROUP_DISCOUNT_VERSION,       // current version number
			'license' => $license_key,  // license key (used get_option above to retrieve from DB)
			'item_id' => WP_TRAVEL_ENGINE_GROUP_DISCOUNT_ITEM_ID,   // id of this product in EDD
			'author'  => 'WP Travel Engine',  // author of this plugin
			'url'     => home_url(),
		);
	return $array;
}

$wp_travel_engine                  = get_option( 'wp_travel_engine_license' );
$wte_group_discount_license_status = isset( $wp_travel_engine['wte_group_discount_license_status'] ) ? esc_attr( $wp_travel_engine['wte_group_discount_license_status'] ) : '';

if ( isset( $wte_group_discount_license_status ) && $wte_group_discount_license_status == 'valid' ) {
	add_filter( 'wp_travel_engine_licenses', 'wte_group_discount_license' );
}
