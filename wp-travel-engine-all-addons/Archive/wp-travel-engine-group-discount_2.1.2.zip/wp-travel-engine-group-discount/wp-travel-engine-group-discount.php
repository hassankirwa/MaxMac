<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://wptravelengine.com/
 * @since             1.0.0
 * @package           Wp_Travel_Engine_Group_Discount
 *
 * @wordpress-plugin
 * Plugin Name:       WP Travel Engine - Group Discount
 * Plugin URI:        https://wptravelengine.com/
 * Description:       An extension of WP Travel Engine plugin to give group discount.
 * Version:           2.1.2
 * Author:            wptravelengine
 * Author URI:        https://wptravelengine.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wp-travel-engine-group-discount
 * Domain Path:       /languages
 * WTE requires at least: 4.3.0
 * WTE Tested up to: 5.2
 * WTE: 146:wte_group_discount_license_key
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'WP_TRAVEL_ENGINE_GROUP_DISCOUNT_VERSION', '2.1.2' );
define( 'WP_TRAVEL_ENGINE_GROUP_DISCOUNT_FILE_PATH', __FILE__ );
define( 'WP_TRAVEL_ENGINE_GROUP_DISCOUNT_REQUIRES_AT_LEAST', '4.3.0' );

register_activation_hook( __FILE__, 'activate_wp_travel_engine_group_discount' );
/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-wp-travel-engine-group-discount-activator.php
 */
function activate_wp_travel_engine_group_discount() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wp-travel-engine-group-discount-activator.php';
	Wp_Travel_Engine_Group_Discount_Activator::activate();
}

register_deactivation_hook( __FILE__, 'deactivate_wp_travel_engine_group_discount' );
/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-wp-travel-engine-group-discount-deactivator.php
 */
function deactivate_wp_travel_engine_group_discount() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-wp-travel-engine-group-discount-deactivator.php';
	Wp_Travel_Engine_Group_Discount_Deactivator::deactivate();
}

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_wp_travel_engine_group_discount() {
	$plugin = new Wp_Travel_Engine_Group_Discount();
	$plugin->run();

}

/**
 * Plugin Initialization.
 */
add_action(
	'plugins_loaded',
	function() {
		if ( ! defined( 'WP_TRAVEL_ENGINE_VERSION' ) || version_compare( WP_TRAVEL_ENGINE_VERSION, WP_TRAVEL_ENGINE_GROUP_DISCOUNT_REQUIRES_AT_LEAST, '<' ) ) {
			add_action(
				'admin_notices',
				function() {
					echo wp_kses_post(
						sprintf(
							'<div class="error"><p>'
							// translators: 1. WTE Extension Name 2. Link to WTE Plugin.
							. sprintf( __( '%1$s requires the %2$s plugin to work. Please install and activate the latest <strong>WP Travel Engine</strong> plugin first.', 'wp-travel-engine-group-discount' ), '<strong>WP Travel Engine - Group Discount</strong>', '<a href="https://wptravelengine.com" target="__blank">WP Travel Engine</a>' )
							. '</p></div>'
						)
					);
				}
			);
		} else {
			/**
			 * The core plugin class that is used to define internationalization,
			 * admin-specific hooks, and public-facing site hooks.
			 */
			require plugin_dir_path( __FILE__ ) . 'includes/class-wp-travel-engine-group-discount.php';

			run_wp_travel_engine_group_discount();
		}
	}
);
