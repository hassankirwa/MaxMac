=== WP Travel Engine - Group Discount ===
Contributors: wptravelengine
Donate link: https://wptravelengine.com/
Tags: group-booking, group-discount, group-tour, package-deal, deals
Requires at least: 4.4.0
Tested up to: 5.6
Stable tag: 2.1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

An extension of WP Travel Engine plugin to give group discount.

== Description ==

An extension of WP Travel Engine plugin that allows travel agencies and tour operators to give group discount to their customers.

== Changelog ==

= 2.1.2 =
Released on: 4th August, 2021
* Fix - Group Pricing can not be added on new pricing categories
* Fixes - Minor bugs

= 2.1.1 =
Released on: 10th June, 2021
* Dev - Compatibility fixes for WP Travel Engine
* Fixes - Minor Bug Fixes

= 2.1.0 =
Released on: 6th May, 2021
* Dev - Added WTE Plugin Headers
* Enhancements - Compatible with Upcoming WTE major release.
* Fixes - Minor Bug Fixes

= 2.0.3 =
Released on: 5th January, 2021

Fixes:
* Fixed Compatibility issues for currency converter code display in Group Discount list.
* Minor typo fixes.

= 2.0.2 =

Released on: 20th November, 2020

Fixes:

* Minor typo fixes.

= 2.0.1 =

Released on: 1st September, 2020

Enhancements:

* Settings added for Group Discount toggle texts.
* Design enhancements for Available Group Discount toggle.

Fixes:

* Minor bug fixes.

= 2.0.0 =

Released on: 18th June, 2020

Enhancements:

* Revamped backend UI.
* Support for group discount in range(1-5, 5-10) added.
* Assets minification, optimization, and conditional loading.

Fixes:

* Array to String conversion error in settings resolved.
* Minor bug fixes.

= 1.1.2 =

Released on: 2nd April, 2020

Enhancements:

* Compatibility check for WordPress 5.4.
* Support for WP Travel Engine list/grid template added.
* Hooks added for Travel Muni theme.

Fixes:

* Warning fixes for 404 page.
* Minor bug fixes.

= 1.1.1 =

Released on: 29th January, 2020

Enhancements:

* Group Discount added for infant.
* Hooks added for Currency Converter addon.

Fixes:

* Minor bug fixes.

= 1.1.0 =

Released on: 21st January, 2020

Fixes:

* Group Discount price issue fix.
* Minor bug fixes.

= 1.0.9 =

Released on: 14th January, 2020

Enhancements:

* Compatibility testing with WP Travel Engine 3.0.
* Shiny update added for future versions.

Fixes:

* Undefined index and warning issues fix.
* Minor bug fixes.

= 1.0.8 =

* Group Discount PopUp Scroll Issue Fixed

= 1.0.7 =

* Thousands Separator implemented

= 1.0.6 =

* Compatible with Trip Fixed Starting Dates

= 1.0.5 =

* Design changes and js fixing

= 1.0.0 =

* Initial release
