<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://wptravelengine.com/
 * @since      1.0.0
 *
 * @package    Wp_Travel_Engine_Group_Discount
 * @subpackage Wp_Travel_Engine_Group_Discount/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Wp_Travel_Engine_Group_Discount
 * @subpackage Wp_Travel_Engine_Group_Discount/includes
 * @author     wptravelengine <info@raratheme.com>
 */
use WPTravelEngine\Packages;
class Wp_Travel_Engine_Group_Discount {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Wp_Travel_Engine_Group_Discount_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {
		if ( defined( 'WP_TRAVEL_ENGINE_GROUP_DISCOUNT_VERSION' ) ) {
			$this->version = WP_TRAVEL_ENGINE_GROUP_DISCOUNT_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->plugin_name = 'wp-travel-engine-group-discount';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();

		$this->init_hooks();

	}

	/**
	 * Hooks and Filters.
	 *
	 * @return void
	 */
	private function init_hooks() {
		add_filter(
			'wte_rest_fields__trip-packages',
			function( $fields ) {
				$fields['group-pricing'] = array(
					'type'            => 'array',
					'schema'          => array(
						'type' => 'array',
					),
					'get_callback'    => function( $prepared, $field ) {
						$group_pricings = get_post_meta( $prepared['id'], $field, ! 0 );

						if ( empty( $group_pricings ) ) {
							$group_pricings = array();
						}

						$package_categories = Packages\get_packages_pricing_categories();
						foreach ( $package_categories as $pcategory ) {
							if ( ! empty( $group_pricings[ $pcategory->term_id ] ) ) {
								continue;
							}
							$group_pricings[ $pcategory->term_id ][] = array(
								'from'  => 1,
								'to'    => '',
								'price' => 0,
							);
						}
						return $group_pricings;
					},
					'update_callback' => function() {
						// @TODO Add later.
					},
				);

				return $fields;
			}
		);

		add_filter(
			'wte_locate_template',
			function( $template, $template_name ) {
				if ( 'script-templates/trip-edit/tab-pricing/group-discount/tmpl-wte-group-discount-pricing.php' === $template_name ) {
					$template = plugin_dir_path( WP_TRAVEL_ENGINE_GROUP_DISCOUNT_FILE_PATH ) . 'includes/script-templates/trip-edit/tab-pricing/tmpl-wte-group-discount-pricing.php';
				}
				return $template;
			},
			11,
			2
		);

		add_filter(
			'has_packages_group_discounts',
			function( $has_group_discounts, $trip_ID = null ) {
				if ( ! $trip_ID ) {
					global $wtetrip;
				} else {
					$wtetrip = \wte_get_trip( $trip_ID );
				}
				$packages = $wtetrip->packages;

				$primary_pricing_category_id = get_option( 'primary_pricing_category', 0 );

				if ( $primary_pricing_category_id ) {
					$term = get_term( $primary_pricing_category_id );
				}
				foreach ( $packages as $package ) {
					$package_categories = (object) $package->{'package-categories'};

					$package_categories_ids = ( isset( $package_categories->{'c_ids'} ) ) ? $package_categories->{'c_ids'} : array();

					if ( ! $primary_pricing_category_id ) {
						$primary_pricing_category_id = ! empty( $package_categories_ids ) && is_array( $package_categories_ids ) ? array_shift( $package_categories_ids ) : 0;
					}
					if ( ! $primary_pricing_category_id ) {
						continue;
					}

					$term = get_term( $primary_pricing_category_id );

					if ( ! ( $term instanceof \WP_Term ) ) {
						return false;
					}

					if ( isset( $package_categories->enabled_group_discount[ $term->term_id ] ) && '1' == $package_categories->enabled_group_discount[ $term->term_id ] ) {
						return true;
					}
				}

				return $has_group_discounts;
			},
			10,
			2
		);

		// Save Package dates.
		add_action( 'save_trip_package', array( $this, 'save_trip_package' ), 10, 3 );
	}

	public function save_trip_package( $package_id, $posted_data, $trip_id ) {
		$group_pricings = isset( $posted_data['group_pricings'] ) ? (array) $posted_data['group_pricings'] : array();

		if ( isset( $group_pricings[ $package_id ] ) ) {
			$group_pricing = $group_pricings[ $package_id ];
			update_post_meta( +$package_id, 'group-pricing', $group_pricing );
		}
	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Wp_Travel_Engine_Group_Discount_Loader. Orchestrates the hooks of the plugin.
	 * - Wp_Travel_Engine_Group_Discount_i18n. Defines internationalization functionality.
	 * - Wp_Travel_Engine_Group_Discount_Admin. Defines all hooks for the admin area.
	 * - Wp_Travel_Engine_Group_Discount_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies() {

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wp-travel-engine-group-discount-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'includes/class-wp-travel-engine-group-discount-i18n.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-wp-travel-engine-group-discount-admin.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'public/class-wp-travel-engine-group-discount-public.php';

		/**
		 * The class responsible for shiny update feature of the addon.
		 */
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'updater/wte-group-discount-updater.php';

		$this->loader = new Wp_Travel_Engine_Group_Discount_Loader();

	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Wp_Travel_Engine_Group_Discount_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Wp_Travel_Engine_Group_Discount_i18n();

		$this->loader->add_action( 'init', $plugin_i18n, 'load_plugin_textdomain' );

	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {

		$plugin_admin = new Wp_Travel_Engine_Group_Discount_Admin( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'admin_notices', $plugin_admin, 'check_dependency' );

		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_styles' );
		$this->loader->add_action( 'admin_enqueue_scripts', $plugin_admin, 'enqueue_scripts' );
		$this->loader->add_action( 'wp_travel_engine_group_discount', $plugin_admin, 'wp_travel_engine_group_discount' );
		// $this->loader->add_action( 'admin_footer', $plugin_admin, 'wp_travel_engine_group_discount_template' );
		$this->loader->add_action( 'wp_travel_engine_trip_group_discount', $plugin_admin, 'wp_travel_engine_trip_group_discount' );
		$this->loader->add_action( 'wte_after_pricing_options_section', $plugin_admin, 'wte_add_group_discount_pricing' );

		$this->loader->add_action( 'wpte_get_global_extensions_tab', $plugin_admin, 'wte_gd_extension_settings' );
	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {

		$plugin_public = new Wp_Travel_Engine_Group_Discount_Public( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_styles' );
		$this->loader->add_action( 'wp_enqueue_scripts', $plugin_public, 'enqueue_scripts' );
		$this->loader->add_action( 'wp_travel_engine_group_discount_guide', $plugin_public, 'wp_travel_engine_group_discount_guide' );
		$this->loader->add_action( 'wp_ajax_group_discount_calculate', $plugin_public, 'wp_travel_engine_group_discount_calculate' );
		$this->loader->add_action( 'wp_ajax_nopriv_group_discount_calculate', $plugin_public, 'wp_travel_engine_group_discount_calculate' );
		$this->loader->add_action( 'wp_travel_engine_group_discount_info', $plugin_public, 'wp_travel_engine_group_discount_info' );
		$this->loader->add_action( 'wpte_child_field', $plugin_public, 'wpte_child_field', 10, 1 );

		// Add hooks only if the global discount is enabled.
		$wte_settings = get_option( 'wp_travel_engine_settings' );
		if ( isset( $wte_settings['group']['discount'] ) && '1' === $wte_settings['group']['discount'] ) {
			$this->loader->add_action( 'wte_after_price_info', $plugin_public, 'display_group_discount_options' );
			// Add child price info
			$this->loader->add_action( 'wpte_after_travellers_input', $plugin_public, 'display_child_input_field' );
			// Update default per travel.
			$this->loader->add_filter( 'wte_default_traveller_type', $plugin_public, 'update_default_traveller_type' );
			$this->loader->add_filter( 'wte_default_traveller_unit', $plugin_public, 'update_default_traveller_unit' );
			// Display child price info
			$this->loader->add_action( 'wte_after_price_info_list', $plugin_public, 'display_child_price_info' );

			// Display child price info
			$this->loader->add_action( 'wte_after_price_info_list', $plugin_public, 'display_infant_price_info' );

			$this->loader->add_filter( 'wte_apply_group_discount_default', $plugin_public, 'mp_apply_group_discount_default' );

			$this->loader->add_filter( 'wp_travel_engine_group_discount_available_text', $plugin_public, 'get_group_discount_available_text' );
		}

	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Wp_Travel_Engine_Group_Discount_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

}
