<?php
/**
 * Template for group discount pricing
 */
?>
<script id="tmpl-wte-group-discount-pricing" type="text/html">
<#
var {store, packageID, categoryID, groupDiscount} = data
var categoryidSuffix = '_' + packageID + '_' + categoryID
var enabledGroupDiscount = store.editFormData[packageID].packageCategories[categoryID].enabledGroupDiscount || false
var category = store.editFormData[packageID].packageCategories[categoryID]
#>
	<?php
	$field_builder = new WTE_Field_Builder_Admin(
		array(
			array(
				'type'            => 'custom',
				'value'           => call_user_func(
					function() {
						ob_start();
						( new WTE_Field_Builder_Admin(
							array(
								array(
									'label'             => __( 'Group Discount', 'wp-travel-engine-group-discount' ),
									'name'              => 'categories[{{packageID}}][enabled_group_discount][{{categoryID}}]',
									'value'             => '1',
									'default_value'     => '1',
									'type'              => 'checkbox',
									'id'                => 'group_discount{{categoryidSuffix}}',
									'tooltip'           => __( 'Check this if you want to enable Group Discount. You can add prices for the different groups.', 'wp-travel-engine-group-discount' ),
									'checked_classname' => "{{(enabledGroupDiscount) ? ' active' : ''}}",
									'attributes'        => array(
										'checked' => "{{(enabledGroupDiscount) ? 'checked' : ''}}",
										'data-toggle-target' => '#wte-gd-list{{categoryidSuffix}}',
									),
								),
							)
						) )->render();
						?>
						<div class="wte-group-discount-list" id="wte-gd-list{{categoryidSuffix}}" style="{{(enabledGroupDiscount) ? '' : 'display:none;'}}">
							<div class="wte-row">
								<div class="wte-col">
									<label class="wpte-field-label"><?php esc_html_e( 'Number of Person', 'wp-travel-engine-group-discount' ); ?></label>
								</div>
								<div class="wte-col">
									<label class="wpte-field-label">
									{{category.pricingType == 'per-person' ? "<?php esc_html_e( 'Price/person', 'wp-travel-engine-group-discount' ); ?>" : "<?php esc_html_e( 'Price/group', 'wp-travel-engine-group-discount' ); ?>"}}
								</div>
							</div>
							<div class="wte-group-discount__items">
								<#
								var group_pricing = groupDiscount
								var groupPricing = group_pricing
								for(var index in groupPricing ) { // foriigp
									var from = groupPricing[index]['from']
									var to = groupPricing[index]['to']
									var price = groupPricing[index]['price'] || category.price || 0
									var dataGP = JSON.stringify({index, from, to, price, defaultPrice: category.price || 0, packageID, categoryID })
									#>
									<div class="wte-row wte-group-list-item" data-gp-info="{{dataGP}}">
										<div class="wte-col">
											<input type="text" readonly data-gp-name="from" data-gp-value="{{from}}" name="group_pricings[{{packageID}}][{{categoryID}}][{{index}}][from]" value="{{from}}">
											-
											<input type="text" data-gp-name="to" data-gp-value="{{to}}" name="group_pricings[{{packageID}}][{{categoryID}}][{{index}}][to]" placeholder="&infin;" value="{{to}}">
										</div>
										<div class="wte-col">
											<input type="text" data-gp-name="price" data-gp-value="{{price}}" name="group_pricings[{{packageID}}][{{categoryID}}][{{index}}][price]" value="{{price}}" data-wte-field-type="price">
										</div>
									</div>
									<#
								} // endforiigp
								#>
							</div>
						</div>
						<?php
						return ob_get_clean();
					}
				),
				'wrapper_classes' => 'wte-group-discounts',
			),
		)
	);
	$field_builder->render();
	?>
</script>

<script>
	(function () {
		// return
		document.addEventListener('wteEditPackageRender', function () {
			const editStore = wteEdit.editAPI._store

			const renderGroupDiscount = () => {
				let gdWrapper = document.getElementById(`wte-group-discount-pricing_${packageID}_${categoryID}`)
				gdWrapper.innerHTML = wp.template('wte-group-discount-pricing')({
					store: wteEdit.editAPI._store.getState(),
					packageID,
					categoryID,
					groupDiscount: editFormData[packageID].groupDiscountPricing[categoryID] || []
				})
			}

			const {editFormData, packageCategoriesCollection, tripPackages} = editStore.getState()

			let gdRendered = false;

			wteEdit.editAPI.state$.subscribe(function() {
				if(gdRendered) {
					return
				}
				let _editFormData = editStore.getState().editFormData
				for(let _pid in _editFormData ){
					let _formData = _editFormData[_pid]
					const {groupDiscountPricing} = _formData

					for(let _cid in _formData.packageCategories ) {
						document.getElementById(`wte-group-discount-pricing_${_pid}_${_cid}`).innerHTML = wp.template('wte-group-discount-pricing')({
							store: editStore.getState(),
							packageID: _pid,
							categoryID: _cid,
							groupDiscount: groupDiscountPricing[_cid] || []
						})
					}
				}
				gdRendered = !0
			})

			let _editFormData = {}
			for(let _pid in editFormData ){
				let _formData = editFormData[_pid]
				const {groupDiscountPricing} = _formData

				let _groupDiscountPricing = {}
				for(let _cid in _formData.packageCategories ) {
					let _pc = _formData.packageCategories[_cid]
					if(! groupDiscountPricing[_cid]) {
						_groupDiscountPricing[_cid] = [
							{from:1, to : '', price: _pc.price }
						]
						continue
					}
					_groupDiscountPricing[_cid] = groupDiscountPricing[_cid]
				}
				_editFormData[_pid] = {
					...editFormData[_pid],
					groupDiscountPricing: _groupDiscountPricing
				}
			}

			editStore.dispatch({
				type: 'UPDATE_STORE',
				data: {
					editFormData: _editFormData
				}
			})

			let unsubscriber = null // This wiil hold unsubscribe function the listener.
			let prevGDData;


			wteutil.on('change', '.wte-group-discount-list .wte-group-list-item input', function (e) {

				unsubscriber && unsubscriber()
				let _self = this
				let infoContainer = _self.closest('[data-gp-info]')
				if (!infoContainer) throw new Error('Required info is not available')
				let info = infoContainer.dataset.gpInfo

				info = JSON.parse(info)

				let { packageID, categoryID, index } = info

				let _value = _self.value

				let {editFormData} = wteEdit.editAPI._store.getState()

				unsubscriber = wteEdit.editAPI._store.subscribe(() => {
					let {editFormData} = wteEdit.editAPI._store.getState()
					let nextGDData = editFormData[packageID].groupDiscountPricing[categoryID]

					if (lodash.isEqual(prevGDData, nextGDData)) {
						return
					}
					prevGDData = [...nextGDData]
					let gdWrapper = document.getElementById(`wte-group-discount-pricing_${packageID}_${categoryID}`)
					gdWrapper.innerHTML = wp.template('wte-group-discount-pricing')({
						store: wteEdit.editAPI._store.getState(),
						packageID,
						categoryID,
						groupDiscount: editFormData[packageID].groupDiscountPricing[categoryID] || []
					})
				})


				let groupDiscountPricing = {
					...editFormData[packageID]['groupDiscountPricing'],
					[categoryID] : (() => {
						let gdData = [...editFormData[packageID]['groupDiscountPricing'][categoryID]]
						gdData[index] = {
							...editFormData[packageID]['groupDiscountPricing'][categoryID][index],
							[_self.dataset.gpName] : _self.value
						}
						return gdData
					})()
				}

				if(groupDiscountPricing[categoryID]) {
					let _from = 0
					let _prevTo = 0

					let _gdRange = [...groupDiscountPricing[categoryID]]
					for(let _i in groupDiscountPricing[categoryID]) {
						let r = groupDiscountPricing[categoryID][_i]

						let from = _prevTo + 1

						let to = r.to
						if(to.length < 1) {
							_gdRange[_i] = {
								...r,
								from,
								to
							}
							_gdRange.splice(+_i + 1, _gdRange.length - +_i )
							break;
						}
						to = +to

						if(+to < from) {
							to = from + 1
						}

						_prevTo = to
						_gdRange[_i] = {
							...r,
							from,
							to
						}

						if(+_i == _gdRange.length - 1) {
							_gdRange = [..._gdRange, {from : to + 1, to: '', price: 0}]
						}

					}
					groupDiscountPricing[categoryID] = _gdRange

				}

				_editFormData = {
					...editFormData,
					[packageID]: {
						...editFormData[packageID],
						groupDiscountPricing,
						packageCategories : {
							...editFormData[packageID]?.packageCategories || {},
							[categoryID] : {
								...editFormData[packageID]?.packageCategories[categoryID] || {},
								enabledGroupDiscount: true
							}
						},

					}
				}

				wteEdit.editAPI._store.dispatch({
					'type': 'UPDATE_STORE',
					data: {
						editFormData: _editFormData
					}
				})
			})
		})
	})()
</script>
