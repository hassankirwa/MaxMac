<?php 
/**
 * Group Discount settings / Global
 */
$wp_travel_engine_settings = get_option('wp_travel_engine_settings');
?>
<div class="wpte-field wpte-checkbox advance-checkbox">
    <label class="wpte-field-label" for="wp_travel_engine_settings[group][discount]"><?php _e( 'Enable Group Discount','wp-travel-engine-group-discount' ); ?></label>
    <div class="wpte-checkbox-wrap">
        <input type="checkbox" id="wp_travel_engine_settings[group][discount]" name="wp_travel_engine_settings[group][discount]" value="1" <?php if(isset($wp_travel_engine_settings['group']['discount']) && $wp_travel_engine_settings['group']['discount']!='' ) echo 'checked'; ?>>
        <label for="wp_travel_engine_settings[group][discount]"></label>
    </div>
    <span class="wpte-tooltip"><?php esc_html_e( 'Check this if you want to enable group discount option on trips.', 'wp-travel-engine-group-discount' ); ?></span>
</div>

<div class="wpte-field wpte-text wpte-floated">
    <label for="wp_travel_engine_settings[group][discount_availability]" class="wpte-field-label"><?php _e('Group Discount Info','wp-travel-engine-group-discount');?></label>
    <input type="text" id="wp_travel_engine_settings[group][discount_availability]" name="wp_travel_engine_settings[group][discount_availability]" value="<?php echo isset($wp_travel_engine_settings['group']['discount_availability']) ? esc_attr( $wp_travel_engine_settings['group']['discount_availability'] ): '';?>">
    <span class="wpte-tooltip"><?php esc_html_e( "Group discount available text message for archives.", 'wp-travel-engine-group-discount' ); ?></span>
</div>

<div class="wpte-field wpte-text wpte-floated">
    <label for="wp_travel_engine_settings[group][discount_guide_title]" class="wpte-field-label"><?php _e('Discount Guide Title','wp-travel-engine-group-discount');?></label>
    <input type="text" id="wp_travel_engine_settings[group][discount_guide_title]" name="wp_travel_engine_settings[group][discount_guide_title]" value="<?php echo isset($wp_travel_engine_settings['group']['discount_guide_title']) ? esc_attr( $wp_travel_engine_settings['group']['discount_guide_title'] ): '';?>">
    <span class="wpte-tooltip"><?php esc_html_e( "Enter the text for the title of group discount toggle in booking form.", 'wp-travel-engine-group-discount' ); ?></span>
</div>

<div class="wpte-field wpte-text wpte-floated">
    <label for="wp_travel_engine_settings[group][discount_guide_open_title]" class="wpte-field-label"><?php _e('Discount Guide Open Title','wp-travel-engine-group-discount');?></label>
    <input type="text" id="wp_travel_engine_settings[group][discount_guide_open_title]" name="wp_travel_engine_settings[group][discount_guide_open_title]" value="<?php echo isset($wp_travel_engine_settings['group']['discount_guide_open_title']) ? esc_attr( $wp_travel_engine_settings['group']['discount_guide_open_title'] ): '';?>">
    <span class="wpte-tooltip"><?php esc_html_e( "Enter the text for the title of group discount toggle when toggle is opened in booking form.", 'wp-travel-engine-group-discount' ); ?></span>
</div>
<?php
