<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://wptravelengine.com/
 * @since      1.0.0
 *
 * @package    Wp_Travel_Engine_Group_Discount
 * @subpackage Wp_Travel_Engine_Group_Discount/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Wp_Travel_Engine_Group_Discount
 * @subpackage Wp_Travel_Engine_Group_Discount/includes
 * @author     wptravelengine <info@raratheme.com>
 */
class Wp_Travel_Engine_Group_Discount_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
