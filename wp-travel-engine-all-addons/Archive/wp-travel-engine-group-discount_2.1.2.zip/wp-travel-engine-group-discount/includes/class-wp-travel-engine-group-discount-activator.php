<?php

/**
 * Fired during plugin activation
 *
 * @link       https://wptravelengine.com/
 * @since      1.0.0
 *
 * @package    Wp_Travel_Engine_Group_Discount
 * @subpackage Wp_Travel_Engine_Group_Discount/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Wp_Travel_Engine_Group_Discount
 * @subpackage Wp_Travel_Engine_Group_Discount/includes
 * @author     wptravelengine <info@raratheme.com>
 */
class Wp_Travel_Engine_Group_Discount_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		$arr     = array();
		$options = get_option( 'wp_travel_engine_settings', array() );

		if ( ! is_array( $options ) || isset( $options['group']['discount'] ) ) {
			return;
		}

		$arr['group']['discount'] = '1';
		$enquiry_page             = array_merge_recursive( $options, $arr );
		update_option( 'wp_travel_engine_settings', $enquiry_page );

	}

}
