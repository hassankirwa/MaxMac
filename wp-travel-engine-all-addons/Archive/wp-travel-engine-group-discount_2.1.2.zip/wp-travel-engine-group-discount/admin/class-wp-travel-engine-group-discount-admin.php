<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://wptravelengine.com/
 * @since      1.0.0
 *
 * @package    Wp_Travel_Engine_Group_Discount
 * @subpackage Wp_Travel_Engine_Group_Discount/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Wp_Travel_Engine_Group_Discount
 * @subpackage Wp_Travel_Engine_Group_Discount/admin
 * @author     wptravelengine <info@raratheme.com>
 */
class Wp_Travel_Engine_Group_Discount_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wp_Travel_Engine_Group_Discount_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wp_Travel_Engine_Group_Discount_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		// wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/wp-travel-engine-group-discount-admin.css', array(), $this->version, 'all' );

	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wp_Travel_Engine_Group_Discount_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wp_Travel_Engine_Group_Discount_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		$screen = get_current_screen();

		$gd_pricing_options = array( 
			'adult'  => array(
				'label' => 'traveler',
				'cost' => 'cost'
			), 
			'child'  => array(
				'label' => 'child',
				'cost' => 'child_cost'
			), 
			'infant' => array(
				'label' => 'infant',
				'cost' => 'infant_cost'
			)
		);
		
		if ($screen->post_type == 'trip' ) {

			wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/wp-travel-engine-group-discount-admin.js', array( 'jquery' ), $this->version, false );

			wp_localize_script ( $this->plugin_name, 'gd_pricing_options', $gd_pricing_options );
		}
	}

	public function wp_travel_engine_group_discount()
	{ 
		$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings' );
		if( isset( $wp_travel_engine_settings['group']['discount'] ) && is_array( $wp_travel_engine_settings['group']['discount'] ) ) {
			$wp_travel_engine_settings['group']['discount'] = end( $wp_travel_engine_settings['group']['discount'] );
		}
		$option = isset($wp_travel_engine_settings['group']['discount']) ? esc_attr($wp_travel_engine_settings['group']['discount']) : '';
		?>
		<div class="group-status-options"><h3 class="status-options"><?php _e('Group Discount Settings','wp-travel-engine-group-discount');?></h3>
			<div class="group-dates-options">
				<label for="wp_travel_engine_settings[group][discount]"><?php _e( 'Enable Group Discount:','wp-travel-engine-group-discount' ); ?><span class="tooltip" title="<?php _e( 'Check this if you want to enable group discount option on trips.', 'wp-travel-engine-group-discount' ); ?>"><i class="fas fa-question-circle"></i></span></label>
				
				<input type="checkbox" name="wp_travel_engine_settings[group][discount]" class="disable_notif" id="wp_travel_engine_settings[group][discount]" value="1" <?php echo checked('1', $option); ?>/>
				<label for="wp_travel_engine_settings[group][discount]" class="checkbox-label"></label>
			</div>

			<div class="group-dates-options">
				<label for="wp_travel_engine_settings[group][discount_availability]"><?php _e( 'Group Discount Availability Label:','wp-travel-engine-group-discount' ); ?><span class="tooltip" title="<?php _e( 'Group Discount Availability Label in Price holder.', 'wp-travel-engine-group-discount' ); ?>"><i class="fas fa-question-circle"></i></span></label>
				<input type="text" name="wp_travel_engine_settings[group][discount_availability]" id="wp_travel_engine_settings[group][discount_availability]" value="<?php echo isset($wp_travel_engine_settings['group']['discount_availability']) ? esc_attr($wp_travel_engine_settings['group']['discount_availability']) : 'Group Discount Available';?>"/>
				
			</div>

			<div class="group-dates-options">
				<label for="wp_travel_engine_settings[group][discount_title]"><?php _e( 'Discount Guide Label in Price Holder:','wp-travel-engine-group-discount' ); ?><span class="tooltip" title="<?php _e( 'Text to include in price holder for group discount.', 'wp-travel-engine-group-discount' ); ?>"><i class="fas fa-question-circle"></i></span></label>
				<input type="text" name="wp_travel_engine_settings[group][discount_title]" id="wp_travel_engine_settings[group][discount_title]" value="<?php echo isset($wp_travel_engine_settings['group']['discount_title']) ? esc_attr($wp_travel_engine_settings['group']['discount_title']) : 'Group Discount Guide';?>"/>
			</div>

			<h4 class="status-options"><?php _e('Group Discount Popup Labels','wp-travel-engine-group-discount');?></h4>
			<div class="group-dates-options">
				<label for="wp_travel_engine_settings[group][discount_guide_title]"><?php _e( 'Label for Group Discount Guide:','wp-travel-engine-group-discount' ); ?><span class="tooltip" title="<?php _e( 'Text to show for group discount label in Popup.', 'wp-travel-engine-group-discount' ); ?>"><i class="fas fa-question-circle"></i></span></label>
				<input type="text" name="wp_travel_engine_settings[group][discount_guide_title]" id="wp_travel_engine_settings[group][discount_guide_title]" value="<?php echo isset($wp_travel_engine_settings['group']['discount_guide_title']) ? esc_attr($wp_travel_engine_settings['group']['discount_guide_title']) : 'Group Discount';?>"/>
				
			</div>
			<div class="group-dates-options">
				<label for="wp_travel_engine_settings[group][discount_guide_traveler]"><?php _e( 'Label of Number of Traveler:','wp-travel-engine-group-discount' ); ?><span class="tooltip" title="<?php _e( 'Text to show for number of travelers in group discount popup.', 'wp-travel-engine-group-discount' ); ?>"><i class="fas fa-question-circle"></i></span></label>
				<input type="text" name="wp_travel_engine_settings[group][discount_guide_traveler]" id="wp_travel_engine_settings[group][discount_guide_traveler]" value="<?php echo isset($wp_travel_engine_settings['group']['discount_guide_traveler']) ? esc_attr($wp_travel_engine_settings['group']['discount_guide_traveler']) : 'Number of Travelers';?>"/>
				
			</div>
			<div class="group-dates-options">
				<label for="wp_travel_engine_settings[group][discount_guide_cost]"><?php _e( 'Label for Total Cost:','wp-travel-engine-group-discount' ); ?><span class="tooltip" title="<?php _e( 'Text to show for total cost in group discount popup.', 'wp-travel-engine-group-discount' ); ?>"><i class="fas fa-question-circle"></i></span></label>
				<input type="text" name="wp_travel_engine_settings[group][discount_guide_cost]" id="wp_travel_engine_settings[group][discount_guide_cost]" value="<?php echo isset($wp_travel_engine_settings['group']['discount_guide_cost']) ? esc_attr($wp_travel_engine_settings['group']['discount_guide_cost']) : 'Total Cost';?>"/>
				
			</div>
			<div class="group-dates-options">
				<label for="wp_travel_engine_settings[group][discount_guide_cost_traveler]"><?php _e( 'Label for Cost (per traveler):','wp-travel-engine-group-discount' ); ?><span class="tooltip" title="<?php _e( 'Text to show for cost per travelers in group discount popup.', 'wp-travel-engine-group-discount' ); ?>"><i class="fas fa-question-circle"></i></span></label>
				<input type="text" name="wp_travel_engine_settings[group][discount_guide_cost_traveler]" id="wp_travel_engine_settings[group][discount_guide_cost_traveler]" value="<?php echo isset($wp_travel_engine_settings['group']['discount_guide_cost_traveler']) ? esc_attr($wp_travel_engine_settings['group']['discount_guide_cost_traveler']) : 'Cost Per Traveler';?>"/>
				
			</div>

			<div class="group-dates-options">
				<label for="wp_travel_engine_settings[group][discount_guide_child_traveler]"><?php _e( 'Label of Number of Child Traveler:','wp-travel-engine-group-discount' ); ?><span class="tooltip" title="<?php _e( 'Text to show for number of child travelers in group discount popup.', 'wp-travel-engine-group-discount' ); ?>"><i class="fas fa-question-circle"></i></span></label>
				<input type="text" name="wp_travel_engine_settings[group][discount_guide_child_traveler]" id="wp_travel_engine_settings[group][discount_guide_child_traveler]" value="<?php echo isset($wp_travel_engine_settings['group']['discount_guide_child_traveler']) ? esc_attr($wp_travel_engine_settings['group']['discount_guide_child_traveler']) : 'Number of Child Travelers';?>"/>
				
			</div>
			
			<div class="group-dates-options">
				<label for="wp_travel_engine_settings[group][discount_guide_child_cost_traveler]"><?php _e( 'Label for Cost (per child traveler):','wp-travel-engine-group-discount' ); ?><span class="tooltip" title="<?php _e( 'Text to show for cost per child travelers in group discount popup.', 'wp-travel-engine-group-discount' ); ?>"><i class="fas fa-question-circle"></i></span></label>
				<input type="text" name="wp_travel_engine_settings[group][discount_guide_child_cost_traveler]" id="wp_travel_engine_settings[group][discount_guide_child_cost_traveler]" value="<?php echo isset($wp_travel_engine_settings['group']['discount_guide_child_cost_traveler']) ? esc_attr($wp_travel_engine_settings['group']['discount_guide_child_cost_traveler']) : 'Cost Per Child Traveler';?>"/>
				
			</div>

		</div>
	<?php
	}

	public function wp_travel_engine_group_discount_template()
	{ 
		$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', true );
		?>
		<div id="group-discount-template" style="display:none;">
			<div class="group-discount-inner" data-id="{{index}}"><i class="btn-close"></i>
				<table>
					<thead>
						<tr><td><?php _e('Group Discount ID: {{index}}','wp-travel-engine-group-discount' ); ?></td></tr>
						<tr><td><label for="wp_travel_engine_setting[group][traveler][{{index}}]"><?php _e('Number of Travelers','wp-travel-engine-group-discount');?><span class="required">*</span></label></td>
							<td><label for="wp_travel_engine_setting[group][cost][{{index}}]">
									<?php _e('Price','wp-travel-engine-group-discount');
									if(class_exists('Wp_Travel_Engine_Functions'))
									{
				                        global $post;
										$code = 'USD';

										$post_author = is_object( $post ) && isset( $post->post_author ) ? $post->post_author : '';

									    $user = get_userdata( $post_author );
									    if ( class_exists( 'Vendor_Wp_Travel_Engine' ) && $user && in_array( 'trip_vendor', $user->roles ) ) 
									    {
									        $userid = $user->ID;
									        $user = get_user_meta( $userid, 'wpte_vendor',true );
									        if( isset( $user['currency_code'] ) && $user['currency_code']!='' )
									        {
									            $code = $user['currency_code'];
									        }
									    }                                        
									    elseif( isset( $wp_travel_engine_settings['currency_code'] ) && $wp_travel_engine_settings['currency_code']!= '' )
									    {
									        $code = $wp_travel_engine_settings['currency_code'];
									    }
									    $obj = new Wp_Travel_Engine_Functions();
									    $currency = $obj->wp_travel_engine_currencies_symbol( $code );
									    echo ' ('.esc_attr($currency).')'; ?><span class="required">*</span>
									<?php 
									}
									?>
							    </label>
						    </td>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><input type="number" min="1" id="wp_travel_engine_setting[group][traveler][{{index}}]" name="wp_travel_engine_setting[group][traveler][{{index}}]" required></td>
							<td><input type="number" id="wp_travel_engine_setting[group][cost][{{index}}]" name="wp_travel_engine_setting[group][cost][{{index}}]" required></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>

		<div id="child-group-discount-template" style="display:none;">
			<div class="child-group-discount-inner" data-id="{{index}}"><i class="btn-close"></i>
				<table>
					<thead>
						<tr><td><?php _e('Child Group Discount ID: {{index}}','wp-travel-engine-group-discount' ); ?></td></tr>
						<tr><td><label for="wp_travel_engine_setting[group][child][{{index}}]"><?php _e('Number of Child Travelers','wp-travel-engine-group-discount');?><span class="required">*</span></label></td>
							<td><label for="wp_travel_engine_setting[group][cost][{{index}}]">
									<?php _e('Price','wp-travel-engine-group-discount');
									if(class_exists('Wp_Travel_Engine_Functions'))
									{
										global $post;
										$code = 'USD';

										$post_author = is_object( $post ) && isset( $post->post_author ) ? $post->post_author : '';

									    $user = get_userdata( $post_author );
									    if ( class_exists( 'Vendor_Wp_Travel_Engine' ) && $user && in_array( 'trip_vendor', $user->roles ) ) 
									    {
									        $userid = $user->ID;
									        $user = get_user_meta( $userid, 'wpte_vendor',true );
									        if( isset( $user['currency_code'] ) && $user['currency_code']!='' )
									        {
									            $code = $user['currency_code'];
									        }
									    }                                        
									    elseif( isset( $wp_travel_engine_settings['currency_code'] ) && $wp_travel_engine_settings['currency_code']!= '' )
									    {
									        $code = $wp_travel_engine_settings['currency_code'];
									    }
									    $obj = new Wp_Travel_Engine_Functions();
									    $currency = $obj->wp_travel_engine_currencies_symbol( $code );
									    echo ' ('.esc_attr($currency).')'; ?><span class="required">*</span>
									<?php 
									}
									?>
							    </label>
						    </td>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><input type="number" min="1" id="wp_travel_engine_setting[group][child][{{index}}]" name="wp_travel_engine_setting[group][child][{{index}}]" required></td>
							<td><input type="number" id="wp_travel_engine_setting[group][child_cost][{{index}}]" name="wp_travel_engine_setting[group][child_cost][{{index}}]" required></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>

		<div id="infant-group-discount-template" style="display:none;">
			<div class="infant-group-discount-inner" data-id="{{index}}"><i class="btn-close"></i>
				<table>
					<thead>
						<tr><td><?php _e('Infant Group Discount ID: {{index}}','wp-travel-engine-group-discount' ); ?></td></tr>
						<tr><td><label for="wp_travel_engine_setting[group][infant][{{index}}]"><?php _e('Number of Infant Travelers','wp-travel-engine-group-discount');?><span class="required">*</span></label></td>
							<td><label for="wp_travel_engine_setting[group][cost][{{index}}]">
									<?php _e('Price','wp-travel-engine-group-discount');
									if(class_exists('Wp_Travel_Engine_Functions'))
									{
										global $post;
										$code = 'USD';

										$post_author = is_object( $post ) && isset( $post->post_author ) ? $post->post_author : '';

									    $user = get_userdata( $post_author );
									    if ( class_exists( 'Vendor_Wp_Travel_Engine' ) && $user && in_array( 'trip_vendor', $user->roles ) ) 
									    {
									        $userid = $user->ID;
									        $user = get_user_meta( $userid, 'wpte_vendor',true );
									        if( isset( $user['currency_code'] ) && $user['currency_code']!='' )
									        {
									            $code = $user['currency_code'];
									        }
									    }                                        
									    elseif( isset( $wp_travel_engine_settings['currency_code'] ) && $wp_travel_engine_settings['currency_code']!= '' )
									    {
									        $code = $wp_travel_engine_settings['currency_code'];
									    }
									    $obj = new Wp_Travel_Engine_Functions();
									    $currency = $obj->wp_travel_engine_currencies_symbol( $code );
									    echo ' ('.esc_attr($currency).')'; ?><span class="required">*</span>
									<?php 
									}
									?>
							    </label>
						    </td>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td><input type="number" min="1" id="wp_travel_engine_setting[group][infant][{{index}}]" name="wp_travel_engine_setting[group][infant][{{index}}]" required></td>
							<td><input type="number" id="wp_travel_engine_setting[group][infant_cost][{{index}}]" name="wp_travel_engine_setting[group][infant_cost][{{index}}]" required></td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	<?php
	echo 
	'<style>
	#group-discount-template{
		display: none;
	}
	</style>';
	} 

	public function wp_travel_engine_trip_group_discount()
	{ 
		$tid = '';
		if(isset($_GET['vendor-trip']))
		{
		   $tid = $_GET['vendor-trip'];
		}
		else if(isset($_SESSION['draft'])){
		   $tid = $_SESSION['draft'];
		}
		else{
		   global $post;
		   $tid = $post->ID;
		}
		$wp_travel_engine_postmeta_setting = get_post_meta( $tid,'wp_travel_engine_setting',true );
		$option = isset($wp_travel_engine_postmeta_setting['group']['discount']) ? esc_attr($wp_travel_engine_postmeta_setting['group']['discount']) : '';
		$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', true );
		if(isset($wp_travel_engine_settings['group']['discount']))
		{
		?>
	    <div class="group-settings">
	        <label for="wp_travel_engine_setting[group][discount]"><?php _e('Enable Adult Group Discount:','wp-travel-engine-group-discount') ?></label>
	        <input class="group-discount-check" type="checkbox" id="wp_travel_engine_setting[group][discount]" name="wp_travel_engine_setting[group][discount]" value="1" <?php checked( $option, 1 ); ?>>
	        <label for="wp_travel_engine_setting[group][discount]" class="checkbox-label"></label>
	    </div>
		<div class="group-discount">
		    <?php
		    if(isset($wp_travel_engine_postmeta_setting['group']['traveler'])) :
			    $max = max(array_keys($wp_travel_engine_postmeta_setting['group']['traveler']));
			    for ( $i=1; $i<=$max; $i++ ) { 
			        if(array_key_exists($i, $wp_travel_engine_postmeta_setting['group']['traveler']))
			        {
			            ?>
			            <div class="group-discount-inner" data-id="<?php echo $i; ?>"><i class="btn-close"></i>
			                <table>
			                    <thead>
			                        <tr><td><?php _e('Adult Group Discount ID: ','wp-travel-engine-group-discount' ); echo $i;?></td></tr>
			                        <tr><td><label for="wp_travel_engine_setting[group][traveler][<?php echo $i;?>]"><?php _e('Number of Adult Travelers','wp-travel-engine-group-discount');?><span class="required">*</span></label></td>
			                            <td><label for="wp_travel_engine_setting[group][cost][<?php echo $i;?>]">
			                                    <?php _e('Price','wp-travel-engine-group-discount');
						                        $post = get_post($tid);
												$code = 'USD';
											    $user = get_userdata( $post->post_author );
											    if ( class_exists( 'Vendor_Wp_Travel_Engine' ) && $user && in_array( 'trip_vendor', $user->roles ) ) 
											    {
											        $userid = $user->ID;
											        $user = get_user_meta( $userid, 'wpte_vendor',true );
											        if( isset( $user['currency_code'] ) && $user['currency_code']!='' )
											        {
											            $code = $user['currency_code'];
											        }
											    }                                        
											    elseif( isset( $wp_travel_engine_settings['currency_code'] ) && $wp_travel_engine_settings['currency_code']!= '' )
											    {
											        $code = $wp_travel_engine_settings['currency_code'];
											    }
											    $obj = new Wp_Travel_Engine_Functions();
											    $currency = $obj->wp_travel_engine_currencies_symbol( $code );
			                                    echo ' ('.esc_attr($currency).')'; ?><span class="required">*</span>
			                                </label>
			                            </td>
			                        </tr>
			                    </thead>
			                    <tbody>
			                        <tr>
			                            <td><input type="number" min="1" id="wp_travel_engine_setting[group][traveler][<?php echo $i;?>]" name="wp_travel_engine_setting[group][traveler][<?php echo $i;?>]" value="<?php echo isset( $wp_travel_engine_postmeta_setting['group']['traveler'][$i] ) ? esc_attr( $wp_travel_engine_postmeta_setting['group']['traveler'][$i] ):'';?>" required></td>
			                            <td><input type="number" id="wp_travel_engine_setting[group][cost][<?php echo $i;?>]" name="wp_travel_engine_setting[group][cost][<?php echo $i;?>]" value="<?php echo isset( $wp_travel_engine_postmeta_setting['group']['cost'][$i] ) ? esc_attr( $wp_travel_engine_postmeta_setting['group']['cost'][$i] ): '';?>" required></td>
			                        </tr>
			                    </tbody>
			                </table>
			            </div>

			    <?php
			        } 
			    } 
			endif;
			?>
			<span class="discount-holder"></span>
		    <div class="group-settings">
		        <input type="button" class="button button-small add-discount" value="<?php _e('Add Adult Group Discount','wp-travel-engine-group-discount');?>">
		        <div class="settings-note"><?php _e('Add Adult Group Discount by pressing the above button. You can add price for different adult group.','wp-travel-engine-group-discount');?></div>
		    </div>
		</div>
		<div class="group-settings">
	        <label for="wp_travel_engine_setting[child-group][discount]"><?php _e('Enable Child Group Discount:','wp-travel-engine-group-discount') ?></label>
	        <?php
	        $option = isset($wp_travel_engine_postmeta_setting['child-group']['discount']) ? esc_attr($wp_travel_engine_postmeta_setting['child-group']['discount']) : '';
	        ?>
	        <input class="child-group-discount-check" type="checkbox" id="wp_travel_engine_setting[child-group][discount]" name="wp_travel_engine_setting[child-group][discount]" value="1" <?php checked( $option, 1 ); ?>>
	        <label for="wp_travel_engine_setting[child-group][discount]" class="checkbox-label"></label>
	    </div>
		<div class="child-group-discount">
			<?php
			if(isset($wp_travel_engine_postmeta_setting['group']['child'])) :
			    $max = max(array_keys($wp_travel_engine_postmeta_setting['group']['child']));
			    for ( $i=1; $i<=$max; $i++ ) { 
			        if(array_key_exists($i, $wp_travel_engine_postmeta_setting['group']['child']))
			        {
			            ?>
			            <div class="child-group-discount-inner" data-id="<?php echo $i; ?>"><i class="btn-close"></i>
			                <table>
			                    <thead>
			                        <tr><td><?php _e('Child Group Discount ID: ','wp-travel-engine-group-discount' ); echo $i;?></td></tr>
			                        <tr><td><label for="wp_travel_engine_setting[group][child][<?php echo $i;?>]"><?php _e('Number of Child Travelers','wp-travel-engine-group-discount');?><span class="required">*</span></label></td>
			                            <td><label for="wp_travel_engine_setting[group][cost][<?php echo $i;?>]">
			                                    <?php _e('Price','wp-travel-engine-group-discount');
			                                    $post = get_post($tid);
												$code = 'USD';
											    $user = get_userdata( $post->post_author );
											    if ( class_exists( 'Vendor_Wp_Travel_Engine' ) && $user && in_array( 'trip_vendor', $user->roles ) ) 
											    {
											        $userid = $user->ID;
											        $user = get_user_meta( $userid, 'wpte_vendor',true );
											        if( isset( $user['currency_code'] ) && $user['currency_code']!='' )
											        {
											            $code = $user['currency_code'];
											        }
											    }                                        
											    elseif( isset( $wp_travel_engine_settings['currency_code'] ) && $wp_travel_engine_settings['currency_code']!= '' )
											    {
											        $code = $wp_travel_engine_settings['currency_code'];
											    }
											    $obj = new Wp_Travel_Engine_Functions();
											    $currency = $obj->wp_travel_engine_currencies_symbol( $code );
			                                    echo ' ('.esc_attr($currency).')'; ?><span class="required">*</span>
			                                </label>
			                            </td>
			                        </tr>
			                    </thead>
			                    <tbody>
			                        <tr>
			                            <td><input type="number" min="1" id="wp_travel_engine_setting[group][child][<?php echo $i;?>]" name="wp_travel_engine_setting[group][child][<?php echo $i;?>]" value="<?php echo isset( $wp_travel_engine_postmeta_setting['group']['child'][$i] ) ? esc_attr( $wp_travel_engine_postmeta_setting['group']['child'][$i] ):'';?>" required></td>
			                            <td><input type="number" id="wp_travel_engine_setting[group][child_cost][<?php echo $i;?>]" name="wp_travel_engine_setting[group][child_cost][<?php echo $i;?>]" value="<?php echo isset( $wp_travel_engine_postmeta_setting['group']['child_cost'][$i] ) ? esc_attr( $wp_travel_engine_postmeta_setting['group']['child_cost'][$i] ): '';?>" required></td>
			                        </tr>
			                    </tbody>
			                </table>
			            </div>
			    <?php
			        } 
			    } 
			endif;
		    ?>
		    <span class="child-discount-holder"></span>
		    <div class="group-settings">
		        <input type="button" class="button button-small add-child-discount" value="<?php _e('Add Child Group Discount','wp-travel-engine-group-discount');?>">
		        <div class="settings-note"><?php _e( 'Add Child Group Discount by pressing the above button. You can add price for different child group.','wp-travel-engine-group-discount' );?></div>
		    </div>
		</div>

		<div class="group-settings">
	        <label for="wp_travel_engine_setting[infant-group][discount]"><?php _e('Enable Infant Group Discount:','wp-travel-engine-group-discount') ?></label>
	        <?php
	        $option = isset($wp_travel_engine_postmeta_setting['infant-group']['discount']) ? esc_attr($wp_travel_engine_postmeta_setting['infant-group']['discount']) : '';
	        ?>
	        <input class="infant-group-discount-check" type="checkbox" id="wp_travel_engine_setting[infant-group][discount]" name="wp_travel_engine_setting[infant-group][discount]" value="1" <?php checked( $option, 1 ); ?>>
	        <label for="wp_travel_engine_setting[infant-group][discount]" class="checkbox-label"></label>
	    </div>
		<div class="infant-group-discount">
			<?php
			if(isset($wp_travel_engine_postmeta_setting['group']['infant'])) :
			    $max = max(array_keys($wp_travel_engine_postmeta_setting['group']['infant']));
			    for ( $i=1; $i<=$max; $i++ ) { 
			        if(array_key_exists($i, $wp_travel_engine_postmeta_setting['group']['infant']))
			        {
			            ?>
			            <div class="infant-group-discount-inner" data-id="<?php echo $i; ?>"><i class="btn-close"></i>
			                <table>
			                    <thead>
			                        <tr><td><?php _e('Infant Group Discount ID: ','wp-travel-engine-group-discount' ); echo $i;?></td></tr>
			                        <tr><td><label for="wp_travel_engine_setting[group][infant][<?php echo $i;?>]"><?php _e('Number of Infant Travelers','wp-travel-engine-group-discount');?><span class="required">*</span></label></td>
			                            <td><label for="wp_travel_engine_setting[group][cost][<?php echo $i;?>]">
			                                    <?php _e('Price','wp-travel-engine-group-discount');
			                                    $post = get_post($tid);
												$code = 'USD';
											    $user = get_userdata( $post->post_author );
											    if ( class_exists( 'Vendor_Wp_Travel_Engine' ) && $user && in_array( 'trip_vendor', $user->roles ) ) 
											    {
											        $userid = $user->ID;
											        $user = get_user_meta( $userid, 'wpte_vendor',true );
											        if( isset( $user['currency_code'] ) && $user['currency_code']!='' )
											        {
											            $code = $user['currency_code'];
											        }
											    }                                        
											    elseif( isset( $wp_travel_engine_settings['currency_code'] ) && $wp_travel_engine_settings['currency_code']!= '' )
											    {
											        $code = $wp_travel_engine_settings['currency_code'];
											    }
											    $obj = new Wp_Travel_Engine_Functions();
											    $currency = $obj->wp_travel_engine_currencies_symbol( $code );
			                                    echo ' ('.esc_attr($currency).')'; ?><span class="required">*</span>
			                                </label>
			                            </td>
			                        </tr>
			                    </thead>
			                    <tbody>
			                        <tr>
			                            <td><input type="number" min="1" id="wp_travel_engine_setting[group][infant][<?php echo $i;?>]" name="wp_travel_engine_setting[group][infant][<?php echo $i;?>]" value="<?php echo isset( $wp_travel_engine_postmeta_setting['group']['infant'][$i] ) ? esc_attr( $wp_travel_engine_postmeta_setting['group']['infant'][$i] ):'';?>" required></td>
			                            <td><input type="number" id="wp_travel_engine_setting[group][infant_cost][<?php echo $i;?>]" name="wp_travel_engine_setting[group][infant_cost][<?php echo $i;?>]" value="<?php echo isset( $wp_travel_engine_postmeta_setting['group']['infant_cost'][$i] ) ? esc_attr( $wp_travel_engine_postmeta_setting['group']['infant_cost'][$i] ): '';?>" required></td>
			                        </tr>
			                    </tbody>
			                </table>
			            </div>
			    <?php
			        } 
			    } 
			endif;
		    ?>
		    <span class="infant-discount-holder"></span>
		    <div class="group-settings">
		        <input type="button" class="button button-small add-infant-discount" value="<?php _e('Add Infant Group Discount','wp-travel-engine-group-discount');?>">
		        <div class="settings-note"><?php _e( 'Add Infant Group Discount by pressing the above button. You can add price for different infant group.','wp-travel-engine-group-discount' );?></div>
		    </div>
		</div>
	<?php
		}
	}

	/**
	 * This will add group discount fields in WP Travel Engine - Pricing Tab.
	 * 
	 * @since 2.0.0
	 */
	public function wte_add_group_discount_pricing() {
		include plugin_dir_path( __FILE__ ) . '/partials/wp-travel-engine-group-discount-admin-display.php';
	}

	/**
	 * This will uninstall this plugin if parent WP Travel plugin not found.
	 * 
	 * @since 1.1.1
	 */
	public function check_dependency() {

		if ( ! class_exists( 'Wp_Travel_Engine' ) || ! $this->meets_requirements() ) {
			echo '<div class="error">';
			echo wp_kses_post( '
				<p>
					<strong>
						WP Travel Engine - Group Discount
					</strong> 
					requires the <a href="https://wptravelengine.com" target="__blank">WP Travel Engine.</a>
					Please install and activate the latest WP Travel Engine plugin first. 
					<b>WP Travel Engine - Group Discount will be deactivated now.</b>
				</p>' );
			echo '</div>';

			// Deactivate Plugins.
			deactivate_plugins( plugin_basename( WP_TRAVEL_ENGINE_GROUP_DISCOUNT_FILE_PATH ) );
		}
	}

	/**
	 * Check if all plugin requirements are met.
	 *
	 * @since 1.1.1
	 *
	 * @return bool True if requirements are met, otherwise false.
	 */
	private function meets_requirements() {
		return ( class_exists( 'WP_Travel_Engine' ) && defined( 'WP_TRAVEL_ENGINE_VERSION' ) && version_compare( WP_TRAVEL_ENGINE_VERSION, '4.1.1', '>=' ) );
	}

	/**
	 * Global settings array register.
	 *
	 * @return void
	 */
	function wte_gd_extension_settings( $extension_settings ) {
		$extension_settings['wte_gd'] = array(
			'label'        => __( 'Group Discount', 'wp-travel-engine-group-discount' ),
			'content_path' => plugin_dir_path( WP_TRAVEL_ENGINE_GROUP_DISCOUNT_FILE_PATH ) . 'includes/settings/global-settings.php',
			'current'      => false,
		);
		return $extension_settings;
	}

}
