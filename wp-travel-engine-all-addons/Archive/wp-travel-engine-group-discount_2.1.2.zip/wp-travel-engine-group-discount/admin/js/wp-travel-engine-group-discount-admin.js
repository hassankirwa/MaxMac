function wte_gd_revamped_ui_js( content_key ) {

    // Bail if content key is not availibility.
    if( content_key[0] != 'wpte-pricing' ) {
        return;
    }

    jQuery(document).on( 'click', '.wpte-gd-toggle', function(e) {
        var input = jQuery(this);
        if( input.hasClass( "active" ) ) {
            input.siblings('.wpte-onoff-popup').find('input[type=number]:not(.gd-range-high)').attr('required', 'required');
            input.siblings('.wpte-onoff-popup').find('.gd-range-high:not(:last)').attr('required', 'required');
        } else {
            input.siblings('.wpte-onoff-popup').find('input[type=number]').removeAttr('required');
        }
    });

    jQuery(document).on( 'blur', '.gd-range-high', function(e) {
        e.preventDefault();

        var input = jQuery(this),
            i = input.parents('.wte-gd-row').nextAll('.wte-gd-row').length,
            id = input.parents('.wte-gd-row').attr( 'data-id' );

        var travrange = input.val();
        travrange = parseInt(travrange);
        if(isNaN(travrange)) {
            if( i > 0 ) {
                input.parents('.wte-gd-row').nextAll('.wte-gd-row').remove();
                if( id != 1 ) {
                    input.parents('.wte-gd-row').find('.wpte-floated:first').append('<button class="wpte-delete wpte-gd-delete"></button>');
                }
                if( id == 1 ) {
                    input.removeAttr('required');
                }
            }
            return;
        }

        var prevrange = input.prev().val();
        prevrange = parseInt(prevrange);
        if( travrange < prevrange ) {
            input.val('');
            return;
        }

        if( i > 0 ) {
            input.parents('.wte-gd-row').nextAll('.wte-gd-row').each(function() {
                travrange = jQuery(this).prev().find('.gd-range-high').val();
                travrange = parseInt(travrange);
                jQuery(this).find('.gd-range-low').val(travrange+=1);

                var nextrange = jQuery(this).find('.gd-range-high').val();
                nextrange = parseInt(nextrange);
                if( ! isNaN(travrange) && travrange >= nextrange ) {
                    jQuery(this).find('.gd-range-high').val(travrange+=1);
                }
            });
            return;
        }

        var template = wp.template( 'group-dist-block-tmp' ),
            type = input.parents('.wte-gd-row').attr( 'data-type' ),    
            index  = get_max_gd_id(type),   
            travlbl = gd_pricing_options[type].label,
            costlbl = gd_pricing_options[type].cost;

        var tmplData = {
            index: index,
            type: type,
            travlbl: travlbl,
            travrange: travrange+1,
            costlbl: costlbl
        };
        input.parents('.wpte-form-content .wte-gd-row').find('.wpte-gd-delete').remove();
        input.parents('.wpte-form-content .wte-gd-row').after( template( tmplData ) );

    });

    jQuery( document ).on( 'click', '.wpte-gd-delete', function(e) {
        e.preventDefault();
    
        var confirmation = confirm(WTE_UI.suretodel);
        if (!confirmation) {
            return false;
        }
        var id = jQuery(this).parents('.wte-gd-row').attr( 'data-id' );

        jQuery(this).parents('.wte-gd-row').prev().find('.gd-range-high').val('');
        jQuery(this).parents('.wte-gd-row').prev().find('.gd-range-high').removeAttr('required');
        if( id != 2 ) {
            jQuery(this).parents('.wte-gd-row').prev().find('.wpte-floated:first').append('<button class="wpte-delete wpte-gd-delete"></button>');
        }
        jQuery(this).parents('.wte-gd-row').remove();
    
    });

}

function get_max_gd_id(type) {
    var maximum=0;
    jQuery( '.wte-gd-row' ).each(function() {
        var option = jQuery(this).attr( 'data-type' );
        if( option == type ) {
            var value =  jQuery(this).attr( 'data-id' );
            if(!isNaN(value)) {
                value = parseInt(value);
                maximum = (value > maximum) ? value : maximum;
            }
        }
    });
    maximum++;
    return maximum;
}

jQuery(document).ready(function($){

    wpte_add_action( 'wpte_after_admin_tab_shown', 'wte_gd_revamped_ui_js', 10 );

    $('body').on('click', '.add-discount', function (e){ 
        e.preventDefault();
        var len=0;
        $( '.group-discount-inner:visible' ).each(function() {
            var value =  $(this).attr( 'data-id' );
            if(!isNaN(value))
            {
                value = parseInt(value);
                len = (value > len) ? value : len;
            }
        });
        len++;
        var newinput = $( '#group-discount-template' ).clone();
        newinput.html(function(i, oldHTML) {
            return oldHTML.replace( /{{index}}/g, len );
        });
        $( '.discount-holder' ).before(  newinput.html() );
    });

    $('body').on('click', '.add-child-discount', function (e){ 
        e.preventDefault();
        var len=0;
        $( '.child-group-discount-inner:visible' ).each(function() {
            var value =  $(this).attr( 'data-id' );
            if(!isNaN(value))
            {
                value = parseInt(value);
                len = (value > len) ? value : len;
            }
        });
        len++;
        var newinput = $( '#child-group-discount-template' ).clone();
        newinput.html(function(i, oldHTML) {
            return oldHTML.replace( /{{index}}/g, len );
        });
        $( '.child-discount-holder' ).before(  newinput.html() );
    });

    $('body').on('click', '.add-infant-discount', function (e){ 
        e.preventDefault();
        var len=0;
        $( '.infant-group-discount-inner:visible' ).each(function() {
            var value =  $(this).attr( 'data-id' );
            if(!isNaN(value))
            {
                value = parseInt(value);
                len = (value > len) ? value : len;
            }
        });
        len++;
        var newinput = $( '#infant-group-discount-template' ).clone();
        newinput.html(function(i, oldHTML) {
            return oldHTML.replace( /{{index}}/g, len );
        });
        $( '.infant-discount-holder' ).before(  newinput.html() );
    });

    $('body').on('click', '.group-discount-inner .btn-close', function (e){   
        e.preventDefault();
        $(this).parent().fadeOut('slow',function(){
            $(this).remove();
        });
    });
    
    if ($('.group-discount-check').is( ':checked' )) {
        $('.group-discount').show();
    }
    else{
        $('.group-discount').hide();
    }

    $('body').on('click', '.group-discount-check', function (e){ 
        if ($('.group-discount-check').is( ':checked' )) {
            $('.group-discount').fadeIn('slow');
        }
        else{
            $('.group-discount').fadeOut('slow');
        }
    });


    $('body').on('click', '.child-group-discount-inner .btn-close', function (e){   
        e.preventDefault();
        $(this).parent().fadeOut('slow',function(){
            $(this).remove();
        });
    });

    $('body').on('click', '.infant-group-discount-inner .btn-close', function (e){   
        e.preventDefault();
        $(this).parent().fadeOut('slow',function(){
            $(this).remove();
        });
    });
    
    if ($('.child-group-discount-check').is( ':checked' )) {
        $('.child-group-discount').show();
    }
    else{
        $('.child-group-discount').hide();
    }

    $('body').on('click', '.child-group-discount-check', function (e){ 
        if ($('.child-group-discount-check').is( ':checked' )) {
            $('.child-group-discount').fadeIn('slow');
        }
        else{
            $('.child-group-discount').fadeOut('slow');
        }
    });

    if ($('.infant-group-discount-check').is(':checked')) {
        $('.infant-group-discount').show();
    }
    else {
        $('.infant-group-discount').hide();
    }

    $('body').on('click', '.infant-group-discount-check', function (e) {
        if ($('.infant-group-discount-check').is(':checked')) {
            $('.infant-group-discount').fadeIn('slow');
        }
        else {
            $('.infant-group-discount').fadeOut('slow');
        }
    });
});