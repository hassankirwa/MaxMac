<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://wptravelengine.com/
 * @since      1.0.0
 *
 * @package    Wp_Travel_Engine_Group_Discount
 * @subpackage Wp_Travel_Engine_Group_Discount/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->

<?php
	global $post;
	// Get post ID.
if ( ! is_object( $post ) && defined( 'DOING_AJAX' ) && DOING_AJAX ) {
	$post_id  = $_POST['post_id'];
	$next_tab = $_POST['next_tab'];
} else {
	$post_id = $post->ID;
}
	/**
	 * Group Discount Settings.
	 */
	$wte_trip_settings         = get_post_meta( $post_id, 'wp_travel_engine_setting', true );
	$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', true );

if ( ! isset( $wp_travel_engine_settings['group']['discount'] ) ) {
	?>
			<div class="wpte-form-block">
				<div class="wpte-title-wrap">
					<h2 class="wpte-title"><?php _e( 'Group Discount', 'wp-travel-engine-group-discount' ); ?></h2>
				</div> <!-- .wpte-title-wrap -->
				<div class="wpte-info-block">
					<p><?php _e( 'Group Discount is disabled. Please enable Group Discount via WP Travel Engine > Settings > Extensions > Group Discount.', 'wp-travel-engine-group-discount' ); ?></p>
				</div>
			</div>
		<?php
		return;
}

	$default_price = wp_travel_engine_get_actual_trip_price( $post_id );

	// default options.
	$default_pricing_options = apply_filters(
		'wte_gd_pricing_options',
		array(
			'adult'  => array(
				'group', // enable
				'traveler',
				'cost',
			),
			'child'  => array(
				'child-group', // enable
				'child',
				'child_cost',
			),
			'infant' => array(
				'infant-group', // enable
				'infant',
				'infant_cost',
			),
		)
	);
	?>

<div class="wpte-form-block-wrap">
	<div class="wpte-form-block">
		<div class="wpte-title-wrap">
			<h2 class="wpte-title"><?php _e( 'Group Discount', 'wp-travel-engine-group-discount' ); ?></h2>
			<span class="wpte-tooltip"><?php _e( 'Please add the total prices per person. Prices can be changed according to the number of people booking.', 'wp-travel-engine-group-discount' ); ?></span>
		</div> <!-- .wpte-title-wrap -->

		<div class="wpte-form-content">
			<?php
			foreach ( $default_pricing_options as $option => $label ) {
				$enable    = $label[0];
				$label_gd  = ucfirst( $option );
				$enable_gd = isset( $wte_trip_settings[ $enable ]['discount'] ) ? esc_attr( $wte_trip_settings[ $enable ]['discount'] ) : '';
				?>
				<div class="wpte-field wpte-onoff-block">
					<a href="Javascript:void(0);" class="wpte-onoff-toggle wpte-gd-toggle <?php echo $enable_gd ? 'active' : ''; ?>">
						<label for="wp_travel_engine_setting[<?php echo $enable; ?>][discount]" class="wpte-field-label"><?php echo esc_html( sprintf( __( 'Enable %1$s Group Discount', 'wp-travel-engine-group-discount' ), $label_gd ) ); ?><span class="wpte-onoff-btn"></span></label>
					</a>
					<input type="hidden" name="wp_travel_engine_setting[<?php echo $enable; ?>][discount]" value="0">
					<input 
						type    = "checkbox"
						id      = "wp_travel_engine_setting[<?php echo $enable; ?>][discount]"
						name    = "wp_travel_engine_setting[<?php echo $enable; ?>][discount]"
						value   = "1"
						<?php checked( $enable_gd, 1 ); ?>
					/>
					<span class="wpte-tooltip">
						<?php echo esc_html( sprintf( __( 'Check this if you want to enable %1$s Group Discount. You can add prices for the different %2$s groups.', 'wp-travel-engine-group-discount' ), $label_gd, $option ) ); ?>
					</span>

					<div <?php echo $enable_gd ? 'style="display:block;"' : ''; ?> class="wpte-onoff-popup wpte-form-block">
						<div class="wpte-title-wrap">
							<h2 class="wpte-title"><?php echo $label_gd; ?></h2>
						</div>

						<div class="wpte-form-content">
							<?php
							$traveler = $label[1];
							$cost     = $label[2];
							if ( isset( $wte_trip_settings['group'][ $traveler ] ) ) :
								$max = max( array_keys( $wte_trip_settings['group'][ $traveler ] ) );

								for ( $i = 1; $i <= $max; $i++ ) :
									if ( array_key_exists( $i, $wte_trip_settings['group'][ $traveler ] ) ) :
										$from_traveler = isset( $wte_trip_settings['group'][ $traveler ][ $i ] ) ? $wte_trip_settings['group'][ $traveler ][ $i ] : '';

										$to_traveler = isset( $wte_trip_settings['group'][ $traveler ][ $i . '_' . $i ] ) ? $wte_trip_settings['group'][ $traveler ][ $i . '_' . $i ] : '';

										$price_per_person = isset( $wte_trip_settings['group'][ $cost ][ $i ] ) ? $wte_trip_settings['group'][ $cost ][ $i ] : '';

										$price_per_person = ! isset( $wte_trip_settings['group'][ $traveler ][ $i . '_' . $i ] ) ? bcdiv( $price_per_person, $from_traveler, 2 ) : $price_per_person;

                                        $min = " min=\"1\" ";
                                        if ( empty( $to_traveler ) ) {
                                            $min = ' ';
                                        }
										?>
										<div class="wpte-repeater-block wte-gd-row" data-id="<?php echo $i; ?>" data-type="<?php echo $option; ?>">
											<div class="wpte-floated">
												<div class="wpte-col2">
													<div class="wpte-field wpte-multi-fields">
														<?php
														if ( $i == 1 ) {
															?>
															<label class="wpte-field-label"><?php _e( 'Number Of Person', 'wp-travel-engine-group-discount' ); ?></label>
															<?php
														}
														?>
														<div class="wpte-floated">
															<input 
																type="number" readonly 
																class="gd-range-low"
                                                                min="1" 
																name="wp_travel_engine_setting[group][<?php echo $traveler; ?>][<?php echo $i; ?>]" 
																value="<?php echo esc_attr( $from_traveler ); ?>" 
																placeholder="1"
															>
															-
															<input 
																type="number"
																class="gd-range-high"
                                                                <?php echo $min; ?>
																name="wp_travel_engine_setting[group][<?php echo $traveler; ?>][<?php echo $i . '_' . $i; ?>]" 
																value="<?php echo esc_attr( $to_traveler ); ?>" 
																placeholder="Unlimited" 
																<?php echo ( $enable_gd && ! empty( $to_traveler ) ) ? 'required' : ''; ?>
															>
														</div>
													</div>
												</div>

												<div class="wpte-col2">
													<div class="wpte-field wpte-multi-fields">
														<?php
														if ( $i == 1 ) {
															?>
															<label class="wpte-field-label"><?php _e( 'Price Per Person', 'wp-travel-engine-group-discount' ); ?></label>
															<?php
														}
														?>
																									
														<div class="wpte-floated">
															<input 
																type="number" min="0" 
																name="wp_travel_engine_setting[group][<?php echo $cost; ?>][<?php echo $i; ?>]" 
																value="<?php echo esc_attr( $price_per_person ); ?>" 
																placeholder="<?php _e( 'Total price per person', 'wp-travel-engine-group-discount' ); ?>" 
																<?php echo ( $enable_gd ) ? 'required' : ''; ?>
															>
															<span class="wpte-sublabel"><?php echo esc_html( wp_travel_engine_get_currency_code() ); ?></span>
														</div>
													</div>
												</div>
												<?php
												if ( $i != 1 && $i == $max ) {
													?>
													<button class="wpte-delete wpte-gd-delete"></button>
													<?php
												}
												?>
											</div>
										</div>
										<?php
									endif;
								endfor;

							else :
								?>
								<div class="wpte-repeater-block wte-gd-row" data-id="1" data-type="<?php echo $option; ?>">
									<div class="wpte-floated">
										<div class="wpte-col2">
											<div class="wpte-field wpte-multi-fields">
												<label class="wpte-field-label"><?php _e( 'Number Of Person', 'wp-travel-engine-group-discount' ); ?></label>
												<div class="wpte-floated">
													<input 
														type="number" readonly 
														class="gd-range-low" min="1" 
														name="wp_travel_engine_setting[group][<?php echo $traveler; ?>][1]" 
														value="1" 
														placeholder="1"
													>
													-
													<input 
														type="number" 
														class="gd-range-high" min="1" 
														name="wp_travel_engine_setting[group][<?php echo $traveler; ?>][1_1]" 
														value="" 
														placeholder="Unlimited"
													>
												</div>
											</div>
										</div>
				
										<div class="wpte-col2">
											<div class="wpte-field wpte-multi-fields">
												<label class="wpte-field-label"><?php _e( 'Price Per Person', 'wp-travel-engine-group-discount' ); ?></label>
												<div class="wpte-floated">
													<input 
														type="number" min="0" 
														name="wp_travel_engine_setting[group][<?php echo $cost; ?>][1]" 
														value="<?php echo esc_attr( $default_price ); ?>" 
														placeholder="<?php _e( 'Total price per person', 'wp-travel-engine-group-discount' ); ?>" 
														<?php echo ( $enable_gd ) ? 'required' : ''; ?>
													>
													<span class="wpte-sublabel"><?php echo esc_html( wp_travel_engine_get_currency_code() ); ?></span>
												</div>
											</div>
										</div>
									</div>
								</div>
							<?php endif; ?>

							<span class="wpte-tooltip"><?php _e( 'Please add the group range like 1-5, 5-10, 10-Unlimited. Leave the higher range input field empty for the Unlimited range.', 'wp-travel-engine-group-discount' ); ?></span>
						</div>
					</div> <!-- .wpte-form-block -->
				</div>
				<?php
			}
			?>
		</div> <!-- .wpte-form-content -->
	</div> <!-- .wpte-form-block -->
</div> <!-- .wpte-form-block-wrap -->

<script type="text/html" id="tmpl-group-dist-block-tmp">
	<div class="wpte-repeater-block wte-gd-row" data-id="{{data.index}}" data-type="{{data.type}}">
		<div class="wpte-floated">
			<div class="wpte-col2">
				<div class="wpte-field wpte-multi-fields">
					<div class="wpte-floated">
						<input type="number" readonly min="1" class="gd-range-low" name="wp_travel_engine_setting[group][{{data.travlbl}}][{{data.index}}]" value="{{data.travrange}}" placeholder="1">
						-
						<input type="number" min="1" class="gd-range-high" name="wp_travel_engine_setting[group][{{data.travlbl}}][{{data.index}}_{{data.index}}]" value="" placeholder="Unlimited">
					</div>
				</div>
			</div>

			<div class="wpte-col2">
				<div class="wpte-field wpte-multi-fields">
					<div class="wpte-floated">
						<input type="number" min="0" name="wp_travel_engine_setting[group][{{data.costlbl}}][{{data.index}}]" value="" placeholder="<?php _e( 'Total price per person', 'wp-travel-engine-group-discount' ); ?>" required>
						<span class="wpte-sublabel"><?php echo esc_html( wp_travel_engine_get_currency_code() ); ?></span>
					</div>
				</div>
			</div>
			<button class="wpte-delete wpte-gd-delete"></button>
		</div>
	</div>
</script>
<?php
