
jQuery(document).ready(function($){
    $('[data-popup-open]').on('click', function(e)  {
        var targeted_popup_class = jQuery(this).attr('data-popup-open');
        $('[data-popup="' + targeted_popup_class + '"]').fadeIn(350);
        e.preventDefault();
    });

    //----- CLOSE
    $('[data-popup-close]').on('click', function(e)  {
        var targeted_popup_class = jQuery(this).attr('data-popup-close');
        $('[data-popup="' + targeted_popup_class + '"]').fadeOut(350);

        e.preventDefault();
    });
    
    function addComma(nStr) {
        nStr += '';
        var x = nStr.split('.');
        var x1 = x[0];
        var x2 = x.length > 1 ? '.' + x[1] : '';
        var rgx = /(\d+)(\d{3})/;
        while (rgx.test(x1)) {
            x1 = x1.replace(rgx, '$1' + WPTE_Price_Separator + '$2');
        }
        return x1 + x2;
    }

    $('body').on('change', '.travelers-no, .child-travelers-no', function (e){ 
        e.preventDefault();
        var val = $('.travelers-no').val();
        var val1 = $('.child-travelers-no').val();
        nonce = $('#nonce').val();
        var pid = $('.group-discount-check').attr('data-id');
        var date = 0;
        date = $('.wp-travel-engine-price-datetime').val();
        var total1 = 0;
        var total2 = 0;
        jQuery.ajax({
            type : 'post',
            url : WTEAjaxData.ajaxurl,
            data : {action: 'group_discount_calculate', val1 : val1, val : val, nonce: nonce, pid: pid, date: date},
            beforeSend: function(){
                $("#price-loading").fadeIn(500);
            },
            success: function(response){
                $('.discount-price-traveler').text('');
                if( response && response.data != undefined )
                {
                    if( response.data.adult )
                    {
                        $cost = JSON.parse(response.data.adult);
                        total1 = $cost;
                        var per = '';
                        per = $cost/val;
                        $('.discount-price-traveler').html(per);
                    }
                    if( val1!= 0 && response.data.child )
                    {
                        var max = $('.child-travelers-no').attr('max');
                        if( val1 > max )
                        {
                            $('.discount-price-per-child-traveler').html(wpte_gd.first_part+max+wpte_gd.second_part);
                            $('.discount-price-per-child-traveler').show();
                            $('.discount-price-per-child-traveler .currency').hide();
                            $('.discount-price-per-child-traveler .currency-code').hide();
                        }
                        else{
                            $cost = response.data.child;
                            total2 = $cost;
                            var per = '';
                            per = $cost/val1;
                            if( per!='' )
                            {
                                $('.discount-price-per-child-traveler').show();
                                $('.discount-price-child-traveler').html(per);
                            }
                        }
                    }
                    var total = 0;
                    $service_cost = 0;
                    total = total1+total2;
                    $('#trip-cost').val(total);
                    if( $('.extra-service').length > 0 )
                    {
                        $('.extra-service').each(function() {
                            var val = $(this).val();
                            var dataid = $(this).attr('data-id');
                            var cost = parseInt( $( '.extra-service-cost[data-id='+dataid+']' ).attr('data-cost') );
                            var service = val*cost;
                            $('.service-temporary[data-id="' + dataid + '"]').val(service); 
                            $service_cost = 0;
                            $('.service-temporary').each(function(){
                                if($(this).val()!=0)
                                {
                                    $service_cost += parseInt($(this).val());
                                }
                            });
                        });
                    }
                    total  = total + $service_cost;
                    $('.total').html(addComma(total));
                }
            },
            complete: function(){
                $("#price-loading").fadeOut(500);             
            }
        });   
    });
});

function applyGroupDiscount(count, type, cost) {
    type = type.toLowerCase();
    if ( 'adult' == type || 'person' == type ) {
        type = 'travelers';
    }

    // Apply group discount.
    if ( 'travelers' === type ) {
        var travelers = Object.keys(wteGroupDiscount.traveler);
        var arrycount = travelers.length;
            travelers = travelers.map(returnInt);
            
        var uniquetravelers = travelers.filter( onlyUnique );
        var uniquecount = uniquetravelers.length;
        
        for (traveller in wteGroupDiscount.traveler) {
            if ( uniquecount == arrycount && count == wteGroupDiscount.traveler[traveller] ) {
                return wteGroupDiscount['cost'][traveller];
            }

            var i = traveller+'_'+traveller;
            var min = wteGroupDiscount.traveler[traveller];
                min = parseInt(min);
            var max = wteGroupDiscount.traveler[i];
                max = parseInt(max);
            
            if( uniquecount != arrycount && ( ( isNaN(max) && !isNaN(min) && count >= min ) 
            || inRange( count, min, max ) ) ) {
                return parseInt(count) * parseFloat(wteGroupDiscount['cost'][traveller]);
            }           
        }
    } else if ( 'child' === type ) {
        var children = Object.keys(wteGroupDiscount.child);
        var arrycount = children.length;
            children = children.map(returnInt);
            
        var uniquechildren = children.filter( onlyUnique );
        var uniquecount = uniquechildren.length;

        for (child in wteGroupDiscount.child) {
            if ( uniquecount == arrycount && count == wteGroupDiscount.child[child] ) {
                return wteGroupDiscount['child_cost'][child]
            }

            var i = child+'_'+child;
            var min = wteGroupDiscount.child[child];
                min = parseInt(min);
            var max = wteGroupDiscount.child[i];
                max = parseInt(max);
            
            if( uniquecount != arrycount && ( ( isNaN(max) && !isNaN(min) && count >= min ) 
            || inRange( count, min, max ) ) ) {
                return parseInt(count) * parseFloat(wteGroupDiscount['child_cost'][child]);
            }
        }
    } else if ( 'infant' === type ) {
        var infants = Object.keys(wteGroupDiscount.infant);
        var arrycount = infants.length;
            infants = infants.map(returnInt);
            
        var uniqueinfants = infants.filter( onlyUnique );
        var uniquecount = uniqueinfants.length;

        for (infant in wteGroupDiscount.infant) {
            if ( uniquecount == arrycount && count == wteGroupDiscount.infant[infant] ) {
                return wteGroupDiscount['infant_cost'][infant]
            }

            var i = infant+'_'+infant;
            var min = wteGroupDiscount.infant[infant];
                min = parseInt(min);
            var max = wteGroupDiscount.infant[i];
                max = parseInt(max);
            
            if( uniquecount != arrycount && ( ( isNaN(max) && !isNaN(min) && count >= min ) 
            || inRange( count, min, max ) ) ) {
                return parseInt(count) * parseFloat(wteGroupDiscount['infant_cost'][infant]);
            }
        }
    }
    return cost;
}

function inRange(x, min, max) {
    return ((x-min)*(x-max) <= 0);
}

function returnInt(element) {
    return parseInt(element, 10)
}

function onlyUnique(value, index, self) { 
    return self.indexOf(value) === index;
}