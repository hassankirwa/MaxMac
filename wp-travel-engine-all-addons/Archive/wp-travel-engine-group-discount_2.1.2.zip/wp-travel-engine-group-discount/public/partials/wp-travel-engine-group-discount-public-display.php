<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://wptravelengine.com/
 * @since      1.0.0
 *
 * @package    Wp_Travel_Engine_Group_Discount
 * @subpackage Wp_Travel_Engine_Group_Discount/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
