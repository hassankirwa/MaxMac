<?php

/**
 * Template for child price input in price list in booking form at trip page.
 *
 * @link       https://wptravelengine.com/
 * @since      1.0.0
 *
 * @package    Wp_Travel_Engine_Group_Discount
 * @subpackage Wp_Travel_Engine_Group_Discount/public/partials
 */
?>

<div class="wpte-bf-traveler-block">
    <div class="wpte-bf-traveler">
        <div class="wpte-bf-number-field">
            <input type="text" name="add-member" value="0"
                disabled
                data-type = "child"
                data-cart-field = "child-travelers" 
                data-cost-field = 'child-travelers-cost'
                min="0"
                data-cost="<?php echo esc_attr( $per_child_price ); ?>"/>
            <button class="wpte-bf-plus">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path fill="currentColor" d="M368 224H224V80c0-8.84-7.16-16-16-16h-32c-8.84 0-16 7.16-16 16v144H16c-8.84 0-16 7.16-16 16v32c0 8.84 7.16 16 16 16h144v144c0 8.84 7.16 16 16 16h32c8.84 0 16-7.16 16-16V288h144c8.84 0 16-7.16 16-16v-32c0-8.84-7.16-16-16-16z"></path></svg>
            </button>
            <button class="wpte-bf-minus">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512"><path fill="currentColor" d="M368 224H16c-8.84 0-16 7.16-16 16v32c0 8.84 7.16 16 16 16h352c8.84 0 16-7.16 16-16v-32c0-8.84-7.16-16-16-16z"></path></svg>
            </button>
        </div>
        <span><?php _e( 'Child', 'wp-travel-engine-group-discount' ); ?></span>
    </div>
    <?php if ( ! empty( $per_child_price ) ): ?>
    <div class="wpte-bf-price">
        <ins>
            <?php echo wp_travel_engine_get_currency_code(); ?>
            <b><?php echo wp_travel_engine_get_formated_price_separator( $per_child_price ); ?></b>
        </ins>
        <span class="wpte-bf-pqty"><?php _e( 'Per Child', 'wp-travel-engine-group-discount' ); ?></span>
    </div>
    <?php endif; ?>
</div>