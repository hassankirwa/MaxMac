<?php

/**
 * Template for child price informtion display.
 *
 * @link       https://wptravelengine.com/
 * @since      1.0.0
 *
 * @package    Wp_Travel_Engine_Group_Discount
 * @subpackage Wp_Travel_Engine_Group_Discount/public/partials
 */
?>

<div class="wpte-bf-price">
    <!-- <del>$1,300 USD</del> -->
    <ins>
        <?php echo wp_travel_engine_get_formated_price_with_currency_code_symbol( $price ); ?>
    </ins>
<span class="wpte-bf-pqty"><?php _e( 'Per Child', 'wp-travel-engine-group-discount' ); ?></span>
</div>