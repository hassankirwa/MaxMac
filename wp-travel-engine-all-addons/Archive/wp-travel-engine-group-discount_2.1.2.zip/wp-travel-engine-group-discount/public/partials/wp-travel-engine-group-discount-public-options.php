<?php

/**
 * Template for group discount options in the trip page.
 *
 * @link       https://wptravelengine.com/
 * @since      1.0.0
 *
 * @package    Wp_Travel_Engine_Group_Discount
 * @subpackage Wp_Travel_Engine_Group_Discount/public/partials
 */
$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', true );

$currency_code   = wp_travel_engine_get_currency_code( false );
$currency_symbol = wp_travel_engine_get_currency_symbol( $currency_code );

$currency_option = isset( $wp_travel_engine_settings['currency_option'] ) && ! empty( $wp_travel_engine_settings['currency_option'] ) ? $wp_travel_engine_settings['currency_option'] : 'symbol';

$currency_code_or_symbol = 'symbol' === $currency_option ? $currency_symbol : $currency_code;

?>

<!-- Group discount options -->
<div class="wpte-bf-toggle-wrap wpte-bf-animate-toggle">
    <button class="wpte-bf-toggle-title">
        <i class="fas fa-users"></i>
        <span class="wtebf-toggle-title"><?php echo esc_html( $global_group_discount_labels['discount_guide_title'] ); ?></span>
        <span style="display:none;" class="wtebf-toggle-title-active"><?php echo esc_html( $global_group_discount_labels['discount_guide_open_title'] ); ?></span>
    </button>
    <div class="wpte-bf-toggle-content">
        <table>
            <thead>
                <tr>
                    <th><?php echo esc_html( $global_group_discount_labels['discount_guide_traveler'] ); ?></th>
                    <th><?php echo esc_html( $global_group_discount_labels['discount_guide_cost'] ); ?></th>
                </tr>
            </thead>
            <tbody>
            <!-- List adult group discount options -->
            <?php if ( isset( $group_discount['traveler'] ) && $adult_discount_enable && ! $adult_discount_empty) : ?>
                <?php foreach( $group_discount['traveler'] as $index => $traveler ) : ?>
                    <tr>
                        <td><?php printf( _nx( '%s Adult', '%s Adults', $traveler, 'group of adult', 'wp-travel-engine-group-discount' ), $traveler ); ?></td>
                        <td><?php echo esc_html( $currency_code_or_symbol ); ?><?php echo esc_html( wp_travel_engine_get_formated_price_separator( $group_discount['cost'] [$index] ) ); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            <!-- ./ List adult group discount options -->

            <!-- List child group discount options -->
            <?php if ( isset( $group_discount['child'] ) && $child_discount_enable && !$child_discount_empty ) : ?>
                <?php foreach( $group_discount['child'] as $index => $child ) : ?>
                    <tr>
                        <td><?php printf( _nx( '%s Child', '%s Children', $child, 'group of children', 'wp-travel-engine-group-discount' ),  $child ); ?></td>
                        <td><?php echo esc_html( $currency_code_or_symbol ); ?><?php echo esc_html( wp_travel_engine_get_formated_price_separator( $group_discount['child_cost'][$index] ) ); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            <!-- ./ List infant group discount options -->

            <?php if ( isset( $group_discount['infant'] ) && $infant_discount_enable && !$infant_discount_empty ) : ?>
                <?php foreach( $group_discount['infant'] as $index => $infant ) : ?>
                    <tr>
                        <td><?php printf( _nx( '%s Infant', '%s Infants', $infant, 'group of infantren', 'wp-travel-engine-group-discount' ), $infant ); ?></td>
                        <td><?php echo esc_html( $currency_code_or_symbol ); ?><?php echo esc_html( wp_travel_engine_get_formated_price_separator( $group_discount['infant_cost'][$index] ) ); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<!-- Group discount options -->