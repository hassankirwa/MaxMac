<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://wptravelengine.com/
 * @since      1.0.0
 *
 * @package    Wp_Travel_Engine_Group_Discount
 * @subpackage Wp_Travel_Engine_Group_Discount/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Wp_Travel_Engine_Group_Discount
 * @subpackage Wp_Travel_Engine_Group_Discount/public
 * @author     wptravelengine <info@raratheme.com>
 */
class Wp_Travel_Engine_Group_Discount_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = WP_TRAVEL_ENGINE_GROUP_DISCOUNT_VERSION;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wp_Travel_Engine_Group_Discount_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wp_Travel_Engine_Group_Discount_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		$asset_script_path = '/min/';
		$version_prefix    = '-' . WP_TRAVEL_ENGINE_GROUP_DISCOUNT_VERSION;

		if ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) {
			$asset_script_path = '/';
			$version_prefix    = '';
		}

		if( is_singular( 'trip' )) {

			wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css'. $asset_script_path .'wp-travel-engine-group-discount-public'. $version_prefix .'.css', array(), $this->version, 'all' );
			
		}

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Wp_Travel_Engine_Group_Discount_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Wp_Travel_Engine_Group_Discount_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		global $post;

		$post_id = 0;

		if ( is_object( $post ) ) :

			$post_id = $post->ID;

		endif;

		$asset_script_path = '/min/';
		$version_prefix    = '-' . WP_TRAVEL_ENGINE_GROUP_DISCOUNT_VERSION;

		if ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) {
			$asset_script_path = '/';
			$version_prefix    = '';
		}

		wp_register_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js'. $asset_script_path .'wp-travel-engine-group-discount-public'. $version_prefix .'.js', array( 'jquery' ), $this->version, true );

		// Localize the script with new data
		$translation_array = array(
			'first_part' => __( 'You can not select more than ', 'wp-travel-engine-group-discount' ),
			'second_part' => __( ' children.', 'wp-travel-engine-group-discount' ),
		);
		wp_localize_script( $this->plugin_name, 'wpte_gd', $translation_array );

		$trip_meta = $this->get_trip_meta( $post_id );

		if ( ! $this->is_adult_group_discount_enable( $post_id ) ) {
			if ( isset( $trip_meta['group']['traveler'] ) ) {
				unset( $trip_meta['group']['traveler'] );
			}
			if ( isset( $trip_meta['group']['cost'] ) ) {
				unset( $trip_meta['group']['cost'] );
			}
		}

		if ( ! $this->is_child_group_discount_enable( $post_id ) ) {
			if ( isset( $trip_meta['group']['child'] ) ) {
				unset( $trip_meta['group']['child'] );
			}
			if ( isset( $trip_meta['group']['child_cost'] ) ) {
				unset( $trip_meta['group']['child_cost'] );
			}
		}

		if ( ! $this->is_infant_group_discount_enable( $post_id ) ) {
			if ( isset( $trip_meta['group']['infant'] ) ) {
				unset( $trip_meta['group']['infant'] );
			}
			if ( isset( $trip_meta['group']['infant_cost'] ) ) {
				unset( $trip_meta['group']['infant_cost'] );
			}
		}
		
		if ( $this->is_group_discount_enable( $post_id ) && isset( $trip_meta['group'] ) ) {
			$trip_meta['group'] = apply_filters( 'wte_gd_before_localize', $trip_meta['group'], $post_id );
			wp_localize_script( $this->plugin_name, 'wteGroupDiscount', $trip_meta['group'] );
		}

		if( is_singular( 'trip' ) ) {
			wp_enqueue_script( $this->plugin_name );
		}

	}

	public function wp_travel_engine_group_discount_guide()
	{
		global $post;


        $wp_travel_engine_settings = get_option( 'wp_travel_engine_settings' );
    	$wp_travel_engine_setting = get_post_meta( $post->ID,'wp_travel_engine_setting',true );
        ob_start();
    	if(isset($wp_travel_engine_settings['group']['discount']) && isset($wp_travel_engine_setting['group']['discount']) || isset($wp_travel_engine_settings['group']['discount']) && isset($wp_travel_engine_setting['child-group']['discount']))
        { 	?>
            <a href="#" data-popup-open="popup-1" data-id="<?php echo $post->ID; ?>" class="group-discount-check"><?php echo isset($wp_travel_engine_settings['group']['discount_title']) ? esc_attr($wp_travel_engine_settings['group']['discount_title']) : 'Group Discount Guide'; ?><i class="fa fa-angle-double-right"></i></a>
			<div class="group-discount-pop" data-popup="popup-1">
		        <div class="popup-inner">
		        	<div class="group-discount-content">
		            	<h3><?php echo isset($wp_travel_engine_settings['group']['discount_guide_title']) ? esc_attr($wp_travel_engine_settings['group']['discount_guide_title']) : 'Group Discount'; ?></h3>
				        <?php
				        if(isset($wp_travel_engine_settings['group']['discount']))
				        { 
				        	if(isset($wp_travel_engine_setting['group']['discount']) && isset($wp_travel_engine_setting['group']['traveler']))
				        	{
				        	?>
		                    <table>
		                        <thead>
		                            <tr>
		                                <td><?php echo isset($wp_travel_engine_settings['group']['discount_guide_traveler']) ? esc_attr($wp_travel_engine_settings['group']['discount_guide_traveler']) : 'Number of Travelers';?></td>
		                                <td><?php echo isset($wp_travel_engine_settings['group']['discount_guide_cost_traveler']) ? esc_attr($wp_travel_engine_settings['group']['discount_guide_cost_traveler']) : 'Cost Per Traveler';
		                                	$code = 'USD';
					                        $obj = new Wp_Travel_Engine_Functions();
					                        $code = $obj->trip_currency_code( $post );
					                        $currency = $obj->wp_travel_engine_currencies_symbol( $code ); 

										    echo ' ('.esc_attr($currency).')';?></td>
		                                <td><?php echo isset($wp_travel_engine_settings['group']['discount_guide_cost']) ? esc_attr($wp_travel_engine_settings['group']['discount_guide_cost']) : 'Total Cost';
		                                	$code = 'USD';
					                        $obj = new Wp_Travel_Engine_Functions();
					                        $code = $obj->trip_currency_code( $post );
					                        $currency = $obj->wp_travel_engine_currencies_symbol( $code );

										    echo ' ('.esc_attr($currency).')';?></td>
		                            </tr>
		                        </thead>
		                        <tbody>
									<?php
									global $post;
									$wp_travel_engine_setting = get_post_meta( $post->ID,'wp_travel_engine_setting',true );
									if( isset($wp_travel_engine_setting['group']['traveler']) )
									{
			                        	$max = max(array_keys($wp_travel_engine_setting['group']['traveler']));
									    for ( $i=1; $i<=$max; $i++ ) { 
									        if(array_key_exists($i, $wp_travel_engine_setting['group']['traveler']))
									        { ?>
					                            <tr>
													<td><?php echo isset( $wp_travel_engine_setting['group']['traveler'][$i] ) ? esc_attr( $wp_travel_engine_setting['group']['traveler'][$i] ):'';?></td>

							                        <td><i class="fa fa-tag"></i>
							                        	<?php $cost_per = $wp_travel_engine_setting['group']['cost'][$i] / $wp_travel_engine_setting['group']['traveler'][$i];
							                        	if( class_exists( 'Wte_Trip_Currency_Converter_Init' ) )
						                                { 
						                                    $obj = new Wp_Travel_Engine_Functions();
						                                    $cost_per = $obj->convert_trip_price( $post, $cost_per );
						                                } 
							                        	echo esc_attr($cost_per); ?>
							                        </td>
							                        <td><i class="fa fa-tag"></i>
							                        	<?php 
							                        	$total_cost =  isset( $wp_travel_engine_setting['group']['cost'][$i] ) ? esc_attr( $wp_travel_engine_setting['group']['cost'][$i] ): '';
							                        	if( class_exists( 'Wte_Trip_Currency_Converter_Init' ) )
						                                { 
						                                    $obj = new Wp_Travel_Engine_Functions();
						                                    $total_cost = $obj->convert_trip_price( $post, $total_cost );
						                                } 
							                        	echo esc_attr($total_cost);
							                        	// echo isset( $wp_travel_engine_setting['group']['cost'][$i] ) ? esc_attr( $wp_travel_engine_setting['group']['cost'][$i] ): '';
							                        	?>
							                        </td>
												</tr>
											<?php
											}
										}
									}
									?>
		                        </tbody>
		                    </table>
							<?php 
							}
						}
						if(isset($wp_travel_engine_settings['group']['discount']))
			        	{ 
				        	if(isset($wp_travel_engine_setting['child-group']['discount']))
				        	{	?>
			                    <table>
			                        <thead>
			                            <tr>
			                                <td><?php echo isset($wp_travel_engine_settings['group']['discount_guide_child_traveler']) ? esc_attr($wp_travel_engine_settings['group']['discount_guide_child_traveler']) : 'Number of Child Travelers';?></td>
			                                <td><?php echo isset($wp_travel_engine_settings['group']['discount_guide_child_cost_traveler']) ? esc_attr($wp_travel_engine_settings['group']['discount_guide_child_cost_traveler']) : 'Cost Per Child Traveler'; 
			                                	$code = 'USD';
						                        $obj = new Wp_Travel_Engine_Functions();
						                        $code = $obj->trip_currency_code( $post );
						                        $currency = $obj->wp_travel_engine_currencies_symbol( $code );

											    echo ' ('.esc_attr($currency).')';?></td>
			                                <td><?php echo isset($wp_travel_engine_settings['group']['discount_guide_cost']) ? esc_attr($wp_travel_engine_settings['group']['discount_guide_cost']) : 'Total Cost';
			                                	$code = 'USD';
						                        $obj = new Wp_Travel_Engine_Functions();
						                        $code = $obj->trip_currency_code( $post );
						                        $currency = $obj->wp_travel_engine_currencies_symbol( $code );

											    echo ' ('.esc_attr($currency).')';?></td>
			                            </tr>
			                        </thead>
			                        <tbody>
										<?php
										global $post;
										$wp_travel_engine_setting = get_post_meta( $post->ID,'wp_travel_engine_setting',true );
										if ( isset( $wp_travel_engine_setting['group']['child'] ) && ! empty( $wp_travel_engine_setting['group']['child'] ) ) {
											$max = max(array_keys($wp_travel_engine_setting['group']['child']));
											for ( $i=1; $i<=$max; $i++ ) { 
												if(array_key_exists($i, $wp_travel_engine_setting['group']['child']))
												{ ?>
													<tr>
														<td><?php echo isset( $wp_travel_engine_setting['group']['child'][$i] ) ? esc_attr( $wp_travel_engine_setting['group']['child'][$i] ):'';?></td>
														<td><i class="fa fa-tag"></i>
															<?php $cost_per = $wp_travel_engine_setting['group']['child_cost'][$i] / $wp_travel_engine_setting['group']['child'][$i];
															if( class_exists( 'Wte_Trip_Currency_Converter_Init' ) )
															{ 
																$obj = new Wp_Travel_Engine_Functions();
																$cost_per = $obj->convert_trip_price( $post, $cost_per );
															} 
															echo esc_attr($cost_per); ?></td>
														<td><i class="fa fa-tag"></i>
															<?php
															$total_cost =  isset( $wp_travel_engine_setting['group']['child_cost'][$i] ) ? esc_attr( $wp_travel_engine_setting['group']['child_cost'][$i] ): '';
															if( class_exists( 'Wte_Trip_Currency_Converter_Init' ) )
															{ 
																$obj = new Wp_Travel_Engine_Functions();
																$total_cost = $obj->convert_trip_price( $post, $total_cost );
															} 
															echo esc_attr($total_cost); 
															// echo isset( $wp_travel_engine_setting['group']['child_cost'][$i] ) ? esc_attr( $wp_travel_engine_setting['group']['child_cost'][$i] ): '';
															?></td>
													</tr>
												<?php
												}
											}
										}
										?>
			                        </tbody>
			                    </table>
				        	<?php
				        	} 
				        }
			        ?>
			    	</div>
		            <a href="#" data-popup-close="popup-1"><?php _e('Close','wp-travel-engine-group-discount') ?></a>
		            <a class="popup-close" data-popup-close="popup-1" href="#">x</a>
			    </div>
				<?php
			    if(isset($wp_travel_engine_settings['group']['discount']) && isset($wp_travel_engine_setting['group']['discount']) || isset($wp_travel_engine_settings['group']['discount']) && isset($wp_travel_engine_setting['child-group']['discount']))
		        { 	?>
	    	</div>
		    <?php
				}
			}
	        $output = ob_get_contents();
			ob_end_clean();
			echo $output;	
	}

	public function wp_travel_engine_group_discount_calculate()
	{
		$nonce = $_REQUEST['nonce'];
		$pid = $_REQUEST['pid'];
		$post = get_post($pid);
        $wp_travel_engine_settings = get_option( 'wp_travel_engine_settings' );
    	$wp_travel_engine_setting = get_post_meta( $pid,'wp_travel_engine_setting',true );
    	$WTE_Fixed_Starting_Dates_setting = get_post_meta( $pid, 'WTE_Fixed_Starting_Dates_setting', true );
    	$datetime = isset($_REQUEST['date']) && $_REQUEST['date']!='' ? esc_attr( $_REQUEST['date'] ): '';

        if(isset($wp_travel_engine_settings['group']['discount']) && isset($wp_travel_engine_setting['group']['discount']) || isset($wp_travel_engine_settings['group']['discount']) && isset($wp_travel_engine_setting['child-group']['discount']))
        { 
			$array = array();
			if( isset( $_POST['val'] ) && wp_verify_nonce( $nonce, 'wp_travel_engine_booking_nonce' ) )
			{
				$id = ( intval( $_POST['val'] ) );
				$wp_travel_engine_setting = get_post_meta( $pid,'wp_travel_engine_setting',true );
				if( in_array( $id, $wp_travel_engine_setting['group']['traveler'] ) )
				{
					$key = array_search ( $id, $wp_travel_engine_setting['group']['traveler'] );
					$cost = $wp_travel_engine_setting['group']['cost'][$key];
					if( class_exists( 'Wte_Trip_Currency_Converter_Init' ) )
                    { 
                    	$obj = new Wp_Travel_Engine_Functions();
                        $cost = $obj->convert_trip_price( $post, $cost );
                    }
					$array['adult'] = ( intval( $cost ) );
				}
				elseif( class_exists( 'WTE_Fixed_Starting_Dates' ) && isset($WTE_Fixed_Starting_Dates_setting) && $WTE_Fixed_Starting_Dates_setting!='' && isset($WTE_Fixed_Starting_Dates_setting['departure_dates']['edate']) && $WTE_Fixed_Starting_Dates_setting['departure_dates']['edate'] !='' && $datetime!='')
				{
			    	$sortable_settings = get_post_meta( $pid, 'list_serialized', true);
			    	if(!is_array($sortable_settings))
			        {
			          $sortable_settings = json_decode($sortable_settings);
			        }
			        $today = strtotime(date("Y-m-d"))*1000;
					foreach($sortable_settings as $content)
					{
						if(isset($WTE_Fixed_Starting_Dates_setting['departure_dates']['edate'][$content->id]))
						{
				    		if( $today <= strtotime($WTE_Fixed_Starting_Dates_setting['departure_dates']['sdate'][$content->id])*1000 )
				        	{
				        		if( $datetime == $WTE_Fixed_Starting_Dates_setting['departure_dates']['sdate'][$content->id] )
				        		{
				        			$trip_cost = $WTE_Fixed_Starting_Dates_setting['departure_dates']['cost'][$content->id];
				        			$cost = intval( $_POST['val'] ) * $trip_cost;
				        			if( class_exists( 'Wte_Trip_Currency_Converter_Init' ) )
				                    { 
				                    	$obj = new Wp_Travel_Engine_Functions();
				                        $cost = $obj->convert_trip_price( $post, $cost );
				                    }
				        			$array['adult'] = ( intval( $cost ) );
				        		}
				        	}
				        }
				    }
				}
				else{
    				$cost = isset( $wp_travel_engine_setting['trip_price'] ) ? $wp_travel_engine_setting['trip_price']: '';
                    $prev_cost = isset( $wp_travel_engine_setting['trip_prev_price'] ) ? $wp_travel_engine_setting['trip_prev_price']: '';
                    if( class_exists( 'Wte_Trip_Currency_Converter_Init' ) )
                    { 
                    	$obj = new Wp_Travel_Engine_Functions();
                        $cost = $obj->convert_trip_price( $post, $cost );
                        $prev_cost = $obj->convert_trip_price( $post, $prev_cost );
                    }
                    if( $cost!='' && isset($wp_travel_engine_setting['sale']) )
                    { 
						$cost = intval( $_POST['val'] ) * $cost;
                    } 
                    else{
                        $cost = intval( $_POST['val'] ) * $prev_cost;
                    }
                    $array['adult'] = ( intval( $cost ) );
				}
			}
			if( isset( $_POST['val1'] ) && wp_verify_nonce( $nonce, 'wp_travel_engine_booking_nonce' ) )
			{
				$id = ( intval( $_POST['val1'] ) );
				if( in_array( $id, $wp_travel_engine_setting['group']['child'] ) )
				{
					$key = array_search ( $id, $wp_travel_engine_setting['group']['child'] );
					$cost = $wp_travel_engine_setting['group']['child_cost'][$key];
					if( class_exists( 'Wte_Trip_Currency_Converter_Init' ) )
                    { 
                    	$obj = new Wp_Travel_Engine_Functions();
                        $cost = $obj->convert_trip_price( $post, $cost );
                    }
					$array['child'] = ( intval( $cost ) );
				}
				elseif( class_exists( 'WTE_Fixed_Starting_Dates' ) && isset($WTE_Fixed_Starting_Dates_setting) && $WTE_Fixed_Starting_Dates_setting!='' && isset($WTE_Fixed_Starting_Dates_setting['departure_dates']['edate']) && $WTE_Fixed_Starting_Dates_setting['departure_dates']['edate'] !='' && $datetime!='' && $_POST['val1'] > 0 )
				{
			    	$sortable_settings = get_post_meta( $pid, 'list_serialized', true);
			    	if(!is_array($sortable_settings))
			        {
			          $sortable_settings = json_decode($sortable_settings);
			        }
			        $today = strtotime(date("Y-m-d"))*1000;
					foreach($sortable_settings as $content)
					{
						if(isset($WTE_Fixed_Starting_Dates_setting['departure_dates']['edate'][$content->id]))
						{
				    		if( $today <= strtotime($WTE_Fixed_Starting_Dates_setting['departure_dates']['sdate'][$content->id])*1000 )
				        	{
				        		if( $datetime == $WTE_Fixed_Starting_Dates_setting['departure_dates']['sdate'][$content->id] )
				        		{
				        			$trip_cost = $WTE_Fixed_Starting_Dates_setting['departure_dates']['cost'][$content->id];
				        			$cost = intval( $_POST['val1'] ) * $trip_cost;
				        			if( class_exists( 'Wte_Trip_Currency_Converter_Init' ) )
				                    { 
				                    	$obj = new Wp_Travel_Engine_Functions();
				                        $cost = $obj->convert_trip_price( $post, $cost );
				                    }
				        			$array['child'] = ( intval( $cost ) );
				        		}
				        	}
				        }
				    }
				}
				else{
					// $value = max(array_keys($wp_travel_engine_setting['group']['child']));
     //                $cost  = $wp_travel_engine_setting['group']['child_cost'][$value];
					if(isset($wp_travel_engine_setting['sale']) && isset($wp_travel_engine_setting['sale']) && $wp_travel_engine_setting['trip_price']!='')
					{
						$trip_cost = $wp_travel_engine_setting['trip_price'];
					}
					else
					{
						$trip_cost = $wp_travel_engine_setting['trip_prev_price'];
					}
					$tcost = $trip_cost*$_POST['val1'];
					if( class_exists( 'Wte_Trip_Currency_Converter_Init' ) )
                    { 
                    	$obj = new Wp_Travel_Engine_Functions();
                        $tcost = $obj->convert_trip_price( $post, $tcost );
                    }
                    $array['child'] = ( intval( $tcost ) ); 
				}
			}
			echo wp_send_json_success($array);
		}
		wp_die();
	}

	public function wp_travel_engine_group_discount_info()
	{
		global $post;
        $wp_travel_engine_settings = get_option( 'wp_travel_engine_settings' );
    	$wp_travel_engine_setting = get_post_meta( $post->ID,'wp_travel_engine_setting',true );
        if(isset($wp_travel_engine_settings['group']['discount']) && isset($wp_travel_engine_setting['group']['discount']) || isset($wp_travel_engine_settings['group']['discount']) && isset($wp_travel_engine_setting['child-group']['discount']))
        {
			$message = isset($wp_travel_engine_settings['group']['discount_availability']) ? esc_attr($wp_travel_engine_settings['group']['discount_availability']) : 'Group Discount Available';
			echo '<div class="group-discount-notice">'.$message.'</div>';
			
		}
	}
	public function wpte_child_field($post)
	{	
		$wp_travel_engine_setting = get_post_meta( $post->ID,'wp_travel_engine_setting',true );
		if(isset($wp_travel_engine_setting['group']['child']) && $wp_travel_engine_setting['group']['child']!='')
		{
			$value = max($wp_travel_engine_setting['group']['child']);
		}
		?>
		<div class="travelers-number-input">
			<label for="group-discount-child-number">
				<?php $no_of_child_travelers = __('Number of Child Travelers: ','wp-travel-engine-group-discount'); 
	                    echo apply_filters('wp_travel_engine_no_of_travelers_text', $no_of_child_travelers);?>
	    	</label>
	    	<input id="group-discount-child-number" type="number" max="<?php if(isset($wp_travel_engine_setting['group']['child']) && $wp_travel_engine_setting['group']['child']!='')
		{ echo $value; }?>" name="child-travelers" class="child-travelers-no" value="0">
		</div>
	<?php
	}

	/**
	 * Display group discount options in the booking form in trip page.
	 *
	 * @return void
	 */
	public function display_group_discount_options() {
		global $post;

		global $wtetrip;

		if ( $wtetrip && ! $wtetrip->use_legacy_trip ) {
			return; //  Do nothing.
		}

		// Bail early if the group discount is not enabled in trip.
		if ( ! $this->is_group_discount_enable() ) {
			return;
		}

		if ( ! $this->is_adult_group_discount_enable( $post->ID ) && ! $this->is_child_group_discount_enable( $post->ID ) ) {
			return;
		}

		if ( $this->is_adult_group_discount_empty( $post->ID ) && $this->is_child_group_discount_empty( $post->ID ) ) {
			return;
		}

		if ( $this->is_adult_group_discount_empty( $post->ID ) && ! $this->is_child_group_discount_enable( $post->ID ) ) {
			return;
		}

		if ( $this->is_child_group_discount_empty( $post->ID ) && ! $this->is_adult_group_discount_enable( $post->ID ) ) {
			return;
		}

		$post_meta = get_post_meta( $post->ID, 'wp_travel_engine_setting', true );

		$wte_settings = get_option( 'wp_travel_engine_settings' );

		$global_group_discount_labels_default = array(
			'discount_availability'              => __( 'Group Discount Available', 'wp-travel-engine-group-discount' ),
			'discount_title'                     => __( 'Group Discount Guide', 'wp-travel-engine-group-discount' ),
			'discount_guide_title'               => __( 'See Available Group Discount', 'wp-travel-engine-group-discount' ),
			'discount_guide_open_title'          => __( 'Available Group Discount', 'wp-travel-engine-group-discount' ),
			'discount_guide_traveler'            => __( 'Number of Travelers', 'wp-travel-engine-group-discount' ),
			'discount_guide_cost'                => __( 'Price Per Person', 'wp-travel-engine-group-discount' ),
			'discount_guide_cost_traveler'       => __( 'Cost Per Traveler', 'wp-travel-engine-group-discount' ),
			'discount_guide_child_traveler'      => __( 'Number of Child Traveler', 'wp-travel-engine-group-discount' ),
			'discount_guide_child_cost_traveler' => __( 'Cost Per Child Traveler', 'wp-travel-engine-group-discount' )
		);

		$global_group_discount_labels_saved = array();
		if ( isset( $wte_settings['group'] ) ) {
			$global_group_discount_labels_saved = $wte_settings['group'];
		};

		$global_group_discount_labels = array();

		foreach( $global_group_discount_labels_default as $key => $label ) {
			$global_group_discount_labels[$key] = isset( $global_group_discount_labels_saved[$key] ) && ! empty( $global_group_discount_labels_saved[$key] ) ? $global_group_discount_labels_saved[$key] : $global_group_discount_labels_default[$key];
		}

		// Set default values to global group discount if not available.
		// $global_group_discount_labels = wp_parse_args( $global_group_discount_labels, $global_group_discount_labels_default );

		$child_discount_enable = $this->is_child_group_discount_enable( $post->ID );
		$adult_discount_enable = $this->is_adult_group_discount_enable( $post->ID );
		$child_discount_empty  = $this->is_child_group_discount_empty( $post->ID );
		$adult_discount_empty  = $this->is_adult_group_discount_empty( $post->ID );

		$infant_discount_enable = $this->is_infant_group_discount_enable( $post->ID );
		$infant_discount_empty  = $this->is_infant_group_discount_empty( $post->ID );

		$group_discount = $post_meta['group'];

		$travellers_list = [];
		if ( isset( $group_discount['traveler'] ) ) {
			$max = max( array_keys( $group_discount['traveler'] ) );

			for ( $i=1; $i<=$max; $i++ ) {
				if( array_key_exists( $i, $group_discount['traveler'] ) ) {
					$from_traveler = isset( $group_discount['traveler'][$i] ) ? $group_discount['traveler'][$i] : '';
					$to_traveler = isset( $group_discount['traveler'][$i.'_'.$i] ) ? $group_discount['traveler'][$i.'_'.$i] : '';

					$separator = '';
					if( isset( $group_discount['traveler'][$i.'_'.$i] ) && 1 != $max ) {
						$separator = '' != $group_discount['traveler'][$i.'_'.$i] ? '-' : '+';
					}

					$price_per_person = isset($group_discount['cost'][$i] ) ? $group_discount['cost'][$i] : '';
					$price_per_person = ! isset( $group_discount['traveler'][$i.'_'.$i] ) ? bcdiv( $price_per_person, $from_traveler, 2) : $price_per_person;

					$travellers_list[ $from_traveler .$separator. $to_traveler ] = apply_filters(
						'wte_gd_adult_price',
						$price_per_person,
						$post->ID
					);
				}				
			}

			$group_discount['traveler'] = array_keys( $travellers_list );
			$group_discount['cost'] = array_values( $travellers_list );
		}

		$child_list = [];
		if ( isset( $group_discount['child'] ) ) {
			$max = max( array_keys( $group_discount['child'] ) );

			for ( $i=1; $i<=$max; $i++ ) {
				if( array_key_exists( $i, $group_discount['child'] ) ) {
					$from_child = isset( $group_discount['child'][$i] ) ? $group_discount['child'][$i] : '';
					$to_child = isset( $group_discount['child'][$i.'_'.$i] ) ? $group_discount['child'][$i.'_'.$i] : '';

					$separator = '';
					if( isset( $group_discount['child'][$i.'_'.$i] ) && 1 != $max ) {
						$separator = '' != $group_discount['child'][$i.'_'.$i] ? '-' : '+';
					}

					$price_per_person = isset($group_discount['child_cost'][$i] ) ? $group_discount['child_cost'][$i] : '';
					$price_per_person = ! isset( $group_discount['child'][$i.'_'.$i] ) ? bcdiv( $price_per_person, $from_child, 2) : $price_per_person;

					$child_list[ $from_child .$separator. $to_child ] = apply_filters(
						'wte_gd_child_price',
						$price_per_person,
						$post->ID
					);
				}				
			}

			$group_discount['child'] = array_keys( $child_list );
			$group_discount['child_cost'] = array_values( $child_list );
		}

		$infant_list = [];
		if ( isset( $group_discount['infant'] ) ) {
			$max = max( array_keys( $group_discount['infant'] ) );

			for ( $i=1; $i<=$max; $i++ ) {
				if( array_key_exists( $i, $group_discount['infant'] ) ) {
					$from_infant = isset( $group_discount['infant'][$i] ) ? $group_discount['infant'][$i] : '';
					$to_infant = isset( $group_discount['infant'][$i.'_'.$i] ) ? $group_discount['infant'][$i.'_'.$i] : '';

					$separator = '';
					if( isset( $group_discount['infant'][$i.'_'.$i] ) && 1 != $max ) {
						$separator = '' != $group_discount['infant'][$i.'_'.$i] ? '-' : '+';
					}

					$price_per_person = isset($group_discount['infant_cost'][$i] ) ? $group_discount['infant_cost'][$i] : '';
					$price_per_person = ! isset( $group_discount['infant'][$i.'_'.$i] ) ? bcdiv( $price_per_person, $from_infant, 2) : $price_per_person;

					$infant_list[ $from_infant .$separator. $to_infant ] = apply_filters(
						'wte_gd_infant_price',
						$price_per_person,
						$post->ID
					);
				}				
			}

			$group_discount['infant'] = array_keys( $infant_list );
			$group_discount['infant_cost'] = array_values( $infant_list );
		}
		
		require_once plugin_dir_path( __FILE__ ) . 'partials/wp-travel-engine-group-discount-public-options.php';

	}

	/**
	 * Check whether the trip has group discount enabled or not.
	 *
	 * @param int $trip_id Trip Id.
	 * @return boolean 
	 */
	private function is_group_discount_enable() {
		$settings = get_option( 'wp_travel_engine_settings' );

		return isset( $settings['group']['discount'] );
	}

	/**
	 * Check whether adult group discount enabled or not. *
	 * 
	 * @param int $trip_id Trip Id.
	 * @return boolean 
	 */
	private function is_adult_group_discount_enable( $trip_id ) {
		// Get trip meta.
		$trip_meta = $this->get_trip_meta( $trip_id );
		if ( false === $trip_meta ) {
			return false;
		}

		// Return false if the discount is not set.
		if ( ! isset( $trip_meta['group']['discount'] ) ) {
			return false;
		}

		if ( '1' === $trip_meta['group']['discount'] ) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Check whether adult group discount enabled or not. *
	 * 
	 * @param int $trip_id Trip Id.
	 * @return boolean 
	 */
	private function is_child_group_discount_enable( $trip_id ) {
		// Get trip meta.
		$trip_meta = $this->get_trip_meta( $trip_id );
		if ( false === $trip_meta ) {
			return false;
		}
			
		// Return false if the discount is not set.
		if ( ! isset( $trip_meta['child-group']['discount'] ) ) {
			return false;
		}

		if ( '1' === $trip_meta['child-group']['discount'] ) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Check whether adult group discount enabled or not. *
	 * 
	 * @param int $trip_id Trip Id.
	 * @return boolean 
	 */
	private function is_infant_group_discount_enable( $trip_id ) {
		// Get trip meta.
		$trip_meta = $this->get_trip_meta( $trip_id );
		if ( false === $trip_meta ) {
			return false;
		}
			
		// Return false if the discount is not set.
		if ( ! isset( $trip_meta['infant-group']['discount'] ) ) {
			return false;
		}

		if ( '1' === $trip_meta['infant-group']['discount'] ) {
			return true;
		} else {
			return false;
		}
	}

	private function is_infant_group_discount_empty( $trip_id ) {
		// Get trip meta.
		$trip_meta = $this->get_trip_meta( $trip_id );
		if ( false === $trip_meta ) {
			return true;
		}

		// Return true if the infant group discount is not set.
		if ( ! isset( $trip_meta['infant-group']['discount'] ) ) {
			return true;
		}

		return ! isset( $trip_meta['group']['infant'] );

	}

	private function is_child_group_discount_empty( $trip_id ) {
		// Get trip meta.
		$trip_meta = $this->get_trip_meta( $trip_id );
		if ( false === $trip_meta ) {
			return true;
		}

		// Return true if the child group discount is not set.
		if ( ! isset( $trip_meta['child-group']['discount'] ) ) {
			return true;
		}

		return ! isset( $trip_meta['group']['child'] );

	}

	private function is_adult_group_discount_empty( $trip_id ) {
		// Get trip meta.
		$trip_meta = $this->get_trip_meta( $trip_id );
		if ( false === $trip_meta ) {
			return true;
		}

		return ! isset( $trip_meta['group']['traveler'] );

	}

	public function display_child_input_field() {
		global $post;

		if ( ! $this->is_child_group_discount_enable( $post->ID ) ) {
			return;
		}

		$per_child_price = $this->get_per_child_price( $post->ID );
		$per_child_price = ( null === $per_child_price ) ? '' : $per_child_price;

 		require_once plugin_dir_path( __FILE__ ) . 'partials/wp-travel-engine-group-discount-public-child.php';
	}

	/**
	 * Check whether the trip has per child price.
	 *
	 * @param [type] $trip_id
	 * @return boolean
	 */
	private function is_per_child_price_exists( $trip_id ) {
		// Get trip meta.
		$trip_meta = $this->get_trip_meta( $trip_id );
		if ( false === $trip_meta ) {
			return false;
		}

		return isset( $trip_meta[ 'group']['child'] );		
	}

	/**
	 * Get per child price is exists.
	 */
	private function get_per_child_price( $trip_id ) {
		$trip_meta = $this->get_trip_meta( $trip_id );

		$per_child_price = '';

		if ( isset( $trip_meta['group']['child'] ) ) {
			$child_list = $trip_meta['group']['child'];
			foreach( $child_list as $index => $child ) {
				if ( '1' === $child ) {
					$per_child_price = $trip_meta['group']['child_cost'][ $index ];
					break;
				}
			}
		}

		if ( '' === $per_child_price ) {
			$per_child_price = $this->get_per_adult_price( $trip_id );
		}

		return apply_filters( 'wte_gd_child_price', $per_child_price, $trip_id );
	}

	/**
	 * Get per child price is exists.
	 */
	private function get_per_infant_price( $trip_id ) {
		$trip_meta = $this->get_trip_meta( $trip_id );

		$per_infant_price = '';

		if ( isset( $trip_meta['group']['infant'] ) ) {
			$infant_list = $trip_meta['group']['infant'];
			foreach( $infant_list as $index => $infant ) {
				if ( '1' === $infant ) {
					$per_infant_price = $trip_meta['group']['infant_cost'][ $index ];
					break;
				}
			}
		}

		if ( '' === $per_infant_price ) {
			$per_infant_price = $this->get_per_adult_price( $trip_id );
		}

		return apply_filters( 'wte_gd_per_infant_price', $per_infant_price, $trip_id );
	}

	/**
	 * Get per adult price.
	 */
	private function get_per_adult_price( $trip_id ) {
		$per_adult_price = wp_travel_engine_get_actual_trip_price( $trip_id );
		return $per_adult_price;
	}

	/**
	 * Get trip meta.
	 */
	public function get_trip_meta( $trip_id ) {
		$trip = get_post( $trip_id );

		// Bail early if the post is not found.
		if ( null === $trip ) {
			return false;
		}

		return get_post_meta( $trip_id, 'wp_travel_engine_setting', true );
	}

	public function update_default_traveller_type( $type ) {
		// Bail early if the child group discount is not enabled.
		if ( ! $this->is_group_discount_enable( get_the_ID() ) ) {
			return $type;
		}

		if( ! $this->is_child_group_discount_enable( get_the_ID() ) ) {
			return $type;
		}

		return __( 'Adult', 'wp-travel-engine-group-discount' );
	}

	public function update_default_traveller_unit( $unit ) {
		// Bail early if the child group discount is not enabled.
		if ( ! $this->is_group_discount_enable( get_the_ID() ) ) {
			return $unit;
		}

		if( ! $this->is_child_group_discount_enable( get_the_ID() ) ) {
			return $unit;
		}

		return __( 'Per Adult', 'wp-travel-engine-group-discount' );
	}

	public function display_child_price_info() {
		global $post;

		if ( ! $this->is_child_group_discount_enable( $post->ID ) ) {
			return;
		}

		// Don't show the child price info, if the multi pricing is for child is set.
		$trip_settings = get_post_meta( $post->ID, 'wp_travel_engine_setting', true );
		$multiple_pricing_options = isset( $trip_settings['multiple_pricing']['child']['price'] ) && ! empty( $trip_settings['multiple_pricing']['child']['price'] ) ? $trip_settings['multiple_pricing']['child']['price'] : false;		

		if ( $multiple_pricing_options) {
			return;
		}

		$price = $this->get_per_child_price( get_the_ID() );
		require_once plugin_dir_path( __FILE__ ) . 'partials/wp-travel-engine-group-discount-public-child-price-info.php';
	}

	public function display_infant_price_info() {
		global $post;

		if ( ! $this->is_infant_group_discount_enable( $post->ID ) ) {
			return;
		}

		// Don't show the infant price info, if the multi pricing for infant is set.
		$trip_settings = get_post_meta( $post->ID, 'wp_travel_engine_setting', true );
		$multiple_pricing_options = isset( $trip_settings['multiple_pricing']['infant']['price'] ) && ! empty( $trip_settings['multiple_pricing']['infant']['price'] ) ? $trip_settings['multiple_pricing']['infant']['price'] : false;

		if ( $multiple_pricing_options) {
			return;
		}

		$price = $this->get_per_infant_price( get_the_ID() );
		require_once plugin_dir_path( __FILE__ ) . 'partials/wp-travel-engine-group-discount-public-infant-price-info.php';
	}

	/**
	 * Undocumented function
	 *
	 * @return void
	 */
	public function mp_apply_group_discount_default( $prev_price ) {

		global $post;

		if ( ! is_object( $post ) ) {
			return $prev_price;
		}

		if ( ! $this->is_child_group_discount_enable( $post->ID ) ) {
			return $prev_price;
		}

		$price = $this->get_per_child_price( $post->ID );

		return $price;

	}

	/**
	 * Get group discount available text.
	 *
	 * @param [type] $available_text
	 * @return void
	 */
	public function get_group_discount_available_text( $available_text ) {
		$settings = get_option( 'wp_travel_engine_settings' );

		if ( isset( $settings['group']['discount_availability'] ) && ! empty( $settings['group']['discount_availability']  ) ) {
			$available_text = $settings['group']['discount_availability'];
		}

		return $available_text;
	}
}
