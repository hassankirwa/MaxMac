jQuery(document).ready(function($){
    if ($('.wte-payhere-checkout').is( ':checked' )) {
        $('.wte-payhere-payment-form').fadeIn('slow');
    }
    else{
        $('.wte-payhere-payment-form').fadeOut('slow');
    }
    $('body').on('click', '.wte-payhere-checkout', function (e){ 
        if ($('.wte-payhere-checkout').is( ':checked' )) {
            $('.wte-payhere-payment-form').fadeIn('slow');
        }
        else{
            $('.wte-payhere-payment-form').fadeOut('slow');
        }
    });
});