/**
 * Handle new booking form.
 */
jQuery(function($){

    payhere.onCompleted = function onCompleted(orderId) {
        $('#wp-travel-engine-new-checkout-form input[type="submit"]').click();
    };

    payhere.onError = function onError(error) {
        alert("An error occured while making the payment. Error: " + error);
    };

    /**
     * Return form data.
     */
    function getFormData() {
        var firstName   = $('input[name="wp_travel_engine_booking_setting[place_order][booking][fname]"]').val();
        var lastName    = $('input[name="wp_travel_engine_booking_setting[place_order][booking][lname]"]').val();
        var email       = $('input[name="wp_travel_engine_booking_setting[place_order][booking][email]"]').val();
        var country     = $('select[name="wp_travel_engine_booking_setting[place_order][booking][country]"]').val();
        var address     = $('input[name="wp_travel_engine_booking_setting[place_order][booking][address]"]').val();
        var city        = $('input[name="wp_travel_engine_booking_setting[place_order][booking][city]"]').val();
        var phone       = $('input[name="wp_travel_engine_booking_setting[place_order][booking][phone]"]').val();
        var productInfo = $('.wpte-bf-trip-name').text();

        return {
            firstName: firstName,
            lastName: lastName,
            email: email,
            country: country,
            address: address,
            productInfo: productInfo,
            city: city,
            phone: phone,
        };
    }

    const payhere_remove = function(){
		
		jQuery( '[name=wp_travel_engine_nw_bkg_submit]' ).off( 'click',handleBookingForm );
	
	}

    var handleBookingForm = function(event) {

        if ( ! $('#wp-travel-engine-new-checkout-form').parsley().isValid() ) {
            return;
        }

        if( $('#wp-travel-engine-new-checkout-form').parsley().isValid() ) {
            event.preventDefault();
        }

        var formData = getFormData();

        var payment_mode = $('input[name=wp_travel_engine_payment_mode]:checked').val();

        var requestData = {
            "sandbox"    : payhere_vars.sandbox ? true : false,
            "merchant_id": payhere_vars.merchant_id,
            "return_url" : window.location.href,
            "cancel_url" : window.location.href,
            "notify_url" : payhere_vars.notify_url,
            "first_name" : formData.firstName,
            "last_name"  : formData.lastName,
            "email"      : formData.email,
            "phone"      : formData.phone,
            "address"    : formData.address,
            "city"       : formData.city,
            "country"    : formData.country,
            "order_id"   : Object.keys(wte_cart)[0],
            "items"      : formData.productInfo,
            "currency"   : wte.currency.code,
            "amount"     : 'partial' == payment_mode ? wte.payments.total_partial : wte.payments.total,
            "platform"   : 'wp-travel-engine'
        }

        payhere.startPayment(requestData);

    }


    $('input[name="wpte_checkout_paymnet_method"').change(function(event){

        payhere_checkout();

    });

    const payhere_checkout = function(){

        payhere_remove();
		
		var payment_gateway = jQuery('input[name=wpte_checkout_paymnet_method]:checked').val();

        if ( 'payhere_payment' === payment_gateway ) {
			
            jQuery(".paypal-button").remove();
			
			jQuery('[name=wp_travel_engine_nw_bkg_submit]').click(handleBookingForm);
        }
    }

    payhere_checkout();

});
