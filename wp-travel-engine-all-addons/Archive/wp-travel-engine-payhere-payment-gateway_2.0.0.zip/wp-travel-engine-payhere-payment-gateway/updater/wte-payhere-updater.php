<?php
/**
 * Easy Digital Downloads Plugin Updater
 *
 * @package wte_payhere_payment_Gateway
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Includes the files needed for the plugin updater.
 *
 * @since 1.0.0
 */
if( !class_exists( 'EDD_SL_Plugin_Updater' ) ) {

	include( dirname( __FILE__ ) . '/EDD_SL_Plugin_Updater.php' );
}

/**
 * Download ID for the product in Easy Digital Downloads.
 *
 * @since 1.0.0
 */
define( 'WP_TRAVEL_ENGINE_PAYHERE_PAYMENT_ITEM_ID', 30754 );

/**
 * Setup the updater for the WTE_PayHere Add-on.
 *
 * @since 1.0.0
 */
function wte_payhere_payments_payment_updater() {

	// retrieve our license key from the DB
	$settings    = get_option( 'wp_travel_engine_license' );
	$license_key = isset( $settings['wte_payhere_payment_license_key'] ) ? esc_attr( $settings['wte_payhere_payment_license_key'] ) : '';

	// setup the updater
	$edd_updater = new EDD_SL_Plugin_Updater( WP_TRAVEL_ENGINE_STORE_URL, WTE_PAYHERE_PAYMENTS_FILE_PATH,
		array(
			'version' => WTE_PAYHERE_PAYMENTS_VERSION,                    // current version number
			'license' => $license_key,             // license key (used get_option above to retrieve from DB)
			'item_id' => WP_TRAVEL_ENGINE_PAYHERE_PAYMENT_ITEM_ID,       // ID of the product
			'author'  => 'WP Travel Engine', // author of this plugin
			'beta'    => false,
		)
	);

}
add_action( 'admin_init', 'wte_payhere_payments_payment_updater', 0 );

/**
 * Add-ons name for plugin license page.
 *
 * @since 1.0.0
 */
function wte_payhere_payment_name($array)
{
	$array['WP Travel Engine - PayHere Payment Gateway'] =  'wte_payhere_payment';
	return $array;
}
add_filter( 'wp_travel_engine_addons', 'wte_payhere_payment_name' );

/**
 * Add-ons Item ID for plugin license page.
 *
 * @since 1.0.0
 */
function wte_payhere_payment_id($array)
{
	$array['wte_payhere_payment'] = WP_TRAVEL_ENGINE_PAYHERE_PAYMENT_ITEM_ID;
	return $array;
}
add_filter( 'wp_travel_engine_addons_id', 'wte_payhere_payment_id' );
