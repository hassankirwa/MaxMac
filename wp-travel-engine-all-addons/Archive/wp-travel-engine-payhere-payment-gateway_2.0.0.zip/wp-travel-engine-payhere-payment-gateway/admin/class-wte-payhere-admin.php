<?php
/**
 * Class WTE_PayHere_Admin
 * 
 * @package WTE_Payhere_Admin
 */

/**
  * PayHere Admin Class
  * 
  * @since 1.0.0
  */
class WTE_PayHere_Admin {

    /**
     * Clas Constructor
     * 
     * @acces public
     */
    public function __construct() {

        $this->init_hooks();

        require WTE_PAYHERE_PAYMENTS_BASE_PATH . '/updater/wte-payhere-updater.php';

    }

    /**
     * Init admin area hooks.
     *
     * @return void
     */
    public function init_hooks() {

        add_action( 'wp_travel_engine_payment_gateways_settins', array( $this, 'payhere_settings' ) );

    }

    /**
     * Payhere admin area settings.
     *
     * @return void
     */
    public function payhere_settings() {

        $wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', true );

        ?>
            <div class="wte-payhere-payment-form wp-travel-engine-settings">
                <h4><?php _e( 'Payhere paymet settings', 'wte-payhere-payment'); ?></h4>
                
                <label for="wp_travel_engine_settings[payhere_merchant_id]"><?php _e('Payhere Merchant ID : ','wte-payhere-payment');?> <span class="tooltip" title="Enter a valid Payhere Merchant ID. All payments will go to this account."><i class="fas fa-question-circle"></i></span></label> 
                <input type="text" id="wp_travel_engine_settings[payhere_merchant_id]" name="wp_travel_engine_settings[payhere_merchant_id]" value="<?php echo isset($wp_travel_engine_settings['payhere_merchant_id']) ? esc_attr( $wp_travel_engine_settings['payhere_merchant_id'] ): '';?>">

                <label for="wp_travel_engine_settings[payhere_merchant_secret]"><?php _e('Payhere Merchant Secret : ','wte-payhere-payment');?> <span class="tooltip" title="Enter a valid Payhere Merchant Secret."><i class="fas fa-question-circle"></i></span></label> 
                <input type="text" id="wp_travel_engine_settings[payhere_merchant_secret]" name="wp_travel_engine_settings[payhere_merchant_secret]" value="<?php echo isset($wp_travel_engine_settings['payhere_merchant_secret']) ? esc_attr( $wp_travel_engine_settings['payhere_merchant_secret'] ): '';?>">

                <div class="wp-travel-engine-settings">
                    <label for="wp_travel_engine_settings[payhere_enable_onsite]"><?php _e('Enable onsite checkout : ','wte-payhere-payment');?> <span class="tooltip" title="<?php _e('Check to enable onsite checkout.', 'wte-payhere-payment'); ?>"><i class="fas fa-question-circle"></i></span></label>
                    <input type="checkbox" id="wp_travel_engine_settings[payhere_enable_onsite]" name="wp_travel_engine_settings[payhere_enable_onsite]" value="1" <?php if(isset($wp_travel_engine_settings['payhere_enable_onsite']) && $wp_travel_engine_settings['payhere_enable_onsite']!='' ) echo 'checked'; ?>>
                    <label for="wp_travel_engine_settings[payhere_enable_onsite]" class="checkbox-label"></label>
                </div>
            </div>

        <?php

    }

}
