<?php
/**
 * Get Global Settings
 */
$wp_travel_engine_settings = get_option( 'wp_travel_engine_settings', true );
?>

        <div class="wpte-field wpte-text wpte-floated">
            <label for="wp_travel_engine_settings[payhere_merchant_id]" class="wpte-field-label"><?php _e('Payhere Merchant ID','wte-payhere-payment');?></label>
            <input type="text" id="wp_travel_engine_settings[payhere_merchant_id]" name="wp_travel_engine_settings[payhere_merchant_id]" value="<?php echo isset($wp_travel_engine_settings['payhere_merchant_id']) ? esc_attr( $wp_travel_engine_settings['payhere_merchant_id'] ): '';?>">
            <span class="wpte-tooltip"><?php esc_html_e( "Payhere Merchant ID for your payhere account. All payments will go to this account.", 'wte-payhere-payment' ); ?></span>
        </div>

        <div class="wpte-field wpte-text wpte-floated">
            <label for="wp_travel_engine_settings[payhere_merchant_secret]" class="wpte-field-label"><?php _e('Payhere Merchant Secret','wte-payhere-payment');?></label>
            <input type="text" id="wp_travel_engine_settings[payhere_merchant_secret]" name="wp_travel_engine_settings[payhere_merchant_secret]" value="<?php echo isset($wp_travel_engine_settings['payhere_merchant_secret']) ? esc_attr( $wp_travel_engine_settings['payhere_merchant_secret'] ): '';?>">
            <span class="wpte-tooltip"><?php esc_html_e( "Payhere Merchant Secret for your payhere account. All payments will go to this account.", 'wte-payhere-payment' ); ?></span>
        </div>

        <div class="wpte-field wpte-checkbox advance-checkbox">
            <label class="wpte-field-label" for="wp_travel_engine_settings[payhere_enable_onsite]"><?php _e('Enable onsite checkout','wte-payhere-payment');?></label>
            <div class="wpte-checkbox-wrap">
                <input type="checkbox" id="wp_travel_engine_settings[payhere_enable_onsite]" name="wp_travel_engine_settings[payhere_enable_onsite]" value="1" <?php if(isset($wp_travel_engine_settings['payhere_enable_onsite']) && $wp_travel_engine_settings['payhere_enable_onsite']!='' ) echo 'checked'; ?>>
                <label for="wp_travel_engine_settings[payhere_enable_onsite]" class="checkbox-label"></label>
            </div>
            <span class="wpte-tooltip"><?php esc_html_e( 'Check to enable onsite checkout while paying with PayHere.', 'wte-payhere-payment' ); ?></span>
        </div>

<?php
