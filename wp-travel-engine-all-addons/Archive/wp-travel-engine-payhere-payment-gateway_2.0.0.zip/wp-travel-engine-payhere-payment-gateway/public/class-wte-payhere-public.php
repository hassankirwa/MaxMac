<?php
/**
 * Class WTE_PayHere_Public
 * 
 * @package WTE_Payhere_Public
 */

/**
  * PayHere Admin Class
  * 
  * @since 1.0.0
  */
class WTE_PayHere_Public {

    /**
     * Clas Constructor
     * 
     * @acces public
     */
    public function __construct() {

        $this->init_hooks();

        $wte_settings = get_option( 'wp_travel_engine_settings' );

        // Setup default merchant data.
		$this->merchant_id      = isset( $wte_settings['payhere_merchant_id'] ) ? $wte_settings['payhere_merchant_id'] : '';
        $this->merchant_secret  = isset( $wte_settings['payhere_merchant_secret'] ) ? $wte_settings['payhere_merchant_secret'] : '';

        $this->onsite_checkout_enable = isset( $wte_settings['payhere_enable_onsite'] ) && '1' == $wte_settings['payhere_enable_onsite'] ? true : false;
        
        $this->response_url	= add_query_arg( 'wte_payment', 'wte_gateway_payhere', home_url( '/' ) );

        $this->url = 'https://www.payhere.lk/pay/checkout';

        // Setup the test data, if in test mode.
		if ( defined( 'WP_TRAVEL_ENGINE_PAYMENT_DEBUG' ) && WP_TRAVEL_ENGINE_PAYMENT_DEBUG ) {
            
            $this->url = 'https://sandbox.payhere.lk/pay/checkout';

		} else {

			$this->send_debug_email = false;
        
        }

    }

    /**
     * Init admin area hooks.
     *
     * @return void
     */
    public function init_hooks() {

        add_action( 'wp_travel_engine_after_booking_process_completed', array( $this, 'generate_form' ) );

        add_action( 'init', array( &$this, 'response_catcher' ) );

        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

        if ( $this->payhere_enabled() ) :

            add_filter( 'wp_travel_engine_checkout_default_fields', array( $this, 'payhere_additional_fields' ) );

        endif;

    }

    /**
     * Enabled payhere
     *
     * @return void
     */
    public function payhere_enabled () {

        $wte_settings = get_option( 'wp_travel_engine_settings' );

        return isset( $wte_settings['payhere_payment'] ) && '1' == $wte_settings['payhere_payment'];

    }

    /**
     * Add affitional field.
     *
     * @return void
     */
    public function payhere_additional_fields ( $form_fields ) {

        $form_fields['phone_number']  = array(
            'type'          => 'number',
            'wrapper_class' => 'wp-travel-engine-billing-details-field-wrap',
            'field_label'   => __( 'Phone Number', 'wte-payhere-payment' ),
            'label_class'	=> 'wpte-bf-label',
            'name'          => 'wp_travel_engine_booking_setting[place_order][booking][phone]',
            'id'            => 'wp_travel_engine_booking_setting[place_order][booking][phone]',
            'validations'   => array(
                'required'  => true,
            ),
            'attributes'    => array(
                'data-msg' => __( 'Please enter a valid phone number ( numbers only )', 'wte-payhere-payment' ),
                'data-parsley-required-message' => __( 'Please enter a valid phone number ( numbers only )', 'wte-payhere-payment' ),
            ),
            'default'  => '',
            'priority' => 31,
        );

        return $form_fields;

    }

    /**
     * Scripts Enqueue.
     *
     * @return void
     */
    public function enqueue_scripts() {

    }

    /**
     * Payhere Form.
     *
     * @return void
     */
    public function generate_form( $booking_id, $partial_payment = false ) {

        if ( ! $booking_id ) {
			return;
		}
		
		// Is partial payment check.
		if ( ! $partial_payment ) {
			do_action( 'wte_payment_process', $booking_id );
		}

		// Check if paypal is selected.
		if ( ! isset( $_POST['wpte_checkout_paymnet_method'] ) || 'payhere_payment' !== $_POST['wpte_checkout_paymnet_method'] ) {
			return;
        }

        global $wte_cart;
        
        $cart_totals    = $wte_cart->get_total();
        $payment_mode   = isset( $_POST['wp_travel_engine_payment_mode'] ) ? $_POST['wp_travel_engine_payment_mode'] : '';
        $payment_amount = wp_travel_engine_get_formated_price( $cart_totals['total'] );

        if ( 'partial' === $payment_mode && wp_travel_engine_is_cart_partially_payable() ) :

			$payment_amount = wp_travel_engine_get_formated_price( $cart_totals['total_partial'] );

        endif;

        $return_url = wp_travel_engine_get_booking_confirm_url();

		$return_url = add_query_arg( array(
			'booking_id'  => $booking_id,
			'booked'      => true,
			'wte_gateway' => 'payhere',
		), $return_url );

        $booking_metas = get_post_meta( $booking_id, 'wp_travel_engine_booking_setting', true );
        
        $fail_cancel_url = isset( $booking_metas['place_order']['tid'] ) && ! empty( $booking_metas['place_order']['tid'] ) ? get_the_permalink( $booking_metas['place_order']['tid'] ) : home_url( '/' );
        
        $payhere_args = array(
            'merchant_id' => $this->merchant_id,
            'return_url'  => $return_url,
            'cancel_url'  => $fail_cancel_url,
            'notify_url'  => $this->response_url,
            'first_name'  => esc_attr( $_POST['wp_travel_engine_booking_setting']['place_order']['booking']['fname'] ),
            'last_name'   => esc_attr( $_POST['wp_travel_engine_booking_setting']['place_order']['booking']['lname'] ),
            'email'       => esc_attr( $_POST['wp_travel_engine_booking_setting']['place_order']['booking']['email'] ),
            'phone'      => esc_attr( $_POST['wp_travel_engine_booking_setting']['place_order']['booking']['phone'] ),
            'address'    => esc_attr( $_POST['wp_travel_engine_booking_setting']['place_order']['booking']['address'] ),
            'city'       => esc_attr( $_POST['wp_travel_engine_booking_setting']['place_order']['booking']['city'] ),
            'country'    => esc_attr( $_POST['wp_travel_engine_booking_setting']['place_order']['booking']['country'] ),
            'order_id'   => $booking_id,
            'items'      => get_the_title( $booking_metas['place_order']['tid'] ),
            'currency' => wp_travel_engine_get_currency_code(),
            'amount'   => $payment_amount,
            'platform' => 'wp-travel-engine'
        );
        
        $trips = array();
        $i=1;
        foreach ( $wte_cart->getItems() as $item ) {
            
            $trips[] = get_the_title( $item['trip_id'] );
            
            $payhere_args['item_name_'.$i]   = get_the_title( $item['trip_id'] );
            $payhere_args['item_number_'.$i] = $item['trip_id'];
            $payhere_args['amount_'.$i]      = $item['trip_price'];
            $payhere_args['quantity_'.$i]    = 1;
            $payhere_args['tax_'.$i]         = 0;

            $i++;
        }
        
        $payhere_args['items'] = implode( ', ', $trips);

        if ( $this->onsite_checkout_enable ){
            
            $payment_obj = array();

            foreach( $payhere_args as $key => $value ) {
                $payment_obj[$key] = $value;
            }
            
            $payment_obj['sandbox'] = defined( 'WP_TRAVEL_ENGINE_PAYMENT_DEBUG' ) && WP_TRAVEL_ENGINE_PAYMENT_DEBUG ? true : false;

            echo '<button style="display:none" type="button" class="button-alt" id="wte_payhere_show_payhere_payment_onsite" onclick="payhere_showmodal()">'.
            __('Pay via PayHere', 'wte-payhere-payment').'</button>
            <script type="text/javascript" src="https://www.payhere.lk/lib/payhere.js"></script>
            <script>

                document.querySelector("#wte_payhere_show_payhere_payment_onsite").dispatchEvent(new Event("click"));

                payhere.onCompleted = function onCompleted(orderId) {
                    window.location = "'. $payhere_args['return_url'] . '";
                };
            
                payhere.onError = function onError(error) {
                    alert("An error occured while making the payment. Error: " + error);
                };

                function payhere_showmodal(){
                    let payment = ' . json_encode( $payment_obj ) . ';
                    payhere.startPayment(payment);
                }
            </script>';
        exit;
        } else {

            $payhere_form_args = array();
        
            foreach ( $payhere_args as $key => $value ) {

                $payhere_form_args[] = '<input type="hidden" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '" />';

            }

            // The form
            echo '<p>'. esc_html_e( 'Redirecting to payhere website...', 'wte-payhere-payment' ) .'</p>
                <form action="' . $this->url . '" method="POST" name="payhere_payment_form" id="payhere_payment_form">
                    ' . implode( '', $payhere_form_args ) . '
                    <input type="submit" class="button" id="submit_payhere_payment_form" value="' . __( 'Pay via Payhere', 'wte-payhere-payment' ) . '" />
                    <script type="text/javascript">
                        document.getElementById("submit_payhere_payment_form").click();
                    </script>
                </form>';

        }

        exit;
    }

    /**
	 * Catch notify URL Response.
	 *
	 * @return void
	 */
	public function response_catcher() {

		// Payment response.
		if ( isset( $_GET[ 'wte_payment' ] ) && esc_attr( $_GET[ 'wte_payment' ] ) === 'wte_gateway_payhere' ) {

			$this->check_payhere_response();
        
        }

	}

    /**
     * Check response for payhere payment gateway.
     *
     * @return void
     */
    public function check_payhere_response() {

        global $wte_cart;

        if ( isset( $_REQUEST['order_id'] ) && isset( $_REQUEST['payment_id'] ) ) {
            
            $booking_id = $_REQUEST['order_id'];
            
            if ( $booking_id != '' ) {
                try{
                    
                    $booking_metas = get_post_meta( $booking_id, 'wp_travel_engine_booking_setting', true );
                    $booking_total = $booking_metas['place_order']['cost'];

                    $booking = get_post( $booking_id );
                    $md5sig  = $_REQUEST['md5sig'];
                    $status  = $_REQUEST['status_code'];
                    
                    $verified = true;

                    if ( $this->merchant_secret ) {

                        $hash  = $_REQUEST['merchant_id'];
                        $hash .= $_REQUEST['order_id'];
                        $hash .= $_REQUEST['payhere_amount'];
                        $hash .= $_REQUEST['payhere_currency'];
                        $hash .= $_REQUEST['status_code'];
                        $hash .= strtoupper( md5( $this->merchant_secret ) );
                        $md5hash = strtoupper( md5( $hash ) );
                        $md5sig = $_REQUEST['md5sig'];

                        if ( ( $md5hash != $md5sig ) || ( strtolower( $_REQUEST['merchant_id'] ) != strtolower(  $this->merchant_id ) )
                            || $_REQUEST['payhere_amount'] != ( $booking_total ) ) {
                            $verified = false;
                        }
                    }
                    
                    $payment_details = array();

                    $payment_details['status_code'] = array(
                        'label' => __( 'Status Code', 'wte-payhere-payment' ),
                        'value' => $status
                    );

                    update_post_meta( $booking_id, 'wp_travel_engine_booking_payment_gateway', 'PayHere Payment' );
                    
                    $trans_authorised = false;
                    
                    if ( $verified ) {

                        $status = strtolower( $status );

                        $payment_status  = get_post_meta( $booking_id, 'wp_travel_engine_booking_payment_status', true );

                        if ( $status=="2" ) {

                            $trans_authorised = true;

                            if ( $payment_status == 'pending' ) {

                                $payment_details['payhere_payment_id'] = array(
                                    'label' => __( 'PayHere Payment ID', 'wte-payhere-payment' ),
                                    'value' => $_REQUEST['payment_id']
                                );

                                update_post_meta( $booking_id, 'wp_travel_engine_booking_payment_status', 'completed' );

                            } else {

                                update_post_meta( $booking_id, 'wp_travel_engine_booking_payment_status', 'completed' );
                                
                                $payment_details['payhere_payment_id'] = array(
                                    'label' => __( 'PayHere Payment ID', 'wte-payhere-payment' ),
                                    'value' => $_REQUEST['payment_id']
                                );

                            }
                        } elseif ( $status=="0" ) {

                            $trans_authorised = true;

                            update_post_meta( $booking_id, 'wp_travel_engine_booking_payment_status', 'on-hold' );

                            $payment_details['payhere_payment_id'] = array(
                                'label' => __( 'PayHere Payment ID', 'wte-payhere-payment' ),
                                'value' => $_REQUEST['payment_id']
                            );
                            
                        } else {

                            update_post_meta( $booking_id, 'wp_travel_engine_booking_payment_status', 'cancelled' );

                            $payment_details['payhere_payment_eror'] = array(
                                'label' => __( 'Error', 'wte-payhere-payment' ),
                                'value' => 'Transaction ERROR. Status Code: '. $status
                            );

                        }
                    } else {

                        update_post_meta( $booking_id, 'wp_travel_engine_booking_payment_status', 'cancelled' );

                            $payment_details['payhere_payment_eror'] = array(
                                'label' => __( 'Security Error. Illegal access detected.', 'wte-payhere-payment' ),
                                'value' => json_encode( $_REQUEST )
                            );

                    }
                    if ( $trans_authorised == false ) {
                        
                        update_post_meta( $booking_id, 'wp_travel_engine_booking_payment_status', 'failed' );

                    }

                    update_post_meta( $booking_id, 'wp_travel_engine_booking_payment_details', $payment_details );

                } catch ( Exception $e ) {
                    // $errorOccurred = true;
                    $msg = "Error";
                }
            }

        }

    }

}
