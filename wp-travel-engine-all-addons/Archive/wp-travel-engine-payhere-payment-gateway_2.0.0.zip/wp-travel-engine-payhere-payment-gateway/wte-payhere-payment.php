<?php
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://wptravelengine.com/
 * @since             1.0.0
 * @package           WTE_PayHere_Payment
 *
 * @wordpress-plugin
 * Plugin Name:       WP Travel Engine - PayHere Payment Gateway
 * Plugin URI:        https://wptravelengine.com/
 * Description:       An extension of WP Travel Engine plugin to accept payment directly on your website through PayHere Payment Gateway.
 * Version:           2.0.0
 * Author:            WP Travel Engine
 * Author URI:        https://wptravelengine.com/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       wte-payhere-payment
 * Domain Path:       /languages
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WTE_PayHere_Payment' ) ) :
	/**
	 * Class WTE_PayHere_Payment.
	 * 
	 * @package WTE Payhere Checkout.
	 */
	class WTE_PayHere_Payment {

		/**
		 * Plugin Name.
		 *
		 * @var string
		 */
		public $plugin_name = 'wte-payhere-payment';

		/**
		 * Version.
		 *
		 * @var string
		 */
		public $version = '2.0.0';

		/**
		 * Allowed currencies
		 */
		public $allowed_currencies = array( 'LKR', 'USD', 'GBP', 'EUR', 'AUD' );

		/**
		 * The single instance of the class.
		 *
		 * @var string $_instance
		 */
		protected static $_instance = null;

		/**
		 * Main WTE_PayHere_Payment Instance.
		 * Ensures only one instance of WTE_PayHere_Payment is loaded or can be loaded.
		 *
		 * @return WTE_PayHere_Payment - Main instance.
		 */
		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}
			return self::$_instance;
		}

		/**
		 * Class Constructor.
		 */
		public function __construct() {
            
            $this->define_constants();
            
			add_action( 'admin_notices', array( $this, 'check_dependency' ) );
            
            if ( class_exists( 'WP_Travel_Engine' ) ) {

				$this->init_hooks();
				if ( is_admin() ) :
				
					new WTE_PayHere_Admin;
				
				endif;

				new WTE_PayHere_Public;
            }

		}

		/**
		 * Plugin constants.
		 */
		private function define_constants() {

            $this->define( 'WTE_PAYHERE_PAYMENTS_FILE_PATH', __FILE__ );
            $this->define( 'WTE_PAYHERE_PAYMENTS_BASE_PATH', dirname( __FILE__ ) );
            $this->define( 'WTE_PAYHERE_PAYMENTS_VERSION', $this->version );

		}

		/**
		 * Define constants.
		 *
		 * @param string $name Constant name.
		 * @param string $value Constant value.
		 */
		public function define( $name, $value ) {
            
            if ( ! defined( $name ) ) {
				define( $name, $value );
			}
        
        }

		/**
		 * Include  required function/ class files.
		 */
		private function includes() {

			require WTE_PAYHERE_PAYMENTS_BASE_PATH . '/public/class-wte-payhere-public.php';
			
			/**
			 * The class responsible for updating the add-on from EDD.
			 */
			if ( is_admin() ){
				
				require WTE_PAYHERE_PAYMENTS_BASE_PATH . '/admin/class-wte-payhere-admin.php';
			}
		}

		/**
		 * Hooks to init in start.
		 */
		public function init_hooks() {
			
            $this->includes();
            
            add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
            
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
			
			// Add filter for the sortable gateway list.
			add_filter( 'wp_travel_engine_available_payment_gateways', array( $this, 'payhere_gateway_list' ) );
			
			add_action( 'admin_notices', array( $this, 'show_notifications' ) );

			add_filter( 'wpte_settings_get_global_tabs', array( $this, 'add_global_settings' ) );

        }

        /**
         * admin scripts
         *
         * @return void
         */
        public function enqueue_admin_scripts(){

            wp_enqueue_script( 'wte-payhere-payment-admin-js', plugin_dir_url( __FILE__ ). '/assets/js/payhere-admin.js', array( 'jquery' ), '', false );

        }

        /**
         * Enqueue Scripts
         *
         * @return void
         */
        public function enqueue_scripts(){
        
            
        }

        /**
         * Check if Stripe is enabled.
         *
         * @return boolean
         */
        public function is_wte_payhere_enabled() {
            
            $wte_options = get_option('wp_travel_engine_settings', true);

            return isset( $wte_options['payhere_payment'] ) && $wte_options['payhere_payment'] != '';     

		}
		
		/**
		 * Show notifications.
		 */
		public function show_notifications( ) { 

			$currency_code = wp_travel_engine_get_currency_code();
			
			if ( in_array( $currency_code, $this->allowed_currencies ) ) {
				return;
			}
		?>

			<div class="notice notice-error"> 
				<p>
					<strong><?php _e( 'PayHere Error : ', 'wte-payhere-payment' ); ?></strong>
					<?php _e( 'Currency not supported. Change the currency to supported currency to enable PayHere checkout.', 'wte-payhere-payment' ); ?>
				</p>
			</div>
		<?php 
		}

        /**
         * Check if checkout process uses payhere checkout.
         *
         * @return void
         */
        public function checkout_uses_payhere() {

            return 'POST' === $_SERVER['REQUEST_METHOD'] && array_key_exists( 'wpte_checkout_paymnet_method', $_REQUEST ) && 'payhere_payment' === $_REQUEST['wpte_checkout_paymnet_method'] && array_key_exists( 'payhere_payment_details', $_REQUEST ) && ! empty( $_REQUEST['payhere_payment_details'] );

        }

		/**
		 * This will uninstall this plugin if parent WP Travel plugin not found.
		 */
		public function check_dependency() {

			if ( ! class_exists( 'Wp_Travel_Engine' ) || ! $this->meets_requirements() ) {
                
                echo '<div class="error">';
					echo wp_kses_post( '<p><strong>WP Travel Engine - PayHere Payment Gateway</strong> requires the <a href="https://wptravelengine.com" target="__blank">WP Travel Engine</a> <strong>v.4.0.0 or later</strong> to work. Please install, activate  or update WP Travel Engine plugin and then reactivate this addon. <b>WP Travel Engine PayHere Payment Gateway will be deactivated now.</b></p>' );
				echo '</div>';

				// Deactivate Plugins.
				deactivate_plugins( plugin_basename( __FILE__ ) );
			}
		}

		/**
		 * Check if all plugin requirements are met.
		 *
		 * @since 1.0.0
		 *
		 * @return bool True if requirements are met, otherwise false.
		 */
		private function meets_requirements() {
			return ( class_exists( 'WP_Travel_Engine' ) && defined( 'WP_TRAVEL_ENGINE_VERSION' ) && version_compare( WP_TRAVEL_ENGINE_VERSION, '4.0.0', '>=' ) );
		}

		/**
		 * Add Payhere to payment gateways list.
		 *
		 * @param [type] $gateway_list
		 * @return void
		 */
		public function payhere_gateway_list( $gateway_list ) {

			if ( ! in_array( wp_travel_engine_get_currency_code(), $this->allowed_currencies ) ) 
				return $gateway_list;

			$gateway_list['payhere_payment'] = array(
				'label'       => __( 'Payhere Checkout', 'wte-payhere-payment' ),
				'input_class' => 'wte-payhere-checkout',
				'info_text'   => __( 'Please check this to enable PayHere checkout for trip booking and fill the account info below.', 'wte-payhere-payment' ),
				'icon_url'    => '',
				);

			return $gateway_list;

		}

		/**
		 * Add Global Settings section.
		 *
		 * @param [type] $global_tabs
		 * @return void
		 */
		public function add_global_settings( $global_tabs ) {

			if ( isset( $global_tabs['wpte-payment'] ) ) {
				$global_tabs['wpte-payment']['sub_tabs']['wte-payhere'] = array(
					'label' => __( 'PayHere Payment', 'wte-payhere-payment' ),
					'content_path' => plugin_dir_path( WTE_PAYHERE_PAYMENTS_FILE_PATH ) . 'admin/global-settings.php',
					'current' => false,
				);
			}
	
			return $global_tabs;
		}

	}

	/**
	 * Initiate addon.
	 */
	function wte_payhere_payment_init() {
		return WTE_PayHere_Payment::instance();
	}

	add_action( 'plugins_loaded', 'wte_payhere_payment_init' );
endif;
