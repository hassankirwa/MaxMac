=== WP Travel Engine - PayHere Payment Gateway ===
Contributors: wptravelengine
Plugin link: https://wptravelengine.com/
Tags: payments, payhere, checkout, wp-travel-engine, booking
Requires at least: 4.4.0
Tested up to: 5.4
Requires PHP: 5.6
Stable tag: 2.0.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Payment addon for WP Travel Engine to checkout trip bookings using PayHere Payment Gateway.

== Description ==

Payment addon for WP Travel Engine to checkout trip bookings using PayHere Payment Gateway.

WP Travel Engine - PayHere Payment Gateway addon requires WP Travel Engine plugin v. 3.0.5 or later installed and activated in the site.

== Changelog ==

= 2.0.0 =

Released on: 19th June, 2020

Enhancements:

* Revamped backend UI.
* Assets minification, optimization, and conditional loading.

Fixes:

* Minor bug fixes.

= 1.0.1 =

Released on: 7th April, 2020

Enhancements:

* Compatibility check for WordPress 5.4.
* Requirements check for WP Travel Engine.

= 1.0.0 =

Released on: 6th Feb 2020

* Initial release
