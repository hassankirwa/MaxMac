(function ($) {
    $(function () {

        var file_frame;
        var allowed_filetype = [
            "application/msword",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/pdf",
            "image/jpeg",
            "image/png",
            "text/plain"
           ];
           wtefd_sortable();
           $(document).on('click', '#wtfd-file-add', function (e) {
            e.preventDefault();
             var $this = $(this);
             var field_setting_type = $(this).data('setting-type');
             var preview_text = $(this).data('text-preview');
             var replace_file_text = $(this).data('text-replace-file');
             var remove_file_text = $(this).data('text-remove-file');
             if (file_frame)
                file_frame.close();

            file_frame = wp.media.frames.file_frame = wp.media({
                title: $(this).data('uploader-title'),
                button: {
                    text: $(this).data('uploader-button-text'),
                },
                library : {
                    type: allowed_filetype
                 },
                multiple: true
            });

            index_max_count = parseInt($this.parents('.wtefd-inner-wrap').find('.wtefd-max-img-count').val());
            
            file_frame.on('select', function () {
                selection = file_frame.state().get('selection');
                selection.map(function (attachment, i) {
                    attachment = attachment.toJSON(),
                        index = index_max_count + (i + 1);
                        switch(attachment.subtype) {
                        case 'vnd.openxmlformats-officedocument.wordprocessingml.document':
                            attachment_subtype = 'file-msword';
                        break;
                        default:
                            attachment_subtype = attachment.subtype
                        }                  
                        file_html_content  = '<li data-id="'+index+'"><span class="tabs-handle"><span>Sort</span></span>'
                        +'<div class="form-builder">'
                        +'<div class="download-fields-wrap">'
                        +'<div class="file-type-preview file-'+attachment.type+' file-'+attachment_subtype+'"></div>'
                        +'<div class="field-id"><input type="hidden" readonly class="wtefd-file-id-val" name="'+field_setting_type+'[file_downloads][wte_files_downloadable][' + index + '][id]"'
                        +'value="' + attachment.id + '"></div>'
                        +'<div class="field-url"><input type="hidden" readonly class="wtefd-file-url" name="'+field_setting_type+'[file_downloads][wte_files_downloadable][' + index + '][url]"'
                        +'value="' + attachment.url + '"></div>'
                        +'<div class="field-title"><input type="text" class="wtefd-file-title" name="'+field_setting_type+'[file_downloads][wte_files_downloadable][' + index + '][title]"'
                        +'value="' + attachment.filename +'"></div>'
                        +'<a class="wtefd-preview-button button button-secondary" href="' + attachment.url + '" target="_blank" >'+preview_text+'</a>'
                        +'</div>'
                        +'<div class="download-field-action-wrap">'
                        +'<a class="wtefd-change-file" href="#" data-uploader-title="Change File"'
                        +'data-uploader-button-text="'+replace_file_text+'"><i class="fas fa-sync-alt"></i></a>'
                        +'<a class="wtefd-remove-file" href="#"><i class="fas fa-trash-alt"></i></a>'
                        +'</div>'
                        +'</div>'
                        +'</li>';
                        $(file_html_content).insertBefore($this.closest('.wtefd-main-wrap').find('.wtefd-files-field-coll #wtefd-add-remove-fields'));
                    $this.parents('.wtefd-inner-wrap').find('.wtefd-max-img-count').val(parseInt(index));
                });
            });
            wtefd_sortable();
            file_frame.open();
        });

        $(document).on('click', 'a.wtefd-change-file', function (e) {
            e.preventDefault();
            var that = $(this);
            if (file_frame)
                file_frame.close();
            file_frame = wp.media.frames.file_frame = wp.media({
                title: $(this).data('uploader-title'),
                button: {
                    text: $(this).data('uploader-button-text'),
                },
                library : {
                    type: allowed_filetype
                  },
                multiple: false
            });
            file_frame.on('select', function () {
                attachment = file_frame.state().get('selection').first().toJSON();
                switch(attachment.subtype) {
                    case 'vnd.openxmlformats-officedocument.wordprocessingml.document':
                        attachment_subtype = 'file-msword';
                    break;
                    default:
                        attachment_subtype = attachment.subtype
                    }
                that.parents('.form-builder').find('.file-type-preview').removeClass().addClass('file-type-preview file-'+attachment.type +' file-'+attachment_subtype);           
                that.parents('.form-builder').find('.wtefd-file-id-val').attr('value', attachment.id);
                that.parents('.form-builder').find('.wtefd-file-url').attr('value', attachment.url);
                that.parents('.form-builder').find('.wtefd-preview-button').attr('href', attachment.url);
                that.parents('.form-builder').find('.wtefd-file-title').attr('value', attachment.filename);
            });
            file_frame.open();
        });

        /**
         * sortable for file adder field
         */
        function wtefd_sortable() {
            if ($('.wtefd-files-field-coll').length) {
            $('.wtefd-files-field-coll').sortable({
                opacity: 0.9,
                revert: true
            });
            $('.wtefd-files-field-coll').disableSelection();
        }
        }

        /**
         * Remove file element on file field remove click
         */
        $(document).on('click', '.wtefd-files-field-coll a.wtefd-remove-file', function (e) {
            e.preventDefault();
            var cur_id_reset = $(this).closest('li').attr('data-id');
            $(this).closest('li').animate({ opacity: 0 }, 200, function () {
                $(this).remove();
            });
        });

        /**
         * Intialize add global file upload file on click using ajax
         */
        $('body').on('click', '.add-file-global-ajax', function(e) {
            e.preventDefault();
            $this = $(this);
            var val = parseInt($this.parent().find('#wtefd-file-selector-global').find(':selected').val());
            var text = $this.parent().find('#wtefd-file-selector-global').find(':selected').text();
            var max_count = parseInt($this.parents('.wtefd-inner-wrap').find('.wtefd-max-img-count').val());
            var max_count_new = max_count + 1;
            flag=false;
            if(val !== '' && !isNaN(val) && val != undefined){
                flag=true;
            }
            if(flag == true){
            jQuery.ajax({
                url: wtefd_backend_js_object.ajax_url,
                type: 'post',
                data: {
                    file_id: val,
                    file_text: text,
                    max_count:max_count_new,
                    _wpnonce: wtefd_backend_js_object.ajax_nonce,
                    action: 'wtefd_add_global_file_field'
                },
                beforeSend: function() {
                    $this.parent().find('.wtefd-loader').fadeIn(500);
                },
                success: function(response) {
                    $this.parents('.wtefd-inner-wrap').find('.wtefd-max-img-count').val(max_count_new);
                    file_html_content  = response;
                    $(file_html_content).insertBefore($this.closest('.wtefd-main-wrap').find('.wtefd-files-field-coll #wtefd-add-remove-fields'));
                    //$this.parents('#trip-downloads').find('.wtefd-files-field-coll').append(response);
                    wtefd_sortable();
                },
                complete: function() {
                   file_html_content  = $this.parent().find('.wtefd-loader').fadeOut(500);
                    $this.parent().find('#wtefd-file-selector-global').find(':selected').removeAttr("selected");
                }
            });
        }
        });

    });
}(jQuery));