(function ($) {
    $(function () {

       
    });
}(jQuery));