<?php

defined('ABSPATH') or die("No script kiddies please!");

/**
 * Plugin Name: WP Travel Engine - File Downloads
 * Plugin URI: https://wptravelengine.com
 * Description: WP Travel Engine - File DownLoads is a custom addon for WP Travel Engine plugin that helps you add/create downlodable files
 * Author: WP Travel Engine
 * Author URI: https://wptravelengine.com
 * Text Domain: wte-file-downloads
 * Domain Path: /i18n/languages
 * Version: 2.0.3
 * License: GPL2+
 * License URI: https://www.gnu.org/licenses/gpl-2.0.txt
 *
 * @package WTE File Downloads.
 */
if (!defined('WTEFD_VERSION')) {
    define('WTEFD_VERSION', '2.0.3');
}

if (!defined('WTEFD_IMAGE_DIR')) {
    define('WTEFD_IMAGE_DIR', plugin_dir_url(__FILE__) . '/assets/images/');
}

if (!defined('WTEFD_JS_DIR')) {
    define('WTEFD_JS_DIR', plugin_dir_url(__FILE__) . '/assets/js/');
}
if (!defined('WTEFD_CSS_DIR')) {
    define('WTEFD_CSS_DIR', plugin_dir_url(__FILE__) . '/assets/css/');
}

if (!defined('WTEFD_ADMIN_DIR')) {
    define('WTEFD_ADMIN_DIR', dirname(__FILE__) . '/admin/');
}
if (!defined('WTEFD_FRONT_TEMPLATE_DIR')) {
    define('WTEFD_FRONT_TEMPLATE_DIR', dirname(__FILE__) . '/templates/');
}

if (!defined('WTEFD_CLASSES_DIR')) {
    define('WTEFD_CLASSES_DIR', dirname(__FILE__) . '/classes');
}

if (!defined('WTEFD_FILE_ROOT_DIR')) {
    define('WTEFD_FILE_ROOT_DIR', plugin_dir_path(__FILE__));
}
if (!defined('WTEFD_PLUGIN_URL')) {
    define('WTEFD_PLUGIN_URL', plugin_dir_url(__FILE__));
}
if (!defined('WTEFD_FILE_PATH')) {
    define('WTEFD_FILE_PATH', __FILE__);
}

if (!class_exists('WTE_File_Downloads')) {
    global $globalvariables;
    class WTE_File_Downloads {

        function __construct() {
            add_action('admin_init', array($this, 'wtefd_check_parent_plugin'));
            add_action('plugins_loaded', array($this, 'wtefd_include_call'));
        }

        function wtefd_check_parent_plugin() {
            if (is_admin() && current_user_can('activate_plugins') && !is_plugin_active('wp-travel-engine/wp-travel-engine.php')) {
                add_action('admin_notices', array($this, 'wtefd_show_message_for_parent_plugin'));
                deactivate_plugins(plugin_basename(__FILE__));
                if (isset($_GET['activate'])) {
                    unset($_GET['activate']);
                }
            }
        }

        /**
         * Function to check if parent plugin is enabled
         * 
         */
        function wtefd_show_message_for_parent_plugin() {
            if ( ! $this->meets_requirements()) {
                echo '<div class="notice notice-error is-dismissable">';
                echo wp_kses_post('<p><strong>WP Travel Engine - WTE File Downloads</strong> requires the <a href="https://wptravelengine.com" target="__blank">WP Travel Engine</a> <b>version - 4.0.0 or later</b> to work. Please install and activate the latest WP Travel Engine plugin first. <b>WP Travel Engine - WTE File Downloads will be deactivated now.</b></p>');
                echo '</div>';
                deactivate_plugins(plugin_basename(__FILE__));
            }
        }

        /**
		 * Check if all plugin requirements are met.
		 *
		 * @since 1.0.0
		 *
		 * @return bool True if requirements are met, otherwise false.
		 */
		private function meets_requirements() {
			return ( class_exists( 'WP_Travel_Engine' ) && defined( 'WP_TRAVEL_ENGINE_VERSION' ) && version_compare( WP_TRAVEL_ENGINE_VERSION, '4.0.0', '>=' ) );
        }

        /**
         * Function to enqueue required JS and CSS 
         *
         */
        function wtefd_include_call() {
          
            $this->declare_global();
            $this->wtefd_required_includes();
        }

        private function declare_global() {
            global $globalvariables; //parent plugin setting wp_travel_engine_settings
            $globalvariables['global_setting_key'] = 'wp_travel_engine_settings';
            $globalvariables['meta_setting_key'] = 'wte_file_downloads';
            return $globalvariables;
           }

        /**
         * Call File Downloads Init Class
         *
         */
        function wtefd_required_includes() {
            if ( $this->meets_requirements() ) {
                if (is_admin()) {
                    require_once WTEFD_FILE_ROOT_DIR . '/updater/wte-file-downloads-updater.php';
                }
                include WTEFD_CLASSES_DIR . '/class-library.php';
                include WTEFD_CLASSES_DIR . '/class-init.php';
                include WTEFD_CLASSES_DIR . '/class-enqueue.php';
                include WTEFD_CLASSES_DIR . '/class-shortcode.php';
                include WTEFD_CLASSES_DIR . '/class-action.php';
            }
        }

    }

    $WTE_File_Downloads_Object = new WTE_File_Downloads();
}