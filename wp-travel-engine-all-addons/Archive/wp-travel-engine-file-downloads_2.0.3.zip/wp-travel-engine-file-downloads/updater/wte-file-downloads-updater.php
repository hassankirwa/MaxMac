<?php

/**
 * Easy Digital Downloads Plugin Updater
 *
 * @package WTE File Downloads
 */
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Includes the files needed for the plugin updater.
 *
 * @since 1.0.0
 */
if (!class_exists('EDD_SL_Plugin_Updater')) {

    include( dirname(__FILE__) . '/EDD_SL_Plugin_Updater.php' );
}

/**
 * Download ID for the product in Easy Digital Downloads.
 *
 * @since 1.0.0
 */
define('WTE_FILES_DOWNLOADS_ITEM_ID', 34335);

/**
 * Setup the updater for the WTE File Downloads Add-on.
 *
 * @since 1.0.0
 */
function wte_files_downloads_updater() {

    // retrieve our license key from the DB
    $settings = get_option('wp_travel_engine_license');
    $license_key = isset($settings['wte_file_downloads_license_key']) ? esc_attr($settings['wte_file_downloads_license_key']) : '';

    // setup the updater
    $edd_updater = new EDD_SL_Plugin_Updater(WP_TRAVEL_ENGINE_STORE_URL, WTEFD_FILE_PATH,
        array(
            'version' => WTEFD_VERSION, // current version number
            'license' => $license_key, // license key (used get_option above to retrieve from DB)
            'item_id' => WTE_FILES_DOWNLOADS_ITEM_ID, // ID of the product
            'author' => 'WP Travel Engine', // author of this plugin
            'beta' => false,
        )
    );
}

add_action('admin_init', 'wte_files_downloads_updater', 0);

/**
 * Add-ons name for plugin license page.
 *
 * @since 1.0.0
 */
function wte_file_downloads_name($array) {
    $array['WP Travel Engine - File Downloads'] = 'wte_file_downloads';
    return $array;
}

add_filter('wp_travel_engine_addons', 'wte_file_downloads_name');

/**
 * Add-ons Item ID for plugin license page.
 *
 * @since 1.0.0
 */
function wte_file_downloads_id($array) {
    $array['wte_file_downloads'] = WTE_FILES_DOWNLOADS_ITEM_ID;
    return $array;
}

add_filter('wp_travel_engine_addons_id', 'wte_file_downloads_id');
