<?php defined('ABSPATH') or die('No script kiddies please!!');

if (
    isset($meta_settings['file_downloads']['wte_files_downloadable'])
    && !empty($meta_settings['file_downloads']['wte_files_downloadable'])
) {
    $trip_specific_nempty_flag = 'true';
    $trip_specific_files_list = $meta_settings['file_downloads']['wte_files_downloadable'];
} else {
    $trip_specific_nempty_flag = 'false';
    $trip_specific_files_list = '';
}

if ((isset($global_settings['file_downloads']['wte_files_downloadable'])
    && !empty($global_settings['file_downloads']['wte_files_downloadable']))) {
    $global_nempty_flag = 'true';
    $global_files_list = $global_settings['file_downloads']['wte_files_downloadable'];
} else {
    $global_nempty_flag = 'false';
    $global_files_list = '';
}

if (
    (isset($global_settings['file_downloads']['wte_file_download_global_check'])
    && $global_settings['file_downloads']['wte_file_download_global_check'] == 1)
    || !isset($global_settings['file_downloads']['wte_file_download_global_check'])
) {
    $global_list_check_flag = 'true';
} else {
    $global_list_check_flag = 'false';
}

if ((isset($global_settings['file_downloads']['wte_file_download_force_global']) && $global_settings['file_downloads']['wte_file_download_force_global'] !== 1)) {
    $force_global_file_flag = 'true';
} else {
    $force_global_file_flag = 'false';
}

$trip_id = (isset($atts['trip_id'])) ? $atts['trip_id'] : '';

if($trip_specific_nempty_flag == 'true' || $global_nempty_flag == 'true'){
?>
<div class="file-downloadable-wrap">
    <?php 
        if(isset($global_settings['file_downloads']['wte_file_download_label'])
        && !empty($global_settings['file_downloads']['wte_file_download_label'])){
    ?>
    <div class="file downloadable-header">
        <?php echo esc_attr($global_settings['file_downloads']['wte_file_download_label']); ?>
    </div>
    <?php
        }else if (!isset($global_settings['file_downloads']) && $trip_specific_nempty_flag == 'true' && $global_nempty_flag == 'false'){
            ?>
    <div class="file downloadable-header">
        <?php echo __('Downloadable Files','wte-file-downloads'); ?>
    </div>
    <?php } ?>
    <?php 
        if(isset($global_settings['file_downloads']['wte_file_download_description'])
        && !empty($global_settings['file_downloads']['wte_file_download_description'])){
            ?>
    <div class="file downloadable-description">
    <?php 
    $obj = new WTE_File_Downloads_Library;
    echo esc_attr($obj->wtefd_stripslashes_deep($global_settings['file_downloads']['wte_file_download_description'])); ?>
    </div>
    <?php
        }else if (!isset($global_settings['file_downloads']) && $trip_specific_nempty_flag == 'true' && $global_nempty_flag == 'false'){
            ?>
    <div class="file downloadable-description">
        <?php echo __('Please find downloadable files below.','wte-file-downloads'); ?>
    </div>
    <?php } ?>
    <div class="file-downloadable-list">
        <?php
        if ($global_list_check_flag == 'true' && $trip_specific_nempty_flag == 'true' && $global_nempty_flag == 'true' && $force_global_file_flag == 'true') {
           $this->list_file_downlodable($global_files_list);
            if (isset($global_settings['file_downloads']['wte_file_download_force_global']) && $global_settings['file_downloads']['wte_file_download_force_global'] == '1') {
                $trip_specific_array_check = array();
                foreach ($global_files_list as $gkey => $gvalue) {
                    array_push($trip_specific_array_check, $gvalue['id']);
                }
                foreach ($trip_specific_files_list as $key => $value) {
                    if (in_array($value['id'], $trip_specific_array_check)) {
                        unset($trip_specific_files_list[$key]);
                    }
                }
                $arr = $trip_specific_files_list;
                $this->list_file_downlodable($arr);
            } else {
                $this->list_file_downlodable($trip_specific_files_list);
            }
        }
     
        if ($global_list_check_flag == 'true' && $trip_specific_nempty_flag == 'true' && $global_nempty_flag == 'true' && $force_global_file_flag == 'true') {
            $this->list_file_downlodable($global_files_list);
            $this->list_file_downlodable($trip_specific_files_list);
        } else if ($global_list_check_flag == 'true' && $trip_specific_nempty_flag == 'true' && $global_nempty_flag == 'true' && $force_global_file_flag == 'false') {
            $this->list_file_downlodable($trip_specific_files_list);
        } else if ($global_list_check_flag == 'false' && $trip_specific_nempty_flag == 'true' && $global_nempty_flag == 'true' && $force_global_file_flag == 'false') {
            $this->list_file_downlodable($trip_specific_files_list);
        } else if ($global_list_check_flag == 'true' && $trip_specific_nempty_flag == 'false' && $global_nempty_flag == 'true' && $force_global_file_flag == 'true') {
            $this->list_file_downlodable($global_files_list);
        } else if ($global_list_check_flag == 'true' && $trip_specific_nempty_flag == 'false' && $global_nempty_flag == 'true' && $force_global_file_flag == 'false') {
            $this->list_file_downlodable($global_files_list);
        } else if ($global_list_check_flag == 'false' && $trip_specific_nempty_flag == 'true' && $global_nempty_flag == 'false' && $force_global_file_flag == 'false') {
            $this->list_file_downlodable($trip_specific_files_list);
        }else if (!isset($global_settings['file_downloads']) && $global_list_check_flag == 'true' && $trip_specific_nempty_flag == 'true' && $global_nempty_flag == 'false' && $force_global_file_flag == 'false') {
            $this->list_file_downlodable($trip_specific_files_list);
        }else if ($trip_specific_nempty_flag == 'true' && $global_nempty_flag == 'false') {
            $this->list_file_downlodable($trip_specific_files_list);
        }?>
    </div>
</div>
<?php } ?>