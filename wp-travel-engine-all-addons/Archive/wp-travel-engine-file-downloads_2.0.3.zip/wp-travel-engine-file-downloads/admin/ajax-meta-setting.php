<?php
defined('ABSPATH') or die('No script kiddies please!!');
$attachment_src = wp_get_attachment_url($file_id);
$file_details = get_post_mime_type(intval($file_id));
?>
<li data-id="<?php echo $max_count;?>">
    <span class="tabs-handle"><span><?php _e('Sort','wte-file-downloads');?></span></span>
    <div class="form-builder">
        <div class="download-fields-wrap">
                <?php 
                if(!empty($file_details) || $file_details !== false){
                    $file_detail = explode("/",$file_details);
                    switch($file_detail[1]){
                        case 'vnd.openxmlformats-officedocument.wordprocessingml.document':
                        $fite_detail_subtype='doc';
                        break;
                        default:
                        $fite_detail_subtype=$file_detail[1];
                    }
                    $file_detail_subtype="";
                ?>
                <div class="file-type-preview file-<?php echo $file_detail[0];?> file-<?php echo $fite_detail_subtype;?>"></div>
                <?php } ?>    
            <div class="field-id">
                <input type="hidden" readonly class="wtefd-file-id-val"
                    name="wte_file_downloads[file_downloads][wte_files_downloadable][<?php echo $max_count;?>][id]"
                    value="<?php echo $file_id;?>">
            </div>
            <div class="field-url"><input type="hidden" readonly class="wtefd-file-url"
                    name="wte_file_downloads[file_downloads][wte_files_downloadable][<?php echo $max_count;?>][url]"
                    value="<?php echo esc_url($attachment_src);?>">
            </div>
            
            <div class="field-title">
                <input type="text" class="wtefd-file-title"
                    name="wte_file_downloads[file_downloads][wte_files_downloadable][<?php echo $max_count;?>][title]"
                    value="<?php echo stripslashes_deep($file_text);?>">
            </div>
            <a class="wtefd-preview-button button button-secondary"
                href="<?php echo isset($attachment_src) && !empty($attachment_src)?esc_url($attachment_src):''?>"
                target="_blank">
            <?php _e('Preview','wte-file-downloads');?>
            </a>
        </div>
        <div class="download-field-action-wrap">
            <a class="wtefd-remove-file" href="#"><?php _e('Remove','wte-file-downloads');?></a>
        </div>
    </div>
</li>