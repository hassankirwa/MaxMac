<?php defined('ABSPATH') or die("No script kiddies please!"); ?>

<?php
global $post, $globalvariables;

$options = get_option('wp_travel_engine_settings', true);

if ( ! is_object( $post ) && defined( 'DOING_AJAX' ) && DOING_AJAX ) {
    $post_id  = $_POST['post_id'];
    $next_tab = $_POST['next_tab']; 
} else {
    $post_id = $post_id;
}

$field_setting_var = $globalvariables['meta_setting_key'];
$wte_file_downloads = get_post_meta( $post_id, $field_setting_var, true );

if (isset($options['file_downloads']['wte_files_downloadable'])) {
    $filedownload_global_array_keys = $options['file_downloads']['wte_files_downloadable'];
}else{
    $filedownload_global_array_keys='';
}

if (isset($wte_file_downloads['file_downloads']['wte_files_downloadable'])) {
    $filedownload_meta_array_keys=array();
        $filedownload_meta_array_keys = $wte_file_downloads['file_downloads']['wte_files_downloadable'];
    }else{
    $filedownload_meta_array_keys='';
    } 
?>

<div id="trip-downloads" class="wpte-file-downloads wtefd-main-wrap">
     <div class="wpte-info-block">
        <p><?php _e('You can add, edit and delete the global files via','wte-file-downloads');?>
        <b><?php _e('WP Travel Engine &gt; Settings &gt; Extensions &gt; File Downloads','wte-file-downloads');?></b>. <a target="_blank" href="<?php echo admin_url().'edit.php?post_type=booking&page=class-wp-travel-engine-admin.php';?>"><?php _e('Go To Settings.','wte-file-downloads');?></a></p>
        <p><?php _e('You can use the shortcode ','wte-file-downloads');?> <b>[trip_file_downloads trip_id=<?php echo $post_id;?>]</b> <?php _e('to display downloadable file list in posts/pages/tabs and widget.','wte-file-downloads');?> </p>
    </div>
    <div class="wtefd-inner-wrap meta-downloads-wrap">
        <div class="wpte-field wpte-select wpte-floated">
            <label for="wtefd-file-selector-global" class="wpte-field-label">
                <?php _e('Global Files List','wte-file-downloads');?>
            </label>
            <select id="wtefd-file-selector-global">
                <option value=""><?php _e('Choose Global Download Files','wte-file-downloads');?></option>
                <?php   
            if(!empty($filedownload_global_array_keys)){
                foreach ($filedownload_global_array_keys as $key => $value) { 
                ?>
                <option value="<?php echo $value['id'] && !empty($value['id'])?esc_attr(intval($value['id'])):''?>"><?php echo $value['title'] && !empty($value['title'])?esc_attr($value['title']):'Untitled File';?></option>
                <?php 
                } 
            }else{ ?>
                <option disabled="disabled"><?php _e('No Global File Found','wte-file-downloads');?></option>
            <?php } ?>
            </select>
            <input type="button" class="button button-small add-file-global-ajax"
            value="<?php _e('Add Global File','wte-file-downloads');?>">
            <div id="loader" class="wtefd-loader" style="display: none">
                <div class="table">
                    <div class="table-row">
                        <div class="table-cell">
                            <i class="fa fa-spinner fa-spin" aria-hidden="true"></i>
                        </div>
                    </div>
                </div>
            </div>

            <span class="wpte-tooltip">
                <?php _e('Choose the download file from the drop-down and click on <b> Add Global File </b> to add Global Files.','wte-file-downloads');?>
            </span>
        </div>
        
        <ul class="wtefd-fields-meta-wrap wtefd-files-field-coll">
            <?php 
            if(!empty($filedownload_meta_array_keys)){
            foreach ($filedownload_meta_array_keys as $key => $value) { 
            $keyArray[$key] = $key;
            include(WTEFD_ADMIN_DIR . 'reapeater-inner.php');
                }
            }
            $max_key = (isset($keyArray) && !empty($keyArray)) ? array_keys($keyArray, max($keyArray)) : array('0' => '0');
            ?>
            <input type="hidden" name="wte_file_downloads[file_downloads][file_downloads_meta_max_count]"
                value="<?php echo intval($max_key[0]);?>" class="wtefd-max-img-count" />
            <div id="wtefd-add-remove-fields">
                <?php
                    $other_attributes = array(
                        'id' => 'wtfd-file-add',
                        'data-setting-type'=>$field_setting_var,
                        'data-text-preview'=>__('Preview','wte-file-downloads'),
                        'data-text-replace-file'=>__('Change File','wte-file-downloads'),
                        'data-text-remove-file'=>__('Remove','wte-file-downloads')
                        );
                    submit_button(
                        __('Add New File','wte-file-downloads'),
                        '',
                        '',
                        true,
                        $other_attributes
                    );
                ?>
                <span class="file-dl-additional-info"><?php _e('Supports: .JPG, .PNG, .PDF, .DOC','wte-file-downloads');?></span>
            </div>
        </ul>
    </div>
</div>
<?php if ( $next_tab ) : ?>
    <div class="wpte-field wpte-submit">
        <input data-tab="file_downloads" data-post-id="<?php echo esc_attr( $post_id ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'wpte-trip-tab-save-continue' ) ); ?>" data-next-tab="<?php echo isset($next_tab['callback_function'])?esc_attr( $next_tab['callback_function'] ):''; ?>" class="wpte_save_continue_link" type="submit" name="wpte_trip_tabs_save_continue" value="<?php _e( 'Save &amp; Continue', 'wte-file-downloads' ); ?>">
    </div>
<?php endif; ?>