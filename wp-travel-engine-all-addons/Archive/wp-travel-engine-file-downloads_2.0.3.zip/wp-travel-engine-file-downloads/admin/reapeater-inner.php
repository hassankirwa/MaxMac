<?php defined('ABSPATH') or die("No script kiddies please!"); 
$file_details = get_post_mime_type(intval($value['id']));

?>
<li class="ui-state-default" data-id="<?php echo $key;?>">
    <span class="tabs-handle"><span><?php _e('Sort','wte-file-downloads');?></span></span>
    <div class="form-builder">
        <div class="download-fields-wrap">
            <?php 
            if(!empty($file_details) || $file_details !== false){
                $file_detail = explode("/",$file_details);
                switch($file_detail[1]){
                    case 'vnd.openxmlformats-officedocument.wordprocessingml.document':
                    $fite_detail_subtype='doc';
                    break;
                    default:
                    $fite_detail_subtype=$file_detail[1];
                }
                $file_detail_subtype="";
            ?>
            <div class="file-type-preview file-<?php echo $file_detail[0];?> file-<?php echo $fite_detail_subtype;?>"></div>
            <?php } ?>
            <div class="field-id">
                <input type="hidden" readonly class="wtefd-file-id-val"
                    name="<?php echo $field_setting_var;?>[file_downloads][wte_files_downloadable][<?php echo $key;?>][id]"
                    value="<?php echo isset($value['id']) && !empty($value['id'])?esc_attr(intval($value['id'])):''?>">
            </div>
            <div class="field-title">
                <input type="text" class="wtefd-file-title"
                    name="<?php echo $field_setting_var;?>[file_downloads][wte_files_downloadable][<?php echo $key;?>][title]"
                    value="<?php echo isset($value['title']) && !empty($value['title'])?esc_attr($value['title']):''?>">
            </div>
            <div class="field-url"><input type="hidden" readonly class="wtefd-file-url"
                    name="<?php echo $field_setting_var;?>[file_downloads][wte_files_downloadable][<?php echo $key;?>][url]"
                    value="<?php echo isset($value['url']) && !empty($value['url'])?esc_url($value['url']):''?>">
            </div>
            <div class="field-preview">
                <a class="wtefd-preview-button button button-secondary"
                    href="<?php echo isset($value['url']) && !empty($value['url'])?esc_url($value['url']):''?>"
                    target="_blank">
                    <?php _e('Preview','wte-file-downloads');?>
                </a>
            </div>
        </div>
        <div class="download-field-action-wrap">
            <a class="wtefd-change-file" href="#" data-uploader-title="<?php _e('Change File','wte-file-downloads');?>"
                data-uploader-button-text="<?php _e('Replace File','wte-file-downloads');?>"><i
                    class="fas fa-sync-alt"></i></a>
            <a class="wtefd-remove-file" href="#"><i class="fas fa-trash-alt"></i></a>
        </div>
    </div>
</li>