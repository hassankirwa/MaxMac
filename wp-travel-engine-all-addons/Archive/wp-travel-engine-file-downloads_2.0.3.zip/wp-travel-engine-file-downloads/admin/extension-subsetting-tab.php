<?php
global $globalvariables;

$field_setting_var = $globalvariables['global_setting_key'];
$options = get_option($field_setting_var, true);
$obj = new WTE_File_Downloads_Library;
?>
<div class="wp-travel-engine-fields-settings">
    <div class="wtefd-inner-wrap extension-downloads-wrap wtefd-main-wrap wpte-form-block" >
        <div id="wtefd-global-check" class="wtefd-row">
            <div class="wpte-form-block-wrap">
                <div class="wpte-form-block">
                    <div class="wpte-title-wrap">
                        <h3 class="wpte-title"><?php _e('General Settings','wte-file-downloads');?></h3>
                    </div>
                    <div class="wpte-form-content">
                        <div class="wpte-field wpte-text wpte-floated">
                            <label
                                for="<?php echo $field_setting_var;?>[file_downloads][wte_file_download_label]"
                                class="wpte-field-label"><?php _e('File Download Header Text','wte-file-downloads');?></label>
                            <input type="text" id="<?php echo $field_setting_var;?>[file_downloads][wte_file_download_label]"
                                placeholder="<?php _e('Header Text','wte-file-downloads');?>"
                                name="<?php echo $field_setting_var;?>[file_downloads][wte_file_download_label]"
                                value="<?php echo isset($options['file_downloads']['wte_file_download_label']) && !empty($options['file_downloads']['wte_file_download_label'])?esc_attr($options['file_downloads']['wte_file_download_label']):''; ?>" />
                        </div>
                        <div class="wpte-field wpte-text wpte-floated">
                            <label
                                for="<?php echo $field_setting_var;?>[file_downloads][wte_file_download_description]"
                                class="wpte-field-label"><?php _e('File Download Header Description','wte-file-downloads');?></label>
                            <textarea id="<?php echo $field_setting_var;?>[file_downloads][wte_file_download_description]"
                                placeholder="<?php _e('Header Description','wte-file-downloads');?>"
                                name="<?php echo $field_setting_var;?>[file_downloads][wte_file_download_description]"><?php echo isset($options['file_downloads']['wte_file_download_description']) && !empty($options['file_downloads']['wte_file_download_description'])?esc_attr($obj->wtefd_stripslashes_deep($options['file_downloads']['wte_file_download_description'])):''; ?></textarea>
                        </div>
                        <div id="wtefd-global-check" class="wpte-field wpte-checkbox advance-checkbox">
                            <label class="wpte-field-label" for="<?php echo $field_setting_var;?>[file_downloads][wte_file_download_global_check]"><?php _e('List Global or Trip Specific Files','wte-file-downloads');?></label>
                            <div class="wpte-checkbox-wrap">
                               <input type="checkbox"
                                id="<?php echo $field_setting_var;?>[file_downloads][wte_file_download_global_check]"
                                name="<?php echo $field_setting_var;?>[file_downloads][wte_file_download_global_check]"
                                value="1"
                                <?php echo ((isset($options['file_downloads']['wte_file_download_global_check']) && $options['file_downloads']['wte_file_download_global_check']==1) ||!isset($options['file_downloads']))?'checked="checked"':''; ?>>
                                <label for="<?php echo $field_setting_var;?>[file_downloads][wte_file_download_global_check]"></label>
                            </div>
                            <span class="wpte-tooltip"><?php _e('If checked, global files will be displayed by default if plugin cannot find trip specific files. If unchecked, only file listed in specific trip will be displayed. Else, nothing will be shown.','wte-file-downloads');?></span>
                        </div>
                        <div id="wtefd-global-check-force-global" class="wpte-field wpte-checkbox advance-checkbox">
                            <label class="wpte-field-label" for="<?php echo $field_setting_var;?>[file_downloads][wte_file_download_force_global]">
                                <?php _e('Always List Global File','wte-file-downloads');?></label>
                            <div class="wpte-checkbox-wrap">
                               <input type="checkbox"
                                id="<?php echo $field_setting_var;?>[file_downloads][wte_file_download_force_global]"
                                name="<?php echo $field_setting_var;?>[file_downloads][wte_file_download_force_global]"
                                value="1"
                                <?php echo isset($options['file_downloads']['wte_file_download_force_global']) && $options['file_downloads']['wte_file_download_force_global']==1?'checked="checked"':''; ?>>
                                <label for="<?php echo $field_setting_var;?>[file_downloads][wte_file_download_force_global]"></label>
                            </div>
                            <span class="wpte-tooltip"><?php _e('If checked, global file(s) will always be listed. Then only, trip specific file(s) will be listed. Repeated files will be ommitted.','wte-file-downloads');?></span>
                        </div>
                        <div id="wtefd-global-check-new-tab" class="wpte-field wpte-checkbox advance-checkbox">
                            <label class="wpte-field-label" for="<?php echo $field_setting_var;?>[file_downloads][wte_file_download_new_tab]"><?php _e('View File in New Tab','wte-file-downloads');?></label>
                            <div class="wpte-checkbox-wrap">
                                <input type="checkbox"
                                id="<?php echo $field_setting_var;?>[file_downloads][wte_file_download_new_tab]"
                                name="<?php echo $field_setting_var;?>[file_downloads][wte_file_download_new_tab]" value="1"
                                <?php echo isset($options['file_downloads']['wte_file_download_new_tab']) && $options['file_downloads']['wte_file_download_new_tab']==1?'checked="checked"':''; ?>>
                                <label for="<?php echo $field_setting_var;?>[file_downloads][wte_file_download_new_tab]"></label>
                            </div>
                            <span class="wpte-tooltip"><?php _e('If checked, files like image, pdf, txt will be loaded in new tab. Files like doc,docx are downloaded by default.','wte-file-downloads');?></span>
                        </div>

                        <div id="wtefd-global-check-force-download" class="wpte-field wpte-checkbox advance-checkbox">
                            <label class="wpte-field-label" for="<?php echo $field_setting_var;?>[file_downloads][wte_file_download_click_download]"><?php _e('One Click Download','wte-file-downloads');?></label>
                            <div class="wpte-checkbox-wrap">
                                <input type="checkbox"
                                id="<?php echo $field_setting_var;?>[file_downloads][wte_file_download_click_download]"
                                name="<?php echo $field_setting_var;?>[file_downloads][wte_file_download_click_download]"
                                value="1"
                                <?php echo ((isset($options['file_downloads']['wte_file_download_click_download']) && $options['file_downloads']['wte_file_download_click_download']==1)||!isset($options['file_downloads']))?'checked="checked"':''; ?>>
                                <label for="<?php echo $field_setting_var;?>[file_downloads][wte_file_download_click_download]"></label>
                            </div>
                            <span class="wpte-tooltip"><?php _e('If checked, file(s) will always be downloaded on click.','wte-file-downloads');?></span>
                        </div>
                    </div>
                </div>
                  <div class="wpte-info-block">
                    <b><?php _e('Note :','wte-file-downloads');?></b>
                    <p><b>[trip_file_downloads]</b> - <?php _e('Usable global shortcode to list and display downloadable files.', 'wte-file-downloads' ); ?></p>
                </div>
                <div id="wtefd-global-files" class="wpte-form-block">
                    <div class="wpte-title-wrap">
                        <h3 class="wpte-title"><?php _e('File Uploader','wte-file-downloads');?></h3>
                        <span class="wpte-tooltip"><?php _e('You can upload and set the global files from this setting. You can also change/add the file(s) from each individual trip page as well.','wte-file-downloads');?></span>
                    </div>
                    <div class="wpte-form-content">
                        <div class="trip-info-title-wrapper">
                            <div class="trip-info-title">
                                <h4><?php _e('File URL','wte-file-downloads');?><span class="required">*</span> <span
                                        class="tooltip"
                                        title="<?php _e('Attachment URL of Files uploaded','wte-file-downloads');?>"><i
                                            class="fas fa-question-circle"></i></span>
                                </h4>
                                <h4><?php _e('File Title','wte-file-downloads');?><span class="required"></span> <span
                                        class="tooltip"
                                        title="<?php _e('Alternate title for the file. File name are used as default.','wte-file-downloads');?>"><i
                                            class="fas fa-question-circle"></i></span></h4>
                            </div>
                        </div>
                        <ul class="wtefd-fields-wrap wtefd-files-field-coll" data-setting-title="<?php echo $field_setting_var;?>">
                        <?php
                            if (isset($options['file_downloads']['wte_files_downloadable'])) {
                                $keyArray = array();
                                $arr_keys = $options['file_downloads']['wte_files_downloadable'];
                                foreach ($arr_keys as $key => $value) {
                                    $keyArray[$key] = $key;
                                   include(WTEFD_ADMIN_DIR . 'reapeater-inner.php');
                                }
                            }
                            $max_key = (isset($keyArray) && !empty($keyArray)) ? array_keys($keyArray, max($keyArray)) : array('0' => '0');
                            ?>
                            <input type="hidden"
                            name="<?php echo $field_setting_var;?>[file_downloads][file_downloadable_max_count]"
                            value="<?php echo intval($max_key[0]);?>" class="wtefd-max-img-count" />
                            <div id="wtefd-add-remove-fields">
                                <?php
                                $other_attributes = array(
                                    'id' => 'wtfd-file-add',
                                    'data-setting-type'=>$field_setting_var,
                                    'data-text-preview'=>__('Preview','wte-file-downloads'),
                                    'data-text-replace-file'=>__('Change File','wte-file-downloads'),
                                    'data-text-remove-file'=>__('Remove','wte-file-downloads')
                                    );
                                submit_button(
                                    __('Add New File','wte-file-downloads'),
                                    '',
                                    '',
                                    true,
                                    $other_attributes);
                                ?>
                                <span class="file-dl-additional-info"><?php _e('Supports: .JPG, .PNG, .PDF, .DOC','wte-file-downloads');?></span>
                            </div>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>