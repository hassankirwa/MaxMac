<?php

defined('ABSPATH') or die('No script kiddies please!!');
if ( !class_exists('WTE_File_Downloads_Shortcode') ) {

    /**
     *  Shortcode
     */
    class WTE_File_Downloads_Shortcode extends WTE_File_Downloads_Library {

        function __construct() {
            add_shortcode('trip_file_downloads', array( $this, 'shortcode_manager' ));
            add_action('wte_trip_file_downloads_list', array($this,'wte_file_downloads_call' ));
            add_shortcode('wte_global_file_downloads', array( $this, 'global_shortcode_manager' ));
        }

        public function wte_file_downloads_call(){
            echo do_shortcode('[trip_file_downloads]');
        }

        function global_shortcode_manager($atts) {
            global $post, $globalvariables;
           
            $global_settings = get_option(esc_attr($globalvariables['global_setting_key']), true);
            $meta_settings = get_post_meta( $post->ID, esc_attr($globalvariables['meta_setting_key']), true );
            $global_files_list = isset($global_settings['file_downloads']['wte_files_downloadable'])?is_array($global_settings['file_downloads']['wte_files_downloadable']):'';
            
            ob_start();
            ?>
            <div class="file-downloadable-wrap">
            <?php 
                if(isset($global_settings['file_downloads']['wte_file_download_label'])
                && !empty($global_settings['file_downloads']['wte_file_download_label'])){
            ?>
            <div class="file downloadable-header">
                <?php echo esc_attr($global_settings['file_downloads']['wte_file_download_label']); ?>
            </div>
            <?php
                }else if (!isset($global_settings['file_downloads']) && $trip_specific_nempty_flag == 'true' && $global_nempty_flag == 'false'){
                    ?>
            <div class="file downloadable-header">
                <?php echo __('Downloadable File','wte-file-downloads'); ?>
            </div>
            <?php } ?>
            <?php 
                if(isset($global_settings['file_downloads']['wte_file_download_description'])
                && !empty($global_settings['file_downloads']['wte_file_download_description'])){
                    ?>
            <div class="file downloadable-description">
                <?php echo esc_attr(wtefd_stripslashes_deep($global_settings['file_downloads']['wte_file_download_description'])); ?>
            </div>
            <?php
                }else if (!isset($global_settings['file_downloads']) && $trip_specific_nempty_flag == 'true' && $global_nempty_flag == 'false'){
                    ?>
            <div class="file downloadable-description">
                <?php echo __('Please find downloadable files below.','wte-file-downloads'); ?>
            </div>
            <?php } ?>
                <div class="file-downloadable-list">
                <?php 
                    $this->list_file_downlodable($global_files_list);
                ?>
                </div>
            </div>
            <?php
            $file_downloadable = ob_get_contents();
            ob_end_clean();
            return $file_downloadable;
        }

        function shortcode_manager($atts) {
            global $post, $globalvariables;
            $trip_id = (isset($atts['trip_id']) && !empty($atts['trip_id'])) ? intval($atts['trip_id']) : '';
            if(isset($trip_id) && !empty($trip_id)){
                $post_id = $trip_id;
            }else{
                $post_id = $post->ID;
            }
            $global_settings = get_option(esc_attr($globalvariables['global_setting_key']), true);
            $meta_settings = get_post_meta( $post_id, esc_attr($globalvariables['meta_setting_key']), true );
            
            ob_start();
            include WTEFD_FRONT_TEMPLATE_DIR . 'shortcode.php';
            $file_downloadable = ob_get_contents();
            ob_end_clean();
            return $file_downloadable;
        }

    }

    new WTE_File_Downloads_Shortcode();
}