<?php

/**
 * WP Travel Engine File Downloads Action Class
 */
class WTE_File_Downloads_Action extends WTE_File_Downloads_Library
{

        /**
         * Class Constructor.
         */
        function __construct()
        { 
            add_action( 'save_post_trip', array($this,'wtefd_save_meta_box'));
            add_action('wpte_save_and_continue_additional_meta_data', array($this, 'wtefd_save_meta_box'));
        }
    
        /**
         * Save meta box content.
         *
         * @param int $post_id Post ID
         */
        function wtefd_save_meta_box($post_id) {
        if (!current_user_can('edit_post', $post_id)) return;
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
            if(isset($_POST['wte_file_downloads'])) {
                $obj = new Wp_Travel_Engine_Functions;
                $settings = $obj->wte_sanitize_array( $_POST['wte_file_downloads'] );
                update_post_meta($post_id, 'wte_file_downloads', $settings);
            }
    }

    function wtefd_save_downloads_global_setting() { 
        if(isset($_POST['wte_file_downloads_global']) && !empty($_POST['wte_file_downloads_global'])){
            $obj = new Wp_Travel_Engine_Functions;
            $global_values = $obj->wte_sanitize_array( $_POST['wte_file_downloads_global'] );
            if(!get_option('wte_file_downloads_global')){
                add_option('wte_file_downloads_global', $global_values);
            }else{
                update_option('wte_file_downloads_global', $global_values);
            }
        }else{
         return;
        }
    }
   
}

// Initialize Class
new WTE_File_Downloads_Action();