<?php
defined('ABSPATH') or die('No script kiddies please!!');

if ( !class_exists('WTE_File_Downloads_Enqueue') ) {

    class WTE_File_Downloads_Enqueue {

        /**
         * Enqueue all the necessary JS and CSS
         *
         * since @1.0.0
         */
        function __construct() {
            add_action('admin_enqueue_scripts', array($this, 'wtefd_register_admin_assets'));
            add_action('wp_enqueue_scripts', array($this, 'wtefd_register_front_assets'));
            add_action('wp_ajax_wtefd_add_global_file_field', array( $this, 'add_global_file_field' ));
            add_action('wp_ajax_nopriv_wtefd_add_global_file_field', array( $this, 'no_permission' ));
        }
        /**
     * Back end Scripts
     */
    function wtefd_register_admin_assets()
    {
        $asset_script_path = 'min/';
		$version_prefix    = '-' . WTEFD_VERSION;

		if ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) {
			$asset_script_path = '';
			$version_prefix    = '';
		}

        $screen = get_current_screen();
        if ($screen->post_type == 'trip' || $screen->post_type == 'booking') {
            $ajax_nonce = wp_create_nonce('eg_ajax_nonce');
                $wtefd_object_array = array(
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'ajax_nonce' => $ajax_nonce,
                    'plugin_url' => WTEFD_PLUGIN_URL
                );
            wp_enqueue_script( 'wtefd-backend-jquery', WTEFD_JS_DIR . $asset_script_path .'admin'. $version_prefix .'.js', array( 'jquery' ), WTEFD_VERSION, true );
            wp_localize_script('wtefd-backend-jquery', 'wtefd_backend_js_object', $wtefd_object_array);
            wp_enqueue_style( 'wtefd-backend-design', WTEFD_CSS_DIR . $asset_script_path .'admin'. $version_prefix .'.css', array(), WTEFD_VERSION, 'all' );
        }
    }

    /**
     * Front end Scripts
     */
    function wtefd_register_front_assets()
    {
        $asset_script_path = 'min/';
		$version_prefix    = '-' . WTEFD_VERSION;

		if ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) {
			$asset_script_path = '';
			$version_prefix    = '';
        }
        
        // wp_enqueue_script( 'wtefd-front-jquery', WTEFD_JS_DIR . $asset_script_path .'front'. $version_prefix .'.js', array( 'jquery' ), WTEFD_VERSION, true );
        wp_enqueue_style( 'wtefd-front-design', WTEFD_CSS_DIR . $asset_script_path .'front'. $version_prefix .'.css', array(), WTEFD_VERSION, 'all' );
    }
       
    function add_global_file_field(){
        $options = get_option('wp_travel_engine_settings', true);
       $file_id = intval(sanitize_text_field($_POST['file_id']));
       $file_text = sanitize_text_field($_POST['file_text']);
       $max_count = intval(sanitize_text_field($_POST['max_count']));
       if(empty($file_id)):
        __return_false();
       endif;
       include WTEFD_ADMIN_DIR . 'ajax-meta-setting.php';
       wp_die();
    }
}

    new WTE_File_Downloads_Enqueue();
}