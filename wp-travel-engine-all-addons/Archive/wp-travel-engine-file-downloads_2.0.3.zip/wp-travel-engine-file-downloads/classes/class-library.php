<?php

defined('ABSPATH') or die('No script kiddies please!!');
if ( !class_exists('WTE_File_Downloads_Library') ) {

    class WTE_File_Downloads_Library {

        /**
         * Prints array in pre format
         *
         * @since 1.0.0
         *
         * @param array $array
         */
        function print_array($array) {
            echo "<pre>";
            print_r($array);
            echo "</pre>";
        }

        /**
         * function
         * Custom Function to pull the post type singular
         * 
         * @return void
         */
        function get_current_post_type() {
	
            global $post, $typenow, $current_screen;
            
            if ($post && $post->post_type) return $post->post_type;
            
            elseif($typenow) return $typenow;
            
            elseif($current_screen && $current_screen->post_type) return $current_screen->post_type;
            
            elseif(isset($_REQUEST['post_type'])) return sanitize_key($_REQUEST['post_type']);
            
            return null;
            
        }

        function wtefd_stripslashes_deep($string)
        {
            $string = implode("", explode("\\", $string));
        return stripslashes(trim($string));
        }
            
        /**
         * function to list all the files 
         *
         * @param [type] $files_available
         * @return void
         */
        function list_file_downlodable($files_available){
            global $post, $globalvariables;
            
            $global_settings = get_option($globalvariables['global_setting_key'], true);
            $meta_settings = get_post_meta( $post->ID, $globalvariables['meta_setting_key'], true );
            if(isset($global_settings['file_downloads']['wte_file_download_new_tab']) && $global_settings['file_downloads']['wte_file_download_new_tab'] == '1'){
                $target = "target='_blank'";
            }else{
                $target='';
            }
            if((isset($global_settings['file_downloads']['wte_file_download_click_download']) 
            && $global_settings['file_downloads']['wte_file_download_click_download'] == '1') 
            || !isset($global_settings['file_downloads'])){
                $download = "download";
            }else{
                $download='';
            }

            if(!empty($files_available)){ ?>
<div class="file-downloadable-list">
    <?php
        foreach ($files_available as $key => $value) {
            ?>
    <div class="file-downloadable-list-inner">
        <?php
        $file_details = get_post_mime_type(intval($value['id']));
        if(!empty($file_details) || $file_details !== false){
            $file_detail = explode("/",$file_details);
            switch($file_detail[1]){
                case 'vnd.openxmlformats-officedocument.wordprocessingml.document':
                case 'msword':
                    $fite_detail_subtype='doc';
                    $img_src = WTEFD_IMAGE_DIR.'/doc.png';
                break;
                case 'pdf':
                    $fite_detail_subtype='pdf';
                    $img_src = WTEFD_IMAGE_DIR.'/pdf.png';
                break;
                default:
                $fite_detail_subtype=$file_detail[1];
                $img_src = WTEFD_IMAGE_DIR.'/'.$file_detail[0].'.png';
            }
            $file_detail_subtype="";
        ?>
        <span class="file-type-preview file-<?php echo $file_detail[0];?> file-<?php echo $fite_detail_subtype;?>">
            <img src="<?php echo $img_src;?>"></img></span>
        <?php } ?>
        <span class="file-downloads-file-title"><?php echo $value['title'];?></span>
        <a class="file-downloads-file-download" href=" <?php echo $value['url']; ?>" <?php echo $target;?>
            <?php echo $download;?>><?php echo __('Download','wte-file-downloads');?></a>
    </div>
    <?php } ?>
</div>
<?php
            }
        }
    }
}