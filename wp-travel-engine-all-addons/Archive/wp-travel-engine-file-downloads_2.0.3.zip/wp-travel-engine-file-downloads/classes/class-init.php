<?php

/**
 * WP Travel Engine File Downloads init class
 */
class WTE_File_Downloads_Init extends WTE_File_Downloads_Library
{

    /**
     * Class Constructor.
     */
    public function __construct()
    {
      $this->init_hooks();
      add_action('wp_travel_engine_settings_option_tabs', array($this, 'wtefd_add_extension_setting'));
      add_filter( 'wpte_get_global_extensions_tab', array($this,'wte_file_downloads_extensions_tab_call' ) );
      add_filter( 'wte_trip_file_downloads_setting_path', array($this,'wte_trip_file_downloads_setting_path' ) );
      //add_filter( 'wp_travel_engine_admin_trip_meta_tabs', array($this, 'wtefd_add_extra_services_trips') );
    }

    function wte_trip_file_downloads_setting_path(){
      return WTEFD_ADMIN_DIR . 'meta-setting-tab.php';
    }

    function wte_file_downloads_extensions_tab_call($sub_tabs){
        $sub_tabs['wte_file_downloads'] = array(
            'label'        => __( 'File Downloads', 'wte-file-downloads' ),
            'content_path' => WTEFD_ADMIN_DIR.'extension-subsetting-tab.php',
            'current' => false
        );
        return $sub_tabs;
    }

    /**
     * Init hooks For WTE_File_Downloads_Init 
     *
     * @return void
     */
    public function init_hooks()
    {
        add_action('plugins_loaded', array($this, 'wtefd_load_textdomain'));
    }
    
    /*
     * i18n
     */

    function wtefd_load_textdomain()
    {
        load_textdomain('wte-file-downloads', dirname(plugin_basename(__FILE__)) . '/i18n/languages');
    }

    /** Action hook to add setting in advanced setting tab
     * 
     */
    function wtefd_add_extension_setting($options)
    {
      $option = get_option( 'wp_travel_engine', true );
      $options = array(
        'downloads'    => WTEFD_ADMIN_DIR . 'extension-subsetting-tab.php'            
        );
        return $options;
    }
    /** 
    * Add extra setting tab by
    */
    function wtefd_add_extra_services_tab(){
    ?>
    <li>
        <a href="#trip-downloads"><?php _e('File Downloads','wte-file-downloads');?></a>
    </li>
    <?php
    }

    /**
     * Undocumented function
     *
     * @return void
     */
    function wtefd_add_extra_services_trips($trip_meta_tabs){
     
       $trip_meta_tabs['wte_file_downloads'] = 
        array(
            'tab_label'         => __( 'File Downloads', 'wte-file-downloads' ),
            'tab_heading'       => __( 'File Downloads', 'wte-file-downloads' ),
            'content_path'      => WTEFD_ADMIN_DIR . 'meta-setting-tab.php',
            'callback_function' => 'wpte_edit_trip_tab_wte_file_downloads',
            'content_key'       => 'wpte-tab wte_file_downloads',
            'current'           => false,
            'content_loaded'    => false,
            'priority'          => 100
        );
        return $trip_meta_tabs;
    }
}

// Initialize Class
new WTE_File_Downloads_Init();