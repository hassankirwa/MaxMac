! function(modules) {
    var installedModules = {};

    function __webpack_require__(moduleId) {
        if (installedModules[moduleId]) return installedModules[moduleId].exports;
        var module = installedModules[moduleId] = {
            i: moduleId,
            l: !1,
            exports: {}
        };
        return modules[moduleId].call(module.exports, module, module.exports, __webpack_require__), module.l = !0, module.exports
    }
    __webpack_require__.m = modules, __webpack_require__.c = installedModules, __webpack_require__.d = function(exports, name, getter) {
        __webpack_require__.o(exports, name) || Object.defineProperty(exports, name, {
            configurable: !1,
            enumerable: !0,
            get: getter
        })
    }, __webpack_require__.n = function(module) {
        var getter = module && module.__esModule ? function() {
            return module.default
        } : function() {
            return module
        };
        return __webpack_require__.d(getter, "a", getter), getter
    }, __webpack_require__.o = function(object, property) {
        return Object.prototype.hasOwnProperty.call(object, property)
    }, __webpack_require__.p = "/assets/", __webpack_require__(__webpack_require__.s = 1628)
}({
    1628: function(module, exports) {
        var _createClass = function() {
            function defineProperties(target, props) {
                for (var i = 0; i < props.length; i++) {
                    var descriptor = props[i];
                    descriptor.enumerable = descriptor.enumerable || !1, descriptor.configurable = !0, "value" in descriptor && (descriptor.writable = !0), Object.defineProperty(target, descriptor.key, descriptor)
                }
            }
            return function(Constructor, protoProps, staticProps) {
                return protoProps && defineProperties(Constructor.prototype, protoProps), staticProps && defineProperties(Constructor, staticProps), Constructor
            }
        }();
        new(function() {
            function EmbedCheckout() {
                ! function(instance, Constructor) {
                    if (!(instance instanceof Constructor)) throw new TypeError("Cannot call a class as a function")
                }(this, EmbedCheckout), this.iframes = [], this.defaultStyle = {}, this.style = {};
                var _this = this;
                document.addEventListener("DOMContentLoaded", function(event) {
                    setTimeout(function() {
                        _this.defaultStyle = document.body.getAttribute("style"), _this.addButtonListener(), _this.waitForClose()
                    }, 0)
                })
            }
            return _createClass(EmbedCheckout, [{
                key: "lockBody",
                value: function() {
                    document.body.style.overflow = "hidden", document.body.style.height = "auto"
                }
            }, {
                key: "unlockBody",
                value: function() {
                    document.body.setAttribute("style", this.defaultStyle)
                }
            }, {
                key: "addButtonListener",
                value: function() {
                    var _this2 = this,
                        divs = document.querySelectorAll(".wtrvl-checkout_button");
                    [].forEach.call(divs, function(element) {
                        jQuery(document).on("click", '.wtrvl-checkout_button', function(event) {
                            if (event.preventDefault(), !document.querySelector('iframe[class="wtrvl-ifrm"]') && event.target.classList.contains("wtrvl-checkout_button")) {
                                var iframe = _this2.createIframe(event.target.getAttribute("href")),
                                    style = document.createElement("style");
                                style.innerHTML = "body > *:not(.wtrvl-ifrm){display:none}", window && window.innerWidth <= 991 && document.body.appendChild(style), document.body.appendChild(iframe), _this2.iframes.push(iframe), _this2.style = style, _this2.lockBody()
                            }
                        })
                    })
                }
            }, {
                key: "waitForClose",
                value: function() {
                    var _this3 = this,
                        eventMethod = window.addEventListener ? "addEventListener" : "attachEvent";
                    (0, window[eventMethod])("attachEvent" === eventMethod ? "onmessage" : "message", function(e) {
                        if ("wtrvlCheckoutClosed" === e.data && _this3.closeIframes(), "fileUpload" === e.data) {
                            var iframe = document.querySelector(".wtrvl-ifrm");
                            iframe && (iframe.style.height = "100%")
                        }
                    })
                }
            }, {
                key: "closeIframes",
                value: function() {
                    var _this4 = this;
                    this.iframes.map(function(iframe) {
                        iframe.remove ? iframe.remove() : iframe.parentNode && iframe.parentNode.removeChild(iframe), _this4.style.parentNode && _this4.style.parentNode.removeChild(_this4.style), _this4.unlockBody()
                    })
                }
            }, {
                key: "createIframe",
                value: function(src) {
                    var ifrm = document.createElement("iframe");
                    return ifrm.setAttribute("style", "position:fixed;width: 100vw; height:100vh;top:0;left:0;bottom:0;right:0;z-index:21150313555"), ifrm.setAttribute("frameborder", "0"), ifrm.setAttribute("src", src), ifrm.setAttribute("class", "wtrvl-ifrm"), ifrm
                }
            }]), EmbedCheckout
        }())
    }
});