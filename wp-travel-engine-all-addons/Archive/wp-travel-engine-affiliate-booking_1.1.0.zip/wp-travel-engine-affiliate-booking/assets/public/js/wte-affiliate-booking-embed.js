jQuery(function ($) {
    function wte_affiliate_booking_update_fsd_btns() {

        $('.fixed-starting.dates .dd-list.outer td.accordion-book button').each(function (e) {

            var $this = $(this);


            $(this).attr('href', wte_affiliate_booking.btn_url).html(wte_affiliate_booking.btn_label).attr('class', wte_affiliate_booking.btn_class);

            if (0 == wte_affiliate_booking.is_wetravel) {
                $(this).attr('target', '_blank').attr('rel', 'nofollow');
            }

        });

    }

    if ($('.fixed-starting.dates .dd-list.outer').length > 0) {
        // wte_affiliate_booking_update_fsd_btns();
    }


    $(document).ajaxSuccess(function (e, request, settings) {
        var settingsobj = $.deparam(settings.data);

        if ('filter_departure_dates' === settingsobj.action) {
            // wte_affiliate_booking_update_fsd_btns();
        }
    });

    // New Implementation.
    var bookingBtns = document.querySelectorAll('#open-booking-modal, .wte-fsd-list-booknow-btn')
    if (bookingBtns[0] && window['wte_affiliate_booking']) {

        bookingBtns.forEach(function (btn) {
            var parentEl = btn.parentNode;
            var button_html = window.wte_affiliate_booking.button_html
            if (!!button_html) {
                btn.style.display = 'none';
                parentEl.insertAdjacentHTML('beforeend', button_html);
                var newButton = parentEl.querySelector('.wtrvl-checkout_button')
                newButton && newButton.classList.add('wpte-bf-btn')
            }
        })
    }

});
