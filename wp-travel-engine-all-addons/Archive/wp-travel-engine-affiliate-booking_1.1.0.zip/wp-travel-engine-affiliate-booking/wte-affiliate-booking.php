<?php
/**
 * Plugin Name: WP Travel Engine - WeTravel
 * Plugin URI: https://wptravelengine.com
 * Description: WP Travel Engine addon to support WeTravel or Custom URL Booking.
 * Version: 1.1.0
 * Author: WP Travel Engine
 * Author URI: https://wptravelengine.com
 * License: GPL2
 * Text Domain: wptravelengine-we-travel
 * Domain Path: languages
 * WTE: 125432:wte_affiliate_booking_license_key
 */

/*
Copyright 2019 WP Travel Engine,

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2, as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
define( 'WTE_AFFILIATE_BOOKING_REQUIRES_AT_LEAST', '5.4' );

/**
 * Main plugin instantiation class.
 *
 * @since 1.0.0
 */
class WTE_Affiliate_Booking {

	/**
	 * Track instance of the WTE_Affiliate_Booking class.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	private static $instance = null;

	/**
	 * Tracks current plugin version throughout codebase.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	public $version = '1.1.0';

	/**
	 * Main WTE_Affiliate_Booking Instance
	 *
	 * Ensures only one instance of WTE_Affiliate_Booking is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 *
	 * @return WTE_Affiliate_Booking - Main instance
	 */
	public static function instance() {
		if ( ! isset( self::$instance ) && ! ( self::$instance instanceof WTE_Affiliate_Booking ) ) {
			self::$instance = new WTE_Affiliate_Booking();
			self::$instance->i18n();
			self::$instance->includes();

			new WTE_Affiliate_Booking_Metabox();
			new WTE_Affiliate_Booking_Display();
		}

		return self::$instance;
	}

	/**
	 * Fire up the engines.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		// Define plugin constants
		$this->plugin_file    = __FILE__;
		$this->basename       = plugin_basename( $this->plugin_file );
		$this->directory_path = plugin_dir_path( $this->plugin_file );
		$this->directory_url  = plugin_dir_url( $this->plugin_file );

		define( 'WTE_AFFILIATE_BOOKING_URL', rtrim( plugin_dir_url( __FILE__ ), '/' ) );
		define( 'WTE_AFFILIATE_BOOKING_VERSION', $this->version );
		define( 'WTE_AFFILIATE_BOOKING_FILE_PATH', __FILE__ );
		define( 'WTE_AFFILIATE_BOOKING_BASE_PATH', dirname( __FILE__ ) );

		// Handle plugin activation and deactivation
		register_activation_hook( $this->plugin_file, array( $this, 'activation' ) );
		register_deactivation_hook( $this->plugin_file, array( $this, 'deactivation' ) );

		// Basic setup
		add_action( 'wp_enqueue_scripts', array( $this, 'load_scripts' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'load_admin_scripts' ) );
		add_action( 'admin_notices', array( $this, 'maybe_disable_plugin' ) );

		add_filter(
			'wpte_get_global_extensions_tab',
			function( $global_tabs ) {
				$global_tabs['wte_wetravel'] = array(
					'label'        => __( 'WeTravel', 'wptravelengine-we-travel' ),
					'content_path' => plugin_dir_path( __FILE__ ) . 'includes/views/admin-settings.php',
					'current'      => true,
				);
				return $global_tabs;
			},
			20
		);

		add_action(
			'wpte_after_save_global_settings_data',
			function( $posted_data ) {
				$wetravel_settings = get_option( 'wte_wetravel_settings', array() );
				if ( isset( $posted_data['wte_affiliate_booking'] ) ) {
					if ( isset( $posted_data['wte_affiliate_booking']['book_now_label'] ) ) {
						$wetravel_settings['book_now_label'] = $posted_data['wte_affiliate_booking']['book_now_label'];
					}
				}
				update_option( 'wte_wetravel_settings', $wetravel_settings );
			}
		);

	}

	/**
	 * Plugin activation hook.
	 *
	 * @since  1.0.0
	 */
	public function activation() {

	}

	/**
	 * Plugin deactivation hook.
	 *
	 * @since  1.0.0
	 */
	public function deactivation() {

	}

	/**
	 * Load localization.
	 *
	 * @since 1.0.0
	 */
	public function i18n() {
		load_plugin_textdomain( 'wp-travel-integration', false, $this->directory_path . '/i18n/languages/' );
	}

	/**
	 * Include file dependencies.
	 *
	 * @since 1.0.0
	 */
	public function includes() {
		require_once $this->directory_path . 'includes/class-wte-affiliate-booking-metabox.php';
		require_once $this->directory_path . 'includes/class-wte-affiliate-booking-display.php';
		require_once $this->directory_path . 'updater/updater.php';
	}

	/**
	 * Register frontend CSS and JS files.
	 *
	 * @since 1.0.0
	 */
	public function load_scripts() {

		if ( is_singular( 'trip' ) ) {

			global $post;

			$affiliate_booking = get_post_meta( $post->ID, 'wte_affiliate_booking', true );

			$label      = __( 'Book Now', 'wptravelengine-we-travel' );
			$embed_code = '';
			$url        = '';

			$wetravel_settings = get_option( 'wte_wetravel_settings', array() );

			is_array( $affiliate_booking ) && extract( $affiliate_booking ); // phpcs:ignore WordPress.PHP.DontExtract.extract_extract

			$label = isset( $wetravel_settings['book_now_label'] ) ? $wetravel_settings['book_now_label'] : __( 'Book Now', 'wptravelengine-we-travel' );

			if ( ! empty( $url ) && preg_match( '/wetravel/', $url ) ) {

				preg_match( '/uuid=(\d+)$/', $url, $matches );

				$uuid = 0;
				if ( isset( $matches[1] ) ) {
					$uuid = $matches[1];
				}

				if ( ! $uuid ) {
					return;
				}

				$embed_code = "<button class='wtrvl-checkout_button'
				id='wetravel_button_widget'
				data-env='https://www.wetravel.com'
				data-version='v0.3'
				data-uuid='{$uuid}'
				href='https://www.wetravel.com/checkout_embed?uuid={$uuid}'>{{button_label}}</button><script src='https://cdn.wetravel.com/widgets/embed_checkout.js'></script>";

				$embed_code = str_replace( '{{button_label}}', $label, $embed_code );

				wp_register_script( 'wte-affiliate-booking-embed-js', $this->directory_url . 'assets/public/js/wte-affiliate-booking-embed.js', array( 'jquery' ), WTE_AFFILIATE_BOOKING_VERSION, false );
				wp_localize_script(
					'wte-affiliate-booking-embed-js',
					'wte_affiliate_booking',
					array(
						'btn_class'   => 'wte-affiliate-booking-btn',
						'btn_label'   => esc_html( $label ),
						'btn_url'     => esc_url( $url ),
						'button_html' => $embed_code,
					)
				);
				wp_enqueue_script( 'wte-affiliate-booking-embed-js' );

				wp_register_script( 'wetravel-embed-checkout', 'https://cdn.wetravel.com/widgets/embed_checkout.js', array( 'wte-affiliate-booking-embed-js' ), '0.3', true );

				wp_enqueue_script( 'wetravel-embed-checkout' );

			}
		}
	}

	/**
	 * Register backend CSS and JS files.
	 *
	 * @since 1.0.0
	 */
	public function load_admin_scripts() {

	}

	/**
	 * Output error message and disable plugin if requirements are not met.
	 *
	 * This fires on admin_notices.
	 *
	 * @since 1.0.0
	 */
	public function maybe_disable_plugin() {

		if ( ! $this->meets_requirements() ) {

			// Display our error
			echo '<div id="message" class="error">';
			echo '<p>' . sprintf( __( '<strong>WP Travel Engine - WeTravel</strong> addon requires WP Travel Engine plugin <strong>v.2.2.8 or later</strong> and has been <a href="%s">deactivated</a>. Please install, activate, or update WP Travel Engine plugin and then reactivate this plugin.', 'wptravelengine-we-travel' ), admin_url( 'plugins.php' ) ) . '</p>';
			echo '</div>';

			// Deactivate our plugin
			deactivate_plugins( $this->basename );
		}
	}

	/**
	 * Check if all plugin requirements are met.
	 *
	 * @since 1.0.0
	 *
	 * @return bool True if requirements are met, otherwise false.
	 */
	private function meets_requirements() {
		return ( class_exists( 'WP_Travel_Engine' ) && defined( 'WP_TRAVEL_ENGINE_VERSION' ) && version_compare( WP_TRAVEL_ENGINE_VERSION, '2.2.8', '>=' ) );
	}

}

/**
 * Returns the main instance of WTE_Affiliate_Booking.
 *
 * @since  1.0.0
 * @return WTE_Affiliate_Booking
 */
function wte_affiliate_booking() {

	$meet_requirements = defined( 'WP_TRAVEL_ENGINE_VERSION' ) && version_compare( '5.4.0', WTE_AFFILIATE_BOOKING_REQUIRES_AT_LEAST, '>=' );

	/**
	 * Load plugin updater file
	 */
	if ( ! $meet_requirements ) {
		add_action(
			'admin_notices',
			function() {
				echo wp_kses(
					sprintf(
						'<div class="wte-admin-notice error"><p>%1$s</p></div>',
						sprintf( __( 'The %1$s requires at least WP Travel Engine %2$s. the plugin is currently NOT RUNNING.', 'wptravelengine-we-travel' ), '<b>WP Travel Engine - WeTravel</b>', '<code>' . WTE_AFFILIATE_BOOKING_REQUIRES_AT_LEAST . '</code>' )
					),
					array(
						'div'  => array( 'class' => array() ),
						'p'    => array(),
						'b'    => array(),
						'code' => array(),
					)
				);
			}
		);
	} else {
		/**
		 * The core plugin class that is used to define internationalization,
		 * admin-specific hooks, and public-facing site hooks.
		 */
		return WTE_Affiliate_Booking::instance();
	}

}
add_action( 'plugins_loaded', 'wte_affiliate_booking', 10 );
