<?php
/**
 * Template for displaying Affiliate Booking URL in the metabox of
 * trip post type.
 *
 * @since 1.0.0
 */
?>
<div class="wte-affiliate-booking-meta-holder">
	<div class="wpte-block-content">
		<div class="wpte-field wpte-wetravel-embed wpte-floated">
			<label for="wte_affiliate_booking[url]" class="wpte-field-label"><?php echo __( 'WeTravel Embed Link', 'wptravelengine-we-travel' ); ?></label>
			<input type="text" id="wte_affiliate_booking[url]" name="wte_affiliate_booking[url]" value="<?php echo esc_attr( $url ); ?>" placeholder="<?php echo esc_url( 'https://www.wetravel.com/checkout_embed?uuid=123456789' ); ?>">
			<span class="wpte-tooltip"><?php echo esc_html( 'Enter WeTravel Embed Link' ); ?></span>
		</div>
	</div>
	<?php wp_nonce_field( 'wte_affiliate_booking_save_data_action', 'wte_affiliate_booking_save_data' ); ?>
</div>
<?php
