<?php
/**
 * Functionality for viewing Affiliate Booking Settings.
 *
 * @package WTE Affiliate Booking
 * @author  WP Travel Engine
 * @license GPL2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WTE_Affiliate_Booking_Display {

	/**
	 * Fire up the engines.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {

		add_filter( 'wp_travel_engine_booking_process_btn_html', array( $this, 'render_affiliate_booking_details' ) );

	}

	/**
	 * Render Affiliate Booking Details to the trip post type.
	 *
	 * @since 1.0.0
	 */
	public function render_affiliate_booking_details( $data ) {

		ob_start();

		global $post;

		$affiliate_booking = get_post_meta( $post->ID, 'wte_affiliate_booking', true );

		$label = isset( $affiliate_booking['label'] ) && ! empty( $affiliate_booking['label'] ) ? $affiliate_booking['label'] : __( 'Book Now', 'wptravelengine-we-travel' );
		$url   = isset( $affiliate_booking['url'] ) ? $affiliate_booking['url'] : '';

		if ( isset( $url ) && $url != '' ) {

			$is_wetravel = preg_match( '/wetravel/', $url );
			$add_class   = $is_wetravel ? 'wtrvl-checkout_button' : '';

			if ( $is_wetravel ) {
				?>
					<button href="<?php echo esc_url( $url ); ?>" class="wte-aff-book-btn-main <?php echo esc_attr( $add_class ); ?>"><?php echo esc_html( $label ); ?></button>
				<?php
			} else {
				?>
					<a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="nofollow" class="wte-aff-book-btn-main"><?php echo esc_html( $label ); ?></a>
				<?php
			}
		} else {
			return $data;
		}

		$data = ob_get_clean();

		return $data;
	}

}
