<?php
/**
 * Global Settings for WTE - WeTravel
 *
 * @package  WTE_WeTravel
 */
$wetravel_settings = get_option( 'wte_wetravel_settings', array() );
$label             = isset( $wetravel_settings['book_now_label'] ) ? $wetravel_settings['book_now_label'] : __( 'Book Now', 'wptravelengine-we-travel' );
?>
<div class="wpte-field wpte-text wpte-floated">
	<label for="wte_affiliate_booking[book_now_label]" class="wpte-field-label"><?php _e( 'Book Now Label', 'wptravelengine-we-travel' ); ?></label>
	<input type="text" id="wte_affiliate_booking[book_now_label]" name="wte_affiliate_booking[book_now_label]" value="<?php echo esc_attr( $label ); ?>">
	<span class="wpte-tooltip"><?php _e( 'Label for Book Now button.', 'wptravelengine-we-travel' ); ?></span>
</div>
