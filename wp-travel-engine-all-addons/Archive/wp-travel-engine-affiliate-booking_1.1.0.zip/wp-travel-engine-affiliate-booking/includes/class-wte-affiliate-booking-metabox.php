<?php
/**
 * Add Affiliate Booking Settings metabox.
 *
 * @package WTE Affiliate Booking
 * @author  WP Travel Engine
 * @license GPL2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WTE_Affiliate_Booking_Metabox {

	/**
	 * Fire up the engines.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		// Add metabox.
		add_action( 'add_meta_boxes', array( $this, 'add_affiliate_booking_metabox' ) );
		add_action( 'save_post_trip', array( $this, 'save_affiliate_booking_details' ) );
		// add_filter( '' );
	}

	/**
	 * Add Affiliate Booking Settings metabox to the trip post type.
	 *
	 * @since 1.0.0
	 */
	public function add_affiliate_booking_metabox() {
		add_meta_box(
			'wte_affilaite_booking_metabox',
			__( 'WeTravel Settings', 'wptravelengine-we-travel' ),
			array( $this, 'display_affiliate_booking_metabox' ),
			'trip',
			'normal',
			'high'
		);
	}


	/**
	 * Display Affiliate Booking Settings in trip backend.
	 *
	 * @since 1.0.0
	 */
	public function display_affiliate_booking_metabox() {
		global $post;
		$affiliate_booking = get_post_meta( $post->ID, 'wte_affiliate_booking', true );

		$label      = isset( $affiliate_booking['label'] ) ? $affiliate_booking['label'] : '';
		$url        = isset( $affiliate_booking['url'] ) ? $affiliate_booking['url'] : '';
		$embed_code = isset( $affiliate_booking['embed_code'] ) ? $affiliate_booking['embed_code'] : '';
		$embed_code = isset( $affiliate_booking['embed_code'] ) ? $affiliate_booking['embed_code'] : '';

		require_once WTE_AFFILIATE_BOOKING_BASE_PATH . '/includes/wte-affiliate-booking-template.php';
	}

	/**
	 * Save Affiliate Booking Settings metabox data.
	 *
	 * @since 1.0.0
	 */
	public function save_affiliate_booking_details( $post ) {

		if ( ! isset( $_POST['wte_affiliate_booking_save_data'] ) || ! wp_verify_nonce( $_POST['wte_affiliate_booking_save_data'], 'wte_affiliate_booking_save_data_action' ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post ) ) {
			return $post;
		}

		if ( empty( $_POST['wte_affiliate_booking'] ) ) {
			return $post;
		}

		$sanitized_data = $this->sanitize_affiliate_booking_fields( $_POST['wte_affiliate_booking'] );

		update_post_meta( $post, 'wte_affiliate_booking', $sanitized_data );

		return false;
	}

	/**
	 * Sanitize Affiliate Booking Settings
	 */
	public function sanitize_affiliate_booking_fields( $data = array() ) {

		if ( isset( $data['label'] ) && ! empty( $data['label'] ) ) :

			$data['label'] = sanitize_text_field( $data['label'] );

		endif;

		if ( isset( $data['url'] ) && ! empty( $data['url'] ) ) :

			$data['url'] = esc_url_raw( $data['url'] );

		endif;

		if ( ! empty( $data['embed_code'] ) ) :
			$data['embed_code'] = wp_kses(
				$data['embed_code'],
				array(
					'button' => array(
						'class'        => array(),
						'id'           => array(),
						'data-env'     => array(),
						'data-uid'     => array(),
						'data-uuid'    => array(),
						'data-version' => array(),
						'href'         => array(),
					),
				)
			);

		endif;

		return $data;
	}
}
