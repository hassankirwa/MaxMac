=== WP Travel Engine - WeTravel ===
Contributors: wptravelengine
Plugin link: https://wptravelengine.com/
Tags: affiliate-booking, custom-booking, travel, travel-booking, travel-agency
Requires at least: 4.9
Tested up to: 6.1
Requires PHP: 5.6
WTE requires at least: 5.3+
WTE Tested up to: 5.5+
Stable tag: 1.1.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

WP Travel Engine addon to support WeTravel or Custom URL Booking.

== Description ==

Affiliate Booking requires WP Travel Engine plugin v5.0+ or later installed and activated in the site.

== Changelog ==

= 1.1.0 =
Released on: 7th Dec, 2022

* Enhancement: Adds Support for WP Travel Engine 5.0+
* Minor Issue Fixes

= 1.0.0 =

Released on: 12th December, 2019

* Initial Release
